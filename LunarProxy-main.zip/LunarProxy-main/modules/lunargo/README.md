# lunargo (android)

Native Expo module hosting the Lunar Proxy Go core for the LunarProxy-android
reconstruction.

## Layout

| Path | Role |
|------|------|
| `android/build.gradle` | `:lunargo` library; consumes `expo-modules-core` and the gomobile bind AAR `lunar.aar` via flatDir |
| `android/src/main/AndroidManifest.xml` | `expo.modules.lunargo.ForegroundService` declaration + permissions |
| `android/src/main/java/expo/modules/lunargo/LunargoModule.kt` | `Lunargo` module definition: 38 async functions, `OnCreate` core init, log pump |
| `android/src/main/java/expo/modules/lunargo/LunarCoreHolder.kt` | single `lunar.App` / module holder shared with `ForegroundService` |
| `android/src/main/java/expo/modules/lunargo/ForegroundService.kt` | proxy-session foreground service (notification + `app.start`) |

## Building the gomobile AAR

The `lunar.*` bind classes come from the Go core in `../..` (repo root). Produce
the AAR and place it where the module's flatDir repository looks for it:

```powershell
cd ..\..          # repo root with go.mod
$env:ANDROID_HOME = <sdk path>
gomobile bind -target=android -o build\outputs\aar\lunar.aar .
```

`build.gradle` resolves it from `build/outputs/aar` (flatDir), and the app
plugin `app/plugins/lunargo-flatdir.js` wires `:lunargo` into the Expo prebuild
the same way.

## Module API

All functions are promises except `setPaused` (fire-and-forget, maps to
`app.setEjected`). Errors reject with a `LunargoErrorCode` (e.g.
`AuthenticationError`, `PingError`, `RealmsError`, `SkinError`). Events:
`lunar_log_event` (`{log}`), `lunar_connection_event` (`{status}`,
`{status,error}`).

See `RECONSTRUCTION.md` for the per-function decompiled mapping table.