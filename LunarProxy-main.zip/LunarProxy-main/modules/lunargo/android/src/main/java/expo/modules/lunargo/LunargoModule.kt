package expo.modules.lunargo

import expo.modules.kotlin.Promise
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import kotlin.concurrent.thread

class LunargoModule : Module() {

    private var logPumpRunning = false
    private var logPumpThread: Thread? = null

    override fun definition() = ModuleDefinition {
        Name("Lunargo")
        Events("lunar_log_event", "lunar_connection_event")

        OnCreate {
            val reactContext = appContext.reactContext
                ?: throw IllegalStateException("React context is not available")
            val app = Lunar.new_(reactContext.filesDir.absolutePath, false)
            LunarCoreHolder.register(app, this@LunargoModule)
            startLogPump()
        }

        AsyncFunction("startProxy") { serverAddress: String, entitlementToken: String, promise: Promise ->
            val context = appContext.reactContext
                ?: throw IllegalStateException("React context is not available")
            ForegroundService.start(context, serverAddress, entitlementToken)
            promise.resolve(null)
        }

        AsyncFunction("stopProxy") { promise: Promise ->
            val context = appContext.reactContext
                ?: throw IllegalStateException("React context is not available")
            ForegroundService.stop(context)
            promise.resolve(null)
        }

        AsyncFunction("setProxyAddress") { address: String, subtitle: String, promise: Promise ->
            LunarCoreHolder.app.setProxyAddress(address, subtitle)
            promise.resolve(null)
        }

        AsyncFunction("setUserID") { userID: String, promise: Promise ->
            LunarCoreHolder.app.setUserID(userID)
            promise.resolve(null)
        }

        AsyncFunction("loadCachedAuth") { promise: Promise ->
            try {
                LunarCoreHolder.app.loadCachedAuth()
                promise.resolve(null)
            } catch (e: Exception) {
                promise.reject("AuthenticationError", e.message, e)
            }
        }

        AsyncFunction("authenticate") { interactive: Boolean, promise: Promise ->
            thread {
                try {
                    LunarCoreHolder.app.authenticate(interactive)
                    promise.resolve(null)
                } catch (e: Exception) {
                    promise.reject("AuthenticationError", e.message, e)
                }
            }
        }

        AsyncFunction("cancelAuthenticate") { promise: Promise ->
            LunarCoreHolder.app.cancelAuthentication()
            promise.resolve(null)
        }

        AsyncFunction("logout") { promise: Promise ->
            LunarCoreHolder.app.logout()
            promise.resolve(null)
        }

        AsyncFunction("spoofDevice") { promise: Promise ->
            LunarCoreHolder.app.spoofDevice()
            promise.resolve(null)
        }

        AsyncFunction("terminate") { promise: Promise ->
            try {
                LunarCoreHolder.app.terminate()
                promise.resolve(null)
            } catch (e: Exception) {
                promise.reject("TerminateError", e.message, e)
            }
        }

        AsyncFunction("readLog") { promise: Promise ->
            promise.resolve(LunarCoreHolder.app.readLog())
        }

        AsyncFunction("getProxyInfo") { promise: Promise ->
            try {
                val info = LunarCoreHolder.app.proxyingInfo()
                promise.resolve(
                    mapOf(
                        "localAddress" to info.localAddress,
                        "remoteAddress" to info.remoteAddress,
                    )
                )
            } catch (e: Exception) {
                promise.reject("ProxyInfoError", e.message, e)
            }
        }

        AsyncFunction("getVersionInfo") { promise: Promise ->
            try {
                val info = LunarCoreHolder.app.versionInfo()
                promise.resolve(
                    mapOf(
                        "currentVersion" to info.currentVersion,
                        "currentProtocol" to info.currentProtocol,
                    )
                )
            } catch (e: Exception) {
                promise.reject("VersionInfoError", e.message, e)
            }
        }

        AsyncFunction("setPaused") { paused: Boolean ->
            LunarCoreHolder.app.setEjected(paused)
        }

        AsyncFunction("getDeviceOS") { promise: Promise ->
            promise.resolve(LunarCoreHolder.app.deviceOS())
        }

        AsyncFunction("setDeviceOS") { deviceOS: String, promise: Promise ->
            LunarCoreHolder.app.setDeviceOS(deviceOS)
            promise.resolve(null)
        }

        AsyncFunction("getToken") { promise: Promise ->
            promise.resolve(LunarCoreHolder.app.token())
        }

        AsyncFunction("getCustomServers") { promise: Promise ->
            promise.resolve(LunarCoreHolder.app.customServers())
        }

        AsyncFunction("pingServers") { serversJSON: String, promise: Promise ->
            try {
                promise.resolve(LunarCoreHolder.app.pingServers(serversJSON))
            } catch (e: Exception) {
                promise.reject("PingError", e.message, e)
            }
        }

        AsyncFunction("saveSettings") { promise: Promise ->
            LunarCoreHolder.app.saveSettings()
            promise.resolve(null)
        }

        AsyncFunction("setCustomServers") { serversJSON: String, promise: Promise ->
            LunarCoreHolder.app.setCustomServers(serversJSON)
            promise.resolve(null)
        }

        AsyncFunction("getRealms") { promise: Promise ->
            try {
                promise.resolve(LunarCoreHolder.app.realmsJSON())
            } catch (e: Exception) {
                promise.reject("RealmsError", e.message, e)
            }
        }

        AsyncFunction("requestRealms") { promise: Promise ->
            try {
                promise.resolve(LunarCoreHolder.app.requestRealmsJSON())
            } catch (e: Exception) {
                promise.reject("RealmsError", e.message, e)
            }
        }

        AsyncFunction("getFriends") { promise: Promise ->
            try {
                promise.resolve(LunarCoreHolder.app.friendsJSON())
            } catch (e: Exception) {
                promise.reject("FriendsError", e.message, e)
            }
        }

        AsyncFunction("requestFriends") { promise: Promise ->
            try {
                promise.resolve(LunarCoreHolder.app.requestFriendsJSON())
            } catch (e: Exception) {
                promise.reject("FriendsError", e.message, e)
            }
        }

        AsyncFunction("setResourcePackPaths") { pathsJSON: String, promise: Promise ->
            try {
                LunarCoreHolder.app.setResourcePackPaths(pathsJSON)
                promise.resolve(null)
            } catch (e: Exception) {
                promise.reject("ResourcePackError", e.message, e)
            }
        }

        AsyncFunction("loadSkinFromLocalFiles") { geometryPath: String, texturePath: String, capePath: String, promise: Promise ->
            try {
                LunarCoreHolder.app.loadSkinFromLocalFiles(geometryPath, texturePath, capePath)
                promise.resolve(null)
            } catch (e: Exception) {
                promise.reject("SkinError", e.message, e)
            }
        }

        AsyncFunction("setSkinArmSize") { armSize: String, promise: Promise ->
            try {
                LunarCoreHolder.app.setSkinArmSize(armSize)
                promise.resolve(null)
            } catch (e: Exception) {
                promise.reject("SkinError", e.message, e)
            }
        }

        AsyncFunction("clearSkin") { promise: Promise ->
            try {
                LunarCoreHolder.app.clearSkin()
                promise.resolve(null)
            } catch (e: Exception) {
                promise.reject("SkinError", e.message, e)
            }
        }

        AsyncFunction("getSkinData") { promise: Promise ->
            promise.resolve(LunarCoreHolder.app.skinData())
        }

        AsyncFunction("getResourcePackPaths") { promise: Promise ->
            promise.resolve(LunarCoreHolder.app.resourcePackPaths())
        }

        AsyncFunction("getRecentServers") { promise: Promise ->
            promise.resolve(LunarCoreHolder.app.recentServers())
        }

        AsyncFunction("setRecentServers") { serversJSON: String, promise: Promise ->
            LunarCoreHolder.app.setRecentServers(serversJSON)
            promise.resolve(null)
        }

        AsyncFunction("resolveRealm") { code: String, promise: Promise ->
            try {
                promise.resolve(LunarCoreHolder.app.resolveRealm(code))
            } catch (e: Exception) {
                promise.reject("RealmError", e.message, e)
            }
        }

        AsyncFunction("listAccounts") { promise: Promise ->
            promise.resolve(LunarCoreHolder.app.listAccountsJSON())
        }

        AsyncFunction("getCurrentAccountID") { promise: Promise ->
            promise.resolve(LunarCoreHolder.app.getCurrentAccountID())
        }

        AsyncFunction("switchAccount") { accountId: String, promise: Promise ->
            try {
                LunarCoreHolder.app.switchAccount(accountId)
                promise.resolve(null)
            } catch (e: Exception) {
                promise.reject("SwitchAccountError", e.message, e)
            }
        }

        AsyncFunction("deleteAccount") { accountId: String, promise: Promise ->
            try {
                LunarCoreHolder.app.deleteAccountByID(accountId)
                promise.resolve(null)
            } catch (e: Exception) {
                promise.reject("DeleteAccountError", e.message, e)
            }
        }
    }

    private fun startLogPump() {
        if (logPumpRunning) {
            return
        }
        logPumpRunning = true
        logPumpThread = thread(name = "lunargo-log-pump") { logPumpLoop() }
    }

    private fun logPumpLoop() {
        var log = ""
        while (logPumpRunning && !Thread.currentThread().isInterrupted) {
            try {
                try {
                    log = LunarCoreHolder.app.readLogWait()
                } catch (e: Exception) {
                    Thread.sleep(100)
                }
                if (!logPumpRunning || Thread.currentThread().isInterrupted) {
                    break
                }
                if (log.isNotEmpty()) {
                    sendEvent("lunar_log_event", mapOf("log" to log))
                }
            } catch (e: InterruptedException) {
            }
        }
    }
}