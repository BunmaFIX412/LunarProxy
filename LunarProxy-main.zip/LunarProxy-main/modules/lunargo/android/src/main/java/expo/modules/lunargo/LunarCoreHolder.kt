package expo.modules.lunargo

import lunar.App

object LunarCoreHolder {

    private var appRef: App? = null
    private var moduleRef: LunargoModule? = null

    val app: App
        get() = checkNotNull(appRef) { "lunar" }

    val module: LunargoModule
        get() = checkNotNull(moduleRef) { "eventEmitter" }

    fun register(app: App, module: LunargoModule) {
        appRef = app
        moduleRef = module
    }
}