package expo.modules.lunargo

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import kotlin.concurrent.thread

class ForegroundService : Service() {

    private val channelID = "lunar_foreground"
    private val channelName = "Lunar Foreground Service Channel"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val serverAddress = intent?.getStringExtra(EXTRA_SERVER_ADDRESS)
        if (serverAddress == null || intent?.action == ACTION.STOP.name) {
            shutdown()
            return 0
        }
        val entitlementToken = intent?.getStringExtra(EXTRA_ENTITLEMENT_TOKEN) ?: ""
        val iconResId = intent?.getIntExtra(EXTRA_ICON_RES_ID, android.R.drawable.ic_dialog_info)
            ?: android.R.drawable.ic_dialog_info
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(channelID, channelName, NotificationManager.IMPORTANCE_HIGH)
            )
        }
        val notification: Notification = NotificationCompat.Builder(this, channelID)
            .setContentTitle("Lunar Proxy")
            .setContentText("Playing on $serverAddress")
            .setOngoing(true)
            .setWhen(System.currentTimeMillis())
            .setSmallIcon(iconResId)
            .build()
        val flags = if (Build.VERSION.SDK_INT >= 34) NotificationCompat.FLAG_IMMUTABLE else 0
        NotificationManagerCompat.from(this).notify(NOTIFICATION_ID, notification, flags)
        thread { connect(serverAddress, entitlementToken) }
        return START_NOT_STICKY
    }

    private fun connect(serverAddress: String, entitlementToken: String) {
        try {
            LunarCoreHolder.app.start(serverAddress, entitlementToken)
            LunarCoreHolder.module.sendEvent(
                "lunar_connection_event",
                mapOf("status" to "connected")
            )
        } catch (e: Exception) {
            LunarCoreHolder.module.sendEvent(
                "lunar_connection_event",
                mapOf("status" to "error", "error" to (e.message ?: ""))
            )
            shutdown()
        }
    }

    private fun shutdown() {
        LunarCoreHolder.app.terminate()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private enum class ACTION {
        START,
        STOP,
    }

    companion object {
        private const val EXTRA_SERVER_ADDRESS = "serverAddress"
        private const val EXTRA_ENTITLEMENT_TOKEN = "entitlementToken"
        private const val EXTRA_ICON_RES_ID = "iconResId"
        private const val NOTIFICATION_ID = 6969

        fun start(context: Context, serverAddress: String, entitlementToken: String) {
            val iconResId = context.packageManager
                .getResourcesForApplication(context.packageName)
                .getIdentifier("ic_launcher", "mipmap", context.packageName)
            val intent = Intent(context, ForegroundService::class.java)
                .setAction(ACTION.START.name)
                .putExtra(EXTRA_SERVER_ADDRESS, serverAddress)
                .putExtra(EXTRA_ENTITLEMENT_TOKEN, entitlementToken)
                .putExtra(EXTRA_ICON_RES_ID, iconResId)
            if (Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, ForegroundService::class.java)
                .setAction(ACTION.STOP.name)
            context.startService(intent)
        }
    }
}