import React from 'react';
import { StyleSheet, Switch, Text, TouchableOpacity, View } from 'react-native';

import { colors } from '@/theme/colors';

interface Props {
  label: string;
  description?: string;
  enabled: boolean;
  premiumLocked?: boolean;
  onChange: (enabled: boolean) => void;
}

export function ModuleCard({ label, description, enabled, premiumLocked, onChange }: Props) {
  return (
    <TouchableOpacity
      style={[styles.card, enabled && styles.cardActive]}
      activeOpacity={0.7}
      onPress={() => onChange(!enabled)}
      disabled={premiumLocked}
    >
      <View style={styles.info}>
        <Text style={styles.label}>{label}</Text>
        {description ? <Text style={styles.description}>{description}</Text> : null}
        {premiumLocked ? <Text style={styles.locked}>Premium module</Text> : null}
      </View>
      {premiumLocked ? (
        <View style={styles.lockBadge}>
          <Text style={styles.lockText}>●</Text>
        </View>
      ) : (
        <Switch value={enabled} onValueChange={onChange} trackColor={{ true: colors.primary }} />
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: 14,
    marginVertical: 4,
    borderWidth: 1,
    borderColor: colors.border,
  },
  cardActive: {
    borderColor: colors.primary,
  },
  info: {
    flex: 1,
    paddingRight: 12,
  },
  label: {
    color: colors.text,
    fontSize: 16,
    fontWeight: '600',
  },
  description: {
    color: colors.textMuted,
    fontSize: 13,
    marginTop: 2,
  },
  locked: {
    color: colors.premium,
    fontSize: 12,
    marginTop: 4,
  },
  lockBadge: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: colors.premium,
    alignItems: 'center',
    justifyContent: 'center',
  },
  lockText: {
    color: colors.background,
    fontWeight: '800',
  },
});