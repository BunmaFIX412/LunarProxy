import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { ConnectionStatus } from '@/hooks/useLunar';
import { colors } from '@/theme/colors';

const statusColor: Record<ConnectionStatus, string> = {
  idle: colors.textMuted,
  connecting: colors.warning,
  online: colors.success,
  offline: colors.danger,
  ejected: colors.danger,
};

export function StatusBadge({ status, label }: { status: ConnectionStatus; label: string }) {
  return (
    <View style={[styles.badge, { backgroundColor: statusColor[status] }]}>
      <Text style={styles.text}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
  },
  text: {
    color: colors.background,
    fontSize: 12,
    fontWeight: '700',
  },
});