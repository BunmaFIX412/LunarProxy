import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';

import { useI18n } from '@/i18n';
import { useLunar } from '@/hooks/useLunar';
import { colors } from '@/theme/colors';

export function PremiumScreen() {
  const { t } = useI18n();
  const { premium } = useLunar();

  return (
    <View style={styles.root}>
      <Text style={styles.title}>{t('store.premiumTitle')}</Text>
      <Text style={styles.description}>{t('store.premiumDescription')}</Text>
      {premium ? (
        <Text style={styles.owned}>{t('accounts.premiumBadge')}</Text>
      ) : (
        <TouchableOpacity style={styles.button} activeOpacity={0.8}>
          <Text style={styles.buttonText}>{t('store.subscribe')}</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: colors.background,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  title: { color: colors.premium, fontSize: 26, fontWeight: '800' },
  description: { color: colors.textMuted, fontSize: 14, marginTop: 10, textAlign: 'center' },
  owned: { color: colors.success, fontSize: 16, fontWeight: '700', marginTop: 24 },
  button: {
    marginTop: 24,
    alignSelf: 'stretch',
    backgroundColor: colors.premium,
    borderRadius: 14,
    padding: 16,
    alignItems: 'center',
  },
  buttonText: { color: colors.background, fontSize: 16, fontWeight: '800' },
});