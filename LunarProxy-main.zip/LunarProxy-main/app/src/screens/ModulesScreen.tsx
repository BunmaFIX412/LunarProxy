import React, { useMemo, useState } from 'react';
import { FlatList, StyleSheet, Text, TextInput, View } from 'react-native';

import { ModuleCard } from '@/components/ModuleCard';
import { useI18n } from '@/i18n';
import { useLunar } from '@/hooks/useLunar';
import { ModuleCategory } from '@/stores/modules';
import { colors } from '@/theme/colors';

const categoryOrder: ModuleCategory[] = ['combat', 'movement', 'visual', 'world', 'utility', 'server', 'misc', 'lifeboat', 'free'];

const categoryKey: Record<ModuleCategory, string> = {
  combat: 'modules.categoryCombat',
  movement: 'modules.categoryMovement',
  visual: 'modules.categoryVisual',
  world: 'modules.categoryWorld',
  utility: 'modules.categoryUtility',
  server: 'modules.categoryServer',
  misc: 'modules.categoryMisc',
  lifeboat: 'modules.categoryLifeboat',
  free: 'modules.categoryFree',
};

export function ModulesScreen() {
  const { t } = useI18n();
  const { modules, premium, setModuleEnabled } = useLunar();
  const [query, setQuery] = useState('');

  const grouped = useMemo(() => {
    const q = query.trim().toLowerCase();
    const filtered = modules.filter(
      (m) => !q || m.label.toLowerCase().includes(q) || m.name.toLowerCase().includes(q),
    );
    const result: { category: ModuleCategory; items: typeof filtered }[] = [];
    for (const category of categoryOrder) {
      const items = filtered.filter((m) => m.category === category);
      if (items.length > 0) {
        result.push({ category, items });
      }
    }
    return result;
  }, [modules, query]);

  return (
    <View style={styles.root}>
      <TextInput
        style={styles.search}
        placeholder={t('modules.search')}
        placeholderTextColor={colors.textMuted}
        value={query}
        onChangeText={setQuery}
        autoCapitalize="none"
      />
      <FlatList
        data={grouped}
        keyExtractor={(item) => item.category}
        contentContainerStyle={styles.content}
        ListEmptyComponent={<Text style={styles.empty}>{t('modules.noResults')}</Text>}
        renderItem={({ item }) => (
          <View>
            <Text style={styles.category}>{t(categoryKey[item.category])}</Text>
            {item.items.map((module) => (
              <ModuleCard
                key={module.name}
                label={module.label}
                description={module.description}
                enabled={module.enabled}
                premiumLocked={module.premium && !premium}
                onChange={(enabled) => setModuleEnabled(module.name, enabled)}
              />
            ))}
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  search: {
    margin: 16,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 10,
    backgroundColor: colors.surface,
    color: colors.text,
    borderWidth: 1,
    borderColor: colors.border,
  },
  content: { paddingHorizontal: 16, paddingBottom: 32 },
  category: {
    color: colors.textMuted,
    fontSize: 13,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.8,
    marginTop: 16,
    marginBottom: 6,
  },
  empty: { color: colors.textMuted, textAlign: 'center', marginTop: 40 },
});