import React from 'react';
import { ScrollView, StyleSheet, Text, TouchableOpacity } from 'react-native';

import { SectionHeader } from '@/components/SectionHeader';
import { useI18n } from '@/i18n';
import { useLunar } from '@/hooks/useLunar';
import { colors } from '@/theme/colors';

export function SettingsScreen() {
  const { t } = useI18n();
  const { premium, startProxy, stopProxy } = useLunar();

  return (
    <ScrollView style={styles.root} contentContainerStyle={styles.content}>
      <SectionHeader title={t('settings.general')} />
      <TouchableOpacity style={styles.row} activeOpacity={0.7} onPress={() => (premium ? stopProxy() : startProxy('localhost', '19132'))}>
        <Text style={styles.rowText}>{t('proxy.title')}</Text>
      </TouchableOpacity>
      <SectionHeader title={t('settings.analytics')} />
      <TouchableOpacity style={styles.row} activeOpacity={0.7}>
        <Text style={styles.rowText}>{t('settings.log')}</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  content: { paddingHorizontal: 16, paddingBottom: 32 },
  row: {
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: 14,
    marginBottom: 6,
    borderWidth: 1,
    borderColor: colors.border,
  },
  rowText: { color: colors.text, fontSize: 16, fontWeight: '600' },
});