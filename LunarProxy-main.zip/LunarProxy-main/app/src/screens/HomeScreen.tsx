import { useNavigation } from '@react-navigation/native';
import React from 'react';
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';

import { StatusBadge } from '@/components/StatusBadge';
import { useI18n } from '@/i18n';
import { useLunar } from '@/hooks/useLunar';
import { colors } from '@/theme/colors';
import { RootStackParamList } from '../../App';

const statusKey = {
  idle: 'home.statusIdle',
  connecting: 'home.statusConnecting',
  online: 'home.statusOnline',
  ejected: 'home.statusEjected',
  offline: 'home.statusIdle',
} as const;

export function HomeScreen() {
  const { t } = useI18n();
  const { status, version, proxy, port } = useLunar();
  const navigation = useNavigation<NavigationProp>();

  const entries: { title: string; screen: keyof RootStackParamList }[] = [
    { title: t('modules.title'), screen: 'Modules' },
    { title: t('servers.title'), screen: 'Servers' },
    { title: t('friends.title'), screen: 'Friends' },
    { title: t('realms.title'), screen: 'Realms' },
    { title: t('settings.title'), screen: 'Settings' },
    { title: t('store.title'), screen: 'Store' },
  ];

  return (
    <ScrollView style={styles.root} contentContainerStyle={styles.content}>
      <View style={styles.header}>
        <Text style={styles.title}>{t('home.title')}</Text>
        <StatusBadge status={status} label={t(statusKey[status])} />
      </View>

      <View style={styles.card}>
        <Text style={styles.cardLabel}>{t('home.proxyAddress')}</Text>
        <Text style={styles.cardValue}>{proxy?.localAddress ?? '—'}</Text>
        <Text style={styles.cardLabel}>{t('home.port')}</Text>
        <Text style={styles.cardValue}>{port || '—'}</Text>
        <View style={styles.divider} />
        <Text style={styles.cardLabel}>{t('home.version')}</Text>
        <Text style={styles.cardValue}>
          {version?.currentVersion ?? '—'} ({version?.currentProtocol ?? '—'})
        </Text>
      </View>

      {entries.map((entry) => (
        <TouchableOpacity
          key={entry.screen}
          style={styles.row}
          activeOpacity={0.7}
          onPress={() => navigation.navigate(entry.screen)}
        >
          <Text style={styles.rowText}>{entry.title}</Text>
          <Text style={styles.rowChevron}>›</Text>
        </TouchableOpacity>
      ))}
    </ScrollView>
  );
}

type NavigationProp = ReturnType<typeof useNavigation>;

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  content: { padding: 16, paddingTop: 56 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  title: { color: colors.text, fontSize: 32, fontWeight: '800' },
  card: {
    backgroundColor: colors.surface,
    borderRadius: 14,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: colors.border,
  },
  cardLabel: { color: colors.textMuted, fontSize: 12, marginTop: 8 },
  cardValue: { color: colors.text, fontSize: 18, fontWeight: '600' },
  divider: { height: 1, backgroundColor: colors.border, marginVertical: 10 },
  row: {
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: 16,
    marginBottom: 8,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1,
    borderColor: colors.border,
  },
  rowText: { color: colors.text, fontSize: 16, fontWeight: '600' },
  rowChevron: { color: colors.textMuted, fontSize: 22 },
});