import React, { useEffect, useState } from 'react';
import { FlatList, StyleSheet, Text, TouchableOpacity, View } from 'react-native';

import { SectionHeader } from '@/components/SectionHeader';
import { Account, getClient } from '@/bridge/lunargo';
import { useI18n } from '@/i18n';
import { useLunar } from '@/hooks/useLunar';
import { colors } from '@/theme/colors';

export function AccountsScreen() {
  const { t } = useI18n();
  const { auth } = useLunar();
  const [accounts, setAccounts] = useState<Account[]>([]);

  useEffect(() => {
    const client = getClient();
    const json = client.listAccountsJSON();
    if (json) {
      setAccounts(JSON.parse(json) as Account[]);
    }
  }, [auth]);

  return (
    <FlatList
      style={styles.root}
      contentContainerStyle={styles.content}
      data={accounts}
      keyExtractor={(a) => a.id}
      ListHeaderComponent={
        <>
          <SectionHeader title={t('accounts.title')} />
          <TouchableOpacity style={styles.add} activeOpacity={0.7} onPress={() => getClient().authenticate(true)}>
            <Text style={styles.addText}>{t('accounts.signIn')}</Text>
          </TouchableOpacity>
        </>
      }
      ListEmptyComponent={<Text style={styles.empty}>{t('accounts.noAccounts')}</Text>}
      renderItem={({ item }) => (
        <View style={styles.row}>
          <View style={styles.info}>
            <Text style={styles.gamertag}>{item.gamertag}</Text>
            <Text style={styles.meta}>{item.xuid}</Text>
          </View>
          {item.premium ? <Text style={styles.premium}>{t('accounts.premiumBadge')}</Text> : null}
          <TouchableOpacity activeOpacity={0.7} onPress={() => getClient().switchAccount(item.id)}>
            <Text style={styles.switch}>{t('accounts.switch')}</Text>
          </TouchableOpacity>
        </View>
      )}
    />
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  content: { paddingHorizontal: 16, paddingBottom: 32 },
  add: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    padding: 14,
    alignItems: 'center',
    marginBottom: 12,
  },
  addText: { color: colors.text, fontSize: 15, fontWeight: '700' },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: 14,
    marginBottom: 6,
    borderWidth: 1,
    borderColor: colors.border,
  },
  info: { flex: 1 },
  gamertag: { color: colors.text, fontSize: 16, fontWeight: '600' },
  meta: { color: colors.textMuted, fontSize: 12, marginTop: 2 },
  premium: { color: colors.premium, fontWeight: '700', marginRight: 12 },
  switch: { color: colors.primary, fontWeight: '600' },
  empty: { color: colors.textMuted, textAlign: 'center', marginTop: 40 },
});