import React from 'react';
import { FlatList, StyleSheet, Text, TouchableOpacity } from 'react-native';

import { SectionHeader } from '@/components/SectionHeader';
import { getClient, FriendWorld } from '@/bridge/lunargo';
import { useI18n } from '@/i18n';
import { colors } from '@/theme/colors';

export function FriendsScreen() {
  const { t } = useI18n();
  const [worlds, setWorlds] = React.useState<FriendWorld[]>([]);

  React.useEffect(() => {
    const client = getClient();
    const json = client.friendsJSON();
    if (json) {
      setWorlds(JSON.parse(json) as FriendWorld[]);
    }
    const timer = setTimeout(() => {
      const next = client.requestFriendsJSON();
      if (next) {
        setWorlds(JSON.parse(next) as FriendWorld[]);
      }
    }, 300);
    return () => clearTimeout(timer);
  }, []);

  const join = (world: FriendWorld) => {
    getClient().setProxyAddress(world.handleID, world.worldName);
  };

  return (
    <FlatList
      style={styles.root}
      contentContainerStyle={styles.content}
      data={worlds}
      keyExtractor={(w) => w.handleID}
      ListHeaderComponent={<SectionHeader title={t('friends.title')} />}
      ListEmptyComponent={<Text style={styles.empty}>{t('friends.empty')}</Text>}
      renderItem={({ item }) => (
        <TouchableOpacity style={styles.row} activeOpacity={0.7} onPress={() => join(item)}>
          <Text style={styles.name}>{item.worldName}</Text>
          <Text style={styles.meta}>
            {item.gamertag} · {t('friends.members', { count: item.memberCount, max: item.maxMembers })}
          </Text>
        </TouchableOpacity>
      )}
    />
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  content: { paddingHorizontal: 16, paddingBottom: 32 },
  row: {
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: 14,
    marginBottom: 6,
    borderWidth: 1,
    borderColor: colors.border,
  },
  name: { color: colors.text, fontSize: 16, fontWeight: '600' },
  meta: { color: colors.textMuted, fontSize: 13, marginTop: 4 },
  empty: { color: colors.textMuted, textAlign: 'center', marginTop: 40 },
});