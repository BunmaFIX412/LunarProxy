import React, { useEffect, useState } from 'react';
import { FlatList, StyleSheet, Text, TouchableOpacity } from 'react-native';

import { SectionHeader } from '@/components/SectionHeader';
import { getClient } from '@/bridge/lunargo';
import { useI18n } from '@/i18n';
import { colors } from '@/theme/colors';

export function RealmsScreen() {
  const { t } = useI18n();
  const [realms, setRealms] = useState<{ id: string; name: string }[]>([]);

  useEffect(() => {
    const client = getClient();
    const json = client.realmsJSON();
    if (json) {
      setRealms(JSON.parse(json) as { id: string; name: string }[]);
    }
    const timer = setTimeout(() => {
      const next = client.requestRealmsJSON();
      if (next) {
        setRealms(JSON.parse(next) as { id: string; name: string }[]);
      }
    }, 300);
    return () => clearTimeout(timer);
  }, []);

  return (
    <FlatList
      style={styles.root}
      contentContainerStyle={styles.content}
      data={realms}
      keyExtractor={(r) => r.id}
      ListHeaderComponent={<SectionHeader title={t('realms.title')} />}
      ListEmptyComponent={<Text style={styles.empty}>{t('realms.empty')}</Text>}
      renderItem={({ item }) => (
        <TouchableOpacity
          style={styles.row}
          activeOpacity={0.7}
          onPress={() => getClient().resolveRealm(item.id)}
        >
          <Text style={styles.name}>{item.name}</Text>
          <Text style={styles.chevron}>›</Text>
        </TouchableOpacity>
      )}
    />
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  content: { paddingHorizontal: 16, paddingBottom: 32 },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: 14,
    marginBottom: 6,
    borderWidth: 1,
    borderColor: colors.border,
  },
  name: { color: colors.text, fontSize: 16, fontWeight: '600' },
  chevron: { color: colors.textMuted, fontSize: 20 },
  empty: { color: colors.textMuted, textAlign: 'center', marginTop: 40 },
});