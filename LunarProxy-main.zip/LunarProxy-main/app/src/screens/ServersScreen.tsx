import React, { useEffect, useState } from 'react';
import { FlatList, StyleSheet, Text, TouchableOpacity, View } from 'react-native';

import { SectionHeader } from '@/components/SectionHeader';
import { getClient, ServerStatus } from '@/bridge/lunargo';
import { useI18n } from '@/i18n';
import { colors } from '@/theme/colors';

interface ServerEntry {
  address: string;
  name: string;
  featured?: boolean;
}

const featured: ServerEntry[] = [
  { address: 'play.cubecraft.net', name: 'CubeCraft', featured: true },
  { address: 'play.nethergames.org', name: 'NetherGames', featured: true },
  { address: 'play.lbsg.net', name: 'Lifeboat' },
  { address: 'play.galaxite.net', name: 'Galaxite', featured: true },
  { address: 'mco.mineplex.com', name: 'Mineplex' },
];

export function ServersScreen() {
  const { t } = useI18n();
  const [custom, setCustom] = useState<ServerEntry[]>([]);
  const [recent, setRecent] = useState<string[]>([]);
  const [status, setStatus] = useState<Record<string, ServerStatus>>({});
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    const client = getClient();
    setCustom(parseServers(client.customServers()));
    setRecent(parseRecent(client.recentServers()));
  }, []);

  const refresh = async () => {
    setRefreshing(true);
    const client = getClient();
    const targets = [...featured, ...custom].map((s) => s.address);
    const json = client.pingServers(JSON.stringify(targets));
    const parsed = JSON.parse(json) as Record<string, ServerStatus>;
    setStatus(parsed);
    setRefreshing(false);
  };

  const renderRow = (entry: ServerEntry) => {
    const ping = status[entry.address];
    const online = ping?.online;
    return (
      <TouchableOpacity style={styles.row} activeOpacity={0.7} onPress={refresh}>
        <View style={styles.rowInfo}>
          <Text style={styles.rowName}>{entry.name}</Text>
          <Text style={styles.rowAddress}>{entry.address}</Text>
        </View>
        {online === undefined ? null : online ? (
          <Text style={styles.rowPing}>{ping.pingMs}ms</Text>
        ) : (
          <Text style={styles.rowOffline}>{t('common.offline')}</Text>
        )}
      </TouchableOpacity>
    );
  };

  return (
    <FlatList
      style={styles.root}
      contentContainerStyle={styles.content}
      data={custom.length > 0 ? [featured, custom, recent] : [featured, recent]}
      keyExtractor={(_, i) => String(i)}
      refreshing={refreshing}
      onRefresh={refresh}
      renderItem={({ item }) => (
        <View>
          <SectionHeader
            title={item === featured ? t('servers.featured') : item === custom ? t('servers.custom') : t('servers.recent')}
          />
          {item === featured ? featured.map(renderRow) : item === custom ? custom.map(renderRow) : recent.map((address) => renderRow({ address, name: address }))}
        </View>
      )}
    />
  );
}

function parseServers(json: string): ServerEntry[] {
  try {
    return JSON.parse(json) as ServerEntry[];
  } catch {
    return [];
  }
}

function parseRecent(json: string): string[] {
  try {
    return JSON.parse(json) as string[];
  } catch {
    return [];
  }
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  content: { paddingHorizontal: 16, paddingBottom: 32 },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: 14,
    marginBottom: 6,
    borderWidth: 1,
    borderColor: colors.border,
  },
  rowInfo: { flex: 1 },
  rowName: { color: colors.text, fontSize: 16, fontWeight: '600' },
  rowAddress: { color: colors.textMuted, fontSize: 13, marginTop: 2 },
  rowPing: { color: colors.success, fontWeight: '700' },
  rowOffline: { color: colors.textMuted },
});