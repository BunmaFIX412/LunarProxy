import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';

import { SectionHeader } from '@/components/SectionHeader';
import { useI18n } from '@/i18n';
import { useLunar } from '@/hooks/useLunar';
import { colors } from '@/theme/colors';

export function ProxyScreen() {
  const { t } = useI18n();
  const { proxy, status, startProxy, stopProxy } = useLunar();
  const active = status === 'online' || status === 'connecting';

  return (
    <View style={styles.root}>
      <SectionHeader title={t('proxy.title')} />
      <View style={styles.card}>
        <Text style={styles.label}>{t('proxy.localAddress')}</Text>
        <Text style={styles.value}>{proxy?.localAddress ?? '—'}</Text>
        <Text style={styles.label}>{t('proxy.remoteAddress')}</Text>
        <Text style={styles.value}>{proxy?.remoteAddress ?? '—'}</Text>
      </View>
      <TouchableOpacity
        style={[styles.button, active && styles.buttonStop]}
        activeOpacity={0.8}
        onPress={() => (active ? stopProxy() : startProxy('0.0.0.0', '19132'))}
      >
        <Text style={styles.buttonText}>{active ? t('proxy.stop') : t('proxy.start')}</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background, padding: 16 },
  card: {
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: 14,
    borderWidth: 1,
    borderColor: colors.border,
  },
  label: { color: colors.textMuted, fontSize: 12, marginTop: 8 },
  value: { color: colors.text, fontSize: 16, fontWeight: '600' },
  button: {
    marginTop: 20,
    backgroundColor: colors.primary,
    borderRadius: 14,
    padding: 16,
    alignItems: 'center',
  },
  buttonStop: { backgroundColor: colors.danger },
  buttonText: { color: colors.text, fontSize: 16, fontWeight: '700' },
});