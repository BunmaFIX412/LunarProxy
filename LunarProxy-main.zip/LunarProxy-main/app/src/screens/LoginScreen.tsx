import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';

import { useI18n } from '@/i18n';
import { useLunar } from '@/hooks/useLunar';
import { colors } from '@/theme/colors';

export function LoginScreen() {
  const { t } = useI18n();
  const { auth, status } = useLunar();
  const busy = status === 'connecting';

  return (
    <View style={styles.root}>
      <View style={styles.brand}>
        <View style={styles.logo}>
          <Text style={styles.logoText}>L</Text>
        </View>
        <Text style={styles.title}>{t('login.title')}</Text>
        <Text style={styles.subtitle}>{t('login.description')}</Text>
      </View>
      <TouchableOpacity
        style={[styles.button, busy && styles.buttonBusy]}
        activeOpacity={0.8}
        onPress={() => auth?.authenticated || getClient().authenticate(true)}
        disabled={busy}
      >
        <Text style={styles.buttonText}>{busy ? t('common.loading') : t('login.continue')}</Text>
      </TouchableOpacity>
    </View>
  );
}

import { getClient } from '@/bridge/lunargo';

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: colors.background,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  brand: { alignItems: 'center', marginBottom: 48 },
  logo: {
    width: 88,
    height: 88,
    borderRadius: 24,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  logoText: { color: colors.text, fontSize: 44, fontWeight: '800' },
  title: { color: colors.text, fontSize: 28, fontWeight: '800' },
  subtitle: { color: colors.textMuted, fontSize: 14, marginTop: 8, textAlign: 'center' },
  button: {
    alignSelf: 'stretch',
    backgroundColor: colors.primary,
    borderRadius: 14,
    padding: 16,
    alignItems: 'center',
  },
  buttonBusy: { opacity: 0.6 },
  buttonText: { color: colors.text, fontSize: 16, fontWeight: '700' },
});