import { useMemo } from 'react';

import { en } from './en';

export type Locale = 'en';

const catalogs: Record<Locale, typeof en> = {
  en,
};

export function translate(key: string, params?: Record<string, string | number>): string {
  let value: unknown = catalogs.en;
  for (const part of key.split('.')) {
    if (value && typeof value === 'object') {
      value = (value as Record<string, unknown>)[part];
    } else {
      return key;
    }
  }
  if (typeof value !== 'string') {
    return key;
  }
  if (!params) {
    return value;
  }
  return value.replace(/\{\{(\w+)\}\}/g, (_, name: string) =>
    name in params ? String(params[name]) : `{{${name}}}`,
  );
}

export function useI18n() {
  return useMemo(
    () => ({
      t: translate,
      locale: 'en' as Locale,
    }),
    [],
  );
}