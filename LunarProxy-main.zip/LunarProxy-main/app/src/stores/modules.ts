export type ModuleCategory =
  | 'combat'
  | 'movement'
  | 'visual'
  | 'world'
  | 'utility'
  | 'server'
  | 'misc'
  | 'lifeboat'
  | 'free';

export type ModuleSettingType = 'toggle' | 'slider' | 'select' | 'text' | 'color';

export interface ModuleSetting {
  key: string;
  type: ModuleSettingType;
  label: string;
  description?: string;
  value: string | number | boolean;
  min?: number;
  max?: number;
  step?: number;
  options?: string[];
}

export interface Module {
  name: string;
  category: ModuleCategory;
  label: string;
  description: string;
  premium: boolean;
  enabled: boolean;
  keybind?: string;
  settings: ModuleSetting[];
}

export function parseModules(json: string): Module[] {
  try {
    return JSON.parse(json) as Module[];
  } catch {
    return [];
  }
}