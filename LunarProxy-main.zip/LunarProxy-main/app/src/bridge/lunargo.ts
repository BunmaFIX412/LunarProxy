import { requireNativeModule } from 'expo-modules-core';
import { Platform } from 'react-native';

export interface ProxyInfo {
  localAddress: string;
  remoteAddress: string;
}

export interface VersionInfo {
  currentVersion: string;
  currentProtocol: number;
}

export interface ConnectionEvent {
  status: 'connected' | 'error';
  error?: string;
}

export interface LogEvent {
  log: string;
}

export type LunargoErrorCode =
  | 'ResourcePackError'
  | 'SkinError'
  | 'RealmsError'
  | 'RealmError'
  | 'FriendsError'
  | 'SwitchAccountError'
  | 'DeleteAccountError'
  | 'AuthenticationError'
  | 'TerminateError'
  | 'PingError'
  | 'ProxyInfoError'
  | 'VersionInfoError';

/**
 * Thin, fully typed bridge over the `expo.modules.lunargo` native module.
 *
 * The module owns a single `lunar.App` instance (the Go core bound with
 * gomobile). Every method below maps 1:1 to the native promise API of the
 * released binary (see RECONSTRUCTION.md for the decompiled mapping).
 */
export interface LunargoNativeModule {
  startProxy(serverAddress: string, entitlementToken: string): Promise<void>;
  stopProxy(): Promise<void>;
  setProxyAddress(address: string, subtitle: string): Promise<void>;
  setUserID(userID: string): Promise<void>;
  loadCachedAuth(): Promise<void>;
  authenticate(interactive: boolean): Promise<void>;
  cancelAuthenticate(): Promise<void>;
  logout(): Promise<void>;
  spoofDevice(): Promise<void>;
  terminate(): Promise<void>;
  readLog(): Promise<string>;
  getProxyInfo(): Promise<ProxyInfo>;
  getVersionInfo(): Promise<VersionInfo>;
  setPaused(paused: boolean): void;
  getDeviceOS(): Promise<string>;
  setDeviceOS(deviceOS: string): Promise<void>;
  getToken(): Promise<string>;
  getCustomServers(): Promise<string>;
  pingServers(serversJSON: string): Promise<string>;
  saveSettings(): Promise<void>;
  setCustomServers(serversJSON: string): Promise<void>;
  getRealms(): Promise<string>;
  requestRealms(): Promise<string>;
  getFriends(): Promise<string>;
  requestFriends(): Promise<string>;
  setResourcePackPaths(pathsJSON: string): Promise<void>;
  loadSkinFromLocalFiles(geometryPath: string, texturePath: string, capePath: string): Promise<void>;
  setSkinArmSize(armSize: string): Promise<void>;
  clearSkin(): Promise<void>;
  getSkinData(): Promise<string>;
  getResourcePackPaths(): Promise<string>;
  getRecentServers(): Promise<string>;
  setRecentServers(serversJSON: string): Promise<void>;
  resolveRealm(code: string): Promise<string>;
  listAccounts(): Promise<string>;
  getCurrentAccountID(): Promise<string>;
  switchAccount(accountId: string): Promise<void>;
  deleteAccount(accountId: string): Promise<void>;
}

function nativeLunargo(): LunargoNativeModule | null {
  if (Platform.OS !== 'android') {
    return null;
  }
  return requireNativeModule('Lunargo') as LunargoNativeModule;
}

let module: LunargoNativeModule | null = nativeLunargo();

export function getModule(): LunargoNativeModule {
  if (!module) {
    throw new Error('Lunargo: native module not available');
  }
  return module;
}