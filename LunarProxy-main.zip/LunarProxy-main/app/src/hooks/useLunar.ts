import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';

import { getClient } from '@/bridge/lunargo';
import { AuthState, ConnectTarget, ProxyInfo, VersionInfo } from '@/bridge/lunargo';
import { Module, parseModules } from '@/stores/modules';

export type ConnectionStatus = 'idle' | 'connecting' | 'online' | 'offline' | 'ejected';

interface AppState {
  ready: boolean;
  auth: AuthState | null;
  premium: boolean;
  modules: Module[];
  proxy: ProxyInfo | null;
  version: VersionInfo | null;
  target: ConnectTarget | null;
  status: ConnectionStatus;
  port: number;
}

interface LunarContextValue extends AppState {
  refreshModules: () => void;
  setModuleEnabled: (name: string, enabled: boolean) => void;
  setModuleSetting: (module: string, key: string, value: string) => void;
  startProxy: (host: string, port: string) => void;
  stopProxy: () => void;
  connect: (target: ConnectTarget) => void;
}

const LunarContext = createContext<LunarContextValue | null>(null);

export function LunarProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AppState>({
    ready: false,
    auth: null,
    premium: false,
    modules: [],
    proxy: null,
    version: null,
    target: null,
    status: 'idle',
    port: 0,
  });

  useEffect(() => {
    const client = getClient();
    client.loadCachedAuth();
    setState((prev) => ({
      ...prev,
      ready: true,
      auth: client.getAuthState(),
      premium: client.premium(),
      version: client.versionInfo(),
      modules: parseModules(client.modulesJSON()),
    }));
  }, []);

  const refreshModules = useCallback(() => {
    setState((prev) => ({ ...prev, modules: parseModules(getClient().modulesJSON()) }));
  }, []);

  const setModuleEnabled = useCallback(
    (name: string, enabled: boolean) => {
      getClient().setModuleEnabled(name, enabled);
      refreshModules();
    },
    [refreshModules],
  );

  const setModuleSetting = useCallback(
    (module: string, key: string, value: string) => {
      getClient().setModuleSetting(module, key, value);
      refreshModules();
    },
    [refreshModules],
  );

  const startProxy = useCallback((host: string, port: string) => {
    getClient().start(host, port);
    setState((prev) => ({ ...prev, status: 'connecting' }));
  }, []);

  const stopProxy = useCallback(() => {
    getClient().terminate();
    setState((prev) => ({ ...prev, status: 'idle', proxy: null, target: null }));
  }, []);

  const connect = useCallback((target: ConnectTarget) => {
    getClient().setProxyAddress(target.dialAddress, target.statusSubtitle);
    getClient().setRequestProxyAddress(target.dialAddress);
    setState((prev) => ({ ...prev, target, status: 'connecting' }));
  }, []);

  const value = useMemo<LunarContextValue>(
    () => ({ ...state, refreshModules, setModuleEnabled, setModuleSetting, startProxy, stopProxy, connect }),
    [state, refreshModules, setModuleEnabled, setModuleSetting, startProxy, stopProxy, connect],
  );

  return <LunarContext.Provider value={value}>{children}</LunarContext.Provider>;
}

export function useLunar(): LunarContextValue {
  const ctx = useContext(LunarContext);
  if (!ctx) {
    throw new Error('useLunar must be used within LunarProvider');
  }
  return ctx;
}