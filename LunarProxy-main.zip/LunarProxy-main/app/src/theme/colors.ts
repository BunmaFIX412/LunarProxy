export const colors = {
  background: '#2D3A44',
  surface: '#1F2933',
  surfaceElevated: '#2A3642',
  border: '#3A4A57',
  primary: '#3E92CC',
  primaryDark: '#2C6E99',
  text: '#EDF2F7',
  textMuted: '#9FB3C8',
  success: '#48BB78',
  warning: '#ED8936',
  danger: '#FC8181',
  premium: '#D69E2E',
} as const;