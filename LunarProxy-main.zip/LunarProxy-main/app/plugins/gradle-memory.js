const { withProjectBuildGradle } = require('@expo/config-plugins');

/**
 * Raises the Gradle JVM heap for release builds.
 *
 * R8 + Hermes bytecode + the Go core's debug info make release minification
 * exceed the default 4 GB heap on some machines. This plugin pins the Gradle
 * daemon to a larger heap and enables the parallel GC.
 */
module.exports = function gradleMemory(config) {
  return withProjectBuildGradle(config, (config) => {
    const block = `
org.gradle.jvmargs=-Xmx6g -XX:+UseParallelGC -XX:+HeapDumpOnOutOfMemoryError
org.gradle.parallel=true
org.gradle.caching=true
`;
    const marker = 'org.gradle.jvmargs';
    if (config.modResults.contents.includes(marker)) {
      config.modResults.contents = config.modResults.contents.replace(
        /org\.gradle\.jvmargs=.*\n/,
        block,
      );
    } else {
      config.modResults.contents += block;
    }
    return config;
  });
};