const { withDangerousMod } = require('@expo/config-plugins');
const fs = require('fs');
const path = require('path');

/**
 * Removes duplicate transitive dependencies from the final app build.
 *
 * The Go core pulls in a large tree of native dependencies (gomobile bind,
 * NetherNet, WebRTC). Several of them are also declared transitively by
 * react-native-google-mobile-ads and the Firebase SDKs, which makes Gradle
 * fail on duplicate META-INF entries. This plugin prunes the duplicates from
 * the merged gradle project after the other plugins have run.
 */
module.exports = function removeDuplicates(config) {
  return withDangerousMod(config, ['android', (config) => {
    const gradlePath = path.join(
      config.modRequest.platformProjectRoot,
      'app',
      'build.gradle',
    );
    if (!fs.existsSync(gradlePath)) {
      return config;
    }
    let contents = fs.readFileSync(gradlePath, 'utf-8');

    contents = contents
      .split('\n')
      .filter((line) => {
        const trimmed = line.trim();
        if (!trimmed.startsWith('implementation ')) {
          return true;
        }
        const dep = trimmed.match(/implementation ['"](.+?)(?::[^'"]+)?['"]/);
        if (!dep) {
          return true;
        }
        const groupArtifact = dep[1].split(':').slice(0, 2).join(':');
        return !DUPLICATES.has(groupArtifact);
      })
      .join('\n');

    fs.writeFileSync(gradlePath, contents);
    return config;
  }]);
};

const DUPLICATES = new Set([
  'com.google.firebase:firebase-analytics',
  'com.google.firebase:firebase-crashlytics',
  'com.google.android.gms:play-services-ads',
]);