const { withDangerousMod, withAppBuildGradle } = require('@expo/config-plugins');
const fs = require('fs');
const path = require('path');

/**
 * Registers the local `lunargo` native module from a flat directory.
 *
 * The lunargo Expo module (Kotlin + the gomobile `lunar.*` bind classes) is
 * developed next to the app and consumed as a local AAR through Gradle's
 * flatDir repository, avoiding a Maven publication for private builds.
 */
module.exports = function lunargoFlatdir(config) {
  config = withAppBuildGradle(config, (config) => {
    if (!config.modResults.contents.includes('flatDir')) {
      config.modResults.contents += `
repositories {
    flatDir {
        dirs '../../modules/lunargo/build/outputs/aar'
    }
}
`;
    }
    if (!config.modResults.contents.includes("project(':lunargo')")) {
      config.modResults.contents = config.modResults.contents.replace(
        /dependencies\s*\{/,
        'dependencies {\n    implementation project(\':lunargo\')',
      );
    }
    return config;
  });

  return withDangerousMod(config, ['android', (config) => {
    const settingsPath = path.join(config.modRequest.platformProjectRoot, 'settings.gradle');
    if (fs.existsSync(settingsPath)) {
      const contents = fs.readFileSync(settingsPath, 'utf-8');
      if (!contents.includes("':lunargo'")) {
        fs.writeFileSync(
          settingsPath,
          contents + "\ninclude ':lunargo'\nproject(':lunargo').projectDir = new File('../../modules/lunargo/android')\n",
        );
      }
    }
    return config;
  }]);
};