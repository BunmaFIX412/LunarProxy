import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';
import React, { useEffect, useState } from 'react';
import { ActivityIndicator, StyleSheet, View } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import { initClient } from '@/bridge/lunargo';
import { LunarProvider, useLunar } from '@/hooks/useLunar';
import { AccountsScreen } from '@/screens/AccountsScreen';
import { FriendsScreen } from '@/screens/FriendsScreen';
import { HomeScreen } from '@/screens/HomeScreen';
import { LoginScreen } from '@/screens/LoginScreen';
import { ModulesScreen } from '@/screens/ModulesScreen';
import { PremiumScreen } from '@/screens/PremiumScreen';
import { ProxyScreen } from '@/screens/ProxyScreen';
import { RealmsScreen } from '@/screens/RealmsScreen';
import { ServersScreen } from '@/screens/ServersScreen';
import { SettingsScreen } from '@/screens/SettingsScreen';
import { StoreScreen } from '@/screens/StoreScreen';
import { colors } from '@/theme/colors';

export type RootStackParamList = {
  Home: undefined;
  Modules: undefined;
  Servers: undefined;
  Friends: undefined;
  Realms: undefined;
  Accounts: undefined;
  Settings: undefined;
  Store: undefined;
  Premium: undefined;
  Proxy: undefined;
  Login: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

function Shell() {
  const { ready, auth } = useLunar();

  if (!ready) {
    return (
      <View style={styles.boot}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: colors.surface },
        headerTintColor: colors.text,
        contentStyle: { backgroundColor: colors.background },
      }}
    >
      {!auth?.authenticated ? (
        <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
      ) : (
        <>
          <Stack.Screen name="Home" component={HomeScreen} options={{ headerShown: false }} />
          <Stack.Screen name="Modules" component={ModulesScreen} />
          <Stack.Screen name="Servers" component={ServersScreen} />
          <Stack.Screen name="Friends" component={FriendsScreen} />
          <Stack.Screen name="Realms" component={RealmsScreen} />
          <Stack.Screen name="Accounts" component={AccountsScreen} />
          <Stack.Screen name="Settings" component={SettingsScreen} />
          <Stack.Screen name="Store" component={StoreScreen} />
          <Stack.Screen name="Premium" component={PremiumScreen} />
          <Stack.Screen name="Proxy" component={ProxyScreen} />
        </>
      )}
    </Stack.Navigator>
  );
}

export default function App() {
  const [booted, setBooted] = useState(false);

  useEffect(() => {
    const client = initClient('lunar', true);
    client.setAnalyticsClientInfo('2.3.0', client.clientDeviceOS());
    setBooted(true);
  }, []);

  if (!booted) {
    return (
      <View style={styles.boot}>
        <StatusBar style="light" />
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <SafeAreaProvider>
      <LunarProvider>
        <NavigationContainer>
          <StatusBar style="light" backgroundColor={colors.background} />
          <Shell />
        </NavigationContainer>
      </LunarProvider>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  boot: {
    flex: 1,
    backgroundColor: colors.background,
    alignItems: 'center',
    justifyContent: 'center',
  },
});