# Lunar

A research recovery and open-source reconstruction of Lunar for Minecraft: Bedrock Edition.

This repository contains the reconstructed Lunar Android client and proxy source, recovered from the available application artifacts for research, preservation, and further development.

Lunar operates as a local Minecraft Bedrock proxy, with an Android application providing configuration, authentication, module management, and session control.

> This is an independent software recovery and compatibility project. It is not affiliated with, authorized by, sponsored by, or endorsed by the original Lunar developers, Mojang Studios, or Microsoft.

## Status

The project contains reconstructed source for the primary components of the Lunar application:

- Expo / React Native application
- Android/Kotlin bridge
- Go proxy core
- Authentication and session handling
- Bedrock packet relay
- Module framework and recovered modules
- Supporting libraries and utilities

The reconstruction is based on Lunar **2.3.0**.

The source is substantially recovered, but some generated or reconstructed Go code may still require manual repair before the entire application builds cleanly.

Runtime behavior has not yet been fully verified.

## Architecture

Lunar consists of three primary components:

**Application**

The Android interface is implemented using Expo and React Native and provides the user-facing configuration and management interface.

**Android Bridge**

A Kotlin Expo module connects the application to the native Lunar core and manages the Android foreground service used while the proxy is active.

**Lunar Core**

The primary client functionality is implemented in Go and handles the local Minecraft Bedrock proxy, sessions, authentication, modules, packet relay, settings, and related functionality.


## Modules

The reconstructed core contains modules across several categories, including combat, movement, visual, world, utility, server, and miscellaneous functionality.

Recovered functionality includes modules such as KillAura, AimAssist, AutoCrystal, Reach, Fly, Speed, ESP, XRay, FreeCam, Scaffold, Nuker, AutoFish, StashFinder, ChunkFinder, and others.


## Building

Building the complete Android application requires:

- Android SDK
- Node.js / Expo tooling
- Go
- gomobile
- The dependencies specified by the project

The reconstructed Go core is used to produce the Android library consumed by the Kotlin bridge.

Some reconstructed source may still require manual correction before a clean build is possible.

## Recovery

The source was reconstructed from the available Lunar Android application artifacts.

The original application combines JavaScript, Kotlin/Java, and a native Go core. Each layer required separate recovery before being reconstructed into the current source tree.

Raw APKs, native binaries, bytecode, and extraction outputs are not included in the public source tree.

No original application code or native binary was executed while preparing the reconstruction.

The goal is to preserve Lunar as readable, inspectable, modifiable, and eventually independently buildable source.


## Safety

Recovery was performed through static analysis without executing the original application or native components.

This should not be interpreted as a guarantee that the recovered software is safe. Review the reconstructed source before building or running it.

## Independence

This project has no official or unofficial affiliation, authorization, sponsorship, partnership, endorsement, or other relationship with Lunar, its developers or rights holders, Mojang Studios, or Microsoft.

Lunar, Minecraft, and other names, trademarks, and logos belong to their respective rights holders and are referenced only to identify the software and compatibility targets involved.

---

**Readable over opaque.**  
**Source over black boxes.**
