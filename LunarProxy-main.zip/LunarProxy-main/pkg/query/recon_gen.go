// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package query

// Recovered types (from pclntab type descriptors).

// RaknetQuery is a recovered type.
type RaknetQuery struct{}

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// QueryRaknet recovered at 0x0000000001d418e0 (size 0x00000580).
func QueryRaknet() {
	panic("stub")
}
