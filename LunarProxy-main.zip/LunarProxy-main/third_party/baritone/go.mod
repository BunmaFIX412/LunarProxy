module github.com/oomph-ac/baritone

go 1.26.2