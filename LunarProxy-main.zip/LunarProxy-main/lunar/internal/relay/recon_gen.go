// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package relay

// Recovered types (from pclntab type descriptors).

// ConnectionInfo is a recovered type.
type ConnectionInfo struct{}

// Placeholder receiver types (no equality descriptor in pclntab).

type Relay struct{}

type packetReader struct{}

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// isNormalDisconnectError recovered at 0x000000000199f760 (size 0x000000a0).
func isNormalDisconnectError() {
	panic("stub")
}

// logConnError recovered at 0x000000000199f120 (size 0x00000640).
func logConnError() {
	panic("stub")
}

// newPacketReader recovered at 0x0000000001996ec0 (size 0x00000160).
func newPacketReader() {
	panic("stub")
}

// readBatches recovered at 0x0000000001997020 (size 0x00000120).
func readBatches() {
	panic("stub")
}

// relayDisconnectCause recovered at 0x000000000199a340 (size 0x000000e0).
func relayDisconnectCause() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/relay.(*Relay).Close recovered at 0x000000000199a420 (size 0x00000540).
func (*Relay) Close() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/relay.(*Relay).CustomPacks recovered at 0x00000000019976a0 (size 0x00000100).
func (*Relay) CustomPacks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/relay.(*Relay).GetUpstream recovered at 0x00000000019975e0 (size 0x00000020).
func (*Relay) GetUpstream() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/relay.(*Relay).Listen recovered at 0x0000000001997960 (size 0x000003a0).
func (*Relay) Listen() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/relay.(*Relay).ListenNetwork recovered at 0x0000000001997d60 (size 0x00000520).
func (*Relay) ListenNetwork() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/relay.(*Relay).SetCustomPacks recovered at 0x00000000019977e0 (size 0x00000140).
func (*Relay) SetCustomPacks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/relay.(*Relay).SetUpstream recovered at 0x0000000001997600 (size 0x000000a0).
func (*Relay) SetUpstream() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/relay.(*Relay).claimClient recovered at 0x00000000019985e0 (size 0x00000120).
func (*Relay) claimClient() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/relay.(*Relay).dialUpstream recovered at 0x0000000001998880 (size 0x00000dc0).
func (*Relay) dialUpstream() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/relay.(*Relay).disconnect recovered at 0x0000000001999fa0 (size 0x000003a0).
func (*Relay) disconnect() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/relay.(*Relay).forward recovered at 0x000000000199dd80 (size 0x00000660).
func (*Relay) forward() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/relay.(*Relay).forwardPacket recovered at 0x000000000199a960 (size 0x00003420).
func (*Relay) forwardPacket() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/relay.(*Relay).handleChunkRadiusUpdated recovered at 0x000000000199eb80 (size 0x00000460).
func (*Relay) handleChunkRadiusUpdated() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/relay.(*Relay).handleClientConnection recovered at 0x00000000019982e0 (size 0x00000300).
func (*Relay) handleClientConnection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/relay.(*Relay).handleConnectionError recovered at 0x000000000199efe0 (size 0x00000140).
func (*Relay) handleConnectionError() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/relay.(*Relay).populateGameData recovered at 0x000000000199e700 (size 0x00000480).
func (*Relay) populateGameData() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/relay.(*Relay).redirectTransfer recovered at 0x000000000199e440 (size 0x000002c0).
func (*Relay) redirectTransfer() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/relay.(*Relay).releaseClient recovered at 0x0000000001998740 (size 0x00000100).
func (*Relay) releaseClient() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/relay.(*Relay).runForward recovered at 0x0000000001999b20 (size 0x000001c0).
func (*Relay) runForward() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/relay.(*Relay).setupForwarding recovered at 0x0000000001999640 (size 0x00000420).
func (*Relay) setupForwarding() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/relay.(*Relay).transferClient recovered at 0x000000000199e3e0 (size 0x00000060).
func (*Relay) transferClient() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/relay.(*packetReader).Close recovered at 0x00000000019975a0 (size 0x00000040).
func (*packetReader) Close() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/relay.(*packetReader).Read recovered at 0x0000000001997340 (size 0x00000260).
func (*packetReader) Read() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/relay.(*packetReader).RequestFlush recovered at 0x000000000199fb40 (size 0x00000040).
func (*packetReader) RequestFlush() {
	panic("stub")
}
