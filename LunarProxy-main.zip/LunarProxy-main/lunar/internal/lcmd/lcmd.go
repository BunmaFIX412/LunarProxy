package lcmd

import (
	"sort"
	"strings"

	"github.com/go-gl/mathgl/mgl32"
	"github.com/lunar-bedrock/lunar/lunar/internal/module"
	"github.com/lunar-bedrock/lunar/lunar/player/form"
)

type Source struct {
	player module.Player
	pos    mgl32.Vec3
	output func(string)
}

func NewSource(player module.Player, pos mgl32.Vec3, output func(string)) Source {
	if output == nil {
		output = func(string) {}
	}
	return Source{player: player, pos: pos, output: output}
}

func (s Source) Player() module.Player {
	return s.player
}

func (s Source) Position() mgl32.Vec3 {
	if s.player != nil {
		return s.player.Position()
	}
	return s.pos
}

func (s Source) SendCommandOutput(msg string) {
	if s.output != nil {
		s.output(msg)
	} else if s.player != nil {
		s.player.SendCommandOutput(msg)
	}
}

type Command struct {
	Name        string
	Aliases     []string
	Description string
	Run         func(source Source, args []string)
}

func (c Command) baseName() string {
	if i := strings.IndexByte(c.Name, ' '); i >= 0 {
		return c.Name[:i]
	}
	return c.Name
}

type Availability struct {
	allowed bool
	visible bool
}

func (a *Availability) Allowed() bool {
	return a.allowed
}

func (a *Availability) Visible() bool {
	return a.visible
}

func Allowed() Availability {
	return Availability{allowed: true, visible: true}
}

func Hidden() Availability {
	return Availability{allowed: true, visible: false}
}

func Denied() Availability {
	return Availability{}
}

type BlockName string

func (b BlockName) Type() form.Settings {
	return b
}

func (b BlockName) Options() []form.Option {
	return nil
}

func (b BlockName) Parse(s string) (string, bool) {
	name := strings.ToLower(strings.TrimSpace(s))
	if name == "" {
		return "", false
	}
	return name, true
}

var commands = map[string]Command{}
var prefix = "/"

func SetPrefix(p string) {
	prefix = p
}

func Prefix() string {
	return prefix
}

func RegisterAvailable(c Command) {
	commands[strings.ToLower(c.baseName())] = c
}

func ByAlias(alias string) (Command, bool) {
	alias = strings.ToLower(strings.TrimPrefix(alias, prefix))
	if c, ok := commands[alias]; ok {
		return c, true
	}
	for _, c := range commands {
		for _, a := range c.Aliases {
			if strings.ToLower(a) == alias {
				return c, true
			}
		}
	}
	return Command{}, false
}

func CommandBaseNames() []string {
	out := make([]string, 0, len(commands))
	for name := range commands {
		out = append(out, name)
	}
	sort.Strings(out)
	return out
}

func VisibleCommands() []Command {
	var out []Command
	for _, c := range commands {
		out = append(out, c)
	}
	sort.Slice(out, func(i, j int) bool {
		return out[i].Name < out[j].Name
	})
	return out
}

func TryExecute(source Source, raw string) bool {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return false
	}
	if !strings.HasPrefix(raw, "/") && !strings.HasPrefix(raw, ".") {
		return false
	}
	parts := strings.Fields(raw[1:])
	if len(parts) == 0 {
		return false
	}
	for i := len(parts); i >= 1; i-- {
		name := strings.Join(parts[:i], " ")
		if c, ok := commands[strings.ToLower(name)]; ok {
			c.Run(source, parts[i:])
			return true
		}
	}
	if cmd, ok := ByAlias(parts[0]); ok {
		cmd.Run(source, parts[1:])
		return true
	}
	source.SendCommandOutput(unknownCommandMessage(parts[0]))
	return true
}

func unknownCommandMessage(name string) string {
	return "§cThat command does not exist. Use §7" + prefix + "help§c for a list of commands."
}

func ResolveMinecraftName(name string) string {
	name = strings.ToLower(name)
	switch name {
	case "gapple", "goldenapple", "golden_apple":
		return "golden_apple"
	case "totem", "totem_of_undying":
		return "totem_of_undying"
	case "crystal", "end_crystal":
		return "end_crystal"
	case "web", "cobweb":
		return "cobweb"
	case "anchor", "respawn_anchor":
		return "respawn_anchor"
	}
	return name
}

func BuildPrefixedAvailableCommands() map[string]Availability {
	out := make(map[string]Availability, len(commands))
	for name, c := range commands {
		a := Availability{allowed: true, visible: true}
		if strings.Contains(c.Name, " ") {
			a.visible = false
		}
		out[name] = a
		for _, alias := range c.Aliases {
			if !strings.Contains(alias, " ") {
				out[alias] = a
			}
		}
	}
	return out
}

func init() {
	_ = module.Register
}