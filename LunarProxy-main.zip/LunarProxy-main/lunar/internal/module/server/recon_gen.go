// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package server

// Recovered types (from pclntab type descriptors).

// friendsListCmd is a recovered type.
type friendsListCmd struct{}

// friendsManageCmd is a recovered type.
type friendsManageCmd struct{}

// timeSetPresetCmd is a recovered type.
type timeSetPresetCmd struct{}

// timeSetValueCmd is a recovered type.
type timeSetValueCmd struct{}

// Placeholder receiver types (no equality descriptor in pclntab).

type __javaModeModule__ConfigSection_ModuleSection struct{}

type friendsAction struct{}

type friendsFormCmd struct{}

type friendsScope struct{}

type gameMode struct{}

type gamemodeCmd struct{}

type javaCmd struct{}

type javaModeModule struct{}

type serverInfoCmd struct{}

type timeAction struct{}

type timePreset struct{}

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// Register recovered at 0x0000000001cef620 (size 0x000006a0).
func Register() {
	panic("stub")
}

// friendNames recovered at 0x0000000001cee6c0 (size 0x000000a0).
func friendNames() {
	panic("stub")
}

// newJavaModeModule recovered at 0x0000000001ceeee0 (size 0x00000080).
func newJavaModeModule() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/server.((*javaModeModule).ConfigSection.ModuleSection).Section recovered at 0x0000000001cef020 (size 0x00000060).
func (__javaModeModule__ConfigSection_ModuleSection) Section() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/server.(*friendsAction).Options recovered at 0x0000000001cee780 (size 0x00000060).
func (*friendsAction) Options() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/server.(*friendsAction).Type recovered at 0x0000000001cee760 (size 0x00000020).
func (*friendsAction) Type() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/server.(*friendsFormCmd).Run recovered at 0x0000000001cedd20 (size 0x000000a0).
func (*friendsFormCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/server.(*friendsListCmd).Run recovered at 0x0000000001cee400 (size 0x000002c0).
func (*friendsListCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/server.(*friendsManageCmd).Run recovered at 0x0000000001ceddc0 (size 0x00000640).
func (*friendsManageCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/server.(*friendsScope).Options recovered at 0x0000000001cee800 (size 0x00000060).
func (*friendsScope) Options() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/server.(*friendsScope).Type recovered at 0x0000000001cee7e0 (size 0x00000020).
func (*friendsScope) Type() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/server.(*gameMode).Options recovered at 0x0000000001ceed60 (size 0x00000180).
func (*gameMode) Options() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/server.(*gameMode).Type recovered at 0x0000000001ceed40 (size 0x00000020).
func (*gameMode) Type() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/server.(*gamemodeCmd).Run recovered at 0x0000000001cee860 (size 0x000004e0).
func (*gamemodeCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/server.(*javaCmd).Run recovered at 0x0000000001cef5a0 (size 0x00000080).
func (*javaCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/server.(*javaModeModule).ApplyClickUI recovered at 0x0000000001cef4a0 (size 0x00000100).
func (*javaModeModule) ApplyClickUI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/server.(*javaModeModule).ClickUIFields recovered at 0x0000000001cef260 (size 0x00000240).
func (*javaModeModule) ClickUIFields() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/server.(*javaModeModule).ConfigSection recovered at 0x0000000001ceefa0 (size 0x00000080).
func (*javaModeModule) ConfigSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/server.(*javaModeModule).Enabled recovered at 0x0000000001cef080 (size 0x00000020).
func (*javaModeModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/server.(*javaModeModule).Meta recovered at 0x0000000001ceef60 (size 0x00000040).
func (*javaModeModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/server.(*javaModeModule).SetEnabled recovered at 0x0000000001cef0a0 (size 0x00000020).
func (*javaModeModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/server.(*javaModeModule).Sync recovered at 0x0000000001cef0c0 (size 0x00000020).
func (*javaModeModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/server.(*javaModeModule).ToggleMessage recovered at 0x0000000001cef0e0 (size 0x00000180).
func (*javaModeModule) ToggleMessage() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/server.(*serverInfoCmd).Run recovered at 0x0000000001cefcc0 (size 0x00000080).
func (*serverInfoCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/server.(*timeAction).Options recovered at 0x0000000001cf0280 (size 0x00000060).
func (*timeAction) Options() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/server.(*timeAction).Type recovered at 0x0000000001cf0260 (size 0x00000020).
func (*timeAction) Type() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/server.(*timePreset).Options recovered at 0x0000000001cf0300 (size 0x000000c0).
func (*timePreset) Options() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/server.(*timePreset).Type recovered at 0x0000000001cf02e0 (size 0x00000020).
func (*timePreset) Type() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/server.(*timeSetPresetCmd).Run recovered at 0x0000000001cefd40 (size 0x000003a0).
func (*timeSetPresetCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/server.(*timeSetValueCmd).Run recovered at 0x0000000001cf00e0 (size 0x00000180).
func (*timeSetValueCmd) Run() {
	panic("stub")
}
