// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package utility

// Recovered types (from pclntab type descriptors).

// antiImmobileCmd is a recovered type.
type antiImmobileCmd struct{}

// autoEatCmd is a recovered type.
type autoEatCmd struct{}

// autoFishCmd is a recovered type.
type autoFishCmd struct{}

// autoSellCmd is a recovered type.
type autoSellCmd struct{}

// deathPositionCmd is a recovered type.
type deathPositionCmd struct{}

// modAlertsCmd is a recovered type.
type modAlertsCmd struct{}

// noFallCmd is a recovered type.
type noFallCmd struct{}

// spamRateCmd is a recovered type.
type spamRateCmd struct{}

// stashFinderCmd is a recovered type.
type stashFinderCmd struct{}

// stashFound is a recovered type.
type stashFound struct{}

// teleportCmd is a recovered type.
type teleportCmd struct{}

// Placeholder receiver types (no equality descriptor in pclntab).

type __autoEatModule__ConfigSection_ModuleSection struct{}

type __autoFishModule__ConfigSection_ModuleSection struct{}

type __autoSellModule__ConfigSection_ModuleSection struct{}

type __autoStealModule__ConfigSection_ModuleSection struct{}

type __modAlertsModule__ConfigSection_ModuleSection struct{}

type __spamModule__ConfigSection_ModuleSection struct{}

type antiImmobileModule struct{}

type autoEatModule struct{}

type autoFishModule struct{}

type autoSellFormCmd struct{}

type autoSellModule struct{}

type autoStealCmd struct{}

type autoStealModule struct{}

type deathPositionAction struct{}

type hasteEffect struct{}

type modAlertsFormCmd struct{}

type modAlertsModule struct{}

type noFallModule struct{}

type shulkerPeekCmd struct{}

type slowMineEffect struct{}

type spamFormCmd struct{}

type spamMessageCmd struct{}

type spamModule struct{}

type spamOffCmd struct{}

type stashTarget struct{}

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// Register recovered at 0x0000000001cf5e00 (size 0x00000ca0).
func Register() {
	panic("stub")
}

// allStashTargetNames recovered at 0x0000000001cfa260 (size 0x00000340).
func allStashTargetNames() {
	panic("stub")
}

// deathPositionElapsed recovered at 0x0000000001cf4540 (size 0x00000480).
func deathPositionElapsed() {
	panic("stub")
}

// init recovered at 0x0000000001cf23e0 (size 0x000001c0).
func init() {
	panic("stub")
}

// init.0 recovered at 0x0000000001cf9e80 (size 0x000000c0).
func init_0() {
	panic("stub")
}

// keepClosestStashFound recovered at 0x0000000001cf9860 (size 0x000004c0).
func keepClosestStashFound() {
	panic("stub")
}

// newAntiImmobileModule recovered at 0x0000000001cf2640 (size 0x00000080).
func newAntiImmobileModule() {
	panic("stub")
}

// newAutoEatModule recovered at 0x0000000001cf28a0 (size 0x00000080).
func newAutoEatModule() {
	panic("stub")
}

// newAutoFishModule recovered at 0x0000000001cf31e0 (size 0x00000080).
func newAutoFishModule() {
	panic("stub")
}

// newAutoSellModule recovered at 0x0000000001cf3520 (size 0x00000080).
func newAutoSellModule() {
	panic("stub")
}

// newAutoStealModule recovered at 0x0000000001cf3980 (size 0x00000080).
func newAutoStealModule() {
	panic("stub")
}

// newHasteModule recovered at 0x0000000001cf4a40 (size 0x00000160).
func newHasteModule() {
	panic("stub")
}

// newModAlertsModule recovered at 0x0000000001cf4be0 (size 0x00000080).
func newModAlertsModule() {
	panic("stub")
}

// newNoFallModule recovered at 0x0000000001cf4fc0 (size 0x00000080).
func newNoFallModule() {
	panic("stub")
}

// newSlowMineModule recovered at 0x0000000001cf6c60 (size 0x00000160).
func newSlowMineModule() {
	panic("stub")
}

// newSpamModule recovered at 0x0000000001cf6e00 (size 0x00000080).
func newSpamModule() {
	panic("stub")
}

// registerPlayerModules recovered at 0x0000000001cf5220 (size 0x00000be0).
func registerPlayerModules() {
	panic("stub")
}

// startSpam recovered at 0x0000000001cf7d20 (size 0x000000e0).
func startSpam() {
	panic("stub")
}

// stashTargetDefFor recovered at 0x0000000001cf9f40 (size 0x00000320).
func stashTargetDefFor() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.((*autoEatModule).ConfigSection.ModuleSection).Section recovered at 0x0000000001cf29e0 (size 0x00000060).
func (__autoEatModule__ConfigSection_ModuleSection) Section() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.((*autoFishModule).ConfigSection.ModuleSection).Section recovered at 0x0000000001cf3320 (size 0x00000060).
func (__autoFishModule__ConfigSection_ModuleSection) Section() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.((*autoSellModule).ConfigSection.ModuleSection).Section recovered at 0x0000000001cf3660 (size 0x00000060).
func (__autoSellModule__ConfigSection_ModuleSection) Section() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.((*autoStealModule).ConfigSection.ModuleSection).Section recovered at 0x0000000001cf3ac0 (size 0x00000060).
func (__autoStealModule__ConfigSection_ModuleSection) Section() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.((*modAlertsModule).ConfigSection.ModuleSection).Section recovered at 0x0000000001cf4d20 (size 0x00000060).
func (__modAlertsModule__ConfigSection_ModuleSection) Section() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.((*spamModule).ConfigSection.ModuleSection).Section recovered at 0x0000000001cf6f40 (size 0x00000060).
func (__spamModule__ConfigSection_ModuleSection) Section() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*antiImmobileCmd).Run recovered at 0x0000000001cf2760 (size 0x00000140).
func (*antiImmobileCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*antiImmobileModule).Enabled recovered at 0x0000000001cf2700 (size 0x00000020).
func (*antiImmobileModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*antiImmobileModule).Meta recovered at 0x0000000001cf26c0 (size 0x00000040).
func (*antiImmobileModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*antiImmobileModule).SetEnabled recovered at 0x0000000001cf2720 (size 0x00000020).
func (*antiImmobileModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*antiImmobileModule).Sync recovered at 0x0000000001cf2740 (size 0x00000020).
func (*antiImmobileModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*autoEatCmd).Run recovered at 0x0000000001cf2ac0 (size 0x00000120).
func (*autoEatCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*autoEatModule).ApplyClickUI recovered at 0x0000000001cf3040 (size 0x000001a0).
func (*autoEatModule) ApplyClickUI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*autoEatModule).ClickUIFields recovered at 0x0000000001cf2be0 (size 0x00000460).
func (*autoEatModule) ClickUIFields() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*autoEatModule).ConfigSection recovered at 0x0000000001cf2960 (size 0x00000080).
func (*autoEatModule) ConfigSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*autoEatModule).Enabled recovered at 0x0000000001cf2a40 (size 0x00000020).
func (*autoEatModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*autoEatModule).Meta recovered at 0x0000000001cf2920 (size 0x00000040).
func (*autoEatModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*autoEatModule).SetEnabled recovered at 0x0000000001cf2a60 (size 0x00000020).
func (*autoEatModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*autoEatModule).Sync recovered at 0x0000000001cf2a80 (size 0x00000040).
func (*autoEatModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*autoFishCmd).Run recovered at 0x0000000001cf3400 (size 0x00000120).
func (*autoFishCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*autoFishModule).ConfigSection recovered at 0x0000000001cf32a0 (size 0x00000080).
func (*autoFishModule) ConfigSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*autoFishModule).Enabled recovered at 0x0000000001cf3380 (size 0x00000020).
func (*autoFishModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*autoFishModule).Meta recovered at 0x0000000001cf3260 (size 0x00000040).
func (*autoFishModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*autoFishModule).SetEnabled recovered at 0x0000000001cf33a0 (size 0x00000020).
func (*autoFishModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*autoFishModule).Sync recovered at 0x0000000001cf33c0 (size 0x00000040).
func (*autoFishModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*autoSellCmd).Run recovered at 0x0000000001cf37c0 (size 0x000001c0).
func (*autoSellCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*autoSellFormCmd).Run recovered at 0x0000000001cf3740 (size 0x00000080).
func (*autoSellFormCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*autoSellModule).ConfigSection recovered at 0x0000000001cf35e0 (size 0x00000080).
func (*autoSellModule) ConfigSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*autoSellModule).Enabled recovered at 0x0000000001cf36c0 (size 0x00000020).
func (*autoSellModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*autoSellModule).Meta recovered at 0x0000000001cf35a0 (size 0x00000040).
func (*autoSellModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*autoSellModule).SetEnabled recovered at 0x0000000001cf36e0 (size 0x00000020).
func (*autoSellModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*autoSellModule).Sync recovered at 0x0000000001cf3700 (size 0x00000040).
func (*autoSellModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*autoStealCmd).Run recovered at 0x0000000001cf3b80 (size 0x00000080).
func (*autoStealCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*autoStealModule).ApplyClickUI recovered at 0x0000000001cf3e20 (size 0x000000c0).
func (*autoStealModule) ApplyClickUI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*autoStealModule).ClickUIFields recovered at 0x0000000001cf3c00 (size 0x00000220).
func (*autoStealModule) ClickUIFields() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*autoStealModule).ConfigSection recovered at 0x0000000001cf3a40 (size 0x00000080).
func (*autoStealModule) ConfigSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*autoStealModule).Enabled recovered at 0x0000000001cf3b20 (size 0x00000020).
func (*autoStealModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*autoStealModule).Meta recovered at 0x0000000001cf3a00 (size 0x00000040).
func (*autoStealModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*autoStealModule).SetEnabled recovered at 0x0000000001cf3b40 (size 0x00000020).
func (*autoStealModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*autoStealModule).Sync recovered at 0x0000000001cf3b60 (size 0x00000020).
func (*autoStealModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*deathPositionAction).Options recovered at 0x0000000001cf49e0 (size 0x00000060).
func (*deathPositionAction) Options() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*deathPositionAction).Type recovered at 0x0000000001cf49c0 (size 0x00000020).
func (*deathPositionAction) Type() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*deathPositionCmd).Run recovered at 0x0000000001cf3ee0 (size 0x00000660).
func (*deathPositionCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*hasteEffect).EffectConfig recovered at 0x0000000001cf4ba0 (size 0x00000040).
func (*hasteEffect) EffectConfig() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*modAlertsCmd).Run recovered at 0x0000000001cf4e60 (size 0x00000120).
func (*modAlertsCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*modAlertsFormCmd).Run recovered at 0x0000000001cf4de0 (size 0x00000080).
func (*modAlertsFormCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*modAlertsModule).ApplyClickUI recovered at 0x0000000001cf4fa0 (size 0x00000020).
func (*modAlertsModule) ApplyClickUI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*modAlertsModule).ClickUIFields recovered at 0x0000000001cf4f80 (size 0x00000020).
func (*modAlertsModule) ClickUIFields() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*modAlertsModule).ConfigSection recovered at 0x0000000001cf4ca0 (size 0x00000080).
func (*modAlertsModule) ConfigSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*modAlertsModule).Enabled recovered at 0x0000000001cf4d80 (size 0x00000020).
func (*modAlertsModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*modAlertsModule).Meta recovered at 0x0000000001cf4c60 (size 0x00000040).
func (*modAlertsModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*modAlertsModule).SetEnabled recovered at 0x0000000001cf4da0 (size 0x00000020).
func (*modAlertsModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*modAlertsModule).Sync recovered at 0x0000000001cf4dc0 (size 0x00000020).
func (*modAlertsModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*noFallCmd).Run recovered at 0x0000000001cf50e0 (size 0x00000140).
func (*noFallCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*noFallModule).Enabled recovered at 0x0000000001cf5080 (size 0x00000020).
func (*noFallModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*noFallModule).Meta recovered at 0x0000000001cf5040 (size 0x00000040).
func (*noFallModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*noFallModule).SetEnabled recovered at 0x0000000001cf50a0 (size 0x00000020).
func (*noFallModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*noFallModule).Sync recovered at 0x0000000001cf50c0 (size 0x00000020).
func (*noFallModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*shulkerPeekCmd).Run recovered at 0x0000000001cf6aa0 (size 0x000001c0).
func (*shulkerPeekCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*slowMineEffect).EffectConfig recovered at 0x0000000001cf6dc0 (size 0x00000040).
func (*slowMineEffect) EffectConfig() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*spamFormCmd).Run recovered at 0x0000000001cf79c0 (size 0x000000a0).
func (*spamFormCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*spamMessageCmd).Run recovered at 0x0000000001cf7ba0 (size 0x000000c0).
func (*spamMessageCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*spamModule).ApplyClickUI recovered at 0x0000000001cf77e0 (size 0x000001e0).
func (*spamModule) ApplyClickUI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*spamModule).ClickUIFields recovered at 0x0000000001cf72e0 (size 0x00000500).
func (*spamModule) ClickUIFields() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*spamModule).ConfigSection recovered at 0x0000000001cf6ec0 (size 0x00000080).
func (*spamModule) ConfigSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*spamModule).Enabled recovered at 0x0000000001cf6fa0 (size 0x00000020).
func (*spamModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*spamModule).Meta recovered at 0x0000000001cf6e80 (size 0x00000040).
func (*spamModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*spamModule).SetEnabled recovered at 0x0000000001cf6fc0 (size 0x00000020).
func (*spamModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*spamModule).Sync recovered at 0x0000000001cf6fe0 (size 0x00000040).
func (*spamModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*spamModule).ToggleMessage recovered at 0x0000000001cf7020 (size 0x000002c0).
func (*spamModule) ToggleMessage() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*spamOffCmd).Run recovered at 0x0000000001cf7a60 (size 0x00000140).
func (*spamOffCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*spamRateCmd).Run recovered at 0x0000000001cf7c60 (size 0x000000c0).
func (*spamRateCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*stashFinderCmd).Run recovered at 0x0000000001cf7e00 (size 0x00000ba0).
func (*stashFinderCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*stashTarget).Options recovered at 0x0000000001cf9d40 (size 0x00000140).
func (*stashTarget) Options() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*stashTarget).Type recovered at 0x0000000001cf9d20 (size 0x00000020).
func (*stashTarget) Type() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/utility.(*teleportCmd).Run recovered at 0x0000000001cfa5a0 (size 0x00000460).
func (*teleportCmd) Run() {
	panic("stub")
}
