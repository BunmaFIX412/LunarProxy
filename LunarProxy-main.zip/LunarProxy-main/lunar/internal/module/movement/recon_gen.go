// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package movement

// Recovered types (from pclntab type descriptors).

// autoElytraCmd is a recovered type.
type autoElytraCmd struct{}

// autoRocketCmd is a recovered type.
type autoRocketCmd struct{}

// autoRocketIntervalCmd is a recovered type.
type autoRocketIntervalCmd struct{}

// bunnyHopCmd is a recovered type.
type bunnyHopCmd struct{}

// motionFlyCmd is a recovered type.
type motionFlyCmd struct{}

// speedModule is a recovered type.
type speedModule struct{}

// stepCmd is a recovered type.
type stepCmd struct{}

// waterWalkCmd is a recovered type.
type waterWalkCmd struct{}

// Placeholder receiver types (no equality descriptor in pclntab).

type __autoElytraModule__ConfigSection_ModuleSection struct{}

type __autoRocketModule__ConfigSection_ModuleSection struct{}

type __bunnyHopModule__ConfigSection_ModuleSection struct{}

type __motionFlyModule__ConfigSection_ModuleSection struct{}

type __speedModule__ConfigSection_ModuleSection struct{}

type __stepModule__ConfigSection_ModuleSection struct{}

type airJumpCmd struct{}

type airJumpModule struct{}

type autoElytraModule struct{}

type autoRocketModule struct{}

type autoRocketSetting struct{}

type bunnyHopModule struct{}

type flyCmd struct{}

type flyModule struct{}

type jetpackCmd struct{}

type jetpackModule struct{}

type jumpBoostEffect struct{}

type levitateEffect struct{}

type motionFlyModule struct{}

type phaseCmd struct{}

type phaseModule struct{}

type slowFallingEffect struct{}

type speedAmountCmd struct{}

type speedOffCmd struct{}

type stepHeightCmd struct{}

type stepModule struct{}

type tapTPModule struct{}

type tapTpCmd struct{}

type waterWalkModule struct{}

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// Register recovered at 0x0000000001ce9120 (size 0x00001d60).
func Register() {
	panic("stub")
}

// newAirJumpModule recovered at 0x0000000001ce66c0 (size 0x00000080).
func newAirJumpModule() {
	panic("stub")
}

// newAutoElytraModule recovered at 0x0000000001ce6880 (size 0x00000080).
func newAutoElytraModule() {
	panic("stub")
}

// newAutoRocketModule recovered at 0x0000000001ce6f00 (size 0x00000080).
func newAutoRocketModule() {
	panic("stub")
}

// newBunnyHopModule recovered at 0x0000000001ce77c0 (size 0x00000080).
func newBunnyHopModule() {
	panic("stub")
}

// newFlyModule recovered at 0x0000000001ce7f20 (size 0x00000080).
func newFlyModule() {
	panic("stub")
}

// newJetpackModule recovered at 0x0000000001ce8100 (size 0x00000080).
func newJetpackModule() {
	panic("stub")
}

// newJumpBoostModule recovered at 0x0000000001ce82e0 (size 0x00000160).
func newJumpBoostModule() {
	panic("stub")
}

// newLevitateModule recovered at 0x0000000001ce8480 (size 0x00000160).
func newLevitateModule() {
	panic("stub")
}

// newMotionFlyModule recovered at 0x0000000001ce8620 (size 0x00000080).
func newMotionFlyModule() {
	panic("stub")
}

// newPhaseModule recovered at 0x0000000001ce8f20 (size 0x00000080).
func newPhaseModule() {
	panic("stub")
}

// newSlowFallingModule recovered at 0x0000000001ceae80 (size 0x00000160).
func newSlowFallingModule() {
	panic("stub")
}

// newSpeedModule recovered at 0x0000000001ceb020 (size 0x00000080).
func newSpeedModule() {
	panic("stub")
}

// newStepModule recovered at 0x0000000001ceb7c0 (size 0x00000080).
func newStepModule() {
	panic("stub")
}

// newTapTPModule recovered at 0x0000000001cebec0 (size 0x00000080).
func newTapTPModule() {
	panic("stub")
}

// newWaterWalkModule recovered at 0x0000000001cec080 (size 0x00000080).
func newWaterWalkModule() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.((*autoElytraModule).ConfigSection.ModuleSection).Section recovered at 0x0000000001ce69c0 (size 0x00000060).
func (__autoElytraModule__ConfigSection_ModuleSection) Section() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.((*autoRocketModule).ConfigSection.ModuleSection).Section recovered at 0x0000000001ce7040 (size 0x00000060).
func (__autoRocketModule__ConfigSection_ModuleSection) Section() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.((*bunnyHopModule).ConfigSection.ModuleSection).Section recovered at 0x0000000001ce7900 (size 0x00000060).
func (__bunnyHopModule__ConfigSection_ModuleSection) Section() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.((*motionFlyModule).ConfigSection.ModuleSection).Section recovered at 0x0000000001ce8760 (size 0x00000060).
func (__motionFlyModule__ConfigSection_ModuleSection) Section() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.((*speedModule).ConfigSection.ModuleSection).Section recovered at 0x0000000001ceb160 (size 0x00000060).
func (__speedModule__ConfigSection_ModuleSection) Section() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.((*stepModule).ConfigSection.ModuleSection).Section recovered at 0x0000000001ceb900 (size 0x00000060).
func (__stepModule__ConfigSection_ModuleSection) Section() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*airJumpCmd).Run recovered at 0x0000000001ce67e0 (size 0x000000a0).
func (*airJumpCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*airJumpModule).Enabled recovered at 0x0000000001ce6780 (size 0x00000020).
func (*airJumpModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*airJumpModule).Meta recovered at 0x0000000001ce6740 (size 0x00000040).
func (*airJumpModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*airJumpModule).SetEnabled recovered at 0x0000000001ce67a0 (size 0x00000020).
func (*airJumpModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*airJumpModule).Sync recovered at 0x0000000001ce67c0 (size 0x00000020).
func (*airJumpModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*autoElytraCmd).Run recovered at 0x0000000001ce6a80 (size 0x00000120).
func (*autoElytraCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*autoElytraModule).ApplyClickUI recovered at 0x0000000001ce6e00 (size 0x00000100).
func (*autoElytraModule) ApplyClickUI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*autoElytraModule).ClickUIFields recovered at 0x0000000001ce6ba0 (size 0x00000260).
func (*autoElytraModule) ClickUIFields() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*autoElytraModule).ConfigSection recovered at 0x0000000001ce6940 (size 0x00000080).
func (*autoElytraModule) ConfigSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*autoElytraModule).Enabled recovered at 0x0000000001ce6a20 (size 0x00000020).
func (*autoElytraModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*autoElytraModule).Meta recovered at 0x0000000001ce6900 (size 0x00000040).
func (*autoElytraModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*autoElytraModule).SetEnabled recovered at 0x0000000001ce6a40 (size 0x00000020).
func (*autoElytraModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*autoElytraModule).Sync recovered at 0x0000000001ce6a60 (size 0x00000020).
func (*autoElytraModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*autoRocketCmd).Run recovered at 0x0000000001ce7420 (size 0x00000120).
func (*autoRocketCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*autoRocketIntervalCmd).Run recovered at 0x0000000001ce7540 (size 0x00000200).
func (*autoRocketIntervalCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*autoRocketModule).ApplyClickUI recovered at 0x0000000001ce7340 (size 0x000000e0).
func (*autoRocketModule) ApplyClickUI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*autoRocketModule).ClickUIFields recovered at 0x0000000001ce7100 (size 0x00000240).
func (*autoRocketModule) ClickUIFields() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*autoRocketModule).ConfigSection recovered at 0x0000000001ce6fc0 (size 0x00000080).
func (*autoRocketModule) ConfigSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*autoRocketModule).Enabled recovered at 0x0000000001ce70a0 (size 0x00000020).
func (*autoRocketModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*autoRocketModule).Meta recovered at 0x0000000001ce6f80 (size 0x00000040).
func (*autoRocketModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*autoRocketModule).SetEnabled recovered at 0x0000000001ce70c0 (size 0x00000020).
func (*autoRocketModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*autoRocketModule).Sync recovered at 0x0000000001ce70e0 (size 0x00000020).
func (*autoRocketModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*autoRocketSetting).Options recovered at 0x0000000001ce7760 (size 0x00000060).
func (*autoRocketSetting) Options() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*autoRocketSetting).Type recovered at 0x0000000001ce7740 (size 0x00000020).
func (*autoRocketSetting) Type() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*bunnyHopCmd).Run recovered at 0x0000000001ce79c0 (size 0x00000120).
func (*bunnyHopCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*bunnyHopModule).ApplyClickUI recovered at 0x0000000001ce7e60 (size 0x000000c0).
func (*bunnyHopModule) ApplyClickUI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*bunnyHopModule).ClickUIFields recovered at 0x0000000001ce7ae0 (size 0x00000380).
func (*bunnyHopModule) ClickUIFields() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*bunnyHopModule).ConfigSection recovered at 0x0000000001ce7880 (size 0x00000080).
func (*bunnyHopModule) ConfigSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*bunnyHopModule).Enabled recovered at 0x0000000001ce7960 (size 0x00000020).
func (*bunnyHopModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*bunnyHopModule).Meta recovered at 0x0000000001ce7840 (size 0x00000040).
func (*bunnyHopModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*bunnyHopModule).SetEnabled recovered at 0x0000000001ce7980 (size 0x00000020).
func (*bunnyHopModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*bunnyHopModule).Sync recovered at 0x0000000001ce79a0 (size 0x00000020).
func (*bunnyHopModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*flyCmd).Run recovered at 0x0000000001ce8060 (size 0x000000a0).
func (*flyCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*flyModule).Enabled recovered at 0x0000000001ce7fe0 (size 0x00000020).
func (*flyModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*flyModule).Meta recovered at 0x0000000001ce7fa0 (size 0x00000040).
func (*flyModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*flyModule).SetEnabled recovered at 0x0000000001ce8000 (size 0x00000020).
func (*flyModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*flyModule).Sync recovered at 0x0000000001ce8020 (size 0x00000040).
func (*flyModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*jetpackCmd).Run recovered at 0x0000000001ce8220 (size 0x000000c0).
func (*jetpackCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*jetpackModule).Enabled recovered at 0x0000000001ce81c0 (size 0x00000020).
func (*jetpackModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*jetpackModule).Meta recovered at 0x0000000001ce8180 (size 0x00000040).
func (*jetpackModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*jetpackModule).SetEnabled recovered at 0x0000000001ce81e0 (size 0x00000020).
func (*jetpackModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*jetpackModule).Sync recovered at 0x0000000001ce8200 (size 0x00000020).
func (*jetpackModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*jumpBoostEffect).EffectConfig recovered at 0x0000000001ce8440 (size 0x00000040).
func (*jumpBoostEffect) EffectConfig() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*levitateEffect).EffectConfig recovered at 0x0000000001ce85e0 (size 0x00000040).
func (*levitateEffect) EffectConfig() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*motionFlyCmd).Run recovered at 0x0000000001ce8820 (size 0x00000120).
func (*motionFlyCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*motionFlyModule).ApplyClickUI recovered at 0x0000000001ce8e00 (size 0x00000120).
func (*motionFlyModule) ApplyClickUI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*motionFlyModule).ClickUIFields recovered at 0x0000000001ce8940 (size 0x000004c0).
func (*motionFlyModule) ClickUIFields() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*motionFlyModule).ConfigSection recovered at 0x0000000001ce86e0 (size 0x00000080).
func (*motionFlyModule) ConfigSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*motionFlyModule).Enabled recovered at 0x0000000001ce87c0 (size 0x00000020).
func (*motionFlyModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*motionFlyModule).Meta recovered at 0x0000000001ce86a0 (size 0x00000040).
func (*motionFlyModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*motionFlyModule).SetEnabled recovered at 0x0000000001ce87e0 (size 0x00000020).
func (*motionFlyModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*motionFlyModule).Sync recovered at 0x0000000001ce8800 (size 0x00000020).
func (*motionFlyModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*phaseCmd).Run recovered at 0x0000000001ce9060 (size 0x000000c0).
func (*phaseCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*phaseModule).Enabled recovered at 0x0000000001ce8fe0 (size 0x00000020).
func (*phaseModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*phaseModule).Meta recovered at 0x0000000001ce8fa0 (size 0x00000040).
func (*phaseModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*phaseModule).SetEnabled recovered at 0x0000000001ce9000 (size 0x00000020).
func (*phaseModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*phaseModule).Sync recovered at 0x0000000001ce9020 (size 0x00000040).
func (*phaseModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*slowFallingEffect).EffectConfig recovered at 0x0000000001ceafe0 (size 0x00000040).
func (*slowFallingEffect) EffectConfig() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*speedAmountCmd).Run recovered at 0x0000000001ceb3c0 (size 0x000001a0).
func (*speedAmountCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*speedModule).ApplyClickUI recovered at 0x0000000001ceb740 (size 0x00000080).
func (*speedModule) ApplyClickUI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*speedModule).ClickUIFields recovered at 0x0000000001ceb560 (size 0x000001e0).
func (*speedModule) ClickUIFields() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*speedModule).ConfigSection recovered at 0x0000000001ceb0e0 (size 0x00000080).
func (*speedModule) ConfigSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*speedModule).Enabled recovered at 0x0000000001ceb1c0 (size 0x00000020).
func (*speedModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*speedModule).Meta recovered at 0x0000000001ceb0a0 (size 0x00000040).
func (*speedModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*speedModule).SetEnabled recovered at 0x0000000001ceb1e0 (size 0x00000020).
func (*speedModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*speedModule).Sync recovered at 0x0000000001ceb200 (size 0x00000080).
func (*speedModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*speedModule).ToggleMessage recovered at 0x0000000001ceb280 (size 0x00000020).
func (*speedModule) ToggleMessage() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*speedOffCmd).Run recovered at 0x0000000001ceb2a0 (size 0x00000120).
func (*speedOffCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*stepCmd).Run recovered at 0x0000000001ceb9c0 (size 0x00000120).
func (*stepCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*stepHeightCmd).Run recovered at 0x0000000001cebae0 (size 0x00000180).
func (*stepHeightCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*stepModule).ApplyClickUI recovered at 0x0000000001cebe40 (size 0x00000080).
func (*stepModule) ApplyClickUI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*stepModule).ClickUIFields recovered at 0x0000000001cebc60 (size 0x000001e0).
func (*stepModule) ClickUIFields() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*stepModule).ConfigSection recovered at 0x0000000001ceb880 (size 0x00000080).
func (*stepModule) ConfigSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*stepModule).Enabled recovered at 0x0000000001ceb960 (size 0x00000020).
func (*stepModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*stepModule).Meta recovered at 0x0000000001ceb840 (size 0x00000040).
func (*stepModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*stepModule).SetEnabled recovered at 0x0000000001ceb980 (size 0x00000020).
func (*stepModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*stepModule).Sync recovered at 0x0000000001ceb9a0 (size 0x00000020).
func (*stepModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*tapTPModule).Enabled recovered at 0x0000000001cebf80 (size 0x00000020).
func (*tapTPModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*tapTPModule).Meta recovered at 0x0000000001cebf40 (size 0x00000040).
func (*tapTPModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*tapTPModule).SetEnabled recovered at 0x0000000001cebfa0 (size 0x00000020).
func (*tapTPModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*tapTPModule).Sync recovered at 0x0000000001cebfc0 (size 0x00000020).
func (*tapTPModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*tapTpCmd).Run recovered at 0x0000000001cebfe0 (size 0x000000a0).
func (*tapTpCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*waterWalkCmd).Run recovered at 0x0000000001cec1a0 (size 0x00000120).
func (*waterWalkCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*waterWalkModule).Enabled recovered at 0x0000000001cec140 (size 0x00000020).
func (*waterWalkModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*waterWalkModule).Meta recovered at 0x0000000001cec100 (size 0x00000040).
func (*waterWalkModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*waterWalkModule).SetEnabled recovered at 0x0000000001cec160 (size 0x00000020).
func (*waterWalkModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/movement.(*waterWalkModule).Sync recovered at 0x0000000001cec180 (size 0x00000020).
func (*waterWalkModule) Sync() {
	panic("stub")
}
