package fcmd

import (
	"strings"

	"github.com/lunar-bedrock/lunar/lunar/internal/i18n"
	"github.com/lunar-bedrock/lunar/lunar/internal/lcmd"
	"github.com/lunar-bedrock/lunar/lunar/internal/module"
	"github.com/lunar-bedrock/lunar/lunar/player/form"
)

type OnOffToggle struct {
	value bool
	set   func(bool)
}

func (t *OnOffToggle) Type() form.Settings {
	return t
}

func (t *OnOffToggle) Options() []form.Option {
	return []form.Option{
		{Label: "On", Value: "on"},
		{Label: "Off", Value: "off"},
	}
}

type Off struct{}

func (o *Off) Type() form.Settings {
	return o
}

func (o *Off) Options() []form.Option {
	return nil
}

type ClickUIBoolToggle struct {
	value bool
	set   func(bool)
}

func (t *ClickUIBoolToggle) Type() form.Settings {
	return t
}

func (t *ClickUIBoolToggle) Options() []form.Option {
	return []form.Option{
		{Label: "false", Value: "false"},
		{Label: "true", Value: "true"},
	}
}

func RequirePlayer(source lcmd.Source) module.Player {
	p := source.Player()
	if p == nil {
		source.SendCommandOutput("§cThis command can only be used in-game.")
	}
	return p
}

func SetModuleEnabled(m module.Module, enabled bool) {
	if m == nil {
		return
	}
	if m.Enabled() == enabled {
		return
	}
	m.SetEnabled(enabled)
}

func RunModuleToggle(source lcmd.Source, m module.Module, args []string) {
	if m == nil {
		return
	}
	name := m.Meta().Name
	if len(args) == 0 {
		if m.Enabled() {
			SetModuleEnabled(m, false)
			source.SendCommandOutput(i18n.Tr("module_disabled", map[string]any{"Name": name}))
		} else {
			SetModuleEnabled(m, true)
			source.SendCommandOutput(i18n.Tr("module_enabled", map[string]any{"Name": name}))
		}
		return
	}
	switch strings.ToLower(args[0]) {
	case "on", "enable":
		if m.Enabled() {
			source.SendCommandOutput(i18n.Tr("already_enabled", map[string]any{"Name": name, "Command": lcmd.Prefix() + m.Meta().ID + " off"}))
			return
		}
		SetModuleEnabled(m, true)
		source.SendCommandOutput(i18n.Tr("module_enabled", map[string]any{"Name": name}))
	case "off", "disable":
		if !m.Enabled() {
			source.SendCommandOutput(i18n.Tr("already_disabled", map[string]any{"Name": name, "Command": lcmd.Prefix() + m.Meta().ID + " on"}))
			return
		}
		SetModuleEnabled(m, false)
		source.SendCommandOutput(i18n.Tr("module_disabled", map[string]any{"Name": name}))
	case "toggle":
		if m.Enabled() {
			SetModuleEnabled(m, false)
			source.SendCommandOutput(i18n.Tr("module_disabled", map[string]any{"Name": name}))
		} else {
			SetModuleEnabled(m, true)
			source.SendCommandOutput(i18n.Tr("module_enabled", map[string]any{"Name": name}))
		}
	default:
		source.SendCommandOutput("§cUsage: " + lcmd.Prefix() + m.Meta().ID + " [on|off|toggle]")
	}
}

func RunOptionalModuleToggle(source lcmd.Source, id string, args []string) {
	m, ok := module.ByID(id)
	if !ok {
		source.SendCommandOutput("§cUnknown module: " + id)
		return
	}
	RunModuleToggle(source, m, args)
}

func RegisterModule(name string, aliases []string, description string, m module.Module, run func(source lcmd.Source, args []string)) {
	if run == nil {
		run = func(source lcmd.Source, args []string) {
			RunModuleToggle(source, m, args)
		}
	}
	lcmd.RegisterAvailable(lcmd.Command{
		Name:        name,
		Aliases:     aliases,
		Description: description,
		Run:         run,
	})
}

func init() {
	_ = i18n.Tr
}