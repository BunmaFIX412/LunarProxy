package effect

import (
	"strconv"

	"github.com/lunar-bedrock/lunar/lunar/internal/lcmd"
	"github.com/lunar-bedrock/lunar/lunar/internal/module"
	"github.com/lunar-bedrock/lunar/lunar/player/form"
)

type EffectConfig struct {
	ID       uint8
	Name     string
	Duration int32
}

type Effect interface {
	EffectConfig() EffectConfig
	Enabled() bool
	SetEnabled(bool)
}

type LevelEffect interface {
	Effect
	SetLevel(uint8)
	Level() uint8
}

type EffectSection struct {
	enabled *bool
	level   *uint8
}

func NewEffectSection(enabled *bool, level *uint8) EffectSection {
	return EffectSection{enabled: enabled, level: level}
}

func (s EffectSection) Section() any {
	return struct {
		Enabled bool
		Level   uint8
	}{
		Enabled: *s.enabled,
		Level:   *s.level,
	}
}

type effectModule struct {
	meta      module.Meta
	config    EffectConfig
	enabled   bool
	level     uint8
	toggleMsg bool
	prevSync  bool
	player    func() module.Player
}

func New(meta module.Meta, config EffectConfig, player func() module.Player) module.Module {
	return &effectModule{meta: meta, config: config, player: player, level: 1}
}

func (m *effectModule) Meta() module.Meta {
	return m.meta
}

func (m *effectModule) Enabled() bool {
	return m.enabled
}

func (m *effectModule) SetEnabled(enabled bool) {
	m.enabled = enabled
}

func (m *effectModule) ConfigSection() module.ConfigSection {
	return NewEffectSection(&m.enabled, &m.level)
}

func (m *effectModule) Sync(tick module.Tick) {
	if m.player == nil {
		return
	}
	p := m.player()
	if p == nil {
		return
	}
	if m.enabled && !m.prevSync {
		p.SendEffect(m.config.ID, m.level, m.config.Duration)
	}
	if !m.enabled && m.prevSync {
		p.SendRemoveEffect(m.config.ID)
	}
	m.prevSync = m.enabled
}

func (m *effectModule) ToggleMessage() bool {
	return m.toggleMsg
}

func (m *effectModule) SetToggleMessage(v bool) {
	m.toggleMsg = v
}

func (m *effectModule) SetLevel(level uint8) {
	m.level = level
}

func (m *effectModule) Level() uint8 {
	return m.level
}

func (m *effectModule) DisableRuntime() {
	m.enabled = false
	if m.player == nil {
		return
	}
	if p := m.player(); p != nil {
		p.SendRemoveEffect(m.config.ID)
	}
}

func (m *effectModule) ClickUIFields() []form.Field {
	return []form.Field{
		form.Bool("enabled", "Enabled", m.enabled, m.SetEnabled),
		form.Int("level", "Level", int(m.level), func(v int) {
			m.level = uint8(v)
		}),
	}
}

func (m *effectModule) ApplyClickUI(fields []form.Field) {
	for _, f := range fields {
		switch t := f.(type) {
		case *form.BoolField:
			m.enabled = t.Value()
		case *form.IntField:
			m.level = uint8(t.Value())
		}
	}
}

type LevelCmd[E LevelEffect] struct {
	get    func() E
	name   string
	aliases []string
}

func NewLevelCmd[E LevelEffect](get func() E, name string, aliases []string) *LevelCmd[E] {
	return &LevelCmd[E]{get: get, name: name, aliases: aliases}
}

func (c *LevelCmd[E]) Run(source lcmd.Source, args []string) {
	e := c.get()
	if len(args) == 0 {
		source.SendCommandOutput("§cUsage: " + lcmd.Prefix() + c.name + " <level>")
		return
	}
	level, err := strconv.ParseUint(args[0], 10, 8)
	if err != nil {
		source.SendCommandOutput("§cInvalid level: " + args[0])
		return
	}
	e.SetLevel(uint8(level))
	e.SetEnabled(true)
	source.SendCommandOutput("§a" + e.EffectConfig().Name + " set to §e" + args[0] + "§a.")
}

type OffCmd[E Effect] struct {
	get    func() E
	name   string
	aliases []string
}

func NewOffCmd[E Effect](get func() E, name string, aliases []string) *OffCmd[E] {
	return &OffCmd[E]{get: get, name: name, aliases: aliases}
}

func (c *OffCmd[E]) Run(source lcmd.Source, args []string) {
	e := c.get()
	e.SetEnabled(false)
	if rd, ok := any(e).(interface{ DisableRuntime() }); ok {
		rd.DisableRuntime()
	}
	source.SendCommandOutput("§c" + e.EffectConfig().Name + " disabled.")
}

func Register[E Effect](get func() E, name string, aliases []string, description string) {
	lcmd.RegisterAvailable(lcmd.Command{
		Name:        name,
		Aliases:     aliases,
		Description: description,
		Run: func(source lcmd.Source, args []string) {
			e := get()
			if len(args) > 0 && args[0] == "off" {
				NewOffCmd(get, name, aliases).Run(source, args[1:])
				return
			}
			if le, ok := any(e).(LevelEffect); ok {
				NewLevelCmd(func() LevelEffect { return le }, name, aliases).Run(source, args)
				return
			}
			NewOffCmd(get, name, aliases).Run(source, args)
		},
	})
}