// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package core

// Recovered types (from pclntab type descriptors).

// configCmd is a recovered type.
type configCmd struct{}

// helpCmd is a recovered type.
type helpCmd struct{}

// languageCmd is a recovered type.
type languageCmd struct{}

// Placeholder receiver types (no equality descriptor in pclntab).

type colorsCmd struct{}

type commandName struct{}

type configMode struct{}

type languageOption struct{}

type pingCmd struct{}

type prefixCmd struct{}

type settingsCmd struct{}

type togglesCmd struct{}

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// Register recovered at 0x0000000001cdd860 (size 0x00000840).
func Register() {
	panic("stub")
}

// languageOptions recovered at 0x0000000001cdc8a0 (size 0x00000380).
func languageOptions() {
	panic("stub")
}

// runConfigDelete recovered at 0x0000000001cd9120 (size 0x00000100).
func runConfigDelete() {
	panic("stub")
}

// runConfigList recovered at 0x0000000001cd9220 (size 0x00000b00).
func runConfigList() {
	panic("stub")
}

// runConfigSave recovered at 0x0000000001cd8c00 (size 0x00000520).
func runConfigSave() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/core.(*colorsCmd).Run recovered at 0x0000000001cd82c0 (size 0x000005a0).
func (*colorsCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/core.(*commandName).Options recovered at 0x0000000001cdc400 (size 0x00000280).
func (*commandName) Options() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/core.(*commandName).Parse recovered at 0x0000000001cdc680 (size 0x00000220).
func (*commandName) Parse() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/core.(*commandName).Type recovered at 0x0000000001cdc3e0 (size 0x00000020).
func (*commandName) Type() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/core.(*configCmd).Run recovered at 0x0000000001cd8860 (size 0x00000300).
func (*configCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/core.(*configMode).Options recovered at 0x0000000001cd8b80 (size 0x00000080).
func (*configMode) Options() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/core.(*configMode).Type recovered at 0x0000000001cd8b60 (size 0x00000020).
func (*configMode) Type() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/core.(*helpCmd).Run recovered at 0x0000000001cd9d20 (size 0x000026c0).
func (*helpCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/core.(*languageCmd).Run recovered at 0x0000000001cdcc20 (size 0x00000400).
func (*languageCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/core.(*languageOption).Options recovered at 0x0000000001cdd040 (size 0x00000260).
func (*languageOption) Options() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/core.(*languageOption).Type recovered at 0x0000000001cdd020 (size 0x00000020).
func (*languageOption) Type() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/core.(*pingCmd).Run recovered at 0x0000000001cdd2a0 (size 0x00000340).
func (*pingCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/core.(*prefixCmd).Run recovered at 0x0000000001cdd5e0 (size 0x00000280).
func (*prefixCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/core.(*settingsCmd).Run recovered at 0x0000000001cde0a0 (size 0x000000a0).
func (*settingsCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/core.(*togglesCmd).Run recovered at 0x0000000001cde140 (size 0x00000080).
func (*togglesCmd) Run() {
	panic("stub")
}
