// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package misc

// Recovered types (from pclntab type descriptors).

// disablerCmd is a recovered type.
type disablerCmd struct{}

// statChangerSetCmd is a recovered type.
type statChangerSetCmd struct{}

// statChangerToggleCmd is a recovered type.
type statChangerToggleCmd struct{}

// timerModule is a recovered type.
type timerModule struct{}

// Placeholder receiver types (no equality descriptor in pclntab).

type __disablerModule__ConfigSection_ModuleSection struct{}

type __nicknameModule__ConfigSection_ModuleSection struct{}

type __timerModule__ConfigSection_ModuleSection struct{}

type disablerMode struct{}

type disablerModule struct{}

type nickClearCmd struct{}

type nickSetCmd struct{}

type nicknameModule struct{}

type statChangerClearCmd struct{}

type statChangerListCmd struct{}

type statChangerModule struct{}

type statChangerRemoveCmd struct{}

type timerOffCmd struct{}

type timerSpeedCmd struct{}

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// Register recovered at 0x0000000001ce44a0 (size 0x00000880).
func Register() {
	panic("stub")
}

// newDisablerModule recovered at 0x0000000001ce2000 (size 0x00000080).
func newDisablerModule() {
	panic("stub")
}

// newNicknameModule recovered at 0x0000000001ce3bc0 (size 0x00000080).
func newNicknameModule() {
	panic("stub")
}

// newStatChangerModule recovered at 0x0000000001ce2a60 (size 0x00000080).
func newStatChangerModule() {
	panic("stub")
}

// newTimerModule recovered at 0x0000000001ce4d20 (size 0x00000080).
func newTimerModule() {
	panic("stub")
}

// sanitizeNick recovered at 0x0000000001ce4340 (size 0x00000160).
func sanitizeNick() {
	panic("stub")
}

// statChangerLineIndex recovered at 0x0000000001ce2e40 (size 0x000000e0).
func statChangerLineIndex() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.((*disablerModule).ConfigSection.ModuleSection).Section recovered at 0x0000000001ce2140 (size 0x00000060).
func (__disablerModule__ConfigSection_ModuleSection) Section() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.((*nicknameModule).ConfigSection.ModuleSection).Section recovered at 0x0000000001ce3d00 (size 0x00000060).
func (__nicknameModule__ConfigSection_ModuleSection) Section() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.((*timerModule).ConfigSection.ModuleSection).Section recovered at 0x0000000001ce4e60 (size 0x00000060).
func (__timerModule__ConfigSection_ModuleSection) Section() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*disablerCmd).Run recovered at 0x0000000001ce2280 (size 0x000003c0).
func (*disablerCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*disablerMode).Options recovered at 0x0000000001ce2660 (size 0x00000080).
func (*disablerMode) Options() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*disablerMode).Type recovered at 0x0000000001ce2640 (size 0x00000020).
func (*disablerMode) Type() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*disablerModule).ApplyClickUI recovered at 0x0000000001ce2980 (size 0x000000e0).
func (*disablerModule) ApplyClickUI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*disablerModule).ClickUIFields recovered at 0x0000000001ce26e0 (size 0x000002a0).
func (*disablerModule) ClickUIFields() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*disablerModule).ConfigSection recovered at 0x0000000001ce20c0 (size 0x00000080).
func (*disablerModule) ConfigSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*disablerModule).Enabled recovered at 0x0000000001ce21a0 (size 0x00000020).
func (*disablerModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*disablerModule).Meta recovered at 0x0000000001ce2080 (size 0x00000040).
func (*disablerModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*disablerModule).SetEnabled recovered at 0x0000000001ce21c0 (size 0x00000080).
func (*disablerModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*disablerModule).Sync recovered at 0x0000000001ce2240 (size 0x00000020).
func (*disablerModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*disablerModule).ToggleMessage recovered at 0x0000000001ce2260 (size 0x00000020).
func (*disablerModule) ToggleMessage() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*nickClearCmd).Run recovered at 0x0000000001ce4260 (size 0x000000e0).
func (*nickClearCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*nickSetCmd).Run recovered at 0x0000000001ce4020 (size 0x00000240).
func (*nickSetCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*nicknameModule).ApplyClickUI recovered at 0x0000000001ce3f60 (size 0x000000c0).
func (*nicknameModule) ApplyClickUI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*nicknameModule).ClickUIFields recovered at 0x0000000001ce3dc0 (size 0x000001a0).
func (*nicknameModule) ClickUIFields() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*nicknameModule).ConfigSection recovered at 0x0000000001ce3c80 (size 0x00000080).
func (*nicknameModule) ConfigSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*nicknameModule).Enabled recovered at 0x0000000001ce3d60 (size 0x00000020).
func (*nicknameModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*nicknameModule).Meta recovered at 0x0000000001ce3c40 (size 0x00000040).
func (*nicknameModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*nicknameModule).SetEnabled recovered at 0x0000000001ce3d80 (size 0x00000020).
func (*nicknameModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*nicknameModule).Sync recovered at 0x0000000001ce3da0 (size 0x00000020).
func (*nicknameModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*statChangerClearCmd).Run recovered at 0x0000000001ce3ae0 (size 0x000000e0).
func (*statChangerClearCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*statChangerListCmd).Run recovered at 0x0000000001ce3500 (size 0x000005e0).
func (*statChangerListCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*statChangerModule).ConfigSection recovered at 0x0000000001ce2b60 (size 0x000000c0).
func (*statChangerModule) ConfigSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*statChangerModule).Enabled recovered at 0x0000000001ce2b20 (size 0x00000020).
func (*statChangerModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*statChangerModule).Meta recovered at 0x0000000001ce2ae0 (size 0x00000040).
func (*statChangerModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*statChangerModule).SetEnabled recovered at 0x0000000001ce2b40 (size 0x00000020).
func (*statChangerModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*statChangerModule).Sync recovered at 0x0000000001ce2ce0 (size 0x00000040).
func (*statChangerModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*statChangerRemoveCmd).Run recovered at 0x0000000001ce32e0 (size 0x00000220).
func (*statChangerRemoveCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*statChangerSetCmd).Run recovered at 0x0000000001ce2f20 (size 0x000003c0).
func (*statChangerSetCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*statChangerToggleCmd).Run recovered at 0x0000000001ce2d20 (size 0x00000120).
func (*statChangerToggleCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*timerModule).ApplyClickUI recovered at 0x0000000001ce5480 (size 0x00000080).
func (*timerModule) ApplyClickUI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*timerModule).ClickUIFields recovered at 0x0000000001ce52a0 (size 0x000001e0).
func (*timerModule) ClickUIFields() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*timerModule).ConfigSection recovered at 0x0000000001ce4de0 (size 0x00000080).
func (*timerModule) ConfigSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*timerModule).Enabled recovered at 0x0000000001ce4ec0 (size 0x00000020).
func (*timerModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*timerModule).Meta recovered at 0x0000000001ce4da0 (size 0x00000040).
func (*timerModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*timerModule).SetEnabled recovered at 0x0000000001ce4ee0 (size 0x00000020).
func (*timerModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*timerModule).Sync recovered at 0x0000000001ce4f00 (size 0x00000080).
func (*timerModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*timerModule).ToggleMessage recovered at 0x0000000001ce4f80 (size 0x00000020).
func (*timerModule) ToggleMessage() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*timerOffCmd).Run recovered at 0x0000000001ce5180 (size 0x00000120).
func (*timerOffCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/misc.(*timerSpeedCmd).Run recovered at 0x0000000001ce4fa0 (size 0x000001e0).
func (*timerSpeedCmd) Run() {
	panic("stub")
}
