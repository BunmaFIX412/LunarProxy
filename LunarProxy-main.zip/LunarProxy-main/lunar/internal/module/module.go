package module

import (
	"sort"

	"github.com/go-gl/mathgl/mgl32"
	"github.com/lunar-bedrock/lunar/lunar/player/form"
)

type Category string

const (
	CategoryCombat   Category = "combat"
	CategoryMovement Category = "movement"
	CategoryVisual   Category = "visual"
	CategoryWorld    Category = "world"
	CategoryUtility  Category = "utility"
	CategoryServer   Category = "server"
	CategoryMisc     Category = "misc"
	CategoryUI       Category = "ui"
	CategoryLifeboat Category = "lifeboat"
)

type Meta struct {
	Name        string
	ID          string
	Description string
	Category    Category
	Premium     bool
}

type Tick struct {
	Number int
	Ctx    Ctx
}

type Ctx struct {
	Player Player
}

type Module interface {
	Meta() Meta
	Enabled() bool
	SetEnabled(bool)
	ConfigSection() ConfigSection
	Sync(tick Tick)
}

type ClickUIModule interface {
	ClickUIFields() []form.Field
	ApplyClickUI(fields []form.Field)
}

type RuntimeDepsModule interface {
	RuntimeDeps() []string
}

type ConfigSection interface {
	Section() any
}

type ModuleSection[S any] struct {
	s *S
}

func NewModuleSection[S any](s *S) ModuleSection[S] {
	return ModuleSection[S]{s: s}
}

func (m ModuleSection[S]) Section() any {
	return m.s
}

var modules = map[string]Module{}

func Register(m Module) {
	modules[m.Meta().ID] = m
}

func All() []Module {
	out := make([]Module, 0, len(modules))
	for _, m := range modules {
		out = append(out, m)
	}
	sort.Slice(out, func(i, j int) bool {
		return out[i].Meta().ID < out[j].Meta().ID
	})
	return out
}

func ByID(id string) (Module, bool) {
	m, ok := modules[id]
	return m, ok
}

func Enabled() []Module {
	var out []Module
	for _, m := range modules {
		if m.Enabled() {
			out = append(out, m)
		}
	}
	sort.Slice(out, func(i, j int) bool {
		return out[i].Meta().ID < out[j].Meta().ID
	})
	return out
}

func EnabledByCategory(cat Category) []Module {
	var out []Module
	for _, m := range modules {
		if m.Enabled() && m.Meta().Category == cat {
			out = append(out, m)
		}
	}
	return out
}

type Entity interface {
	RuntimeID() uint64
	Position() mgl32.Vec3
	Health() float64
	Distance() float64
	IsPlayer() bool
	IsMob() bool
	IsFriend() bool
	Name() string
}

type Item struct {
	Name  string
	Count int
}

type AttackHook func(target Entity)

type Player interface {
	Position() mgl32.Vec3
	LookDirection() mgl32.Vec3
	Yaw() float64
	Pitch() float64
	SetRotation(yaw, pitch float64)
	LookAt(pos mgl32.Vec3)
	OnGround() bool
	IsFalling() bool
	IsSneaking() bool
	IsUsingItem() bool
	IsSwimming() bool
	Health() float64
	MaxHealth() float64
	Food() float64
	SelectedSlot() int
	SetSelectedSlot(int)
	HeldItem() Item
	Items() []Item
	Entities() []Entity
	EntityByRuntimeID(id uint64) (Entity, bool)
	Attack(e Entity)
	SwingArm()
	Interact(e Entity)
	UseItem()
	PlaceBlock(pos mgl32.Vec3, face int)
	FindBlocks(names []string, radius float64) []mgl32.Vec3
	AddPreAttackHook(hook AttackHook) func()
	AddPostAttackHook(hook AttackHook) func()
	SendMessage(msg string)
	SendCommandOutput(msg string)
	ExecuteCommand(cmd string)
	Disconnect(reason string)
	SendEffect(id uint8, level uint8, duration int32)
	SendRemoveEffect(id uint8)
}