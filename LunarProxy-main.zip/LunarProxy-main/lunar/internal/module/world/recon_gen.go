// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package world

// Recovered types (from pclntab type descriptors).

// autoMineModule is a recovered type.
type autoMineModule struct{}

// autoToolSwapCmd is a recovered type.
type autoToolSwapCmd struct{}

// fastInteractCmd is a recovered type.
type fastInteractCmd struct{}

// ghostCmd is a recovered type.
type ghostCmd struct{}

// ghostModule is a recovered type.
type ghostModule struct{}

// scaffoldCmd is a recovered type.
type scaffoldCmd struct{}

// spawnerProtectCmd is a recovered type.
type spawnerProtectCmd struct{}

// Placeholder receiver types (no equality descriptor in pclntab).

type __autoMineModule__ConfigSection_ModuleSection struct{}

type __fastInteractModule__ConfigSection_ModuleSection struct{}

type __ghostModule__ConfigSection_ModuleSection struct{}

type __nukeModule__ConfigSection_ModuleSection struct{}

type __scaffoldModule__ConfigSection_ModuleSection struct{}

type __spawnerProtectModule__ConfigSection_ModuleSection struct{}

type autoMineBlockCmd struct{}

type autoMineFormCmd struct{}

type autoMineToggleCmd struct{}

type autoToolSwapModule struct{}

type fastInteractModule struct{}

type fastInteractSpeedCmd struct{}

type nukeModule struct{}

type nukeSizeCmd struct{}

type nukeToggleCmd struct{}

type scaffoldModule struct{}

type spawnerProtectModule struct{}

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// Register recovered at 0x0000000001d0a480 (size 0x00000de0).
func Register() {
	panic("stub")
}

// init recovered at 0x0000000001d07800 (size 0x00000220).
func init() {
	panic("stub")
}

// newAutoMineModule recovered at 0x0000000001d07a20 (size 0x00000080).
func newAutoMineModule() {
	panic("stub")
}

// newAutoToolSwapModule recovered at 0x0000000001d08b00 (size 0x00000080).
func newAutoToolSwapModule() {
	panic("stub")
}

// newFastInteractModule recovered at 0x0000000001d08d60 (size 0x00000080).
func newFastInteractModule() {
	panic("stub")
}

// newGhostModule recovered at 0x0000000001d094a0 (size 0x000000a0).
func newGhostModule() {
	panic("stub")
}

// newNukeModule recovered at 0x0000000001d09c40 (size 0x00000080).
func newNukeModule() {
	panic("stub")
}

// newScaffoldModule recovered at 0x0000000001d0b260 (size 0x00000080).
func newScaffoldModule() {
	panic("stub")
}

// newSpawnerProtectModule recovered at 0x0000000001d0b860 (size 0x00000080).
func newSpawnerProtectModule() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.((*autoMineModule).ConfigSection.ModuleSection).Section recovered at 0x0000000001d07b60 (size 0x00000060).
func (__autoMineModule__ConfigSection_ModuleSection) Section() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.((*fastInteractModule).ConfigSection.ModuleSection).Section recovered at 0x0000000001d08ea0 (size 0x00000060).
func (__fastInteractModule__ConfigSection_ModuleSection) Section() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.((*ghostModule).ConfigSection.ModuleSection).Section recovered at 0x0000000001d09600 (size 0x00000060).
func (__ghostModule__ConfigSection_ModuleSection) Section() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.((*nukeModule).ConfigSection.ModuleSection).Section recovered at 0x0000000001d09d80 (size 0x00000060).
func (__nukeModule__ConfigSection_ModuleSection) Section() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.((*scaffoldModule).ConfigSection.ModuleSection).Section recovered at 0x0000000001d0b3a0 (size 0x00000060).
func (__scaffoldModule__ConfigSection_ModuleSection) Section() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.((*spawnerProtectModule).ConfigSection.ModuleSection).Section recovered at 0x0000000001d0b9a0 (size 0x00000060).
func (__spawnerProtectModule__ConfigSection_ModuleSection) Section() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*autoMineBlockCmd).Run recovered at 0x0000000001d08040 (size 0x00000180).
func (*autoMineBlockCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*autoMineFormCmd).Run recovered at 0x0000000001d07f00 (size 0x00000080).
func (*autoMineFormCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*autoMineModule).ApplyClickUI recovered at 0x0000000001d08920 (size 0x000001e0).
func (*autoMineModule) ApplyClickUI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*autoMineModule).ClickUIFields recovered at 0x0000000001d081c0 (size 0x00000760).
func (*autoMineModule) ClickUIFields() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*autoMineModule).ConfigSection recovered at 0x0000000001d07ae0 (size 0x00000080).
func (*autoMineModule) ConfigSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*autoMineModule).Enabled recovered at 0x0000000001d07bc0 (size 0x00000020).
func (*autoMineModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*autoMineModule).Meta recovered at 0x0000000001d07aa0 (size 0x00000040).
func (*autoMineModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*autoMineModule).SetEnabled recovered at 0x0000000001d07be0 (size 0x00000020).
func (*autoMineModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*autoMineModule).Sync recovered at 0x0000000001d07c00 (size 0x000000c0).
func (*autoMineModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*autoMineModule).ToggleMessage recovered at 0x0000000001d07cc0 (size 0x00000240).
func (*autoMineModule) ToggleMessage() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*autoMineToggleCmd).Run recovered at 0x0000000001d07f80 (size 0x000000c0).
func (*autoMineToggleCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*autoToolSwapCmd).Run recovered at 0x0000000001d08c20 (size 0x00000140).
func (*autoToolSwapCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*autoToolSwapModule).Enabled recovered at 0x0000000001d08bc0 (size 0x00000020).
func (*autoToolSwapModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*autoToolSwapModule).Meta recovered at 0x0000000001d08b80 (size 0x00000040).
func (*autoToolSwapModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*autoToolSwapModule).SetEnabled recovered at 0x0000000001d08be0 (size 0x00000020).
func (*autoToolSwapModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*autoToolSwapModule).Sync recovered at 0x0000000001d08c00 (size 0x00000020).
func (*autoToolSwapModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*fastInteractCmd).Run recovered at 0x0000000001d08f60 (size 0x00000120).
func (*fastInteractCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*fastInteractModule).ApplyClickUI recovered at 0x0000000001d09400 (size 0x000000a0).
func (*fastInteractModule) ApplyClickUI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*fastInteractModule).ClickUIFields recovered at 0x0000000001d09220 (size 0x000001e0).
func (*fastInteractModule) ClickUIFields() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*fastInteractModule).ConfigSection recovered at 0x0000000001d08e20 (size 0x00000080).
func (*fastInteractModule) ConfigSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*fastInteractModule).Enabled recovered at 0x0000000001d08f00 (size 0x00000020).
func (*fastInteractModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*fastInteractModule).Meta recovered at 0x0000000001d08de0 (size 0x00000040).
func (*fastInteractModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*fastInteractModule).SetEnabled recovered at 0x0000000001d08f20 (size 0x00000020).
func (*fastInteractModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*fastInteractModule).Sync recovered at 0x0000000001d08f40 (size 0x00000020).
func (*fastInteractModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*fastInteractSpeedCmd).Run recovered at 0x0000000001d09080 (size 0x000001a0).
func (*fastInteractSpeedCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*ghostCmd).Run recovered at 0x0000000001d09720 (size 0x00000120).
func (*ghostCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*ghostModule).ApplyClickUI recovered at 0x0000000001d09b00 (size 0x00000140).
func (*ghostModule) ApplyClickUI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*ghostModule).ClickUIFields recovered at 0x0000000001d09840 (size 0x000002c0).
func (*ghostModule) ClickUIFields() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*ghostModule).ConfigSection recovered at 0x0000000001d09580 (size 0x00000080).
func (*ghostModule) ConfigSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*ghostModule).Enabled recovered at 0x0000000001d09660 (size 0x00000020).
func (*ghostModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*ghostModule).Meta recovered at 0x0000000001d09540 (size 0x00000040).
func (*ghostModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*ghostModule).SetEnabled recovered at 0x0000000001d09680 (size 0x00000020).
func (*ghostModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*ghostModule).Sync recovered at 0x0000000001d096a0 (size 0x00000080).
func (*ghostModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*nukeModule).ApplyClickUI recovered at 0x0000000001d0a3a0 (size 0x000000e0).
func (*nukeModule) ApplyClickUI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*nukeModule).ClickUIFields recovered at 0x0000000001d0a1a0 (size 0x00000200).
func (*nukeModule) ClickUIFields() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*nukeModule).ConfigSection recovered at 0x0000000001d09d00 (size 0x00000080).
func (*nukeModule) ConfigSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*nukeModule).Enabled recovered at 0x0000000001d09de0 (size 0x00000020).
func (*nukeModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*nukeModule).Meta recovered at 0x0000000001d09cc0 (size 0x00000040).
func (*nukeModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*nukeModule).SetEnabled recovered at 0x0000000001d09e00 (size 0x00000020).
func (*nukeModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*nukeModule).Sync recovered at 0x0000000001d09e20 (size 0x00000040).
func (*nukeModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*nukeSizeCmd).Run recovered at 0x0000000001d09e60 (size 0x00000240).
func (*nukeSizeCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*nukeToggleCmd).Run recovered at 0x0000000001d0a0a0 (size 0x00000100).
func (*nukeToggleCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*scaffoldCmd).Run recovered at 0x0000000001d0b460 (size 0x00000200).
func (*scaffoldCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*scaffoldModule).ApplyClickUI recovered at 0x0000000001d0b7e0 (size 0x00000080).
func (*scaffoldModule) ApplyClickUI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*scaffoldModule).ClickUIFields recovered at 0x0000000001d0b660 (size 0x00000180).
func (*scaffoldModule) ClickUIFields() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*scaffoldModule).ConfigSection recovered at 0x0000000001d0b320 (size 0x00000080).
func (*scaffoldModule) ConfigSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*scaffoldModule).Enabled recovered at 0x0000000001d0b400 (size 0x00000020).
func (*scaffoldModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*scaffoldModule).Meta recovered at 0x0000000001d0b2e0 (size 0x00000040).
func (*scaffoldModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*scaffoldModule).SetEnabled recovered at 0x0000000001d0b420 (size 0x00000020).
func (*scaffoldModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*scaffoldModule).Sync recovered at 0x0000000001d0b440 (size 0x00000020).
func (*scaffoldModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*spawnerProtectCmd).Run recovered at 0x0000000001d0ba80 (size 0x00000120).
func (*spawnerProtectCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*spawnerProtectModule).ApplyClickUI recovered at 0x0000000001d0c5e0 (size 0x00000300).
func (*spawnerProtectModule) ApplyClickUI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*spawnerProtectModule).ClickUIFields recovered at 0x0000000001d0bba0 (size 0x00000a40).
func (*spawnerProtectModule) ClickUIFields() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*spawnerProtectModule).ConfigSection recovered at 0x0000000001d0b920 (size 0x00000080).
func (*spawnerProtectModule) ConfigSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*spawnerProtectModule).Enabled recovered at 0x0000000001d0ba00 (size 0x00000020).
func (*spawnerProtectModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*spawnerProtectModule).Meta recovered at 0x0000000001d0b8e0 (size 0x00000040).
func (*spawnerProtectModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*spawnerProtectModule).SetEnabled recovered at 0x0000000001d0ba20 (size 0x00000020).
func (*spawnerProtectModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/world.(*spawnerProtectModule).Sync recovered at 0x0000000001d0ba40 (size 0x00000040).
func (*spawnerProtectModule) Sync() {
	panic("stub")
}
