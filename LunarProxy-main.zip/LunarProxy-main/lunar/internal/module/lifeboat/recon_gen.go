// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package lifeboat

// Placeholder receiver types (no equality descriptor in pclntab).

type chestTPCmd struct{}

type spawnerTPCmd struct{}

type surfaceTPCmd struct{}

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// Register recovered at 0x0000000001cdf760 (size 0x000005c0).
func Register() {
	panic("stub")
}

// lifeboatSafeEyePosition recovered at 0x0000000001ce16c0 (size 0x00000460).
func lifeboatSafeEyePosition() {
	panic("stub")
}

// lifeboatSupportBlock recovered at 0x0000000001ce1b20 (size 0x00000360).
func lifeboatSupportBlock() {
	panic("stub")
}

// lifeboatSurfaceCandidateY recovered at 0x0000000001ce0780 (size 0x00000380).
func lifeboatSurfaceCandidateY() {
	panic("stub")
}

// lifeboatTPCandidate.less recovered at 0x0000000001ce1640 (size 0x00000080).
func lifeboatTPCandidate_less() {
	panic("stub")
}

// nearestLifeboatBlockTP recovered at 0x0000000001ce0f20 (size 0x00000420).
func nearestLifeboatBlockTP() {
	panic("stub")
}

// nearestLifeboatSurfaceTP recovered at 0x0000000001ce0100 (size 0x00000680).
func nearestLifeboatSurfaceTP() {
	panic("stub")
}

// runLifeboatBlockTP recovered at 0x0000000001ce0b00 (size 0x00000420).
func runLifeboatBlockTP() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/lifeboat.(*chestTPCmd).Run recovered at 0x0000000001cdf6c0 (size 0x000000a0).
func (*chestTPCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/lifeboat.(*spawnerTPCmd).Run recovered at 0x0000000001cdfd20 (size 0x000000e0).
func (*spawnerTPCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/lifeboat.(*surfaceTPCmd).Run recovered at 0x0000000001cdfe00 (size 0x00000300).
func (*surfaceTPCmd) Run() {
	panic("stub")
}
