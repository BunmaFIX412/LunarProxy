package combat

import (
	"github.com/lunar-bedrock/lunar/lunar/internal/i18n"
	"github.com/lunar-bedrock/lunar/lunar/player/form"
)

type killAuraMode string

const (
	killAuraModeMulti  killAuraMode = "multi"
	killAuraModeSingle killAuraMode = "single"
)

func (m killAuraMode) Type() form.Settings {
	return m
}

func (m killAuraMode) Options() []form.Option {
	return []form.Option{
		{Label: i18n.Tr("killaura_mode_multi"), Value: "multi"},
		{Label: i18n.Tr("killaura_mode_single"), Value: "single"},
	}
}

type killAuraSetting struct {
	m *killAuraModule
}

func (s *killAuraSetting) Type() form.Settings {
	return s
}

func (s *killAuraSetting) Options() []form.Option {
	return []form.Option{
		{Label: "cps", Value: "cps"},
		{Label: "reach", Value: "reach"},
		{Label: "mode", Value: "mode"},
		{Label: "fov", Value: "fov"},
		{Label: "fov degrees", Value: "fov_degrees"},
		{Label: "players", Value: "players"},
		{Label: "weapons only", Value: "weapons_only"},
		{Label: "damage indicator", Value: "damage_indicator"},
		{Label: "stop when eating", Value: "stop_when_eating"},
	}
}

type killAuraModeSetting struct {
	m *killAuraModule
}

func (s *killAuraModeSetting) Type() form.Settings {
	return s
}

func (s *killAuraModeSetting) Options() []form.Option {
	return s.m.modeOptions()
}

type killAuraFormSetting struct {
	m *killAuraModule
}

func (s *killAuraFormSetting) Type() form.Settings {
	return s
}

func (s *killAuraFormSetting) Options() []form.Option {
	return nil
}

type killAuraToggleSetting struct {
	m *killAuraModule
}

func (s *killAuraToggleSetting) Type() form.Settings {
	return s
}

func (s *killAuraToggleSetting) Options() []form.Option {
	return []form.Option{
		{Label: "on", Value: "on"},
		{Label: "off", Value: "off"},
	}
}