package combat

import (
	"github.com/lunar-bedrock/lunar/lunar/internal/i18n"
	"github.com/lunar-bedrock/lunar/lunar/internal/module"
	"github.com/lunar-bedrock/lunar/lunar/player/form"
	"github.com/lunar-bedrock/lunar/lunar/player/settings"
)

type killAuraModule struct {
	settings.KillAura
	target uint64
}

func newKillAuraModule() *killAuraModule {
	return &killAuraModule{KillAura: settings.DefaultSettings().KillAura}
}

func (m *killAuraModule) Meta() module.Meta {
	return module.Meta{
		Name:        "KillAura",
		ID:          "killaura",
		Description: i18n.Tr("cmd_killaura_desc"),
		Category:    module.CategoryCombat,
	}
}

func (m *killAuraModule) Enabled() bool {
	return m.KillAura.Enabled
}

func (m *killAuraModule) SetEnabled(enabled bool) {
	m.KillAura.Enabled = enabled
}

func (m *killAuraModule) ConfigSection() module.ConfigSection {
	return module.NewModuleSection(&m.KillAura)
}

func (m *killAuraModule) RuntimeDeps() []string {
	return []string{"tpaura", "infiniteaura"}
}

func (m *killAuraModule) Sync(tick module.Tick) {
	if !m.KillAura.Enabled {
		return
	}
	p := tick.Ctx.Player
	if p == nil {
		return
	}
	target := m.selectTarget(p)
	if target == nil {
		m.target = 0
		return
	}
	m.target = target.RuntimeID()
	p.SwingArm()
	p.Attack(target)
}

func (m *killAuraModule) selectTarget(p module.Player) module.Entity {
	var best module.Entity
	bestDist := m.KillAura.Distance
	for _, e := range p.Entities() {
		if m.KillAura.Players && !e.IsPlayer() {
			continue
		}
		if e.IsFriend() {
			continue
		}
		if e.Distance() > bestDist {
			continue
		}
		if m.KillAura.FOV && !m.inFOV(p, e) {
			continue
		}
		if m.KillAura.WeaponsOnly && !m.holdingWeapon(p) {
			return nil
		}
		best = e
		bestDist = e.Distance()
	}
	return best
}

func (m *killAuraModule) holdingWeapon(p module.Player) bool {
	switch p.HeldItem().Name {
	case "sword", "axe", "pickaxe", "shovel", "hoe", "trident":
		return true
	}
	return false
}

func (m *killAuraModule) inFOV(p module.Player, e module.Entity) bool {
	to := e.Position().Sub(p.Position()).Normalize()
	look := p.LookDirection().Normalize()
	dot := to.Dot(look)
	deg := m.KillAura.FOVDegrees
	if deg <= 0 {
		return true
	}
	return dot >= cosDeg(deg)
}

func (m *killAuraModule) modeOptions() []form.Option {
	return []form.Option{
		{Label: i18n.Tr("killaura_mode_multi"), Value: "multi"},
		{Label: i18n.Tr("killaura_mode_single"), Value: "single"},
	}
}

func killAuraModeLabel(mode string) string {
	switch mode {
	case "single":
		return i18n.Tr("killaura_mode_single")
	default:
		return i18n.Tr("killaura_mode_multi")
	}
}

func (m *killAuraModule) ClickUIFields() []form.Field {
	s := &m.KillAura
	return []form.Field{
		form.Bool("enabled", i18n.Tr("form_enabled"), s.Enabled, func(v bool) { s.Enabled = v }),
		form.Int("cps", i18n.Tr("killaura_form_cps"), int(s.CPS), func(v int) { s.CPS = uint8(v) }),
		form.Float("distance", i18n.Tr("form_reach"), s.Distance, func(v float64) { s.Distance = v }),
		form.Dropdown("mode", i18n.Tr("killaura_setting_mode"), s.Mode, m.modeOptions(), func(v string) { s.Mode = v }),
		form.Bool("players", i18n.Tr("killaura_form_players"), s.Players, func(v bool) { s.Players = v }),
		form.Bool("weapons_only", i18n.Tr("killaura_form_weapons_only"), s.WeaponsOnly, func(v bool) { s.WeaponsOnly = v }),
		form.Bool("fov", i18n.Tr("killaura_setting_fov"), s.FOV, func(v bool) { s.FOV = v }),
		form.Float("fov_degrees", i18n.Tr("killaura_setting_fov_check"), s.FOVDegrees, func(v float64) { s.FOVDegrees = v }),
		form.Bool("damage_indicator", i18n.Tr("killaura_form_indicator"), s.DamageIndicator, func(v bool) { s.DamageIndicator = v }),
		form.Bool("stop_when_eating", i18n.Tr("form_stop_when_eating"), s.StopWhenEating, func(v bool) { s.StopWhenEating = v }),
	}
}

func (m *killAuraModule) ApplyClickUI(fields []form.Field) {
	for _, f := range fields {
		s := &m.KillAura
		switch t := f.(type) {
		case *form.BoolField:
			switch t.Key() {
			case "enabled":
				s.Enabled = t.Value()
			case "players":
				s.Players = t.Value()
			case "weapons_only":
				s.WeaponsOnly = t.Value()
			case "fov":
				s.FOV = t.Value()
			case "damage_indicator":
				s.DamageIndicator = t.Value()
			case "stop_when_eating":
				s.StopWhenEating = t.Value()
			}
		case *form.IntField:
			if t.Key() == "cps" {
				s.CPS = uint8(t.Value())
			}
		case *form.FloatField:
			switch t.Key() {
			case "distance":
				s.Distance = t.Value()
			case "fov_degrees":
				s.FOVDegrees = t.Value()
			}
		case *form.DropdownField:
			if t.Key() == "mode" {
				s.Mode = t.Value()
			}
		}
	}
}

func cosDeg(deg float64) float32 {
	const rad = 3.141592653589793 / 180.0
	return float32(cos(deg * rad))
}

func cos(x float64) float64 {
	x = x - 2*3.141592653589793*float64(int64(x/(2*3.141592653589793)))
	s, t, u := 1.0, x*x, x*x
	for i := 1; i < 10; i++ {
		s = -s * t / (float64(2*i) * float64(2*i-1))
		u += s
	}
	return u
}

func killAuraStatusMessage(s *settings.KillAura, prefix string) string {
	return i18n.Tr("killaura_status", map[string]any{
		"Enabled":         s.Enabled,
		"CPS":             int(s.CPS),
		"Reach":           s.Distance,
		"Mode":            killAuraModeLabel(s.Mode),
		"FOV":             s.FOV,
		"FOVDegrees":      s.FOVDegrees,
		"Indicator":       s.DamageIndicator,
		"StopWhenEating":  s.StopWhenEating,
		"Prefix":          prefix,
	})
}