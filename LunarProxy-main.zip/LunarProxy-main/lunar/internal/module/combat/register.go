package combat

import (
	"github.com/lunar-bedrock/lunar/lunar/internal/i18n"
	"github.com/lunar-bedrock/lunar/lunar/internal/lcmd"
	"github.com/lunar-bedrock/lunar/lunar/internal/module"
	"github.com/lunar-bedrock/lunar/lunar/internal/module/internal/fcmd"
)

func Register() {
	afkClicker := newAFKClickerModule()
	aimAssist := newAimAssistModule()
	anchorAura := newAnchorAuraModule()
	antiCrystal := newAntiCrystalModule()
	autoClicker := newAutoClickerModule()
	autoCrit := newAutoCritModule()
	autoCrystal := newAutoCrystalModule()
	autoLog := newAutoLogModule()
	autoPotion := newAutoPotionModule()
	autoSwitch := newAutoSwitchModule()
	autoTotem := newAutoTotemModule()
	autoWeb := newAutoWebModule()
	backtrack := newBacktrackModule()
	doubleClick := newDoubleClickModule()
	hitBox := newHitBoxModule()
	killAura := newKillAuraModule()
	knockback := newKnockbackModule()
	maceDamage := newMaceDamageModule()
	maceSwap := newMaceSwapModule()
	reach := newReachModule()
	shieldDisabler := newShieldDisablerModule()
	tpAura := newTPAuraModule()
	triggerBot := newTriggerBotModule()

	for _, m := range []module.Module{
		afkClicker, aimAssist, anchorAura, antiCrystal, autoClicker, autoCrit,
		autoCrystal, autoLog, autoPotion, autoSwitch, autoTotem, autoWeb,
		backtrack, doubleClick, hitBox, killAura, knockback, maceDamage,
		maceSwap, reach, shieldDisabler, tpAura, triggerBot,
	} {
		module.Register(m)
	}

	fcmd.RegisterModule("killaura", []string{"ka"}, i18n.Tr("cmd_killaura_desc"), killAura, (&killAuraCmd{m: killAura}).Run)
	lcmd.RegisterAvailable(lcmd.Command{Name: "killaura mode", Description: "Set KillAura mode", Run: (&killAuraModeCmd{m: killAura}).Run})
	lcmd.RegisterAvailable(lcmd.Command{Name: "killaura settings", Description: "View or change KillAura settings", Run: (&killAuraSettingCmd{m: killAura}).Run})
	lcmd.RegisterAvailable(lcmd.Command{Name: "killaura toggles", Description: "Toggle KillAura settings", Run: (&killAuraToggleSettingCmd{m: killAura}).Run})
	lcmd.RegisterAvailable(lcmd.Command{Name: "killaura ui", Description: "Show KillAura settings", Run: (&killAuraFormCmd{m: killAura}).Run})

	fcmd.RegisterModule("tpaura", nil, i18n.Tr("cmd_tpaura_desc"), tpAura, (&tpAuraCmd{m: tpAura}).Run)
	lcmd.RegisterAvailable(lcmd.Command{Name: "tpaura settings", Description: "Change TPAura settings", Run: (&tpAuraSettingCmd{m: tpAura}).Run})

	fcmd.RegisterModule("afkc", []string{"afkclicker"}, i18n.Tr("cmd_afkclicker_desc"), afkClicker, (&afkClickerCmd{m: afkClicker}).Run)
	lcmd.RegisterAvailable(lcmd.Command{Name: "afkc cps", Description: "Set AFKClicker CPS", Run: (&afkClickerCPSCmd{m: afkClicker}).Run})
	lcmd.RegisterAvailable(lcmd.Command{Name: "afkc crouch", Description: "Toggle AFKClicker crouch", Run: (&afkClickerCrouchCmd{m: afkClicker}).Run})
	lcmd.RegisterAvailable(lcmd.Command{Name: "afkc type", Description: "Set AFKClicker click type", Run: (&afkClickerTypeCmd{m: afkClicker}).Run})

	fcmd.RegisterModule("ac", []string{"autoclicker"}, i18n.Tr("cmd_autoclick_desc"), autoClicker, (&autoClickerCmd{m: autoClicker}).Run)
	lcmd.RegisterAvailable(lcmd.Command{Name: "ac cps", Description: "Set AutoClicker CPS", Run: (&autoClickerCPSCmd{m: autoClicker}).Run})

	fcmd.RegisterModule("aimassist", nil, i18n.Tr("cmd_aimassist_desc"), aimAssist, (&aimAssistCmd{m: aimAssist}).Run)
	fcmd.RegisterModule("anchoraura", nil, i18n.Tr("cmd_anchoraura_desc"), anchorAura, (&anchorAuraCmd{m: anchorAura}).Run)

	fcmd.RegisterModule("anticrystal", nil, i18n.Tr("cmd_anticrystal_desc"), antiCrystal, (&antiCrystalCmd{m: antiCrystal}).Run)
	lcmd.RegisterAvailable(lcmd.Command{Name: "anticrystal ylevel", Description: "Set AntiCrystal Y level", Run: (&antiCrystalYLevelCmd{m: antiCrystal}).Run})

	fcmd.RegisterModule("autocrit", nil, i18n.Tr("cmd_autocrit_desc"), autoCrit, (&autoCritCmd{m: autoCrit}).Run)
	fcmd.RegisterModule("autocrystal", nil, i18n.Tr("cmd_autocrystal_desc"), autoCrystal, (&autoCrystalCmd{m: autoCrystal}).Run)
	fcmd.RegisterModule("autolog", nil, i18n.Tr("cmd_autolog_desc"), autoLog, (&autoLogCmd{m: autoLog}).Run)
	fcmd.RegisterModule("autopot", nil, i18n.Tr("cmd_autopot_desc"), autoPotion, (&autoPotionCmd{m: autoPotion}).Run)
	fcmd.RegisterModule("autoswitch", nil, i18n.Tr("cmd_autoswitch_desc"), autoSwitch, (&autoSwitchCmd{m: autoSwitch}).Run)

	fcmd.RegisterModule("autototem", []string{"at"}, i18n.Tr("cmd_autototem_desc"), autoTotem, (&autoTotemCmd{m: autoTotem}).Run)
	fcmd.RegisterModule("autoweb", nil, i18n.Tr("cmd_autoweb_desc"), autoWeb, (&autoWebCmd{m: autoWeb}).Run)
	fcmd.RegisterModule("backtrack", nil, i18n.Tr("cmd_backtrack_desc"), backtrack, (&backtrackCmd{m: backtrack}).Run)

	fcmd.RegisterModule("doubleclick", nil, i18n.Tr("cmd_doubleclick_desc"), doubleClick, (&doubleClickCmd{m: doubleClick}).Run)
	lcmd.RegisterAvailable(lcmd.Command{Name: "doubleclick min", Description: "Set DoubleClick minimum clicks", Run: (&doubleClickMinMaxCmd{m: doubleClick}).Run})
	lcmd.RegisterAvailable(lcmd.Command{Name: "doubleclick max", Description: "Set DoubleClick maximum clicks", Run: (&doubleClickMinMaxCmd{m: doubleClick}).Run})

	fcmd.RegisterModule("hitbox", nil, i18n.Tr("cmd_hitbox_desc"), hitBox, (&hitBoxToggleCmd{m: hitBox}).Run)
	lcmd.RegisterAvailable(lcmd.Command{Name: "hitbox form", Description: "Show Hitbox settings", Run: (&hitBoxFormCmd{m: hitBox}).Run})
	lcmd.RegisterAvailable(lcmd.Command{Name: "hitbox dimension", Description: "Set Hitbox dimension", Run: (&hitBoxDimensionCmd{m: hitBox}).Run})

	fcmd.RegisterModule("knockback", nil, i18n.Tr("cmd_knockback_desc"), knockback, (&knockbackCmd{m: knockback}).Run)
	lcmd.RegisterAvailable(lcmd.Command{Name: "knockback direction", Description: "Set knockback direction", Run: (&knockbackDirectionCmd{m: knockback}).Run})

	fcmd.RegisterModule("macedmg", nil, i18n.Tr("cmd_macedmg_desc"), maceDamage, (&maceDamageCmd{m: maceDamage}).Run)

	fcmd.RegisterModule("maceswap", nil, i18n.Tr("cmd_maceswap_desc"), maceSwap, (&maceSwapCmd{m: maceSwap}).Run)
	lcmd.RegisterAvailable(lcmd.Command{Name: "maceswap slot", Description: "Set MaceSwap slot", Run: (&maceSwapSlotCmd{m: maceSwap}).Run})

	fcmd.RegisterModule("reach", nil, i18n.Tr("cmd_reach_desc"), reach, (&reachToggleCmd{m: reach}).Run)
	lcmd.RegisterAvailable(lcmd.Command{Name: "reach distance", Description: "Set reach distance", Run: (&reachDistanceCmd{m: reach}).Run})

	fcmd.RegisterModule("shielddisabler", nil, i18n.Tr("cmd_shielddisabler_desc"), shieldDisabler, (&shieldDisablerCmd{m: shieldDisabler}).Run)

	fcmd.RegisterModule("triggerbot", nil, i18n.Tr("cmd_triggerbot_desc"), triggerBot, (&triggerBotCmd{m: triggerBot}).Run)
	lcmd.RegisterAvailable(lcmd.Command{Name: "triggerbot cps", Description: "Set TriggerBot CPS", Run: (&triggerBotCPSCmd{m: triggerBot}).Run})
}