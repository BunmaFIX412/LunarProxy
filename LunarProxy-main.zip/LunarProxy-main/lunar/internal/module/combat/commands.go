package combat

import (
	"math/rand"
	"strconv"
	"strings"

	"github.com/lunar-bedrock/lunar/lunar/internal/i18n"
	"github.com/lunar-bedrock/lunar/lunar/internal/lcmd"
	"github.com/lunar-bedrock/lunar/lunar/internal/module"
	"github.com/lunar-bedrock/lunar/lunar/internal/module/internal/fcmd"
)

type killAuraCmd struct {
	m *killAuraModule
}

func (c *killAuraCmd) Run(source lcmd.Source, args []string) {
	if len(args) > 0 && (args[0] == "on" || args[0] == "enable") {
		if moduleEnabled("tpaura") || moduleEnabled("infiniteaura") {
			source.SendCommandOutput(i18n.Tr("killaura_conflict"))
			return
		}
	}
	fcmd.RunModuleToggle(source, c.m, args)
}

type killAuraModeCmd struct {
	m *killAuraModule
}

func (c *killAuraModeCmd) Run(source lcmd.Source, args []string) {
	if len(args) == 0 {
		source.SendCommandOutput("§cUsage: " + lcmd.Prefix() + "killaura mode <multi|single>")
		return
	}
	mode := strings.ToLower(args[0])
	if mode != "multi" && mode != "single" {
		source.SendCommandOutput("§cInvalid mode: " + args[0])
		return
	}
	c.m.KillAura.Mode = mode
	source.SendCommandOutput(i18n.Tr("killaura_updated"))
}

type killAuraSettingCmd struct {
	m *killAuraModule
}

func (c *killAuraSettingCmd) Run(source lcmd.Source, args []string) {
	if len(args) == 0 {
		source.SendCommandOutput(killAuraStatusMessage(&c.m.KillAura, lcmd.Prefix()))
		return
	}
	setting := strings.ToLower(args[0])
	s := &c.m.KillAura
	switch setting {
	case "cps":
		cps, ok := parseCPSArg(source, args, 1)
		if ok {
			s.CPS = uint8(cps)
		}
	case "reach":
		dist, ok := parseFloatArg(source, args, 1)
		if ok {
			s.Distance = dist
		}
	case "fov_degrees", "fov":
		deg, ok := parseFloatArg(source, args, 1)
		if ok {
			s.FOV = true
			s.FOVDegrees = deg
		}
	default:
		source.SendCommandOutput("§cUnknown setting: " + args[0])
		return
	}
	source.SendCommandOutput(i18n.Tr("killaura_updated"))
}

type killAuraToggleSettingCmd struct {
	m *killAuraModule
}

func (c *killAuraToggleSettingCmd) Run(source lcmd.Source, args []string) {
	if len(args) == 0 {
		source.SendCommandOutput("§cUsage: " + lcmd.Prefix() + "killaura <setting> [on|off]")
		return
	}
	setting := strings.ToLower(args[0])
	value := true
	if len(args) > 1 {
		switch strings.ToLower(args[1]) {
		case "on", "true", "enable":
			value = true
		case "off", "false", "disable":
			value = false
		default:
			source.SendCommandOutput("§cInvalid value: " + args[1])
			return
		}
	}
	s := &c.m.KillAura
	switch setting {
	case "players":
		s.Players = value
	case "weapons_only":
		s.WeaponsOnly = value
	case "fov":
		s.FOV = value
	case "damage_indicator", "indicator":
		s.DamageIndicator = value
	case "stop_when_eating":
		s.StopWhenEating = value
	default:
		source.SendCommandOutput("§cUnknown setting: " + args[0])
		return
	}
	source.SendCommandOutput(i18n.Tr("killaura_updated"))
}

type killAuraFormCmd struct {
	m *killAuraModule
}

func (c *killAuraFormCmd) Run(source lcmd.Source, args []string) {
	fcmd.RequirePlayer(source)
	source.SendCommandOutput(i18n.Tr("killaura_status", map[string]any{
		"Enabled":        c.m.KillAura.Enabled,
		"CPS":            int(c.m.KillAura.CPS),
		"Reach":          c.m.KillAura.Distance,
		"Mode":           killAuraModeLabel(c.m.KillAura.Mode),
		"FOV":            c.m.KillAura.FOV,
		"FOVDegrees":     c.m.KillAura.FOVDegrees,
		"Indicator":      c.m.KillAura.DamageIndicator,
		"StopWhenEating": c.m.KillAura.StopWhenEating,
		"Prefix":         lcmd.Prefix(),
	}))
}

type tpAuraCmd struct {
	m *tpAuraModule
}

func (c *tpAuraCmd) Run(source lcmd.Source, args []string) {
	if len(args) > 0 && (args[0] == "on" || args[0] == "enable") {
		if moduleEnabled("killaura") || moduleEnabled("infiniteaura") {
			source.SendCommandOutput(i18n.Tr("tpaura_conflict"))
			return
		}
	}
	fcmd.RunModuleToggle(source, c.m, args)
}

type tpAuraSettingCmd struct {
	m *tpAuraModule
}

func (c *tpAuraSettingCmd) Run(source lcmd.Source, args []string) {
	if len(args) == 0 {
		source.SendCommandOutput("§cUsage: " + lcmd.Prefix() + "tpaura <cps|reach|height|stop_when_eating>")
		return
	}
	setting := strings.ToLower(args[0])
	s := &c.m.TPAura
	switch setting {
	case "cps":
		cps, ok := parseCPSArg(source, args, 1)
		if ok {
			s.CPS = uint8(cps)
		}
	case "reach":
		dist, ok := parseFloatArg(source, args, 1)
		if ok {
			s.Distance = dist
		}
	case "height":
		value := true
		if len(args) > 1 {
			switch strings.ToLower(args[1]) {
			case "on", "true":
				value = true
			case "off", "false":
				value = false
			default:
				source.SendCommandOutput("§cInvalid value: " + args[1])
				return
			}
		}
		s.Height = value
	case "stop_when_eating":
		s.StopWhenEating = true
	default:
		source.SendCommandOutput("§cUnknown setting: " + args[0])
		return
	}
	source.SendCommandOutput(i18n.Tr("tpaura_updated"))
}

type afkClickerCmd struct {
	m *afkClickerModule
}

func (c *afkClickerCmd) Run(source lcmd.Source, args []string) {
	fcmd.RunModuleToggle(source, c.m, args)
}

type afkClickerCPSCmd struct {
	m *afkClickerModule
}

func (c *afkClickerCPSCmd) Run(source lcmd.Source, args []string) {
	if len(args) == 0 {
		source.SendCommandOutput("§cUsage: " + lcmd.Prefix() + "afkc cps <amount>")
		return
	}
	cps, ok := parseCPSArg(source, args, 0)
	if !ok {
		return
	}
	c.m.AFKClicker.CPS = cps
	source.SendCommandOutput(i18n.Tr("afkclicker_updated"))
}

type afkClickerCrouchCmd struct {
	m *afkClickerModule
}

func (c *afkClickerCrouchCmd) Run(source lcmd.Source, args []string) {
	value := !c.m.AFKClicker.Crouch
	if len(args) > 0 {
		switch strings.ToLower(args[0]) {
		case "on", "true", "enable":
			value = true
		case "off", "false", "disable":
			value = false
		default:
			source.SendCommandOutput("§cInvalid value: " + args[0])
			return
		}
	}
	c.m.AFKClicker.Crouch = value
	source.SendCommandOutput(i18n.Tr("afkclicker_updated"))
}

type afkClickerTypeCmd struct {
	m *afkClickerModule
}

func (c *afkClickerTypeCmd) Run(source lcmd.Source, args []string) {
	if len(args) == 0 {
		source.SendCommandOutput("§cUsage: " + lcmd.Prefix() + "afkc type <left|right>")
		return
	}
	clickType := strings.ToLower(args[0])
	if clickType != "left" && clickType != "right" {
		source.SendCommandOutput("§cInvalid click type: " + args[0])
		return
	}
	c.m.AFKClicker.ClickType = clickType
	source.SendCommandOutput(i18n.Tr("afkclicker_updated"))
}

type autoClickerCmd struct {
	m *autoClickerModule
}

func (c *autoClickerCmd) Run(source lcmd.Source, args []string) {
	fcmd.RunModuleToggle(source, c.m, args)
}

type aimAssistCmd struct {
	m *aimAssistModule
}

func (c *aimAssistCmd) Run(source lcmd.Source, args []string) {
	fcmd.RunModuleToggle(source, c.m, args)
}

type anchorAuraCmd struct {
	m *anchorAuraModule
}

func (c *anchorAuraCmd) Run(source lcmd.Source, args []string) {
	fcmd.RunModuleToggle(source, c.m, args)
}

type antiCrystalCmd struct {
	m *antiCrystalModule
}

func (c *antiCrystalCmd) Run(source lcmd.Source, args []string) {
	fcmd.RunModuleToggle(source, c.m, args)
}

type antiCrystalYLevelCmd struct {
	m *antiCrystalModule
}

func (c *antiCrystalYLevelCmd) Run(source lcmd.Source, args []string) {
	if len(args) == 0 {
		source.SendCommandOutput("§cUsage: " + lcmd.Prefix() + "anticrystal <y level>")
		return
	}
	level, err := strconv.ParseFloat(args[0], 64)
	if err != nil {
		source.SendCommandOutput("§cInvalid y level: " + args[0])
		return
	}
	c.m.AntiCrystal.YLevel = level
	source.SendCommandOutput(i18n.Tr("anticrystal_updated"))
}

type autoCritCmd struct {
	m *autoCritModule
}

func (c *autoCritCmd) Run(source lcmd.Source, args []string) {
	fcmd.RunModuleToggle(source, c.m, args)
}

type autoCrystalCmd struct {
	m *autoCrystalModule
}

func (c *autoCrystalCmd) Run(source lcmd.Source, args []string) {
	fcmd.RunModuleToggle(source, c.m, args)
}

type autoLogCmd struct {
	m *autoLogModule
}

func (c *autoLogCmd) Run(source lcmd.Source, args []string) {
	fcmd.RunModuleToggle(source, c.m, args)
}

type autoPotionCmd struct {
	m *autoPotionModule
}

func (c *autoPotionCmd) Run(source lcmd.Source, args []string) {
	fcmd.RunModuleToggle(source, c.m, args)
}

type autoSwitchCmd struct {
	m *autoSwitchModule
}

func (c *autoSwitchCmd) Run(source lcmd.Source, args []string) {
	fcmd.RunModuleToggle(source, c.m, args)
}

type autoTotemCmd struct {
	m *autoTotemModule
}

func (c *autoTotemCmd) Run(source lcmd.Source, args []string) {
	fcmd.RunModuleToggle(source, c.m, args)
}

type autoWebCmd struct {
	m *autoWebModule
}

func (c *autoWebCmd) Run(source lcmd.Source, args []string) {
	fcmd.RunModuleToggle(source, c.m, args)
}

type backtrackCmd struct {
	m *backtrackModule
}

func (c *backtrackCmd) Run(source lcmd.Source, args []string) {
	fcmd.RunModuleToggle(source, c.m, args)
}

type doubleClickCmd struct {
	m *doubleClickModule
}

func (c *doubleClickCmd) Run(source lcmd.Source, args []string) {
	fcmd.RunModuleToggle(source, c.m, args)
}

type doubleClickMinMaxCmd struct {
	m *doubleClickModule
}

func (c *doubleClickMinMaxCmd) Run(source lcmd.Source, args []string) {
	if len(args) < 2 {
		source.SendCommandOutput("§cUsage: " + lcmd.Prefix() + "doubleclick <min|max> <amount>")
		return
	}
	value, err := strconv.Atoi(args[1])
	if err != nil || value < 1 {
		source.SendCommandOutput("§cInvalid amount: " + args[1])
		return
	}
	switch strings.ToLower(args[0]) {
	case "min":
		c.m.DoubleClick.Min = value
	case "max":
		c.m.DoubleClick.Max = value
	default:
		source.SendCommandOutput("§cUsage: " + lcmd.Prefix() + "doubleclick <min|max> <amount>")
		return
	}
	source.SendCommandOutput(i18n.Tr("doubleclick_updated"))
}

type hitBoxFormCmd struct {
	m *hitBoxModule
}

func (c *hitBoxFormCmd) Run(source lcmd.Source, args []string) {
	source.SendCommandOutput(hitBoxStatusMessage(c.m))
}

type hitBoxToggleCmd struct {
	m *hitBoxModule
}

func (c *hitBoxToggleCmd) Run(source lcmd.Source, args []string) {
	fcmd.RunModuleToggle(source, c.m, args)
}

type hitBoxDimensionCmd struct {
	m *hitBoxModule
}

func (c *hitBoxDimensionCmd) Run(source lcmd.Source, args []string) {
	if len(args) == 0 {
		source.SendCommandOutput("§cUsage: " + lcmd.Prefix() + "hitbox dimension <blatant|closet>")
		return
	}
	mode := strings.ToLower(args[0])
	if mode != "blatant" && mode != "closet" {
		source.SendCommandOutput("§cInvalid dimension: " + args[0])
		return
	}
	c.m.HitBox.Mode = mode
	source.SendCommandOutput(i18n.Tr("hitbox_updated"))
}

func hitBoxStatusMessage(m *hitBoxModule) string {
	return "§bHitbox Settings:§r\n- §7Mode:§r " + m.HitBox.Mode +
		"\n- §7Width:§r " + strconv.FormatFloat(m.HitBox.Width, 'g', -1, 64) +
		"\n- §7Height:§r " + strconv.FormatFloat(m.HitBox.Height, 'g', -1, 64)
}

type knockbackCmd struct {
	m *knockbackModule
}

func (c *knockbackCmd) Run(source lcmd.Source, args []string) {
	fcmd.RunModuleToggle(source, c.m, args)
}

type knockbackDirectionCmd struct {
	m *knockbackModule
}

func (c *knockbackDirectionCmd) Run(source lcmd.Source, args []string) {
	if len(args) == 0 {
		source.SendCommandOutput("§cUsage: " + lcmd.Prefix() + "knockback direction <forward|back|left|right|up|down>")
		return
	}
	dir := strings.ToLower(args[0])
	switch dir {
	case "forward", "back", "left", "right", "up", "down":
		c.m.direction = knockbackDirection(dir)
	default:
		source.SendCommandOutput("§cInvalid direction: " + args[0])
		return
	}
	source.SendCommandOutput("§3Knockback direction set to §b" + dir + "§3!")
}

type maceDamageCmd struct {
	m *maceDamageModule
}

func (c *maceDamageCmd) Run(source lcmd.Source, args []string) {
	fcmd.RunModuleToggle(source, c.m, args)
}

type maceSwapCmd struct {
	m *maceSwapModule
}

func (c *maceSwapCmd) Run(source lcmd.Source, args []string) {
	if len(args) > 0 && args[0] == "on" && len(args) > 1 {
		slot, err := strconv.Atoi(args[1])
		if err == nil {
			setMaceSwapSlot(c.m, slot)
			source.SendCommandOutput(i18n.Tr("maceswap_slot_set", map[string]any{"Slot": c.m.MaceSwap.Slot}))
		}
	}
	fcmd.RunModuleToggle(source, c.m, args)
}

type maceSwapSlotCmd struct {
	m *maceSwapModule
}

func (c *maceSwapSlotCmd) Run(source lcmd.Source, args []string) {
	if len(args) == 0 {
		source.SendCommandOutput("§cUsage: " + lcmd.Prefix() + "maceswap slot <1-9>")
		return
	}
	slot, err := strconv.Atoi(args[0])
	if err != nil || slot < 1 || slot > 9 {
		source.SendCommandOutput("§cInvalid slot: " + args[0])
		return
	}
	setMaceSwapSlot(c.m, slot)
	source.SendCommandOutput(i18n.Tr("maceswap_slot_set", map[string]any{"Slot": c.m.MaceSwap.Slot}))
}

type reachDistanceCmd struct {
	m *reachModule
}

func (c *reachDistanceCmd) Run(source lcmd.Source, args []string) {
	if len(args) == 0 {
		source.SendCommandOutput("§cUsage: " + lcmd.Prefix() + "reach <distance>")
		return
	}
	dist, err := strconv.ParseFloat(args[0], 64)
	if err != nil {
		source.SendCommandOutput("§cInvalid distance: " + args[0])
		return
	}
	c.m.Reach.Distance = dist
	source.SendCommandOutput("§3Reach has been set to §b" + strconv.FormatFloat(dist, 'g', -1, 64) + "§3!")
}

type reachToggleCmd struct {
	m *reachModule
}

func (c *reachToggleCmd) Run(source lcmd.Source, args []string) {
	fcmd.RunModuleToggle(source, c.m, args)
}

type shieldDisablerCmd struct {
	m *shieldDisablerModule
}

func (c *shieldDisablerCmd) Run(source lcmd.Source, args []string) {
	fcmd.RunModuleToggle(source, c.m, args)
}

type triggerBotCmd struct {
	m *triggerBotModule
}

func (c *triggerBotCmd) Run(source lcmd.Source, args []string) {
	fcmd.RunModuleToggle(source, c.m, args)
}

type triggerBotCPSCmd struct {
	m *triggerBotModule
}

func (c *triggerBotCPSCmd) Run(source lcmd.Source, args []string) {
	if len(args) == 0 {
		source.SendCommandOutput("§cUsage: " + lcmd.Prefix() + "triggerbot cps <amount>")
		return
	}
	cps, ok := parseCPSArg(source, args, 0)
	if !ok {
		return
	}
	c.m.TriggerBot.CPS = cps
	source.SendCommandOutput(i18n.Tr("triggerbot_updated"))
}

func moduleEnabled(id string) bool {
	m, ok := module.ByID(id)
	return ok && m.Enabled()
}

func parseCPSArg(source lcmd.Source, args []string, index int) (int, bool) {
	if len(args) <= index {
		return 0, false
	}
	cps, err := strconv.Atoi(args[index])
	if err != nil || cps < 1 || cps > 100 {
		source.SendCommandOutput("§cInvalid CPS: " + args[index])
		return 0, false
	}
	return cps, true
}

func parseFloatArg(source lcmd.Source, args []string, index int) (float64, bool) {
	if len(args) <= index {
		source.SendCommandOutput("§cMissing value.")
		return 0, false
	}
	v, err := strconv.ParseFloat(args[index], 64)
	if err != nil {
		source.SendCommandOutput("§cInvalid value: " + args[index])
		return 0, false
	}
	return v, true
}

func parseCPS(s string) (int, bool) {
	cps, err := strconv.Atoi(s)
	if err != nil || cps < 1 || cps > 100 {
		return 0, false
	}
	return cps, true
}

func randBetween(min, max int) int {
	if max <= min {
		return min
	}
	return min + rand.Intn(max-min+1)
}