package combat

import (
	"github.com/lunar-bedrock/lunar/lunar/internal/i18n"
	"github.com/lunar-bedrock/lunar/lunar/internal/module"
	"github.com/lunar-bedrock/lunar/lunar/player/form"
	"github.com/lunar-bedrock/lunar/lunar/player/settings"
)

type tpAuraModule struct {
	settings.TPAura
	target uint64
}

func newTPAuraModule() *tpAuraModule {
	return &tpAuraModule{TPAura: settings.DefaultSettings().TPAura}
}

func (m *tpAuraModule) Meta() module.Meta {
	return module.Meta{
		Name:        "TPAura",
		ID:          "tpaura",
		Description: i18n.Tr("cmd_tpaura_desc"),
		Category:    module.CategoryCombat,
	}
}

func (m *tpAuraModule) Enabled() bool {
	return m.TPAura.Enabled
}

func (m *tpAuraModule) SetEnabled(enabled bool) {
	m.TPAura.Enabled = enabled
}

func (m *tpAuraModule) ConfigSection() module.ConfigSection {
	return module.NewModuleSection(&m.TPAura)
}

func (m *tpAuraModule) RuntimeDeps() []string {
	return []string{"killaura", "infiniteaura"}
}

func (m *tpAuraModule) Sync(tick module.Tick) {
	if !m.TPAura.Enabled {
		return
	}
	p := tick.Ctx.Player
	if p == nil {
		return
	}
	target := m.selectTarget(p)
	if target == nil {
		m.target = 0
		return
	}
	m.target = target.RuntimeID()
	if m.TPAura.Height {
		above := target.Position()
		above[1] += 2.5
		p.LookAt(above)
	} else {
		p.LookAt(target.Position())
	}
	p.SwingArm()
	p.Attack(target)
}

func (m *tpAuraModule) selectTarget(p module.Player) module.Entity {
	var best module.Entity
	bestDist := m.TPAura.Distance
	for _, e := range p.Entities() {
		if !e.IsPlayer() {
			continue
		}
		if e.IsFriend() {
			continue
		}
		if e.Distance() > bestDist {
			continue
		}
		best = e
		bestDist = e.Distance()
	}
	return best
}

func (m *tpAuraModule) ClickUIFields() []form.Field {
	s := &m.TPAura
	return []form.Field{
		form.Bool("enabled", i18n.Tr("form_enabled"), s.Enabled, func(v bool) { s.Enabled = v }),
		form.Int("cps", i18n.Tr("tpaura_form_cps"), int(s.CPS), func(v int) { s.CPS = uint8(v) }),
		form.Float("distance", i18n.Tr("form_reach"), s.Distance, func(v float64) { s.Distance = v }),
		form.Bool("height", i18n.Tr("tpaura_clickui_height"), s.Height, func(v bool) { s.Height = v }),
		form.Bool("stop_when_eating", i18n.Tr("form_stop_when_eating"), s.StopWhenEating, func(v bool) { s.StopWhenEating = v }),
	}
}

func (m *tpAuraModule) ApplyClickUI(fields []form.Field) {
	for _, f := range fields {
		s := &m.TPAura
		switch t := f.(type) {
		case *form.BoolField:
			switch t.Key() {
			case "enabled":
				s.Enabled = t.Value()
			case "height":
				s.Height = t.Value()
			case "stop_when_eating":
				s.StopWhenEating = t.Value()
			}
		case *form.IntField:
			if t.Key() == "cps" {
				s.CPS = uint8(t.Value())
			}
		case *form.FloatField:
			if t.Key() == "distance" {
				s.Distance = t.Value()
			}
		}
	}
}

type tpAuraSetting struct {
	m *tpAuraModule
}

func (s *tpAuraSetting) Type() form.Settings {
	return s
}

func (s *tpAuraSetting) Options() []form.Option {
	return []form.Option{
		{Label: "cps", Value: "cps"},
		{Label: "reach", Value: "reach"},
		{Label: "height", Value: "height"},
		{Label: "stop when eating", Value: "stop_when_eating"},
	}
}