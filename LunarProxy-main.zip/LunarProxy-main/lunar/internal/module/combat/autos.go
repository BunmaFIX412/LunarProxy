package combat

import (
	"github.com/lunar-bedrock/lunar/lunar/internal/i18n"
	"github.com/lunar-bedrock/lunar/lunar/internal/module"
	"github.com/lunar-bedrock/lunar/lunar/player/form"
	"github.com/lunar-bedrock/lunar/lunar/player/settings"
)

type autoCritModule struct {
	settings.AutoCrit
}

func newAutoCritModule() *autoCritModule {
	return &autoCritModule{AutoCrit: settings.DefaultSettings().AutoCrit}
}

func (m *autoCritModule) Meta() module.Meta {
	return module.Meta{
		Name:        "AutoCrit",
		ID:          "autocrit",
		Description: i18n.Tr("cmd_autocrit_desc"),
		Category:    module.CategoryCombat,
	}
}

func (m *autoCritModule) Enabled() bool {
	return m.AutoCrit.Enabled
}

func (m *autoCritModule) SetEnabled(enabled bool) {
	m.AutoCrit.Enabled = enabled
}

func (m *autoCritModule) ConfigSection() module.ConfigSection {
	return module.NewModuleSection(&m.AutoCrit)
}

func (m *autoCritModule) Sync(tick module.Tick) {
	if !m.AutoCrit.Enabled {
		return
	}
	p := tick.Ctx.Player
	if p == nil {
		return
	}
	if !p.OnGround() && !p.IsFalling() {
		return
	}
}

func (m *autoCritModule) ClickUIFields() []form.Field {
	s := &m.AutoCrit
	return []form.Field{
		form.Bool("enabled", i18n.Tr("form_enabled"), s.Enabled, func(v bool) { s.Enabled = v }),
		form.Bool("apply_to_friends", i18n.Tr("autocrit_clickui_apply_friends"), s.ApplyToFriends, func(v bool) { s.ApplyToFriends = v }),
	}
}

func (m *autoCritModule) ApplyClickUI(fields []form.Field) {
	for _, f := range fields {
		s := &m.AutoCrit
		switch t := f.(type) {
		case *form.BoolField:
			switch t.Key() {
			case "enabled":
				s.Enabled = t.Value()
			case "apply_to_friends":
				s.ApplyToFriends = t.Value()
			}
		}
	}
}

type autoLogModule struct {
	settings.AutoLog
	triggered bool
}

func newAutoLogModule() *autoLogModule {
	return &autoLogModule{AutoLog: settings.DefaultSettings().AutoLog}
}

func (m *autoLogModule) Meta() module.Meta {
	return module.Meta{
		Name:        "AutoLog",
		ID:          "autolog",
		Description: i18n.Tr("cmd_autolog_desc"),
		Category:    module.CategoryCombat,
	}
}

func (m *autoLogModule) Enabled() bool {
	return m.AutoLog.Enabled
}

func (m *autoLogModule) SetEnabled(enabled bool) {
	m.AutoLog.Enabled = enabled
	m.triggered = false
}

func (m *autoLogModule) ConfigSection() module.ConfigSection {
	return module.NewModuleSection(&m.AutoLog)
}

func (m *autoLogModule) Sync(tick module.Tick) {
	if !m.AutoLog.Enabled {
		return
	}
	p := tick.Ctx.Player
	if p == nil {
		return
	}
	if m.AutoLog.Hearts <= 0 || p.Health() > m.AutoLog.Hearts*2 {
		return
	}
	if m.triggered {
		return
	}
	m.triggered = true
	if m.AutoLog.Command != "" {
		p.ExecuteCommand(m.AutoLog.Command)
		p.SendMessage(i18n.Tr("autolog_executed_command", map[string]any{"Command": m.AutoLog.Command}))
		return
	}
	p.Disconnect(i18n.Tr("autolog_disconnect"))
}

func (m *autoLogModule) ClickUIFields() []form.Field {
	s := &m.AutoLog
	return []form.Field{
		form.Bool("enabled", i18n.Tr("form_enabled"), s.Enabled, func(v bool) { s.Enabled = v }),
		form.Float("hearts", i18n.Tr("form_health_hearts"), s.Hearts, func(v float64) { s.Hearts = v }),
		form.String("command", i18n.Tr("autolog_clickui_command"), s.Command, func(v string) { s.Command = v }),
	}
}

func (m *autoLogModule) ApplyClickUI(fields []form.Field) {
	for _, f := range fields {
		s := &m.AutoLog
		switch t := f.(type) {
		case *form.BoolField:
			if t.Key() == "enabled" {
				s.Enabled = t.Value()
			}
		case *form.FloatField:
			if t.Key() == "hearts" {
				s.Hearts = t.Value()
			}
		case *form.StringField:
			if t.Key() == "command" {
				s.Command = t.Value()
			}
		}
	}
}

type autoPotionModule struct {
	settings.AutoPotion
	triggered bool
}

func newAutoPotionModule() *autoPotionModule {
	return &autoPotionModule{AutoPotion: settings.DefaultSettings().AutoPotion}
}

func (m *autoPotionModule) Meta() module.Meta {
	return module.Meta{
		Name:        "AutoPotion",
		ID:          "autopot",
		Description: i18n.Tr("cmd_autopot_desc"),
		Category:    module.CategoryCombat,
	}
}

func (m *autoPotionModule) Enabled() bool {
	return m.AutoPotion.Enabled
}

func (m *autoPotionModule) SetEnabled(enabled bool) {
	m.AutoPotion.Enabled = enabled
	m.triggered = false
}

func (m *autoPotionModule) ConfigSection() module.ConfigSection {
	return module.NewModuleSection(&m.AutoPotion)
}

func (m *autoPotionModule) Sync(tick module.Tick) {
	if !m.AutoPotion.Enabled {
		return
	}
	p := tick.Ctx.Player
	if p == nil {
		return
	}
	if m.AutoPotion.Hearts <= 0 || p.Health() > m.AutoPotion.Hearts*2 {
		return
	}
	if m.triggered {
		return
	}
	m.triggered = true
	p.UseItem()
}

func (m *autoPotionModule) ClickUIFields() []form.Field {
	s := &m.AutoPotion
	return []form.Field{
		form.Bool("enabled", i18n.Tr("form_enabled"), s.Enabled, func(v bool) { s.Enabled = v }),
		form.Float("hearts", i18n.Tr("form_health_hearts"), s.Hearts, func(v float64) { s.Hearts = v }),
	}
}

func (m *autoPotionModule) ApplyClickUI(fields []form.Field) {
	for _, f := range fields {
		s := &m.AutoPotion
		switch t := f.(type) {
		case *form.BoolField:
			if t.Key() == "enabled" {
				s.Enabled = t.Value()
			}
		case *form.FloatField:
			if t.Key() == "hearts" {
				s.Hearts = t.Value()
			}
		}
	}
}

type autoSwitchModule struct {
	settings.AutoSwitch
	hits int
}

func newAutoSwitchModule() *autoSwitchModule {
	return &autoSwitchModule{AutoSwitch: settings.DefaultSettings().AutoSwitch}
}

func (m *autoSwitchModule) Meta() module.Meta {
	return module.Meta{
		Name:        "AutoSwitch",
		ID:          "autoswitch",
		Description: i18n.Tr("cmd_autoswitch_desc"),
		Category:    module.CategoryCombat,
	}
}

func (m *autoSwitchModule) Enabled() bool {
	return m.AutoSwitch.Enabled
}

func (m *autoSwitchModule) SetEnabled(enabled bool) {
	m.AutoSwitch.Enabled = enabled
	m.hits = 0
}

func (m *autoSwitchModule) ConfigSection() module.ConfigSection {
	return module.NewModuleSection(&m.AutoSwitch)
}

func (m *autoSwitchModule) Sync(tick module.Tick) {
	if !m.AutoSwitch.Enabled {
		return
	}
	p := tick.Ctx.Player
	if p == nil {
		return
	}
	if m.AutoSwitch.HitsPerSwitch <= 0 {
		return
	}
	hits := m.hits
	if hits > 0 && hits%int(m.AutoSwitch.HitsPerSwitch) == 0 {
		if p.SelectedSlot() == int(m.AutoSwitch.Slot1)-1 {
			p.SetSelectedSlot(int(m.AutoSwitch.Slot2) - 1)
		} else {
			p.SetSelectedSlot(int(m.AutoSwitch.Slot1) - 1)
		}
		m.hits = 0
	}
}

func (m *autoSwitchModule) ClickUIFields() []form.Field {
	s := &m.AutoSwitch
	return []form.Field{
		form.Bool("enabled", i18n.Tr("form_enabled"), s.Enabled, func(v bool) { s.Enabled = v }),
		form.Int("slot1", i18n.Tr("autoswitch_form_slot1"), int(s.Slot1), func(v int) { s.Slot1 = int32(v) }),
		form.Int("slot2", i18n.Tr("autoswitch_form_slot2"), int(s.Slot2), func(v int) { s.Slot2 = int32(v) }),
		form.Int("hits", i18n.Tr("autoswitch_form_hits"), int(s.HitsPerSwitch), func(v int) { s.HitsPerSwitch = int32(v) }),
	}
}

func (m *autoSwitchModule) ApplyClickUI(fields []form.Field) {
	for _, f := range fields {
		s := &m.AutoSwitch
		switch t := f.(type) {
		case *form.BoolField:
			if t.Key() == "enabled" {
				s.Enabled = t.Value()
			}
		case *form.IntField:
			switch t.Key() {
			case "slot1":
				s.Slot1 = int32(t.Value())
			case "slot2":
				s.Slot2 = int32(t.Value())
			case "hits":
				s.HitsPerSwitch = int32(t.Value())
			}
		}
	}
}

type autoTotemModule struct {
	settings.AutoTotem
	totems int
}

func newAutoTotemModule() *autoTotemModule {
	return &autoTotemModule{AutoTotem: settings.DefaultSettings().AutoTotem}
}

func (m *autoTotemModule) Meta() module.Meta {
	return module.Meta{
		Name:        "AutoTotem",
		ID:          "autototem",
		Description: i18n.Tr("cmd_autototem_desc"),
		Category:    module.CategoryCombat,
	}
}

func (m *autoTotemModule) Enabled() bool {
	return m.AutoTotem.Enabled
}

func (m *autoTotemModule) SetEnabled(enabled bool) {
	m.AutoTotem.Enabled = enabled
}

func (m *autoTotemModule) ConfigSection() module.ConfigSection {
	return module.NewModuleSection(&m.AutoTotem)
}

func (m *autoTotemModule) Sync(tick module.Tick) {
	if !m.AutoTotem.Enabled {
		return
	}
	p := tick.Ctx.Player
	if p == nil {
		return
	}
	if m.AutoTotem.Hearts > 0 && p.Health() > m.AutoTotem.Hearts*2 {
		return
	}
	if m.AutoTotem.Delay > 0 && tick.Number%m.AutoTotem.Delay != 0 {
		return
	}
	m.equipTotem(p)
}

func (m *autoTotemModule) equipTotem(p module.Player) {
	for i, item := range p.Items() {
		if item.Name != "totem_of_undying" || i == p.SelectedSlot() {
			continue
		}
		p.SetSelectedSlot(i)
		m.totems = item.Count
		if m.AutoTotem.ShowCounter {
			p.SendMessage(i18n.Tr("autototem_counter", map[string]any{"Count": m.totems}))
		}
		return
	}
}

func (m *autoTotemModule) ClickUIFields() []form.Field {
	s := &m.AutoTotem
	return []form.Field{
		form.Bool("enabled", i18n.Tr("form_enabled"), s.Enabled, func(v bool) { s.Enabled = v }),
		form.Bool("show_counter", i18n.Tr("autototem_clickui_counter"), s.ShowCounter, func(v bool) { s.ShowCounter = v }),
		form.Int("delay", i18n.Tr("autototem_clickui_delay"), s.Delay, func(v int) { s.Delay = v }),
		form.Float("hearts", i18n.Tr("autototem_form_hearts"), s.Hearts, func(v float64) { s.Hearts = v }),
	}
}

func (m *autoTotemModule) ApplyClickUI(fields []form.Field) {
	for _, f := range fields {
		s := &m.AutoTotem
		switch t := f.(type) {
		case *form.BoolField:
			switch t.Key() {
			case "enabled":
				s.Enabled = t.Value()
			case "show_counter":
				s.ShowCounter = t.Value()
			}
		case *form.IntField:
			if t.Key() == "delay" {
				s.Delay = t.Value()
			}
		case *form.FloatField:
			if t.Key() == "hearts" {
				s.Hearts = t.Value()
			}
		}
	}
}

type autoWebModule struct {
	settings.AutoWeb
	hits int
}

func newAutoWebModule() *autoWebModule {
	return &autoWebModule{AutoWeb: settings.DefaultSettings().AutoWeb}
}

func (m *autoWebModule) Meta() module.Meta {
	return module.Meta{
		Name:        "AutoWeb",
		ID:          "autoweb",
		Description: i18n.Tr("cmd_autoweb_desc"),
		Category:    module.CategoryCombat,
	}
}

func (m *autoWebModule) Enabled() bool {
	return m.AutoWeb.Enabled
}

func (m *autoWebModule) SetEnabled(enabled bool) {
	m.AutoWeb.Enabled = enabled
	m.hits = 0
}

func (m *autoWebModule) ConfigSection() module.ConfigSection {
	return module.NewModuleSection(&m.AutoWeb)
}

func (m *autoWebModule) Sync(tick module.Tick) {
	if !m.AutoWeb.Enabled {
		return
	}
	p := tick.Ctx.Player
	if p == nil {
		return
	}
	if m.AutoWeb.HitsPerWeb <= 0 {
		return
	}
	hits := m.hits
	if hits > 0 && hits%m.AutoWeb.HitsPerWeb == 0 {
		for _, e := range p.Entities() {
			if e.IsFriend() {
				continue
			}
			if e.Distance() > m.AutoWeb.Range {
				continue
			}
			pos := e.Position()
			pos[1] -= 0.5
			p.PlaceBlock(pos, 1)
			m.hits = 0
			return
		}
	}
}

func (m *autoWebModule) ClickUIFields() []form.Field {
	s := &m.AutoWeb
	return []form.Field{
		form.Bool("enabled", i18n.Tr("form_enabled"), s.Enabled, func(v bool) { s.Enabled = v }),
		form.Int("hits", i18n.Tr("autoweb_form_hits"), s.HitsPerWeb, func(v int) { s.HitsPerWeb = v }),
		form.Float("range", i18n.Tr("form_reach"), s.Range, func(v float64) { s.Range = v }),
		form.Dropdown("face", i18n.Tr("autoweb_form_face"), s.FaceTarget, faceModeOptions(), func(v string) { s.FaceTarget = v }),
		form.Bool("line_of_sight", i18n.Tr("form_check_line_of_sight"), s.CheckLineOfSight, func(v bool) { s.CheckLineOfSight = v }),
		form.Dropdown("take_from", i18n.Tr("form_take_items_from"), s.TakeFrom, takeFromOptions(), func(v string) { s.TakeFrom = v }),
	}
}

func (m *autoWebModule) ApplyClickUI(fields []form.Field) {
	for _, f := range fields {
		s := &m.AutoWeb
		switch t := f.(type) {
		case *form.BoolField:
			switch t.Key() {
			case "enabled":
				s.Enabled = t.Value()
			case "line_of_sight":
				s.CheckLineOfSight = t.Value()
			}
		case *form.IntField:
			if t.Key() == "hits" {
				s.HitsPerWeb = t.Value()
			}
		case *form.FloatField:
			if t.Key() == "range" {
				s.Range = t.Value()
			}
		case *form.DropdownField:
			switch t.Key() {
			case "face":
				s.FaceTarget = t.Value()
			case "take_from":
				s.TakeFrom = t.Value()
			}
		}
	}
}