package combat

import (
	"github.com/lunar-bedrock/lunar/lunar/internal/i18n"
	"github.com/lunar-bedrock/lunar/lunar/internal/module"
	"github.com/lunar-bedrock/lunar/lunar/player/form"
	"github.com/lunar-bedrock/lunar/lunar/player/settings"
)

type backtrackModule struct {
	settings.Backtrack
	tracking bool
	timer    int
}

func newBacktrackModule() *backtrackModule {
	return &backtrackModule{Backtrack: settings.DefaultSettings().Backtrack}
}

func (m *backtrackModule) Meta() module.Meta {
	return module.Meta{
		Name:        "Backtrack",
		ID:          "backtrack",
		Description: i18n.Tr("cmd_backtrack_desc"),
		Category:    module.CategoryCombat,
	}
}

func (m *backtrackModule) Enabled() bool {
	return m.Backtrack.Enabled
}

func (m *backtrackModule) SetEnabled(enabled bool) {
	m.Backtrack.Enabled = enabled
	m.tracking = false
	m.timer = 0
}

func (m *backtrackModule) ConfigSection() module.ConfigSection {
	return module.NewModuleSection(&m.Backtrack)
}

func (m *backtrackModule) modeOptions() []form.Option {
	return []form.Option{
		{Label: i18n.Tr("backtrack_mode_attack"), Value: "attack"},
		{Label: i18n.Tr("backtrack_mode_range"), Value: "range"},
	}
}

func (m *backtrackModule) Sync(tick module.Tick) {
	if !m.Backtrack.Enabled {
		return
	}
	p := tick.Ctx.Player
	if p == nil {
		return
	}
	near := false
	for _, e := range p.Entities() {
		if e.IsFriend() {
			continue
		}
		if e.Distance() <= m.Backtrack.Range {
			near = true
			break
		}
	}
	if m.Backtrack.TargetMode == "range" {
		if near {
			m.tracking = true
			m.timer = m.Backtrack.TrackingBuffer
		} else if m.timer > 0 {
			m.timer--
		} else {
			m.tracking = false
		}
	} else {
		m.tracking = near
	}
}

func (m *backtrackModule) ClickUIFields() []form.Field {
	s := &m.Backtrack
	return []form.Field{
		form.Bool("enabled", i18n.Tr("form_enabled"), s.Enabled, func(v bool) { s.Enabled = v }),
		form.Int("min", i18n.Tr("backtrack_form_min"), int(s.MinDelay), func(v int) { s.MinDelay = uint16(v) }),
		form.Int("max", i18n.Tr("backtrack_form_max"), int(s.MaxDelay), func(v int) { s.MaxDelay = uint16(v) }),
		form.Bool("esp", i18n.Tr("backtrack_form_esp"), s.ESP, func(v bool) { s.ESP = v }),
		form.Dropdown("mode", i18n.Tr("backtrack_form_mode"), s.TargetMode, m.modeOptions(), func(v string) { s.TargetMode = v }),
		form.Float("range", i18n.Tr("backtrack_form_range"), s.Range, func(v float64) { s.Range = v }),
		form.Int("buffer", i18n.Tr("backtrack_form_buffer"), s.TrackingBuffer, func(v int) { s.TrackingBuffer = v }),
	}
}

func (m *backtrackModule) ApplyClickUI(fields []form.Field) {
	for _, f := range fields {
		s := &m.Backtrack
		switch t := f.(type) {
		case *form.BoolField:
			switch t.Key() {
			case "enabled":
				s.Enabled = t.Value()
			case "esp":
				s.ESP = t.Value()
			}
		case *form.IntField:
			switch t.Key() {
			case "min":
				s.MinDelay = uint16(t.Value())
			case "max":
				s.MaxDelay = uint16(t.Value())
			case "buffer":
				s.TrackingBuffer = t.Value()
			}
		case *form.FloatField:
			if t.Key() == "range" {
				s.Range = t.Value()
			}
		case *form.DropdownField:
			if t.Key() == "mode" {
				s.TargetMode = t.Value()
			}
		}
	}
}

type doubleClickModule struct {
	settings.DoubleClick
	queued        int
	targetID      uint64
	hooksAttached bool
}

func newDoubleClickModule() *doubleClickModule {
	return &doubleClickModule{DoubleClick: settings.DefaultSettings().DoubleClick}
}

func (m *doubleClickModule) Meta() module.Meta {
	return module.Meta{
		Name:        "Double Click",
		ID:          "doubleclick",
		Description: i18n.Tr("cmd_doubleclick_desc"),
		Category:    module.CategoryCombat,
	}
}

func (m *doubleClickModule) Enabled() bool {
	return m.DoubleClick.Enabled
}

func (m *doubleClickModule) SetEnabled(enabled bool) {
	m.DoubleClick.Enabled = enabled
	m.queued = 0
}

func (m *doubleClickModule) ConfigSection() module.ConfigSection {
	return module.NewModuleSection(&m.DoubleClick)
}

func (m *doubleClickModule) RuntimeDeps() []string {
	return []string{"autoclicker", "java"}
}

func (m *doubleClickModule) ensureHooks(p module.Player) {
	if m.hooksAttached {
		return
	}
	m.hooksAttached = true
	p.AddPreAttackHook(func(target module.Entity) {
		if !m.DoubleClick.Enabled {
			return
		}
		m.targetID = target.RuntimeID()
		extra := randBetween(m.DoubleClick.Min, m.DoubleClick.Max)
		if extra < 1 {
			extra = 1
		}
		m.queued += extra
	})
}

func (m *doubleClickModule) Sync(tick module.Tick) {
	if !m.DoubleClick.Enabled {
		return
	}
	p := tick.Ctx.Player
	if p == nil {
		return
	}
	m.ensureHooks(p)
	if m.queued <= 0 {
		return
	}
	target, ok := p.EntityByRuntimeID(m.targetID)
	if !ok {
		m.queued = 0
		return
	}
	m.queued--
	p.SwingArm()
	p.Attack(target)
}

func (m *doubleClickModule) ClickUIFields() []form.Field {
	s := &m.DoubleClick
	return []form.Field{
		form.Bool("enabled", i18n.Tr("form_enabled"), s.Enabled, func(v bool) { s.Enabled = v }),
		form.Int("min", i18n.Tr("doubleclick_form_min"), s.Min, func(v int) { s.Min = v }),
		form.Int("max", i18n.Tr("doubleclick_form_max"), s.Max, func(v int) { s.Max = v }),
	}
}

func (m *doubleClickModule) ApplyClickUI(fields []form.Field) {
	for _, f := range fields {
		s := &m.DoubleClick
		switch t := f.(type) {
		case *form.BoolField:
			if t.Key() == "enabled" {
				s.Enabled = t.Value()
			}
		case *form.IntField:
			switch t.Key() {
			case "min":
				s.Min = t.Value()
			case "max":
				s.Max = t.Value()
			}
		}
	}
}

type hitBoxDimension string

const (
	hitBoxBlatant hitBoxDimension = "blatant"
	hitBoxCloset  hitBoxDimension = "closet"
)

func (d hitBoxDimension) Type() form.Settings {
	return d
}

func (d hitBoxDimension) Options() []form.Option {
	return []form.Option{
		{Label: i18n.Tr("hitbox_mode_blatant"), Value: "blatant"},
		{Label: i18n.Tr("hitbox_mode_closet"), Value: "closet"},
	}
}

type hitBoxModule struct {
	settings.HitBox
}

func newHitBoxModule() *hitBoxModule {
	return &hitBoxModule{HitBox: settings.DefaultSettings().HitBox}
}

func (m *hitBoxModule) Meta() module.Meta {
	return module.Meta{
		Name:        "Hitbox",
		ID:          "hitbox",
		Description: i18n.Tr("cmd_hitbox_desc"),
		Category:    module.CategoryCombat,
	}
}

func (m *hitBoxModule) Enabled() bool {
	return m.HitBox.Enabled
}

func (m *hitBoxModule) SetEnabled(enabled bool) {
	m.HitBox.Enabled = enabled
}

func (m *hitBoxModule) ConfigSection() module.ConfigSection {
	return module.NewModuleSection(&m.HitBox)
}

func (m *hitBoxModule) modeOptions() []form.Option {
	return []form.Option{
		{Label: i18n.Tr("hitbox_mode_blatant"), Value: "blatant"},
		{Label: i18n.Tr("hitbox_mode_closet"), Value: "closet"},
	}
}

func (m *hitBoxModule) Sync(tick module.Tick) {
	if !m.HitBox.Enabled {
		return
	}
}

func (m *hitBoxModule) ClickUIFields() []form.Field {
	s := &m.HitBox
	return []form.Field{
		form.Bool("enabled", i18n.Tr("form_enabled"), s.Enabled, func(v bool) { s.Enabled = v }),
		form.Dropdown("mode", "Mode", s.Mode, m.modeOptions(), func(v string) { s.Mode = v }),
		form.Bool("weapons_only", i18n.Tr("form_weapons_only"), s.WeaponsOnly, func(v bool) { s.WeaponsOnly = v }),
		form.Bool("forward_reach", i18n.Tr("hitbox_form_forward_reach"), s.ForwardReachEnabled, func(v bool) { s.ForwardReachEnabled = v }),
		form.Bool("ignore_friends", i18n.Tr("hitbox_form_ignore_friends"), s.IgnoreFriends, func(v bool) { s.IgnoreFriends = v }),
		form.Float("width", i18n.Tr("hitbox_form_width"), s.Width, func(v float64) { s.Width = v }),
		form.Float("height", i18n.Tr("hitbox_form_height"), s.Height, func(v float64) { s.Height = v }),
	}
}

func (m *hitBoxModule) ApplyClickUI(fields []form.Field) {
	for _, f := range fields {
		s := &m.HitBox
		switch t := f.(type) {
		case *form.BoolField:
			switch t.Key() {
			case "enabled":
				s.Enabled = t.Value()
			case "weapons_only":
				s.WeaponsOnly = t.Value()
			case "forward_reach":
				s.ForwardReachEnabled = t.Value()
			case "ignore_friends":
				s.IgnoreFriends = t.Value()
			}
		case *form.FloatField:
			switch t.Key() {
			case "width":
				s.Width = t.Value()
			case "height":
				s.Height = t.Value()
			}
		case *form.DropdownField:
			if t.Key() == "mode" {
				s.Mode = t.Value()
			}
		}
	}
}

type knockbackDirection string

const (
	knockbackForward knockbackDirection = "forward"
	knockbackBack    knockbackDirection = "back"
	knockbackLeft    knockbackDirection = "left"
	knockbackRight   knockbackDirection = "right"
	knockbackUp      knockbackDirection = "up"
	knockbackDown    knockbackDirection = "down"
)

func (d knockbackDirection) Type() form.Settings {
	return d
}

func (d knockbackDirection) Options() []form.Option {
	return []form.Option{
		{Label: "Forward", Value: "forward"},
		{Label: "Back", Value: "back"},
		{Label: "Left", Value: "left"},
		{Label: "Right", Value: "right"},
		{Label: "Up", Value: "up"},
		{Label: "Down", Value: "down"},
	}
}

type knockbackModule struct {
	settings.Knockback
	direction knockbackDirection
}

func newKnockbackModule() *knockbackModule {
	return &knockbackModule{Knockback: settings.DefaultSettings().Knockback}
}

func (m *knockbackModule) Meta() module.Meta {
	return module.Meta{
		Name:        "Knockback",
		ID:          "knockback",
		Description: i18n.Tr("cmd_knockback_desc"),
		Category:    module.CategoryCombat,
	}
}

func (m *knockbackModule) Enabled() bool {
	return m.Knockback.Enabled
}

func (m *knockbackModule) SetEnabled(enabled bool) {
	m.Knockback.Enabled = enabled
}

func (m *knockbackModule) ConfigSection() module.ConfigSection {
	return module.NewModuleSection(&m.Knockback)
}

func (m *knockbackModule) Sync(tick module.Tick) {
	if !m.Knockback.Enabled {
		return
	}
}

func (m *knockbackModule) ClickUIFields() []form.Field {
	s := &m.Knockback
	return []form.Field{
		form.Bool("enabled", i18n.Tr("form_enabled"), s.Enabled, func(v bool) { s.Enabled = v }),
		form.Float("vertical", "Vertical", float64(s.Vertical), func(v float64) { s.Vertical = float32(v) }),
		form.Float("horizontal", "Horizontal", float64(s.Horizontal), func(v float64) { s.Horizontal = float32(v) }),
		form.Dropdown("direction", "Direction", string(m.direction), m.direction.Options(), func(v string) { m.direction = knockbackDirection(v) }),
	}
}

func (m *knockbackModule) ApplyClickUI(fields []form.Field) {
	for _, f := range fields {
		s := &m.Knockback
		switch t := f.(type) {
		case *form.BoolField:
			if t.Key() == "enabled" {
				s.Enabled = t.Value()
			}
		case *form.FloatField:
			switch t.Key() {
			case "vertical":
				s.Vertical = float32(t.Value())
			case "horizontal":
				s.Horizontal = float32(t.Value())
			}
		case *form.DropdownField:
			if t.Key() == "direction" {
				m.direction = knockbackDirection(t.Value())
			}
		}
	}
}

type maceDamageModule struct {
	settings.JavaMode
}

func newMaceDamageModule() *maceDamageModule {
	return &maceDamageModule{}
}

func (m *maceDamageModule) Meta() module.Meta {
	return module.Meta{
		Name:        "MaceDMG",
		ID:          "macedmg",
		Description: i18n.Tr("cmd_macedmg_desc"),
		Category:    module.CategoryCombat,
	}
}

func (m *maceDamageModule) Enabled() bool {
	return m.JavaMode.Enabled
}

func (m *maceDamageModule) SetEnabled(enabled bool) {
	m.JavaMode.Enabled = enabled
}

func (m *maceDamageModule) ConfigSection() module.ConfigSection {
	return module.NewModuleSection(&m.JavaMode)
}

func (m *maceDamageModule) Sync(tick module.Tick) {
	if !m.JavaMode.Enabled {
		return
	}
	p := tick.Ctx.Player
	if p == nil {
		return
	}
	if p.HeldItem().Name != "mace" || !p.IsFalling() {
		return
	}
}

type maceSwapModule struct {
	settings.MaceSwap
}

func newMaceSwapModule() *maceSwapModule {
	return &maceSwapModule{MaceSwap: settings.DefaultSettings().MaceSwap}
}

func (m *maceSwapModule) Meta() module.Meta {
	return module.Meta{
		Name:        "MaceSwap",
		ID:          "maceswap",
		Description: i18n.Tr("cmd_maceswap_desc"),
		Category:    module.CategoryCombat,
	}
}

func (m *maceSwapModule) Enabled() bool {
	return m.MaceSwap.Enabled
}

func (m *maceSwapModule) SetEnabled(enabled bool) {
	m.MaceSwap.Enabled = enabled
}

func (m *maceSwapModule) ConfigSection() module.ConfigSection {
	return module.NewModuleSection(&m.MaceSwap)
}

func (m *maceSwapModule) Sync(tick module.Tick) {
	if !m.MaceSwap.Enabled {
		return
	}
	p := tick.Ctx.Player
	if p == nil {
		return
	}
	if !p.IsFalling() {
		return
	}
	maceSlot := int(m.MaceSwap.Slot) - 1
	if maceSlot < 0 || maceSlot >= 9 || maceSlot == p.SelectedSlot() {
		return
	}
	p.SetSelectedSlot(maceSlot)
}

func setMaceSwapSlot(m *maceSwapModule, slot int) {
	if slot < 1 {
		slot = 1
	}
	if slot > 9 {
		slot = 9
	}
	m.MaceSwap.Slot = int32(slot)
}

func (m *maceSwapModule) ClickUIFields() []form.Field {
	s := &m.MaceSwap
	return []form.Field{
		form.Bool("enabled", i18n.Tr("form_enabled"), s.Enabled, func(v bool) { s.Enabled = v }),
		form.Int("slot", i18n.Tr("maceswap_form_slot"), int(s.Slot), func(v int) { setMaceSwapSlot(m, v) }),
	}
}

func (m *maceSwapModule) ApplyClickUI(fields []form.Field) {
	for _, f := range fields {
		s := &m.MaceSwap
		switch t := f.(type) {
		case *form.BoolField:
			if t.Key() == "enabled" {
				s.Enabled = t.Value()
			}
		case *form.IntField:
			if t.Key() == "slot" {
				setMaceSwapSlot(m, t.Value())
			}
		}
	}
}

type reachModule struct {
	settings.Reach
}

func newReachModule() *reachModule {
	return &reachModule{Reach: settings.DefaultSettings().Reach}
}

func (m *reachModule) Meta() module.Meta {
	return module.Meta{
		Name:        "Reach",
		ID:          "reach",
		Description: i18n.Tr("cmd_reach_desc"),
		Category:    module.CategoryCombat,
	}
}

func (m *reachModule) Enabled() bool {
	return m.Reach.Enabled
}

func (m *reachModule) SetEnabled(enabled bool) {
	m.Reach.Enabled = enabled
}

func (m *reachModule) ConfigSection() module.ConfigSection {
	return module.NewModuleSection(&m.Reach)
}

func (m *reachModule) Sync(tick module.Tick) {
	if !m.Reach.Enabled {
		return
	}
}

func (m *reachModule) ClickUIFields() []form.Field {
	s := &m.Reach
	return []form.Field{
		form.Bool("enabled", i18n.Tr("form_enabled"), s.Enabled, func(v bool) { s.Enabled = v }),
		form.Float("distance", i18n.Tr("form_reach"), s.Distance, func(v float64) { s.Distance = v }),
	}
}

func (m *reachModule) ApplyClickUI(fields []form.Field) {
	for _, f := range fields {
		s := &m.Reach
		switch t := f.(type) {
		case *form.BoolField:
			if t.Key() == "enabled" {
				s.Enabled = t.Value()
			}
		case *form.FloatField:
			if t.Key() == "distance" {
				s.Distance = t.Value()
			}
		}
	}
}

type shieldDisablerModule struct {
	settings.JavaMode
}

func newShieldDisablerModule() *shieldDisablerModule {
	return &shieldDisablerModule{}
}

func (m *shieldDisablerModule) Meta() module.Meta {
	return module.Meta{
		Name:        "ShieldDisabler",
		ID:          "shielddisabler",
		Description: i18n.Tr("cmd_shielddisabler_desc"),
		Category:    module.CategoryCombat,
	}
}

func (m *shieldDisablerModule) Enabled() bool {
	return m.JavaMode.Enabled
}

func (m *shieldDisablerModule) SetEnabled(enabled bool) {
	m.JavaMode.Enabled = enabled
}

func (m *shieldDisablerModule) ConfigSection() module.ConfigSection {
	return module.NewModuleSection(&m.JavaMode)
}

func (m *shieldDisablerModule) Sync(tick module.Tick) {
	if !m.JavaMode.Enabled {
		return
	}
	p := tick.Ctx.Player
	if p == nil {
		return
	}
	axeSlot := -1
	for i, item := range p.Items() {
		if isAxe(item.Name) {
			axeSlot = i
			break
		}
	}
	if axeSlot < 0 || axeSlot == p.SelectedSlot() {
		return
	}
	for _, e := range p.Entities() {
		if !e.IsPlayer() || e.IsFriend() || e.Distance() > 3.2 {
			continue
		}
		p.SetSelectedSlot(axeSlot)
		p.SwingArm()
		p.Attack(e)
		return
	}
}

func isAxe(name string) bool {
	switch name {
	case "wooden_axe", "stone_axe", "iron_axe", "golden_axe", "diamond_axe", "netherite_axe":
		return true
	}
	return false
}

type triggerBotModule struct {
	settings.TriggerBot
}

func newTriggerBotModule() *triggerBotModule {
	return &triggerBotModule{TriggerBot: settings.DefaultSettings().TriggerBot}
}

func (m *triggerBotModule) Meta() module.Meta {
	return module.Meta{
		Name:        "TriggerBot",
		ID:          "triggerbot",
		Description: i18n.Tr("cmd_triggerbot_desc"),
		Category:    module.CategoryCombat,
	}
}

func (m *triggerBotModule) Enabled() bool {
	return m.TriggerBot.Enabled
}

func (m *triggerBotModule) SetEnabled(enabled bool) {
	m.TriggerBot.Enabled = enabled
}

func (m *triggerBotModule) ConfigSection() module.ConfigSection {
	return module.NewModuleSection(&m.TriggerBot)
}

func (m *triggerBotModule) RuntimeDeps() []string {
	return []string{"spawnerprotect"}
}

func (m *triggerBotModule) Sync(tick module.Tick) {
	if !m.TriggerBot.Enabled {
		return
	}
	p := tick.Ctx.Player
	if p == nil {
		return
	}
	target := m.lookedAt(p)
	if target == nil {
		return
	}
	p.SwingArm()
	p.Attack(target)
}

func (m *triggerBotModule) lookedAt(p module.Player) module.Entity {
	look := p.LookDirection().Normalize()
	pos := p.Position()
	var best module.Entity
	bestDot := 0.9
	for _, e := range p.Entities() {
		if m.TriggerBot.PlayersOnly && !e.IsPlayer() {
			continue
		}
		if m.TriggerBot.WeaponsOnly && !isWeapon(p.HeldItem().Name) {
			return nil
		}
		if e.IsFriend() {
			continue
		}
		to := e.Position().Sub(pos)
		dist := to.Len()
		if dist > 3.2 {
			continue
		}
dot := to.Normalize().Dot(look)
	if float64(dot) > bestDot {
		best = e
		bestDot = float64(dot)
	}
	}
	return best
}

func isWeapon(name string) bool {
	switch name {
	case "sword", "axe", "trident", "mace":
		return true
	}
	return false
}

type aimAssistModule struct {
	settings.AimAssist
	target uint64
}

func newAimAssistModule() *aimAssistModule {
	return &aimAssistModule{AimAssist: settings.DefaultSettings().AimAssist}
}

func (m *aimAssistModule) Meta() module.Meta {
	return module.Meta{
		Name:        "AimAssist",
		ID:          "aimassist",
		Description: i18n.Tr("cmd_aimassist_desc"),
		Category:    module.CategoryCombat,
	}
}

func (m *aimAssistModule) Enabled() bool {
	return m.AimAssist.Enabled
}

func (m *aimAssistModule) SetEnabled(enabled bool) {
	m.AimAssist.Enabled = enabled
}

func (m *aimAssistModule) ConfigSection() module.ConfigSection {
	return module.NewModuleSection(&m.AimAssist)
}

func (m *aimAssistModule) Sync(tick module.Tick) {
	if !m.AimAssist.Enabled {
		return
	}
	p := tick.Ctx.Player
	if p == nil {
		return
	}
	if m.AimAssist.RequireClick && !p.IsUsingItem() {
		return
	}
	target := m.selectTarget(p)
	if target == nil {
		m.target = 0
		return
	}
	m.target = target.RuntimeID()
	p.LookAt(target.Position())
}

func (m *aimAssistModule) selectTarget(p module.Player) module.Entity {
	var best module.Entity
	bestDist := m.AimAssist.Range
	for _, e := range p.Entities() {
		if m.AimAssist.PlayersOnly && !e.IsPlayer() {
			continue
		}
		if m.AimAssist.WeaponsOnly && !isWeapon(p.HeldItem().Name) {
			return nil
		}
		if e.IsFriend() && !m.AimAssist.IncludeFriends {
			continue
		}
		if e.Distance() > bestDist {
			continue
		}
		best = e
		bestDist = e.Distance()
	}
	return best
}

func (m *aimAssistModule) ClickUIFields() []form.Field {
	s := &m.AimAssist
	return []form.Field{
		form.Bool("enabled", i18n.Tr("form_enabled"), s.Enabled, func(v bool) { s.Enabled = v }),
		form.Float("range", i18n.Tr("form_reach"), s.Range, func(v float64) { s.Range = v }),
		form.Bool("require_click", "Require Click", s.RequireClick, func(v bool) { s.RequireClick = v }),
		form.Bool("weapons_only", i18n.Tr("form_weapons_only"), s.WeaponsOnly, func(v bool) { s.WeaponsOnly = v }),
		form.Bool("players_only", i18n.Tr("form_players_only"), s.PlayersOnly, func(v bool) { s.PlayersOnly = v }),
		form.Bool("include_friends", i18n.Tr("aimassist_form_include_friends"), s.IncludeFriends, func(v bool) { s.IncludeFriends = v }),
	}
}

func (m *aimAssistModule) ApplyClickUI(fields []form.Field) {
	for _, f := range fields {
		s := &m.AimAssist
		switch t := f.(type) {
		case *form.BoolField:
			switch t.Key() {
			case "enabled":
				s.Enabled = t.Value()
			case "require_click":
				s.RequireClick = t.Value()
			case "weapons_only":
				s.WeaponsOnly = t.Value()
			case "players_only":
				s.PlayersOnly = t.Value()
			case "include_friends":
				s.IncludeFriends = t.Value()
			}
		case *form.FloatField:
			if t.Key() == "range" {
				s.Range = t.Value()
			}
		}
	}
}