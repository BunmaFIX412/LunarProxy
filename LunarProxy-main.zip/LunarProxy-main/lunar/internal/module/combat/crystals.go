package combat

import (
	"github.com/lunar-bedrock/lunar/lunar/internal/i18n"
	"github.com/lunar-bedrock/lunar/lunar/internal/module"
	"github.com/lunar-bedrock/lunar/lunar/player/form"
	"github.com/lunar-bedrock/lunar/lunar/player/settings"
)

func faceModeOptions() []form.Option {
	return []form.Option{
		{Label: i18n.Tr("face_mode_off"), Value: "off"},
		{Label: i18n.Tr("face_mode_server_side"), Value: "server_side"},
		{Label: i18n.Tr("face_mode_client_side"), Value: "client_side"},
		{Label: i18n.Tr("face_mode_packet_spam"), Value: "packet_spam"},
	}
}

func takeFromOptions() []form.Option {
	return []form.Option{
		{Label: i18n.Tr("take_from_hotbar"), Value: "hotbar"},
		{Label: i18n.Tr("take_from_inventory"), Value: "inventory"},
	}
}

type autoCrystalModule struct {
	settings.AutoCrystal
	hits int
}

func newAutoCrystalModule() *autoCrystalModule {
	return &autoCrystalModule{AutoCrystal: settings.DefaultSettings().AutoCrystal}
}

func (m *autoCrystalModule) Meta() module.Meta {
	return module.Meta{
		Name:        "AutoCrystal",
		ID:          "autocrystal",
		Description: i18n.Tr("cmd_autocrystal_desc"),
		Category:    module.CategoryCombat,
	}
}

func (m *autoCrystalModule) Enabled() bool {
	return m.AutoCrystal.Enabled
}

func (m *autoCrystalModule) SetEnabled(enabled bool) {
	m.AutoCrystal.Enabled = enabled
}

func (m *autoCrystalModule) ConfigSection() module.ConfigSection {
	return module.NewModuleSection(&m.AutoCrystal)
}

func (m *autoCrystalModule) RuntimeDeps() []string {
	return []string{"spawnerprotect"}
}

func (m *autoCrystalModule) Sync(tick module.Tick) {
	if !m.AutoCrystal.Enabled {
		return
	}
	p := tick.Ctx.Player
	if p == nil {
		return
	}
	target := m.selectTarget(p)
	if target == nil {
		return
	}
	if m.AutoCrystal.HeldCrystalOnly && !m.holdingCrystal(p) {
		return
	}
	p.SwingArm()
	p.Attack(target)
}

func (m *autoCrystalModule) holdingCrystal(p module.Player) bool {
	return p.HeldItem().Name == "end_crystal"
}

func (m *autoCrystalModule) selectTarget(p module.Player) module.Entity {
	var best module.Entity
	bestDist := m.AutoCrystal.Range
	for _, e := range p.Entities() {
		if e.Name() != "end_crystal" {
			continue
		}
		if e.Distance() > bestDist {
			continue
		}
		if m.AutoCrystal.CheckLineOfSight && !m.lineOfSight(p, e) {
			continue
		}
		best = e
		bestDist = e.Distance()
	}
	return best
}

func (m *autoCrystalModule) lineOfSight(p module.Player, e module.Entity) bool {
	to := e.Position().Sub(p.Position())
	return p.LookDirection().Dot(to.Normalize()) > 0.2
}

func (m *autoCrystalModule) ClickUIFields() []form.Field {
	s := &m.AutoCrystal
	return []form.Field{
		form.Bool("enabled", i18n.Tr("form_enabled"), s.Enabled, func(v bool) { s.Enabled = v }),
		form.Float("range", i18n.Tr("form_reach"), s.Range, func(v float64) { s.Range = v }),
		form.Bool("autoplace", i18n.Tr("autocrystal_clickui_autoplace"), s.AutoPlace, func(v bool) { s.AutoPlace = v }),
		form.Bool("held_only", i18n.Tr("autocrystal_form_held_only"), s.HeldCrystalOnly, func(v bool) { s.HeldCrystalOnly = v }),
		form.Bool("autoplace_obsidian", i18n.Tr("autocrystal_clickui_autoplace_obsidian"), s.AutoPlaceObsidian, func(v bool) { s.AutoPlaceObsidian = v }),
		form.Bool("esp", i18n.Tr("autocrystal_form_esp"), s.ESP, func(v bool) { s.ESP = v }),
		form.Bool("safe_mode", i18n.Tr("autocrystal_form_safe_mode"), s.SafeMode, func(v bool) { s.SafeMode = v }),
		form.Bool("stop_when_eating", i18n.Tr("form_stop_when_eating"), s.StopWhenEating, func(v bool) { s.StopWhenEating = v }),
		form.Dropdown("face", i18n.Tr("autocrystal_form_face"), s.FaceCrystals, faceModeOptions(), func(v string) { s.FaceCrystals = v }),
		form.Bool("line_of_sight", i18n.Tr("form_check_line_of_sight"), s.CheckLineOfSight, func(v bool) { s.CheckLineOfSight = v }),
		form.Bool("only_own", i18n.Tr("autocrystal_clickui_only_own"), s.OnlyOwnPlaced, func(v bool) { s.OnlyOwnPlaced = v }),
	}
}

func (m *autoCrystalModule) ApplyClickUI(fields []form.Field) {
	for _, f := range fields {
		s := &m.AutoCrystal
		switch t := f.(type) {
		case *form.BoolField:
			switch t.Key() {
			case "enabled":
				s.Enabled = t.Value()
			case "autoplace":
				s.AutoPlace = t.Value()
			case "held_only":
				s.HeldCrystalOnly = t.Value()
			case "autoplace_obsidian":
				s.AutoPlaceObsidian = t.Value()
			case "esp":
				s.ESP = t.Value()
			case "safe_mode":
				s.SafeMode = t.Value()
			case "stop_when_eating":
				s.StopWhenEating = t.Value()
			case "line_of_sight":
				s.CheckLineOfSight = t.Value()
			case "only_own":
				s.OnlyOwnPlaced = t.Value()
			}
		case *form.FloatField:
			if t.Key() == "range" {
				s.Range = t.Value()
			}
		case *form.DropdownField:
			if t.Key() == "face" {
				s.FaceCrystals = t.Value()
			}
		}
	}
}

type anchorAuraModule struct {
	settings.AnchorAura
	target uint64
}

func newAnchorAuraModule() *anchorAuraModule {
	return &anchorAuraModule{AnchorAura: settings.DefaultSettings().AnchorAura}
}

func (m *anchorAuraModule) Meta() module.Meta {
	return module.Meta{
		Name:        "AnchorAura",
		ID:          "anchoraura",
		Description: i18n.Tr("cmd_anchoraura_desc"),
		Category:    module.CategoryCombat,
	}
}

func (m *anchorAuraModule) Enabled() bool {
	return m.AnchorAura.Enabled
}

func (m *anchorAuraModule) SetEnabled(enabled bool) {
	m.AnchorAura.Enabled = enabled
}

func (m *anchorAuraModule) ConfigSection() module.ConfigSection {
	return module.NewModuleSection(&m.AnchorAura)
}

func (m *anchorAuraModule) Sync(tick module.Tick) {
	if !m.AnchorAura.Enabled {
		return
	}
	p := tick.Ctx.Player
	if p == nil {
		return
	}
	target := m.selectTarget(p)
	if target == nil {
		m.target = 0
		return
	}
	m.target = target.RuntimeID()
	anchors := p.FindBlocks([]string{"respawn_anchor"}, m.AnchorAura.Range)
	if len(anchors) == 0 && m.AnchorAura.AutoPlace {
		pos := target.Position()
		pos[1] -= 1
		p.PlaceBlock(pos, 1)
		anchors = p.FindBlocks([]string{"respawn_anchor"}, m.AnchorAura.Range)
	}
	if len(anchors) == 0 {
		return
	}
	p.LookAt(anchors[0])
	p.UseItem()
}

func (m *anchorAuraModule) selectTarget(p module.Player) module.Entity {
	var best module.Entity
	bestDist := m.AnchorAura.Range
	for _, e := range p.Entities() {
		if !m.AnchorAura.IncludeMobs && !e.IsPlayer() {
			continue
		}
		if e.IsFriend() {
			continue
		}
		if e.Distance() > bestDist {
			continue
		}
		best = e
		bestDist = e.Distance()
	}
	return best
}

func (m *anchorAuraModule) ClickUIFields() []form.Field {
	s := &m.AnchorAura
	return []form.Field{
		form.Bool("enabled", i18n.Tr("form_enabled"), s.Enabled, func(v bool) { s.Enabled = v }),
		form.Float("range", i18n.Tr("form_reach"), s.Range, func(v float64) { s.Range = v }),
		form.Bool("autoplace", i18n.Tr("anchoraura_clickui_autoplace"), s.AutoPlace, func(v bool) { s.AutoPlace = v }),
		form.Dropdown("face", i18n.Tr("anchoraura_form_face"), s.FaceAnchors, faceModeOptions(), func(v string) { s.FaceAnchors = v }),
		form.Bool("line_of_sight", i18n.Tr("form_check_line_of_sight"), s.CheckLineOfSight, func(v bool) { s.CheckLineOfSight = v }),
		form.Dropdown("take_from", i18n.Tr("form_take_items_from"), s.TakeFrom, takeFromOptions(), func(v string) { s.TakeFrom = v }),
		form.Bool("include_mobs", i18n.Tr("anchoraura_form_include_mobs"), s.IncludeMobs, func(v bool) { s.IncludeMobs = v }),
		form.Bool("stop_when_eating", i18n.Tr("form_stop_when_eating"), s.StopWhenEating, func(v bool) { s.StopWhenEating = v }),
	}
}

func (m *anchorAuraModule) ApplyClickUI(fields []form.Field) {
	for _, f := range fields {
		s := &m.AnchorAura
		switch t := f.(type) {
		case *form.BoolField:
			switch t.Key() {
			case "enabled":
				s.Enabled = t.Value()
			case "autoplace":
				s.AutoPlace = t.Value()
			case "line_of_sight":
				s.CheckLineOfSight = t.Value()
			case "include_mobs":
				s.IncludeMobs = t.Value()
			case "stop_when_eating":
				s.StopWhenEating = t.Value()
			}
		case *form.FloatField:
			if t.Key() == "range" {
				s.Range = t.Value()
			}
		case *form.DropdownField:
			switch t.Key() {
			case "face":
				s.FaceAnchors = t.Value()
			case "take_from":
				s.TakeFrom = t.Value()
			}
		}
	}
}

type antiCrystalModule struct {
	settings.AntiCrystal
}

func newAntiCrystalModule() *antiCrystalModule {
	return &antiCrystalModule{AntiCrystal: settings.DefaultSettings().AntiCrystal}
}

func (m *antiCrystalModule) Meta() module.Meta {
	return module.Meta{
		Name:        "AntiCrystal",
		ID:          "anticrystal",
		Description: i18n.Tr("cmd_anticrystal_desc"),
		Category:    module.CategoryCombat,
	}
}

func (m *antiCrystalModule) Enabled() bool {
	return m.AntiCrystal.Enabled
}

func (m *antiCrystalModule) SetEnabled(enabled bool) {
	m.AntiCrystal.Enabled = enabled
}

func (m *antiCrystalModule) ConfigSection() module.ConfigSection {
	return module.NewModuleSection(&m.AntiCrystal)
}

func (m *antiCrystalModule) Sync(tick module.Tick) {
	if !m.AntiCrystal.Enabled {
		return
	}
}

func (m *antiCrystalModule) ClickUIFields() []form.Field {
	s := &m.AntiCrystal
	return []form.Field{
		form.Bool("enabled", i18n.Tr("form_enabled"), s.Enabled, func(v bool) { s.Enabled = v }),
		form.Float("ylevel", i18n.Tr("anticrystal_form_ylevel"), s.YLevel, func(v float64) { s.YLevel = v }),
	}
}

func (m *antiCrystalModule) ApplyClickUI(fields []form.Field) {
	for _, f := range fields {
		s := &m.AntiCrystal
		switch t := f.(type) {
		case *form.BoolField:
			if t.Key() == "enabled" {
				s.Enabled = t.Value()
			}
		case *form.FloatField:
			if t.Key() == "ylevel" {
				s.YLevel = t.Value()
			}
		}
	}
}