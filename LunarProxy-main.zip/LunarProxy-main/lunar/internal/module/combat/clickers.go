package combat

import (
	"time"

	"github.com/lunar-bedrock/lunar/lunar/internal/i18n"
	"github.com/lunar-bedrock/lunar/lunar/internal/lcmd"
	"github.com/lunar-bedrock/lunar/lunar/internal/module"
	"github.com/lunar-bedrock/lunar/lunar/player/form"
	"github.com/lunar-bedrock/lunar/lunar/player/settings"
)

type afkClickType string

const (
	afkClickLeft  afkClickType = "left"
	afkClickRight afkClickType = "right"
)

func (t afkClickType) Type() form.Settings {
	return t
}

func (t afkClickType) Options() []form.Option {
	return []form.Option{
		{Label: i18n.Tr("afkclicker_clickui_left"), Value: "left"},
		{Label: i18n.Tr("afkclicker_clickui_right"), Value: "right"},
	}
}

type afkClickerModule struct {
	settings.AFKClicker
	lastClick time.Time
}

func newAFKClickerModule() *afkClickerModule {
	return &afkClickerModule{AFKClicker: settings.DefaultSettings().AFKClicker}
}

func (m *afkClickerModule) Meta() module.Meta {
	return module.Meta{
		Name:        "AFKClicker",
		ID:          "afkclicker",
		Description: i18n.Tr("cmd_afkclicker_desc"),
		Category:    module.CategoryCombat,
	}
}

func (m *afkClickerModule) Enabled() bool {
	return m.AFKClicker.Enabled
}

func (m *afkClickerModule) SetEnabled(enabled bool) {
	m.AFKClicker.Enabled = enabled
	m.lastClick = time.Time{}
}

func (m *afkClickerModule) ConfigSection() module.ConfigSection {
	return module.NewModuleSection(&m.AFKClicker)
}

func (m *afkClickerModule) RuntimeDeps() []string {
	return []string{"spawnerprotect"}
}

func (m *afkClickerModule) Sync(tick module.Tick) {
	if !m.AFKClicker.Enabled {
		return
	}
	p := tick.Ctx.Player
	if p == nil {
		return
	}
	if m.AFKClicker.CPS <= 0 {
		return
	}
	interval := time.Second / time.Duration(m.AFKClicker.CPS)
	now := time.Now()
	if !m.lastClick.IsZero() && now.Sub(m.lastClick) < interval {
		return
	}
	m.lastClick = now
	switch m.AFKClicker.ClickType {
	case "right":
		p.UseItem()
	default:
		for _, e := range p.Entities() {
			if e.Distance() <= 3.2 && p.LookDirection().Dot(e.Position().Sub(p.Position()).Normalize()) > 0.9 {
				p.SwingArm()
				p.Attack(e)
				return
			}
		}
	}
}

func (m *afkClickerModule) clickTypeOptions() []form.Option {
	return []form.Option{
		{Label: i18n.Tr("afkclicker_clickui_left"), Value: "left"},
		{Label: i18n.Tr("afkclicker_clickui_right"), Value: "right"},
	}
}

func (m *afkClickerModule) ClickUIFields() []form.Field {
	s := &m.AFKClicker
	return []form.Field{
		form.Bool("enabled", i18n.Tr("form_enabled"), s.Enabled, func(v bool) { s.Enabled = v }),
		form.Int("cps", i18n.Tr("afkclicker_form_cps"), s.CPS, func(v int) { s.CPS = v }),
		form.Dropdown("clicktype", i18n.Tr("afkclicker_form_clicktype"), s.ClickType, m.clickTypeOptions(), func(v string) { s.ClickType = v }),
		form.Bool("crouch", i18n.Tr("afkclicker_form_crouch"), s.Crouch, func(v bool) { s.Crouch = v }),
	}
}

func (m *afkClickerModule) ApplyClickUI(fields []form.Field) {
	for _, f := range fields {
		s := &m.AFKClicker
		switch t := f.(type) {
		case *form.BoolField:
			switch t.Key() {
			case "enabled":
				s.Enabled = t.Value()
			case "crouch":
				s.Crouch = t.Value()
			}
		case *form.IntField:
			if t.Key() == "cps" {
				s.CPS = t.Value()
			}
		case *form.DropdownField:
			if t.Key() == "clicktype" {
				s.ClickType = t.Value()
			}
		}
	}
}

type afkClickerCPSSetting struct {
	m *afkClickerModule
}

func (s *afkClickerCPSSetting) Type() form.Settings {
	return s
}

func (s *afkClickerCPSSetting) Options() []form.Option {
	return nil
}

type afkClickerCrouchSetting struct {
	m *afkClickerModule
}

func (s *afkClickerCrouchSetting) Type() form.Settings {
	return s
}

func (s *afkClickerCrouchSetting) Options() []form.Option {
	return nil
}

type afkClickerTypeSetting struct {
	m *afkClickerModule
}

func (s *afkClickerTypeSetting) Type() form.Settings {
	return s
}

func (s *afkClickerTypeSetting) Options() []form.Option {
	return s.m.clickTypeOptions()
}

type autoClickerModule struct {
	settings.AutoClicker
	queued        int
	targetID      uint64
	hooksAttached bool
}

func newAutoClickerModule() *autoClickerModule {
	return &autoClickerModule{AutoClicker: settings.DefaultSettings().AutoClicker}
}

func (m *autoClickerModule) Meta() module.Meta {
	return module.Meta{
		Name:        "AutoClicker",
		ID:          "autoclicker",
		Description: i18n.Tr("cmd_autoclick_desc"),
		Category:    module.CategoryCombat,
	}
}

func (m *autoClickerModule) Enabled() bool {
	return m.AutoClicker.Enabled
}

func (m *autoClickerModule) SetEnabled(enabled bool) {
	m.AutoClicker.Enabled = enabled
	m.queued = 0
}

func (m *autoClickerModule) ConfigSection() module.ConfigSection {
	return module.NewModuleSection(&m.AutoClicker)
}

func (m *autoClickerModule) RuntimeDeps() []string {
	return []string{"spawnerprotect"}
}

func (m *autoClickerModule) ensureHooks(p module.Player) {
	if m.hooksAttached {
		return
	}
	m.hooksAttached = true
	p.AddPreAttackHook(func(target module.Entity) {
		if !m.AutoClicker.Enabled {
			return
		}
		m.targetID = target.RuntimeID()
		extra := m.AutoClicker.CPS - 8
		if extra < 0 {
			extra = 0
		}
		m.queued += extra
	})
}

func (m *autoClickerModule) Sync(tick module.Tick) {
	if !m.AutoClicker.Enabled {
		return
	}
	p := tick.Ctx.Player
	if p == nil {
		return
	}
	m.ensureHooks(p)
	if m.queued <= 0 {
		return
	}
	target := m.lastTarget(p)
	if target == nil {
		m.queued = 0
		return
	}
	m.queued--
	p.SwingArm()
	p.Attack(target)
}

func (m *autoClickerModule) lastTarget(p module.Player) module.Entity {
	if m.targetID != 0 {
		if e, ok := p.EntityByRuntimeID(m.targetID); ok {
			return e
		}
	}
	var best module.Entity
	for _, e := range p.Entities() {
		if e.IsFriend() {
			continue
		}
		if best == nil || e.Distance() < best.Distance() {
			best = e
		}
	}
	return best
}

func (m *autoClickerModule) ClickUIFields() []form.Field {
	s := &m.AutoClicker
	return []form.Field{
		form.Bool("enabled", i18n.Tr("form_enabled"), s.Enabled, func(v bool) { s.Enabled = v }),
		form.Int("cps", i18n.Tr("autoclicker_form_cps"), s.CPS, func(v int) { s.CPS = v }),
	}
}

func (m *autoClickerModule) ApplyClickUI(fields []form.Field) {
	for _, f := range fields {
		s := &m.AutoClicker
		switch t := f.(type) {
		case *form.BoolField:
			if t.Key() == "enabled" {
				s.Enabled = t.Value()
			}
		case *form.IntField:
			if t.Key() == "cps" {
				s.CPS = t.Value()
			}
		}
	}
}

type autoClickerCPSCmd struct {
	m *autoClickerModule
}

func (c *autoClickerCPSCmd) Run(source lcmd.Source, args []string) {
	if len(args) == 0 {
		source.SendCommandOutput("§cUsage: " + lcmd.Prefix() + "ac cps <amount>")
		return
	}
	cps, ok := parseCPS(args[0])
	if !ok {
		source.SendCommandOutput("§cInvalid CPS: " + args[0])
		return
	}
	c.m.AutoClicker.CPS = cps
	source.SendCommandOutput(i18n.Tr("autoclicker_updated"))
}