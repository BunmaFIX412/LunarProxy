// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package ui

// Recovered types (from pclntab type descriptors).

// OverlayOption is a recovered type.
type OverlayOption struct{}

// clickUICmd is a recovered type.
type clickUICmd struct{}

// configCreateForm is a recovered type.
type configCreateForm struct{}

// entry·1 is a recovered type.
type entry_1 struct{}

// Placeholder receiver types (no equality descriptor in pclntab).

type clickUICatalog struct{}

type clickUIColor struct{}

type clickUIForm struct{}

type clickUIModuleChanges struct{}

type clickUITheme struct{}

type configConfirmDeleteForm struct{}

type configConfirmOverwriteForm struct{}

type configContentsForm struct{}

type configDetailForm struct{}

type configListForm struct{}

type configRenameForm struct{}

type panelGridForm struct{}

type panelModuleForm struct{}

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// OverlaySnapshotJSON recovered at 0x0000000001c94620 (size 0x000004c0).
func OverlaySnapshotJSON() {
	panic("stub")
}

// Register recovered at 0x0000000001c9a540 (size 0x00000160).
func Register() {
	panic("stub")
}

// SendClickUIForm recovered at 0x0000000001c84e40 (size 0x000000c0).
func SendClickUIForm() {
	panic("stub")
}

// SendConfigForm recovered at 0x0000000001c8ce40 (size 0x00000060).
func SendConfigForm() {
	panic("stub")
}

// SetOverlayModuleEnabled recovered at 0x0000000001c958a0 (size 0x000000e0).
func SetOverlayModuleEnabled() {
	panic("stub")
}

// SetOverlayModuleSetting recovered at 0x0000000001c95980 (size 0x00000860).
func SetOverlayModuleSetting() {
	panic("stub")
}

// buildClickUICatalog recovered at 0x0000000001c8a2e0 (size 0x00000b00).
func buildClickUICatalog() {
	panic("stub")
}

// clickUICategoryDisplayLabel recovered at 0x0000000001c87740 (size 0x00000160).
func clickUICategoryDisplayLabel() {
	panic("stub")
}

// clickUICategoryName recovered at 0x0000000001c852e0 (size 0x000000a0).
func clickUICategoryName() {
	panic("stub")
}

// clickUIDecodeResponse recovered at 0x0000000001c8b1e0 (size 0x000003a0).
func clickUIDecodeResponse() {
	panic("stub")
}

// clickUIFieldControl recovered at 0x0000000001c8b580 (size 0x00001120).
func clickUIFieldControl() {
	panic("stub")
}

// clickUIFieldValueChanged recovered at 0x0000000001c875c0 (size 0x00000180).
func clickUIFieldValueChanged() {
	panic("stub")
}

// clickUIFinalizeValues recovered at 0x0000000001c89d80 (size 0x00000560).
func clickUIFinalizeValues() {
	panic("stub")
}

// clickUIFormatNumber recovered at 0x0000000001c89a00 (size 0x00000080).
func clickUIFormatNumber() {
	panic("stub")
}

// clickUILockedModuleLabel recovered at 0x0000000001c879a0 (size 0x00000360).
func clickUILockedModuleLabel() {
	panic("stub")
}

// clickUILooksLikeDismiss recovered at 0x0000000001c86f80 (size 0x00000140).
func clickUILooksLikeDismiss() {
	panic("stub")
}

// clickUIModuleButtonLabel recovered at 0x0000000001c878a0 (size 0x00000100).
func clickUIModuleButtonLabel() {
	panic("stub")
}

// clickUIModuleEnableControl recovered at 0x0000000001c8c6a0 (size 0x00000280).
func clickUIModuleEnableControl() {
	panic("stub")
}

// clickUIParseBool recovered at 0x0000000001c870c0 (size 0x000000a0).
func clickUIParseBool() {
	panic("stub")
}

// clickUIParseFieldValue recovered at 0x0000000001c87160 (size 0x00000460).
func clickUIParseFieldValue() {
	panic("stub")
}

// clickUISliderSteps recovered at 0x0000000001c89a80 (size 0x00000300).
func clickUISliderSteps() {
	panic("stub")
}

// configContentsBody recovered at 0x0000000001c91720 (size 0x00000b00).
func configContentsBody() {
	panic("stub")
}

// configDialogTitle recovered at 0x0000000001c8cd60 (size 0x000000e0).
func configDialogTitle() {
	panic("stub")
}

// configFirstString recovered at 0x0000000001c942e0 (size 0x00000140).
func configFirstString() {
	panic("stub")
}

// configGridForm recovered at 0x0000000001c8c920 (size 0x00000440).
func configGridForm() {
	panic("stub")
}

// configParseSelection recovered at 0x0000000001c94420 (size 0x00000200).
func configParseSelection() {
	panic("stub")
}

// init recovered at 0x0000000001c84a20 (size 0x000001e0).
func init() {
	panic("stub")
}

// map.init.0 recovered at 0x0000000001c84c00 (size 0x00000240).
func map_init_0() {
	panic("stub")
}

// overlayDescription recovered at 0x0000000001c95180 (size 0x000000e0).
func overlayDescription() {
	panic("stub")
}

// overlayModule recovered at 0x0000000001c94ae0 (size 0x000006a0).
func overlayModule() {
	panic("stub")
}

// overlayParseValue recovered at 0x0000000001c961e0 (size 0x000001a0).
func overlayParseValue() {
	panic("stub")
}

// overlaySetting recovered at 0x0000000001c95260 (size 0x00000640).
func overlaySetting() {
	panic("stub")
}

// panelActiveCategory recovered at 0x0000000001c96560 (size 0x00000100).
func panelActiveCategory() {
	panic("stub")
}

// panelDialogTitle recovered at 0x0000000001c96380 (size 0x000000c0).
func panelDialogTitle() {
	panic("stub")
}

// panelPad recovered at 0x0000000001c96440 (size 0x00000120).
func panelPad() {
	panic("stub")
}

// panelResetModule recovered at 0x0000000001c9a140 (size 0x00000400).
func panelResetModule() {
	panic("stub")
}

// renderClickUI recovered at 0x0000000001c85380 (size 0x000003e0).
func renderClickUI() {
	panic("stub")
}

// renderConfigList recovered at 0x0000000001c8cea0 (size 0x000002c0).
func renderConfigList() {
	panic("stub")
}

// renderPanelGrid recovered at 0x0000000001c96660 (size 0x00000440).
func renderPanelGrid() {
	panic("stub")
}

// renderPanelModule recovered at 0x0000000001c97980 (size 0x00000780).
func renderPanelModule() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*clickUICatalog).stats recovered at 0x0000000001c8ade0 (size 0x00000120).
func (*clickUICatalog) stats() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*clickUICmd).Run recovered at 0x0000000001c84f00 (size 0x00000260).
func (*clickUICmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*clickUIColor).Options recovered at 0x0000000001c85200 (size 0x000000e0).
func (*clickUIColor) Options() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*clickUIColor).Type recovered at 0x0000000001c851e0 (size 0x00000020).
func (*clickUIColor) Type() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*clickUIForm).MarshalJSON recovered at 0x0000000001c85ba0 (size 0x00000280).
func (*clickUIForm) MarshalJSON() ([]byte, error) {
	return nil, nil
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*clickUIForm).SubmitJSON recovered at 0x0000000001c85e20 (size 0x00001160).
func (*clickUIForm) SubmitJSON() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*clickUIForm).addCategoryButton recovered at 0x0000000001c87d00 (size 0x000003a0).
func (*clickUIForm) addCategoryButton() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*clickUIForm).addColumnHeader recovered at 0x0000000001c880a0 (size 0x00000300).
func (*clickUIForm) addColumnHeader() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*clickUIForm).addDivider recovered at 0x0000000001c883a0 (size 0x00000300).
func (*clickUIForm) addDivider() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*clickUIForm).addLockedModule recovered at 0x0000000001c886a0 (size 0x000003a0).
func (*clickUIForm) addLockedModule() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*clickUIForm).addModuleEnable recovered at 0x0000000001c89300 (size 0x00000340).
func (*clickUIForm) addModuleEnable() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*clickUIForm).addModuleField recovered at 0x0000000001c89640 (size 0x000003c0).
func (*clickUIForm) addModuleField() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*clickUIForm).addModuleHeader recovered at 0x0000000001c88a40 (size 0x00000440).
func (*clickUIForm) addModuleHeader() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*clickUIForm).addModuleToggle recovered at 0x0000000001c88e80 (size 0x00000480).
func (*clickUIForm) addModuleToggle() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*clickUIForm).renderCategoryContent recovered at 0x0000000001c85760 (size 0x00000440).
func (*clickUIForm) renderCategoryContent() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*clickUIModuleChanges).apply recovered at 0x0000000001c8af00 (size 0x000002e0).
func (*clickUIModuleChanges) apply() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*clickUITheme).Options recovered at 0x0000000001c85180 (size 0x00000060).
func (*clickUITheme) Options() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*clickUITheme).Type recovered at 0x0000000001c85160 (size 0x00000020).
func (*clickUITheme) Type() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*configConfirmDeleteForm).MarshalJSON recovered at 0x0000000001c8fac0 (size 0x000004c0).
func (*configConfirmDeleteForm) MarshalJSON() ([]byte, error) {
	return nil, nil
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*configConfirmDeleteForm).SubmitJSON recovered at 0x0000000001c8ff80 (size 0x00000400).
func (*configConfirmDeleteForm) SubmitJSON() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*configConfirmOverwriteForm).MarshalJSON recovered at 0x0000000001c90380 (size 0x000004c0).
func (*configConfirmOverwriteForm) MarshalJSON() ([]byte, error) {
	return nil, nil
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*configConfirmOverwriteForm).SubmitJSON recovered at 0x0000000001c90840 (size 0x00000840).
func (*configConfirmOverwriteForm) SubmitJSON() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*configContentsForm).MarshalJSON recovered at 0x0000000001c91080 (size 0x000003e0).
func (*configContentsForm) MarshalJSON() ([]byte, error) {
	return nil, nil
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*configContentsForm).SubmitJSON recovered at 0x0000000001c91460 (size 0x000002c0).
func (*configContentsForm) SubmitJSON() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*configCreateForm).MarshalJSON recovered at 0x0000000001c922a0 (size 0x000004a0).
func (*configCreateForm) MarshalJSON() ([]byte, error) {
	return nil, nil
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*configCreateForm).SubmitJSON recovered at 0x0000000001c92740 (size 0x000008a0).
func (*configCreateForm) SubmitJSON() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*configDetailForm).MarshalJSON recovered at 0x0000000001c8de00 (size 0x00000ea0).
func (*configDetailForm) MarshalJSON() ([]byte, error) {
	return nil, nil
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*configDetailForm).SubmitJSON recovered at 0x0000000001c8f240 (size 0x00000880).
func (*configDetailForm) SubmitJSON() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*configDetailForm).summary recovered at 0x0000000001c8eca0 (size 0x000005a0).
func (*configDetailForm) summary() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*configListForm).MarshalJSON recovered at 0x0000000001c8d160 (size 0x00000920).
func (*configListForm) MarshalJSON() ([]byte, error) {
	return nil, nil
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*configListForm).SubmitJSON recovered at 0x0000000001c8da80 (size 0x00000380).
func (*configListForm) SubmitJSON() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*configRenameForm).MarshalJSON recovered at 0x0000000001c92fe0 (size 0x00000560).
func (*configRenameForm) MarshalJSON() ([]byte, error) {
	return nil, nil
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*configRenameForm).SubmitJSON recovered at 0x0000000001c93540 (size 0x00000da0).
func (*configRenameForm) SubmitJSON() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*panelGridForm).MarshalJSON recovered at 0x0000000001c96aa0 (size 0x00000a00).
func (*panelGridForm) MarshalJSON() ([]byte, error) {
	return nil, nil
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*panelGridForm).SubmitJSON recovered at 0x0000000001c974a0 (size 0x000004e0).
func (*panelGridForm) SubmitJSON() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*panelModuleForm).Close recovered at 0x0000000001c9a020 (size 0x00000120).
func (*panelModuleForm) Close() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*panelModuleForm).MarshalJSON recovered at 0x0000000001c98e80 (size 0x00000500).
func (*panelModuleForm) MarshalJSON() ([]byte, error) {
	return nil, nil
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*panelModuleForm).SubmitJSON recovered at 0x0000000001c99380 (size 0x00000ca0).
func (*panelModuleForm) SubmitJSON() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*panelModuleForm).addDivider recovered at 0x0000000001c986a0 (size 0x00000260).
func (*panelModuleForm) addDivider() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*panelModuleForm).addEnable recovered at 0x0000000001c98900 (size 0x000002c0).
func (*panelModuleForm) addEnable() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*panelModuleForm).addField recovered at 0x0000000001c98bc0 (size 0x000002c0).
func (*panelModuleForm) addField() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*panelModuleForm).addFlagToggle recovered at 0x0000000001c98100 (size 0x00000300).
func (*panelModuleForm) addFlagToggle() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/ui.(*panelModuleForm).addLabel recovered at 0x0000000001c98400 (size 0x000002a0).
func (*panelModuleForm) addLabel() {
	panic("stub")
}
