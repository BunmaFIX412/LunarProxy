// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package toggles

// Placeholder receiver types (no equality descriptor in pclntab).

type toggleCmd struct{}

type toggleModule struct{}

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// Register recovered at 0x0000000001cf1820 (size 0x000004c0).
func Register() {
	panic("stub")
}

// Register.newToggleModuleFactory.func1 recovered at 0x0000000001cf1ce0 (size 0x00000100).
func Register_newToggleModuleFactory_func1() {
	panic("stub")
}

// init recovered at 0x0000000001cf1420 (size 0x00000020).
func init() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/toggles.(*toggleCmd).Run recovered at 0x0000000001cf2120 (size 0x00000140).
func (*toggleCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/toggles.(*toggleModule).Enabled recovered at 0x0000000001cf1e80 (size 0x00000040).
func (*toggleModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/toggles.(*toggleModule).Meta recovered at 0x0000000001cf1de0 (size 0x000000a0).
func (*toggleModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/toggles.(*toggleModule).SetEnabled recovered at 0x0000000001cf1ec0 (size 0x00000060).
func (*toggleModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/toggles.(*toggleModule).Sync recovered at 0x0000000001cf1f20 (size 0x00000040).
func (*toggleModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/toggles.(*toggleModule).ToggleMessage recovered at 0x0000000001cf1f60 (size 0x000001c0).
func (*toggleModule) ToggleMessage() {
	panic("stub")
}
