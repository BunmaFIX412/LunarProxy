// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package visual

// Recovered types (from pclntab type descriptors).

// arrayListModule is a recovered type.
type arrayListModule struct{}

// chunkBordersCmd is a recovered type.
type chunkBordersCmd struct{}

// chunkFinderCmd is a recovered type.
type chunkFinderCmd struct{}

// espCmd is a recovered type.
type espCmd struct{}

// freeCamModule is a recovered type.
type freeCamModule struct{}

// holeESPCmd is a recovered type.
type holeESPCmd struct{}

// newChunksCmd is a recovered type.
type newChunksCmd struct{}

// noInvisibleCmd is a recovered type.
type noInvisibleCmd struct{}

// xrayAddCmd is a recovered type.
type xrayAddCmd struct{}

// xrayModule is a recovered type.
type xrayModule struct{}

// xrayRemoveCmd is a recovered type.
type xrayRemoveCmd struct{}

// Placeholder receiver types (no equality descriptor in pclntab).

type __blockTracersModule__ConfigSection_ModuleSection struct{}

type __chunkBordersModule__ConfigSection_ModuleSection struct{}

type __chunkFinderModule__ConfigSection_ModuleSection struct{}

type __holeESPModule__ConfigSection_ModuleSection struct{}

type __newChunksModule__ConfigSection_ModuleSection struct{}

type __playerESPModule__ConfigSection_ModuleSection struct{}

type __xrayModule__ConfigSection_ModuleSection struct{}

type arrayListCmd struct{}

type blockTracersCmd struct{}

type blockTracersModule struct{}

type chunkBordersMode struct{}

type chunkBordersModule struct{}

type chunkFinderModule struct{}

type freeCamCmd struct{}

type holeESPModule struct{}

type newChunksModule struct{}

type noInvisibleModule struct{}

type playerESPModule struct{}

type tracersCmd struct{}

type tracersModule struct{}

type xrayCmd struct{}

type xrayListCmd struct{}

type xrayToggleCmd struct{}

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// Register recovered at 0x0000000001d029e0 (size 0x00001580).
func Register() {
	panic("stub")
}

// chunkFinderNotifyOptions recovered at 0x0000000001cff580 (size 0x000001a0).
func chunkFinderNotifyOptions() {
	panic("stub")
}

// newArrayListModule recovered at 0x0000000001cfc780 (size 0x00000080).
func newArrayListModule() {
	panic("stub")
}

// newBlockTracersModule recovered at 0x0000000001cfc9e0 (size 0x00000080).
func newBlockTracersModule() {
	panic("stub")
}

// newChunkBordersModule recovered at 0x0000000001cfe6e0 (size 0x00000080).
func newChunkBordersModule() {
	panic("stub")
}

// newChunkFinderModule recovered at 0x0000000001cff200 (size 0x00000080).
func newChunkFinderModule() {
	panic("stub")
}

// newFreeCamModule recovered at 0x0000000001d00840 (size 0x00000080).
func newFreeCamModule() {
	panic("stub")
}

// newHoleESPModule recovered at 0x0000000001d00a40 (size 0x00000080).
func newHoleESPModule() {
	panic("stub")
}

// newNewChunksModule recovered at 0x0000000001d015a0 (size 0x00000080).
func newNewChunksModule() {
	panic("stub")
}

// newNoInvisibleModule recovered at 0x0000000001d01de0 (size 0x00000080).
func newNoInvisibleModule() {
	panic("stub")
}

// newPlayerESPModule recovered at 0x0000000001d02060 (size 0x00000080).
func newPlayerESPModule() {
	panic("stub")
}

// newTracersModule recovered at 0x0000000001d03f60 (size 0x00000080).
func newTracersModule() {
	panic("stub")
}

// newXrayModule recovered at 0x0000000001d04160 (size 0x00000080).
func newXrayModule() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.((*blockTracersModule).ConfigSection.ModuleSection).Section recovered at 0x0000000001cfcb20 (size 0x00000060).
func (__blockTracersModule__ConfigSection_ModuleSection) Section() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.((*chunkBordersModule).ConfigSection.ModuleSection).Section recovered at 0x0000000001cfe820 (size 0x00000060).
func (__chunkBordersModule__ConfigSection_ModuleSection) Section() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.((*chunkFinderModule).ConfigSection.ModuleSection).Section recovered at 0x0000000001cff340 (size 0x00000060).
func (__chunkFinderModule__ConfigSection_ModuleSection) Section() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.((*holeESPModule).ConfigSection.ModuleSection).Section recovered at 0x0000000001d00b80 (size 0x00000060).
func (__holeESPModule__ConfigSection_ModuleSection) Section() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.((*newChunksModule).ConfigSection.ModuleSection).Section recovered at 0x0000000001d016e0 (size 0x00000060).
func (__newChunksModule__ConfigSection_ModuleSection) Section() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.((*playerESPModule).ConfigSection.ModuleSection).Section recovered at 0x0000000001d022e0 (size 0x00000060).
func (__playerESPModule__ConfigSection_ModuleSection) Section() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.((*xrayModule).ConfigSection.ModuleSection).Section recovered at 0x0000000001d042a0 (size 0x00000060).
func (__xrayModule__ConfigSection_ModuleSection) Section() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*arrayListCmd).Run recovered at 0x0000000001cfc940 (size 0x000000a0).
func (*arrayListCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*arrayListModule).Enabled recovered at 0x0000000001cfc840 (size 0x00000020).
func (*arrayListModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*arrayListModule).Meta recovered at 0x0000000001cfc800 (size 0x00000040).
func (*arrayListModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*arrayListModule).SetEnabled recovered at 0x0000000001cfc860 (size 0x00000020).
func (*arrayListModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*arrayListModule).Sync recovered at 0x0000000001cfc880 (size 0x000000c0).
func (*arrayListModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*blockTracersCmd).Run recovered at 0x0000000001cfccc0 (size 0x00000080).
func (*blockTracersCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*blockTracersModule).ApplyClickUI recovered at 0x0000000001cfe600 (size 0x000000e0).
func (*blockTracersModule) ApplyClickUI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*blockTracersModule).ClickUIFields recovered at 0x0000000001cfe3a0 (size 0x00000260).
func (*blockTracersModule) ClickUIFields() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*blockTracersModule).ConfigSection recovered at 0x0000000001cfcaa0 (size 0x00000080).
func (*blockTracersModule) ConfigSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*blockTracersModule).Enabled recovered at 0x0000000001cfcb80 (size 0x00000020).
func (*blockTracersModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*blockTracersModule).Meta recovered at 0x0000000001cfca60 (size 0x00000040).
func (*blockTracersModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*blockTracersModule).RuntimeDeps recovered at 0x0000000001cfcba0 (size 0x00000020).
func (*blockTracersModule) RuntimeDeps() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*blockTracersModule).SetEnabled recovered at 0x0000000001cfcbc0 (size 0x00000020).
func (*blockTracersModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*blockTracersModule).Sync recovered at 0x0000000001cfcbe0 (size 0x00000060).
func (*blockTracersModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*blockTracersModule).ToggleMessage recovered at 0x0000000001cfcc40 (size 0x00000080).
func (*blockTracersModule) ToggleMessage() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*blockTracersModule).toggleTable recovered at 0x0000000001cfcd40 (size 0x00001660).
func (*blockTracersModule) toggleTable() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*chunkBordersCmd).Run recovered at 0x0000000001cfe900 (size 0x000003c0).
func (*chunkBordersCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*chunkBordersMode).Options recovered at 0x0000000001cfece0 (size 0x00000080).
func (*chunkBordersMode) Options() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*chunkBordersMode).Type recovered at 0x0000000001cfecc0 (size 0x00000020).
func (*chunkBordersMode) Type() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*chunkBordersModule).ApplyClickUI recovered at 0x0000000001cff120 (size 0x000000e0).
func (*chunkBordersModule) ApplyClickUI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*chunkBordersModule).ClickUIFields recovered at 0x0000000001cfeea0 (size 0x00000280).
func (*chunkBordersModule) ClickUIFields() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*chunkBordersModule).ConfigSection recovered at 0x0000000001cfe7a0 (size 0x00000080).
func (*chunkBordersModule) ConfigSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*chunkBordersModule).Enabled recovered at 0x0000000001cfe880 (size 0x00000020).
func (*chunkBordersModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*chunkBordersModule).Meta recovered at 0x0000000001cfe760 (size 0x00000040).
func (*chunkBordersModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*chunkBordersModule).RuntimeDeps recovered at 0x0000000001cfe8a0 (size 0x00000020).
func (*chunkBordersModule) RuntimeDeps() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*chunkBordersModule).SetEnabled recovered at 0x0000000001cfe8c0 (size 0x00000020).
func (*chunkBordersModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*chunkBordersModule).Sync recovered at 0x0000000001cfe8e0 (size 0x00000020).
func (*chunkBordersModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*chunkBordersModule).modeOptions recovered at 0x0000000001cfed60 (size 0x00000140).
func (*chunkBordersModule) modeOptions() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*chunkFinderCmd).Run recovered at 0x0000000001cff460 (size 0x00000120).
func (*chunkFinderCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*chunkFinderModule).ApplyClickUI recovered at 0x0000000001d00680 (size 0x000001c0).
func (*chunkFinderModule) ApplyClickUI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*chunkFinderModule).ClickUIFields recovered at 0x0000000001cfff60 (size 0x00000720).
func (*chunkFinderModule) ClickUIFields() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*chunkFinderModule).ConfigSection recovered at 0x0000000001cff2c0 (size 0x00000080).
func (*chunkFinderModule) ConfigSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*chunkFinderModule).Enabled recovered at 0x0000000001cff3a0 (size 0x00000020).
func (*chunkFinderModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*chunkFinderModule).Meta recovered at 0x0000000001cff280 (size 0x00000040).
func (*chunkFinderModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*chunkFinderModule).RuntimeDeps recovered at 0x0000000001cff3c0 (size 0x00000020).
func (*chunkFinderModule) RuntimeDeps() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*chunkFinderModule).SetEnabled recovered at 0x0000000001cff3e0 (size 0x00000020).
func (*chunkFinderModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*chunkFinderModule).Sync recovered at 0x0000000001cff400 (size 0x00000060).
func (*chunkFinderModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*chunkFinderModule).toggleTable recovered at 0x0000000001cff720 (size 0x00000840).
func (*chunkFinderModule) toggleTable() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*espCmd).Run recovered at 0x0000000001d023c0 (size 0x00000120).
func (*espCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*freeCamCmd).Run recovered at 0x0000000001d009a0 (size 0x000000a0).
func (*freeCamCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*freeCamModule).Enabled recovered at 0x0000000001d00900 (size 0x00000020).
func (*freeCamModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*freeCamModule).Meta recovered at 0x0000000001d008c0 (size 0x00000040).
func (*freeCamModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*freeCamModule).SetEnabled recovered at 0x0000000001d00920 (size 0x00000020).
func (*freeCamModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*freeCamModule).Sync recovered at 0x0000000001d00940 (size 0x00000060).
func (*freeCamModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*holeESPCmd).Run recovered at 0x0000000001d00ca0 (size 0x00000120).
func (*holeESPCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*holeESPModule).ApplyClickUI recovered at 0x0000000001d013e0 (size 0x000001c0).
func (*holeESPModule) ApplyClickUI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*holeESPModule).ClickUIFields recovered at 0x0000000001d00dc0 (size 0x00000620).
func (*holeESPModule) ClickUIFields() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*holeESPModule).ConfigSection recovered at 0x0000000001d00b00 (size 0x00000080).
func (*holeESPModule) ConfigSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*holeESPModule).Enabled recovered at 0x0000000001d00be0 (size 0x00000020).
func (*holeESPModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*holeESPModule).Meta recovered at 0x0000000001d00ac0 (size 0x00000040).
func (*holeESPModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*holeESPModule).RuntimeDeps recovered at 0x0000000001d00c00 (size 0x00000020).
func (*holeESPModule) RuntimeDeps() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*holeESPModule).SetEnabled recovered at 0x0000000001d00c20 (size 0x00000020).
func (*holeESPModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*holeESPModule).Sync recovered at 0x0000000001d00c40 (size 0x00000060).
func (*holeESPModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*newChunksCmd).Run recovered at 0x0000000001d017e0 (size 0x00000120).
func (*newChunksCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*newChunksModule).ApplyClickUI recovered at 0x0000000001d01cc0 (size 0x00000120).
func (*newChunksModule) ApplyClickUI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*newChunksModule).ClickUIFields recovered at 0x0000000001d01900 (size 0x000003c0).
func (*newChunksModule) ClickUIFields() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*newChunksModule).ConfigSection recovered at 0x0000000001d01660 (size 0x00000080).
func (*newChunksModule) ConfigSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*newChunksModule).Enabled recovered at 0x0000000001d01740 (size 0x00000020).
func (*newChunksModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*newChunksModule).Meta recovered at 0x0000000001d01620 (size 0x00000040).
func (*newChunksModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*newChunksModule).RuntimeDeps recovered at 0x0000000001d01760 (size 0x00000020).
func (*newChunksModule) RuntimeDeps() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*newChunksModule).SetEnabled recovered at 0x0000000001d01780 (size 0x00000020).
func (*newChunksModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*newChunksModule).Sync recovered at 0x0000000001d017a0 (size 0x00000040).
func (*newChunksModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*noInvisibleCmd).Run recovered at 0x0000000001d01f20 (size 0x00000140).
func (*noInvisibleCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*noInvisibleModule).Enabled recovered at 0x0000000001d01ea0 (size 0x00000020).
func (*noInvisibleModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*noInvisibleModule).Meta recovered at 0x0000000001d01e60 (size 0x00000040).
func (*noInvisibleModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*noInvisibleModule).SetEnabled recovered at 0x0000000001d01ec0 (size 0x00000020).
func (*noInvisibleModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*noInvisibleModule).Sync recovered at 0x0000000001d01ee0 (size 0x00000040).
func (*noInvisibleModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*playerESPModule).ApplyClickUI recovered at 0x0000000001d028c0 (size 0x00000120).
func (*playerESPModule) ApplyClickUI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*playerESPModule).ClickUIFields recovered at 0x0000000001d024e0 (size 0x000003e0).
func (*playerESPModule) ClickUIFields() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*playerESPModule).ConfigSection recovered at 0x0000000001d02260 (size 0x00000080).
func (*playerESPModule) ConfigSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*playerESPModule).Enabled recovered at 0x0000000001d02340 (size 0x00000020).
func (*playerESPModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*playerESPModule).Meta recovered at 0x0000000001d02220 (size 0x00000040).
func (*playerESPModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*playerESPModule).RuntimeDeps recovered at 0x0000000001d02360 (size 0x00000020).
func (*playerESPModule) RuntimeDeps() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*playerESPModule).SetEnabled recovered at 0x0000000001d02380 (size 0x00000020).
func (*playerESPModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*playerESPModule).Sync recovered at 0x0000000001d023a0 (size 0x00000020).
func (*playerESPModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*playerESPModule).modeOptions recovered at 0x0000000001d020e0 (size 0x00000140).
func (*playerESPModule) modeOptions() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*tracersCmd).Run recovered at 0x0000000001d040a0 (size 0x000000c0).
func (*tracersCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*tracersModule).Enabled recovered at 0x0000000001d04020 (size 0x00000020).
func (*tracersModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*tracersModule).Meta recovered at 0x0000000001d03fe0 (size 0x00000040).
func (*tracersModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*tracersModule).RuntimeDeps recovered at 0x0000000001d04040 (size 0x00000020).
func (*tracersModule) RuntimeDeps() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*tracersModule).SetEnabled recovered at 0x0000000001d04060 (size 0x00000020).
func (*tracersModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*tracersModule).Sync recovered at 0x0000000001d04080 (size 0x00000020).
func (*tracersModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*xrayAddCmd).Run recovered at 0x0000000001d04660 (size 0x000006c0).
func (*xrayAddCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*xrayCmd).Run recovered at 0x0000000001d045e0 (size 0x00000080).
func (*xrayCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*xrayListCmd).Run recovered at 0x0000000001d052e0 (size 0x000003c0).
func (*xrayListCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*xrayModule).ApplyClickUI recovered at 0x0000000001d05ce0 (size 0x00000180).
func (*xrayModule) ApplyClickUI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*xrayModule).ClickUIFields recovered at 0x0000000001d056a0 (size 0x00000640).
func (*xrayModule) ClickUIFields() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*xrayModule).ConfigSection recovered at 0x0000000001d04220 (size 0x00000080).
func (*xrayModule) ConfigSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*xrayModule).Enabled recovered at 0x0000000001d04300 (size 0x00000020).
func (*xrayModule) Enabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*xrayModule).Meta recovered at 0x0000000001d041e0 (size 0x00000040).
func (*xrayModule) Meta() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*xrayModule).RuntimeDeps recovered at 0x0000000001d04320 (size 0x00000020).
func (*xrayModule) RuntimeDeps() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*xrayModule).SetEnabled recovered at 0x0000000001d04340 (size 0x00000020).
func (*xrayModule) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*xrayModule).Sync recovered at 0x0000000001d04360 (size 0x00000120).
func (*xrayModule) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*xrayModule).ToggleMessage recovered at 0x0000000001d04480 (size 0x00000020).
func (*xrayModule) ToggleMessage() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*xrayRemoveCmd).Run recovered at 0x0000000001d04d20 (size 0x000005c0).
func (*xrayRemoveCmd) Run() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/module/visual.(*xrayToggleCmd).Run recovered at 0x0000000001d044a0 (size 0x00000140).
func (*xrayToggleCmd) Run() {
	panic("stub")
}
