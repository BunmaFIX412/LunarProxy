package i18n

import "regexp"

var placeholderRe = regexp.MustCompile(`\{\{\.([A-Za-z0-9_]+)\}\}`)

func Tr(key string, values ...map[string]any) string {
	msg, ok := locales[key]
	if !ok {
		return key
	}
	if len(values) > 0 {
		msg = placeholderRe.ReplaceAllStringFunc(msg, func(m string) string {
			name := placeholderRe.FindStringSubmatch(m)[1]
			if v, ok := values[0][name]; ok {
				return toString(v)
			}
			return m
		})
	}
	return msg
}

func toString(v any) string {
	switch t := v.(type) {
	case string:
		return t
	case bool:
		if t {
			return "true"
		}
		return "false"
	case int:
		return itoa(t)
	case int64:
		return itoa64(t)
	case uint8:
		return itoa(int(t))
	case float64:
		return ftoa(t)
	default:
		return ""
	}
}

func itoa(v int) string {
	if v == 0 {
		return "0"
	}
	neg := v < 0
	if neg {
		v = -v
	}
	var buf [20]byte
	i := len(buf)
	for v > 0 {
		i--
		buf[i] = byte('0' + v%10)
		v /= 10
	}
	if neg {
		i--
		buf[i] = '-'
	}
	return string(buf[i:])
}

func itoa64(v int64) string {
	if v == 0 {
		return "0"
	}
	neg := v < 0
	if neg {
		v = -v
	}
	var buf [20]byte
	i := len(buf)
	for v > 0 {
		i--
		buf[i] = byte('0' + v%10)
		v /= 10
	}
	if neg {
		i--
		buf[i] = '-'
	}
	return string(buf[i:])
}

func ftoa(v float64) string {
	iv := int64(v)
	if float64(iv) == v {
		return itoa64(iv)
	}
	s := fmtFloat(v)
	return s
}

func fmtFloat(v float64) string {
	neg := v < 0
	if neg {
		v = -v
	}
	whole := int64(v)
	frac := int((v - float64(whole)) * 1000)
	fracS := itoa(frac)
	for len(fracS) < 3 {
		fracS = "0" + fracS
	}
	for len(fracS) > 1 && fracS[len(fracS)-1] == '0' {
		fracS = fracS[:len(fracS)-1]
	}
	s := itoa64(whole) + "." + fracS
	if neg {
		s = "-" + s
	}
	return s
}

func Match(key, lang string) string {
	msg, ok := locales[key]
	if !ok {
		return key
	}
	_ = lang
	return msg
}

func Parse(key string) string {
	return Tr(key)
}