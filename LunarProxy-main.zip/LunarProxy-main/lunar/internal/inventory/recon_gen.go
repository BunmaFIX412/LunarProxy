// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package inventory

// Recovered types (from pclntab type descriptors).

// OpenWindow is a recovered type.
type OpenWindow struct{}

// boundInventorySlot is a recovered type.
type boundInventorySlot struct{}

// inventoryCompletion is a recovered type.
type inventoryCompletion struct{}

// openContainerState is a recovered type.
type openContainerState struct{}

// Placeholder receiver types (no equality descriptor in pclntab).

type Component struct{}

type Inventory struct{}

type OperationResult struct{}

type foldState struct{}

type legacyInventoryProtocol struct{}

type modernInventoryProtocol struct{}

type requestOrigin struct{}

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// NewComponent recovered at 0x0000000001b7f420 (size 0x00000420).
func NewComponent() {
	panic("stub")
}

// TransferMatching recovered at 0x0000000001b98a00 (size 0x00000340).
func TransferMatching() {
	panic("stub")
}

// inventorySourceMatches recovered at 0x0000000001b95b60 (size 0x00000160).
func inventorySourceMatches() {
	panic("stub")
}

// inventoryStackMatches recovered at 0x0000000001b95cc0 (size 0x00000400).
func inventoryStackMatches() {
	panic("stub")
}

// itemName recovered at 0x0000000001b8d600 (size 0x000000c0).
func itemName() {
	panic("stub")
}

// legacyInventoryProtocol.writeDropOperation recovered at 0x0000000001b942e0 (size 0x00000da0).
func legacyInventoryProtocol_writeDropOperation() {
	panic("stub")
}

// legacyInventoryProtocol.writeSwapOperation recovered at 0x0000000001b938c0 (size 0x00000a20).
func legacyInventoryProtocol_writeSwapOperation() {
	panic("stub")
}

// legacyInventoryProtocol.writeTransferOperation recovered at 0x0000000001b92740 (size 0x00001180).
func legacyInventoryProtocol_writeTransferOperation() {
	panic("stub")
}

// modernInventoryProtocol.writeDropItem recovered at 0x0000000001b91d60 (size 0x00000880).
func modernInventoryProtocol_writeDropItem() {
	panic("stub")
}

// modernInventoryProtocol.writeDropItem.deferwrap1 recovered at 0x0000000001b925e0 (size 0x00000040).
func modernInventoryProtocol_writeDropItem_deferwrap1() {
	panic("stub")
}

// nextMatchingTransfer recovered at 0x0000000001b98d40 (size 0x000008a0).
func nextMatchingTransfer() {
	panic("stub")
}

// validateLegacyTransferDestination recovered at 0x0000000001b95080 (size 0x00000620).
func validateLegacyTransferDestination() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).Boots recovered at 0x0000000001b7fc00 (size 0x00000140).
func (*Component) Boots() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).Chestplate recovered at 0x0000000001b7f980 (size 0x00000140).
func (*Component) Chestplate() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).ClientSelectedHotBarSlot recovered at 0x0000000001b80b40 (size 0x00000020).
func (*Component) ClientSelectedHotBarSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).CloseCurrentWindow recovered at 0x0000000001b8e2a0 (size 0x00000140).
func (*Component) CloseCurrentWindow() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).CompareAndSwapHeldSlot recovered at 0x0000000001b80b20 (size 0x00000020).
func (*Component) CompareAndSwapHeldSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).CreateWindow recovered at 0x0000000001b8d900 (size 0x00000320).
func (*Component) CreateWindow() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).CurrentWindow recovered at 0x0000000001b8dd40 (size 0x00000120).
func (*Component) CurrentWindow() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).CurrentWindowReady recovered at 0x0000000001b8dea0 (size 0x000000e0).
func (*Component) CurrentWindowReady() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).CurrentWindowSize recovered at 0x0000000001b8dfc0 (size 0x00000100).
func (*Component) CurrentWindowSize() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).DropItem recovered at 0x0000000001b8bec0 (size 0x00000060).
func (*Component) DropItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).ForceSync recovered at 0x0000000001b80900 (size 0x00000080).
func (*Component) ForceSync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).ForwardItemStackRequest recovered at 0x0000000001b84080 (size 0x00000100).
func (*Component) ForwardItemStackRequest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).ForwardPlayerAuthInputRequest recovered at 0x0000000001b841c0 (size 0x00000240).
func (*Component) ForwardPlayerAuthInputRequest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).GetOpenContainerPosition recovered at 0x0000000001b8e640 (size 0x00000120).
func (*Component) GetOpenContainerPosition() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).HandleInventoryContent recovered at 0x0000000001b82140 (size 0x00000e00).
func (*Component) HandleInventoryContent() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).HandleInventorySlot recovered at 0x0000000001b81700 (size 0x00000a40).
func (*Component) HandleInventorySlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).HandleItemStackRequest recovered at 0x0000000001b84040 (size 0x00000040).
func (*Component) HandleItemStackRequest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).HandleItemStackResponse recovered at 0x0000000001b84580 (size 0x000011c0).
func (*Component) HandleItemStackResponse() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).HandleSingleRequest recovered at 0x0000000001b82fc0 (size 0x00000140).
func (*Component) HandleSingleRequest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).HeldItemInstance recovered at 0x0000000001b80e40 (size 0x00000100).
func (*Component) HeldItemInstance() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).HeldSlot recovered at 0x0000000001b80980 (size 0x00000020).
func (*Component) HeldSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).Helmet recovered at 0x0000000001b7f840 (size 0x00000140).
func (*Component) Helmet() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).Holding recovered at 0x0000000001b80d00 (size 0x00000140).
func (*Component) Holding() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).HotBarItemInstance recovered at 0x0000000001b80f40 (size 0x000001c0).
func (*Component) HotBarItemInstance() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).Leggings recovered at 0x0000000001b7fac0 (size 0x00000140).
func (*Component) Leggings() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).Offhand recovered at 0x0000000001b7fd40 (size 0x00000140).
func (*Component) Offhand() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).ReadyWindow recovered at 0x0000000001b8e100 (size 0x000001a0).
func (*Component) ReadyWindow() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).RemoveWindow recovered at 0x0000000001b8dc20 (size 0x000000e0).
func (*Component) RemoveWindow() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).SetClientSelectedHotBarSlot recovered at 0x0000000001b80b60 (size 0x000001a0).
func (*Component) SetClientSelectedHotBarSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).SetHeldSlot recovered at 0x0000000001b809a0 (size 0x00000180).
func (*Component) SetHeldSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).SourceContainerID recovered at 0x0000000001b8e7a0 (size 0x00000060).
func (*Component) SourceContainerID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).SwapItem recovered at 0x0000000001b8be40 (size 0x00000080).
func (*Component) SwapItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).Sync recovered at 0x0000000001b80600 (size 0x00000300).
func (*Component) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).SyncSlot recovered at 0x0000000001b7ffc0 (size 0x00000260).
func (*Component) SyncSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).TakeItem recovered at 0x0000000001b8bac0 (size 0x00000080).
func (*Component) TakeItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).Transfer recovered at 0x0000000001b8bb40 (size 0x00000080).
func (*Component) Transfer() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).TransferConfirmedFrom recovered at 0x0000000001b8bbc0 (size 0x00000280).
func (*Component) TransferConfirmedFrom() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).TransferMatching recovered at 0x0000000001b986a0 (size 0x000000c0).
func (*Component) TransferMatching() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).TransferMatchingConfirmed recovered at 0x0000000001b98760 (size 0x000002a0).
func (*Component) TransferMatchingConfirmed() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).WindowFromContainerID recovered at 0x0000000001b7fe80 (size 0x000000a0).
func (*Component) WindowFromContainerID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).WindowFromWindowID recovered at 0x0000000001b7ff20 (size 0x000000a0).
func (*Component) WindowFromWindowID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).applyAuthoritativeSlot recovered at 0x0000000001b871c0 (size 0x000001a0).
func (*Component) applyAuthoritativeSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).applyRequestLocked recovered at 0x0000000001b83ce0 (size 0x00000360).
func (*Component) applyRequestLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).applyResponseSlotsLocked recovered at 0x0000000001b85b20 (size 0x00000cc0).
func (*Component) applyResponseSlotsLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).clientInstanceFromSlot recovered at 0x0000000001b80220 (size 0x000003e0).
func (*Component) clientInstanceFromSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).createLegacyContainerAction recovered at 0x0000000001b964c0 (size 0x00000300).
func (*Component) createLegacyContainerAction() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).createLegacyWorldAction recovered at 0x0000000001b967c0 (size 0x00000300).
func (*Component) createLegacyWorldAction() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).executeAcceptedProxyGroups recovered at 0x0000000001b956a0 (size 0x00000460).
func (*Component) executeAcceptedProxyGroups() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).handleCraftStackRequest recovered at 0x0000000001b884a0 (size 0x000012e0).
func (*Component) handleCraftStackRequest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).handleCreativeCraftStackRequest recovered at 0x0000000001b87dc0 (size 0x000006e0).
func (*Component) handleCreativeCraftStackRequest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).handleDestroyRequest recovered at 0x0000000001b8b560 (size 0x00000560).
func (*Component) handleDestroyRequest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).handleItemTransfer recovered at 0x0000000001b8bf20 (size 0x00001420).
func (*Component) handleItemTransfer() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).handleSwapRequest recovered at 0x0000000001b8ade0 (size 0x00000780).
func (*Component) handleSwapRequest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).handleTransferRequest recovered at 0x0000000001b8a440 (size 0x000009a0).
func (*Component) handleTransferRequest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).hasOpenContainer recovered at 0x0000000001b8e540 (size 0x000000c0).
func (*Component) hasOpenContainer() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).instanceFromItem recovered at 0x0000000001b8d6c0 (size 0x00000240).
func (*Component) instanceFromItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).inventorySyncPackets recovered at 0x0000000001b87620 (size 0x00000720).
func (*Component) inventorySyncPackets() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).legacyWindowID recovered at 0x0000000001b96ac0 (size 0x000000c0).
func (*Component) legacyWindowID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).openContainerInv recovered at 0x0000000001b8e3e0 (size 0x00000120).
func (*Component) openContainerInv() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).probeTransfersLocked recovered at 0x0000000001b83b60 (size 0x00000180).
func (*Component) probeTransfersLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).promoteRequestLocked recovered at 0x0000000001b85860 (size 0x000002c0).
func (*Component) promoteRequestLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).queueItemStackRequest recovered at 0x0000000001b84440 (size 0x00000140).
func (*Component) queueItemStackRequest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).queueSingleRequest recovered at 0x0000000001b83100 (size 0x00000a00).
func (*Component) queueSingleRequest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).refoldLocked recovered at 0x0000000001b867e0 (size 0x000009e0).
func (*Component) refoldLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).rememberRequestIDLocked recovered at 0x0000000001b8d380 (size 0x00000280).
func (*Component) rememberRequestIDLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).resolveOperationSlot recovered at 0x0000000001b960c0 (size 0x00000400).
func (*Component) resolveOperationSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).routeInventoryOperation recovered at 0x0000000001b91a80 (size 0x000000e0).
func (*Component) routeInventoryOperation() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).sourceContainerID recovered at 0x0000000001b8e800 (size 0x000000e0).
func (*Component) sourceContainerID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).syncShulkerTooltipResponseSlot recovered at 0x0000000001b873a0 (size 0x00000280).
func (*Component) syncShulkerTooltipResponseSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).warnInventoryContainerSlotOutOfRange recovered at 0x0000000001b813e0 (size 0x00000320).
func (*Component) warnInventoryContainerSlotOutOfRange() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).warnInventorySlotOutOfRange recovered at 0x0000000001b81100 (size 0x000002e0).
func (*Component) warnInventorySlotOutOfRange() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Component).windowIDForContainer recovered at 0x0000000001b87d40 (size 0x00000080).
func (*Component) windowIDForContainer() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Inventory).BaseSlot recovered at 0x0000000001b8f600 (size 0x00000300).
func (*Inventory) BaseSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Inventory).CanAccept recovered at 0x0000000001b91260 (size 0x000000c0).
func (*Inventory) CanAccept() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Inventory).Each recovered at 0x0000000001b90140 (size 0x00000220).
func (*Inventory) Each() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Inventory).FindSlot recovered at 0x0000000001b91320 (size 0x00000260).
func (*Inventory) FindSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Inventory).FindSlotInRange recovered at 0x0000000001b915c0 (size 0x00000460).
func (*Inventory) FindSlotInRange() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Inventory).FindStack recovered at 0x0000000001b903a0 (size 0x00000180).
func (*Inventory) FindStack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Inventory).FindStackInRange recovered at 0x0000000001b90520 (size 0x00000440).
func (*Inventory) FindStackInRange() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Inventory).PinBase recovered at 0x0000000001b8f200 (size 0x000002a0).
func (*Inventory) PinBase() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Inventory).ResolveSlot recovered at 0x0000000001b8fdc0 (size 0x00000140).
func (*Inventory) ResolveSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Inventory).SetBase recovered at 0x0000000001b8f940 (size 0x00000280).
func (*Inventory) SetBase() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Inventory).SetSlot recovered at 0x0000000001b8ef80 (size 0x00000240).
func (*Inventory) SetSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Inventory).SetSpecialSlot recovered at 0x0000000001b8e8e0 (size 0x000000c0).
func (*Inventory) SetSpecialSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Inventory).SetView recovered at 0x0000000001b8fc00 (size 0x00000180).
func (*Inventory) SetView() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Inventory).Size recovered at 0x0000000001b8ff40 (size 0x00000020).
func (*Inventory) Size() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Inventory).Slot recovered at 0x0000000001b8eb60 (size 0x000003e0).
func (*Inventory) Slot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Inventory).Slots recovered at 0x0000000001b8ff60 (size 0x000001a0).
func (*Inventory) Slots() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Inventory).TransferDestination recovered at 0x0000000001b909a0 (size 0x00000880).
func (*Inventory) TransferDestination() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Inventory).UnpinBase recovered at 0x0000000001b8f4e0 (size 0x000000e0).
func (*Inventory) UnpinBase() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*Inventory).resolveSlotLocked recovered at 0x0000000001b8e9e0 (size 0x00000180).
func (*Inventory) resolveSlotLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*OperationResult).Accepted recovered at 0x0000000001b91a60 (size 0x00000020).
func (*OperationResult) Accepted() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*foldState).apply recovered at 0x0000000001b96ee0 (size 0x000017c0).
func (*foldState) apply() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*foldState).seed recovered at 0x0000000001b96b80 (size 0x00000360).
func (*foldState) seed() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).Boots recovered at 0x0000000001b9c580 (size 0x00000140).
func (*legacyInventoryProtocol) Boots() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).Chestplate recovered at 0x0000000001b9c800 (size 0x00000140).
func (*legacyInventoryProtocol) Chestplate() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).ClientSelectedHotBarSlot recovered at 0x0000000001b9ca80 (size 0x00000020).
func (*legacyInventoryProtocol) ClientSelectedHotBarSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).CloseCurrentWindow recovered at 0x0000000001b9cac0 (size 0x00000040).
func (*legacyInventoryProtocol) CloseCurrentWindow() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).CompareAndSwapHeldSlot recovered at 0x0000000001b9cb20 (size 0x00000020).
func (*legacyInventoryProtocol) CompareAndSwapHeldSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).CreateWindow recovered at 0x0000000001b9cb60 (size 0x00000060).
func (*legacyInventoryProtocol) CreateWindow() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).CurrentWindow recovered at 0x0000000001b9cbe0 (size 0x00000040).
func (*legacyInventoryProtocol) CurrentWindow() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).CurrentWindowReady recovered at 0x0000000001b9cc40 (size 0x00000040).
func (*legacyInventoryProtocol) CurrentWindowReady() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).CurrentWindowSize recovered at 0x0000000001b9cca0 (size 0x00000040).
func (*legacyInventoryProtocol) CurrentWindowSize() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).DropItem recovered at 0x0000000001b9cd00 (size 0x00000060).
func (*legacyInventoryProtocol) DropItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).ForceSync recovered at 0x0000000001b9cdc0 (size 0x00000080).
func (*legacyInventoryProtocol) ForceSync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).ForwardItemStackRequest recovered at 0x0000000001b9cec0 (size 0x00000040).
func (*legacyInventoryProtocol) ForwardItemStackRequest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).ForwardPlayerAuthInputRequest recovered at 0x0000000001b9cf20 (size 0x00000040).
func (*legacyInventoryProtocol) ForwardPlayerAuthInputRequest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).GetOpenContainerPosition recovered at 0x0000000001b9cf80 (size 0x00000060).
func (*legacyInventoryProtocol) GetOpenContainerPosition() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).HandleInventoryContent recovered at 0x0000000001b9d000 (size 0x00000040).
func (*legacyInventoryProtocol) HandleInventoryContent() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).HandleInventorySlot recovered at 0x0000000001b9d060 (size 0x00000040).
func (*legacyInventoryProtocol) HandleInventorySlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).HandleItemStackRequest recovered at 0x0000000001b9d0c0 (size 0x00000040).
func (*legacyInventoryProtocol) HandleItemStackRequest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).HandleItemStackResponse recovered at 0x0000000001b9d140 (size 0x00000040).
func (*legacyInventoryProtocol) HandleItemStackResponse() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).HandleSingleRequest recovered at 0x0000000001b9d1a0 (size 0x00000140).
func (*legacyInventoryProtocol) HandleSingleRequest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).HeldItemInstance recovered at 0x0000000001b9d440 (size 0x00000100).
func (*legacyInventoryProtocol) HeldItemInstance() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).HeldSlot recovered at 0x0000000001b9d640 (size 0x00000020).
func (*legacyInventoryProtocol) HeldSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).Helmet recovered at 0x0000000001b9d680 (size 0x00000140).
func (*legacyInventoryProtocol) Helmet() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).Holding recovered at 0x0000000001b9d900 (size 0x00000140).
func (*legacyInventoryProtocol) Holding() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).HotBarItemInstance recovered at 0x0000000001b9db80 (size 0x00000100).
func (*legacyInventoryProtocol) HotBarItemInstance() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).Leggings recovered at 0x0000000001b9dcc0 (size 0x00000140).
func (*legacyInventoryProtocol) Leggings() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).Offhand recovered at 0x0000000001b9df40 (size 0x00000140).
func (*legacyInventoryProtocol) Offhand() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).ReadyWindow recovered at 0x0000000001b9e1c0 (size 0x000000a0).
func (*legacyInventoryProtocol) ReadyWindow() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).RemoveWindow recovered at 0x0000000001b9e280 (size 0x00000040).
func (*legacyInventoryProtocol) RemoveWindow() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).SetClientSelectedHotBarSlot recovered at 0x0000000001b9e2e0 (size 0x00000040).
func (*legacyInventoryProtocol) SetClientSelectedHotBarSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).SetHeldSlot recovered at 0x0000000001b9e340 (size 0x00000040).
func (*legacyInventoryProtocol) SetHeldSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).SourceContainerID recovered at 0x0000000001b9e3a0 (size 0x00000040).
func (*legacyInventoryProtocol) SourceContainerID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).SwapItem recovered at 0x0000000001b9e400 (size 0x00000080).
func (*legacyInventoryProtocol) SwapItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).Sync recovered at 0x0000000001b9e500 (size 0x00000040).
func (*legacyInventoryProtocol) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).SyncSlot recovered at 0x0000000001b9e560 (size 0x00000040).
func (*legacyInventoryProtocol) SyncSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).TakeItem recovered at 0x0000000001b9e5c0 (size 0x00000080).
func (*legacyInventoryProtocol) TakeItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).Transfer recovered at 0x0000000001b9e6c0 (size 0x00000080).
func (*legacyInventoryProtocol) Transfer() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).TransferConfirmedFrom recovered at 0x0000000001b9e7c0 (size 0x00000100).
func (*legacyInventoryProtocol) TransferConfirmedFrom() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).TransferMatching recovered at 0x0000000001b9e940 (size 0x00000100).
func (*legacyInventoryProtocol) TransferMatching() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).TransferMatchingConfirmed recovered at 0x0000000001b9eb40 (size 0x000000a0).
func (*legacyInventoryProtocol) TransferMatchingConfirmed() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).WindowFromContainerID recovered at 0x0000000001b9ec20 (size 0x00000040).
func (*legacyInventoryProtocol) WindowFromContainerID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).WindowFromWindowID recovered at 0x0000000001b9ec80 (size 0x00000040).
func (*legacyInventoryProtocol) WindowFromWindowID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*legacyInventoryProtocol).write recovered at 0x0000000001b92620 (size 0x00000120).
func (*legacyInventoryProtocol) write() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).Boots recovered at 0x0000000001b99da0 (size 0x00000140).
func (*modernInventoryProtocol) Boots() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).Chestplate recovered at 0x0000000001b9a020 (size 0x00000140).
func (*modernInventoryProtocol) Chestplate() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).ClientSelectedHotBarSlot recovered at 0x0000000001b9a2a0 (size 0x00000020).
func (*modernInventoryProtocol) ClientSelectedHotBarSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).CloseCurrentWindow recovered at 0x0000000001b9a2e0 (size 0x00000040).
func (*modernInventoryProtocol) CloseCurrentWindow() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).CompareAndSwapHeldSlot recovered at 0x0000000001b9a340 (size 0x00000020).
func (*modernInventoryProtocol) CompareAndSwapHeldSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).CreateWindow recovered at 0x0000000001b9a380 (size 0x00000060).
func (*modernInventoryProtocol) CreateWindow() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).CurrentWindow recovered at 0x0000000001b9a400 (size 0x00000040).
func (*modernInventoryProtocol) CurrentWindow() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).CurrentWindowReady recovered at 0x0000000001b9a460 (size 0x00000040).
func (*modernInventoryProtocol) CurrentWindowReady() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).CurrentWindowSize recovered at 0x0000000001b9a4c0 (size 0x00000040).
func (*modernInventoryProtocol) CurrentWindowSize() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).DropItem recovered at 0x0000000001b9a520 (size 0x00000060).
func (*modernInventoryProtocol) DropItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).ForceSync recovered at 0x0000000001b9a5e0 (size 0x00000080).
func (*modernInventoryProtocol) ForceSync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).ForwardItemStackRequest recovered at 0x0000000001b9a6e0 (size 0x00000040).
func (*modernInventoryProtocol) ForwardItemStackRequest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).ForwardPlayerAuthInputRequest recovered at 0x0000000001b9a740 (size 0x00000040).
func (*modernInventoryProtocol) ForwardPlayerAuthInputRequest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).GetOpenContainerPosition recovered at 0x0000000001b9a7a0 (size 0x00000060).
func (*modernInventoryProtocol) GetOpenContainerPosition() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).HandleInventoryContent recovered at 0x0000000001b9a820 (size 0x00000040).
func (*modernInventoryProtocol) HandleInventoryContent() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).HandleInventorySlot recovered at 0x0000000001b9a880 (size 0x00000040).
func (*modernInventoryProtocol) HandleInventorySlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).HandleItemStackRequest recovered at 0x0000000001b9a8e0 (size 0x00000040).
func (*modernInventoryProtocol) HandleItemStackRequest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).HandleItemStackResponse recovered at 0x0000000001b9a960 (size 0x00000040).
func (*modernInventoryProtocol) HandleItemStackResponse() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).HandleSingleRequest recovered at 0x0000000001b9a9c0 (size 0x00000140).
func (*modernInventoryProtocol) HandleSingleRequest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).HeldItemInstance recovered at 0x0000000001b9ac60 (size 0x00000100).
func (*modernInventoryProtocol) HeldItemInstance() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).HeldSlot recovered at 0x0000000001b9ae60 (size 0x00000020).
func (*modernInventoryProtocol) HeldSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).Helmet recovered at 0x0000000001b9aea0 (size 0x00000140).
func (*modernInventoryProtocol) Helmet() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).Holding recovered at 0x0000000001b9b120 (size 0x00000140).
func (*modernInventoryProtocol) Holding() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).HotBarItemInstance recovered at 0x0000000001b9b3a0 (size 0x00000100).
func (*modernInventoryProtocol) HotBarItemInstance() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).Leggings recovered at 0x0000000001b9b4e0 (size 0x00000140).
func (*modernInventoryProtocol) Leggings() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).Offhand recovered at 0x0000000001b9b760 (size 0x00000140).
func (*modernInventoryProtocol) Offhand() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).ReadyWindow recovered at 0x0000000001b9b9e0 (size 0x000000a0).
func (*modernInventoryProtocol) ReadyWindow() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).RemoveWindow recovered at 0x0000000001b9baa0 (size 0x00000040).
func (*modernInventoryProtocol) RemoveWindow() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).SetClientSelectedHotBarSlot recovered at 0x0000000001b9bb00 (size 0x00000040).
func (*modernInventoryProtocol) SetClientSelectedHotBarSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).SetHeldSlot recovered at 0x0000000001b9bb60 (size 0x00000040).
func (*modernInventoryProtocol) SetHeldSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).SourceContainerID recovered at 0x0000000001b9bbc0 (size 0x00000040).
func (*modernInventoryProtocol) SourceContainerID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).SwapItem recovered at 0x0000000001b9bc20 (size 0x00000080).
func (*modernInventoryProtocol) SwapItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).Sync recovered at 0x0000000001b9bd20 (size 0x00000040).
func (*modernInventoryProtocol) Sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).SyncSlot recovered at 0x0000000001b9bd80 (size 0x00000040).
func (*modernInventoryProtocol) SyncSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).TakeItem recovered at 0x0000000001b9bde0 (size 0x00000080).
func (*modernInventoryProtocol) TakeItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).Transfer recovered at 0x0000000001b9bee0 (size 0x00000080).
func (*modernInventoryProtocol) Transfer() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).TransferConfirmedFrom recovered at 0x0000000001b9bfe0 (size 0x00000100).
func (*modernInventoryProtocol) TransferConfirmedFrom() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).TransferMatching recovered at 0x0000000001b9c160 (size 0x00000100).
func (*modernInventoryProtocol) TransferMatching() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).TransferMatchingConfirmed recovered at 0x0000000001b9c360 (size 0x000000a0).
func (*modernInventoryProtocol) TransferMatchingConfirmed() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).WindowFromContainerID recovered at 0x0000000001b9c440 (size 0x00000040).
func (*modernInventoryProtocol) WindowFromContainerID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).WindowFromWindowID recovered at 0x0000000001b9c4a0 (size 0x00000040).
func (*modernInventoryProtocol) WindowFromWindowID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*modernInventoryProtocol).write recovered at 0x0000000001b91b60 (size 0x00000200).
func (*modernInventoryProtocol) write() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/internal/inventory.(*requestOrigin).String recovered at 0x0000000001b7f400 (size 0x00000020).
func (*requestOrigin) String() string {
	return ""
}
