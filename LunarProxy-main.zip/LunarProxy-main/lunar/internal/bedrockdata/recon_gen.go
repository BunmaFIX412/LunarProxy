// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package bedrockdata

// Recovered types (from pclntab type descriptors).

// ItemDef is a recovered type.
type ItemDef struct{}

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// init recovered at 0x0000000001afd9a0 (size 0x00000020).
func init() {
	panic("stub")
}

// map.init.0 recovered at 0x0000000001afd9c0 (size 0x00000140).
func map_init_0() {
	panic("stub")
}
