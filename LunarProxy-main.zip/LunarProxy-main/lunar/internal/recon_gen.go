// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package internal

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// init recovered at 0x0000000001d0d4a0 (size 0x00000080).
func init() {
	panic("stub")
}
