// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package item

// Recovered types (from pclntab type descriptors).

// fallbackItem is a recovered type.
type fallbackItem struct{}

// Placeholder receiver types (no equality descriptor in pclntab).

type EndCrystal struct{}

type FishingRod struct{}

type Mace struct{}

type Shield struct{}

type StackWrapper struct{}

type UnknownItem struct{}

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// ArmorScore recovered at 0x0000000001b78740 (size 0x00000b60).
func ArmorScore() {
	panic("stub")
}

// FromAuthoritativeStackWithNBT recovered at 0x0000000001b794a0 (size 0x00000160).
func FromAuthoritativeStackWithNBT() {
	panic("stub")
}

// FromStackWithNBT recovered at 0x0000000001b79340 (size 0x00000160).
func FromStackWithNBT() {
	panic("stub")
}

// init.0 recovered at 0x0000000001b79e80 (size 0x00000080).
func init_0() {
	panic("stub")
}

// registerItemIfMissing recovered at 0x0000000001b79f00 (size 0x000000e0).
func registerItemIfMissing() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*EndCrystal).EncodeItem recovered at 0x0000000001b792c0 (size 0x00000020).
func (*EndCrystal) EncodeItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*EndCrystal).MaxCount recovered at 0x0000000001b792e0 (size 0x00000020).
func (*EndCrystal) MaxCount() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*FishingRod).EncodeItem recovered at 0x0000000001b79300 (size 0x00000020).
func (*FishingRod) EncodeItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*FishingRod).MaxCount recovered at 0x0000000001b79320 (size 0x00000020).
func (*FishingRod) MaxCount() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*Mace).AttackDamage recovered at 0x0000000001b79da0 (size 0x00000020).
func (*Mace) AttackDamage() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*Mace).DurabilityInfo recovered at 0x0000000001b79e00 (size 0x00000060).
func (*Mace) DurabilityInfo() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*Mace).EnchantmentValue recovered at 0x0000000001b79de0 (size 0x00000020).
func (*Mace) EnchantmentValue() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*Mace).EncodeItem recovered at 0x0000000001b79e60 (size 0x00000020).
func (*Mace) EncodeItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*Mace).MaxCount recovered at 0x0000000001b79dc0 (size 0x00000020).
func (*Mace) MaxCount() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*Shield).EncodeItem recovered at 0x0000000001b79fe0 (size 0x00000020).
func (*Shield) EncodeItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*Shield).OffHand recovered at 0x0000000001b7a000 (size 0x00000020).
func (*Shield) OffHand() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).AddStack recovered at 0x0000000001b79600 (size 0x00000420).
func (*StackWrapper) AddStack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).AnvilCost recovered at 0x0000000001b7a880 (size 0x00000080).
func (*StackWrapper) AnvilCost() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).AsBreakable recovered at 0x0000000001b7a960 (size 0x00000160).
func (*StackWrapper) AsBreakable() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).AsUnbreakable recovered at 0x0000000001b7ac60 (size 0x00000160).
func (*StackWrapper) AsUnbreakable() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).AttackDamage recovered at 0x0000000001b7af60 (size 0x00000080).
func (*StackWrapper) AttackDamage() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).Comparable recovered at 0x0000000001b79a20 (size 0x000000e0).
func (*StackWrapper) Comparable() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).Count recovered at 0x0000000001b7b280 (size 0x00000080).
func (*StackWrapper) Count() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).CustomName recovered at 0x0000000001b7b360 (size 0x00000080).
func (*StackWrapper) CustomName() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).Damage recovered at 0x0000000001b7b460 (size 0x00000160).
func (*StackWrapper) Damage() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).Durability recovered at 0x0000000001b7b780 (size 0x00000080).
func (*StackWrapper) Durability() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).Empty recovered at 0x0000000001b7b8e0 (size 0x00000080).
func (*StackWrapper) Empty() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).Enchantment recovered at 0x0000000001b7ba40 (size 0x00000160).
func (*StackWrapper) Enchantment() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).Enchantments recovered at 0x0000000001b7bd00 (size 0x00000080).
func (*StackWrapper) Enchantments() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).Equal recovered at 0x0000000001b7be60 (size 0x000001a0).
func (*StackWrapper) Equal() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).Grow recovered at 0x0000000001b79b00 (size 0x00000160).
func (*StackWrapper) Grow() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).Item recovered at 0x0000000001b7c3c0 (size 0x00000100).
func (*StackWrapper) Item() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).Lore recovered at 0x0000000001b7c5c0 (size 0x00000100).
func (*StackWrapper) Lore() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).MaxCount recovered at 0x0000000001b7c7c0 (size 0x00000100).
func (*StackWrapper) MaxCount() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).MaxDurability recovered at 0x0000000001b7c9c0 (size 0x00000080).
func (*StackWrapper) MaxDurability() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).NBTData recovered at 0x0000000001b79d40 (size 0x00000060).
func (*StackWrapper) NBTData() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).NetworkID recovered at 0x0000000001b79c60 (size 0x00000020).
func (*StackWrapper) NetworkID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).NetworkIDAuthoritative recovered at 0x0000000001b79d20 (size 0x00000020).
func (*StackWrapper) NetworkIDAuthoritative() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).String recovered at 0x0000000001b7cd60 (size 0x00000080).
func (*StackWrapper) String() string {
	return ""
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).Unbreakable recovered at 0x0000000001b7cec0 (size 0x00000080).
func (*StackWrapper) Unbreakable() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).Value recovered at 0x0000000001b7cfa0 (size 0x00000140).
func (*StackWrapper) Value() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).Values recovered at 0x0000000001b7d220 (size 0x00000080).
func (*StackWrapper) Values() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).WithAnvilCost recovered at 0x0000000001b7d380 (size 0x00000160).
func (*StackWrapper) WithAnvilCost() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).WithAuthoritativeNetworkID recovered at 0x0000000001b79c80 (size 0x000000a0).
func (*StackWrapper) WithAuthoritativeNetworkID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).WithCustomName recovered at 0x0000000001b7d7e0 (size 0x000001a0).
func (*StackWrapper) WithCustomName() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).WithDurability recovered at 0x0000000001b7db60 (size 0x00000160).
func (*StackWrapper) WithDurability() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).WithEnchantments recovered at 0x0000000001b7de80 (size 0x000001a0).
func (*StackWrapper) WithEnchantments() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).WithForcedEnchantments recovered at 0x0000000001b7e200 (size 0x000001a0).
func (*StackWrapper) WithForcedEnchantments() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).WithItem recovered at 0x0000000001b7e580 (size 0x00000180).
func (*StackWrapper) WithItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).WithLore recovered at 0x0000000001b7e8e0 (size 0x00000100).
func (*StackWrapper) WithLore() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).WithValue recovered at 0x0000000001b7eac0 (size 0x000001c0).
func (*StackWrapper) WithValue() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*StackWrapper).WithoutEnchantments recovered at 0x0000000001b7ee80 (size 0x000001a0).
func (*StackWrapper) WithoutEnchantments() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*UnknownItem).EncodeItem recovered at 0x0000000001b792a0 (size 0x00000020).
func (*UnknownItem) EncodeItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*fallbackItem).EncodeItem recovered at 0x0000000001b7a020 (size 0x00000040).
func (*fallbackItem) EncodeItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/item.(*fallbackItem).MaxCount recovered at 0x0000000001b7a060 (size 0x00000020).
func (*fallbackItem) MaxCount() {
	panic("stub")
}
