// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package world

// Recovered types (from pclntab type descriptors).

// BlockPalette is a recovered type.
type BlockPalette struct{}

// RuntimeIDBlockUpdate is a recovered type.
type RuntimeIDBlockUpdate struct{}

// Placeholder receiver types (no equality descriptor in pclntab).

type World struct{}

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// BlockActorID recovered at 0x0000000001b6d980 (size 0x00000060).
func BlockActorID() {
	panic("stub")
}

// BlockName recovered at 0x0000000001b6cc20 (size 0x000000c0).
func BlockName() {
	panic("stub")
}

// IsCanonicalPairedChestAt recovered at 0x0000000001b6db40 (size 0x00000080).
func IsCanonicalPairedChestAt() {
	panic("stub")
}

// IsCanonicalPairedChestEntity recovered at 0x0000000001b6d9e0 (size 0x00000160).
func IsCanonicalPairedChestEntity() {
	panic("stub")
}

// IsPairedChestAt recovered at 0x0000000001b6dbc0 (size 0x000000c0).
func IsPairedChestAt() {
	panic("stub")
}

// New recovered at 0x0000000001b70b20 (size 0x000001a0).
func New() {
	panic("stub")
}

// RetainedBlockEntityData recovered at 0x0000000001b6d6a0 (size 0x000002e0).
func RetainedBlockEntityData() {
	panic("stub")
}

// SessionBlockRegistry recovered at 0x0000000001b6fc60 (size 0x000003e0).
func SessionBlockRegistry() {
	panic("stub")
}

// blockUpdateNBT recovered at 0x0000000001b6d580 (size 0x00000120).
func blockUpdateNBT() {
	panic("stub")
}

// buildSessionBlockRegistry recovered at 0x0000000001b70360 (size 0x00000280).
func buildSessionBlockRegistry() {
	panic("stub")
}

// chunkBlockEntityData recovered at 0x0000000001b6d420 (size 0x00000080).
func chunkBlockEntityData() {
	panic("stub")
}

// chunkBlockRuntimeID recovered at 0x0000000001b6e760 (size 0x00000100).
func chunkBlockRuntimeID() {
	panic("stub")
}

// chunkInView recovered at 0x0000000001b74280 (size 0x000000a0).
func chunkInView() {
	panic("stub")
}

// cloneBlockNBT recovered at 0x0000000001b6f9c0 (size 0x00000080).
func cloneBlockNBT() {
	panic("stub")
}

// decodeBlockWithNBT recovered at 0x0000000001b6fac0 (size 0x000001a0).
func decodeBlockWithNBT() {
	panic("stub")
}

// init recovered at 0x0000000001b6c080 (size 0x00000320).
func init() {
	panic("stub")
}

// init.0 recovered at 0x0000000001b6c3a0 (size 0x00000880).
func init_0() {
	panic("stub")
}

// newBlockPalette recovered at 0x0000000001b71180 (size 0x00000120).
func newBlockPalette() {
	panic("stub")
}

// paletteDigest recovered at 0x0000000001b706e0 (size 0x00000360).
func paletteDigest() {
	panic("stub")
}

// paletteDigest.NewEncoder.func1 recovered at 0x0000000001b70a40 (size 0x00000080).
func paletteDigest_NewEncoder_func1() {
	panic("stub")
}

// setChunkBlockRuntimeID recovered at 0x0000000001b6e9c0 (size 0x00000120).
func setChunkBlockRuntimeID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*BlockPalette).AirRuntimeID recovered at 0x0000000001b70ae0 (size 0x00000020).
func (*BlockPalette) AirRuntimeID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*BlockPalette).InvisibleBedrockRuntimeID recovered at 0x0000000001b70b00 (size 0x00000020).
func (*BlockPalette) InvisibleBedrockRuntimeID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*BlockPalette).Registry recovered at 0x0000000001b70ac0 (size 0x00000020).
func (*BlockPalette) Registry() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*BlockPalette).blockRuntimeIDToNetwork recovered at 0x0000000001b6df20 (size 0x000000a0).
func (*BlockPalette) blockRuntimeIDToNetwork() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*BlockPalette).networkToBlockRuntimeID recovered at 0x0000000001b6dd60 (size 0x000000a0).
func (*BlockPalette) networkToBlockRuntimeID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).AddChunk recovered at 0x0000000001b712a0 (size 0x000001e0).
func (*World) AddChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).AirRuntimeID recovered at 0x0000000001b70d00 (size 0x00000020).
func (*World) AirRuntimeID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).ApplyRuntimeIDBlockUpdate recovered at 0x0000000001b6e140 (size 0x00000100).
func (*World) ApplyRuntimeIDBlockUpdate() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).ApplyRuntimeIDBlockUpdates recovered at 0x0000000001b6e280 (size 0x00000140).
func (*World) ApplyRuntimeIDBlockUpdates() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).Block recovered at 0x0000000001b723c0 (size 0x000000a0).
func (*World) Block() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).BlockEntityData recovered at 0x0000000001b72b00 (size 0x00000200).
func (*World) BlockEntityData() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).BlockNoBoundsCheck recovered at 0x0000000001b72460 (size 0x00000360).
func (*World) BlockNoBoundsCheck() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).BlockRegistry recovered at 0x0000000001b70ce0 (size 0x00000020).
func (*World) BlockRegistry() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).BlockRuntimeIDToBlock recovered at 0x0000000001b6de00 (size 0x00000060).
func (*World) BlockRuntimeIDToBlock() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).BlockRuntimeIDToNetwork recovered at 0x0000000001b6de60 (size 0x00000040).
func (*World) BlockRuntimeIDToNetwork() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).BlockToNetworkRuntimeID recovered at 0x0000000001b6dea0 (size 0x00000080).
func (*World) BlockToNetworkRuntimeID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).Chunk recovered at 0x0000000001b71620 (size 0x000000e0).
func (*World) Chunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).ChunkBlockUpdates recovered at 0x0000000001b72000 (size 0x000001e0).
func (*World) ChunkBlockUpdates() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).ChunkCount recovered at 0x0000000001b71ae0 (size 0x000000e0).
func (*World) ChunkCount() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).ChunkEntries recovered at 0x0000000001b71d40 (size 0x00000280).
func (*World) ChunkEntries() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).ChunkSnapshot recovered at 0x0000000001b71740 (size 0x00000100).
func (*World) ChunkSnapshot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).CleanChunks recovered at 0x0000000001b72f40 (size 0x00000660).
func (*World) CleanChunks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).CloneChunks recovered at 0x0000000001b71c00 (size 0x00000100).
func (*World) CloneChunks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).Dimension recovered at 0x0000000001b73cc0 (size 0x000000e0).
func (*World) Dimension() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).DimensionID recovered at 0x0000000001b73de0 (size 0x00000120).
func (*World) DimensionID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).EncodeChunkForNetwork recovered at 0x0000000001b6dfc0 (size 0x00000180).
func (*World) EncodeChunkForNetwork() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).ForEachChunkBlockUpdate recovered at 0x0000000001b722a0 (size 0x000000e0).
func (*World) ForEachChunkBlockUpdate() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).HasChunk recovered at 0x0000000001b719c0 (size 0x000000e0).
func (*World) HasChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).InvisibleBedrockRuntimeID recovered at 0x0000000001b70d20 (size 0x00000020).
func (*World) InvisibleBedrockRuntimeID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).IsNormalDeepslate recovered at 0x0000000001b72800 (size 0x00000060).
func (*World) IsNormalDeepslate() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).Lock recovered at 0x0000000001b74520 (size 0x00000020).
func (*World) Lock() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).MutateChunk recovered at 0x0000000001b71880 (size 0x00000100).
func (*World) MutateChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).NetworkRuntimeIDToBlock recovered at 0x0000000001b6dc80 (size 0x000000a0).
func (*World) NetworkRuntimeIDToBlock() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).NetworkRuntimeIDToBlockRuntimeID recovered at 0x0000000001b6dd20 (size 0x00000040).
func (*World) NetworkRuntimeIDToBlockRuntimeID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).Palette recovered at 0x0000000001b70cc0 (size 0x00000020).
func (*World) Palette() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).PurgeChunks recovered at 0x0000000001b735e0 (size 0x00000180).
func (*World) PurgeChunks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).RLock recovered at 0x0000000001b74540 (size 0x00000060).
func (*World) RLock() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).RLocker recovered at 0x0000000001b745a0 (size 0x00000020).
func (*World) RLocker() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).RUnlock recovered at 0x0000000001b745c0 (size 0x00000040).
func (*World) RUnlock() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).Range recovered at 0x0000000001b73ca0 (size 0x00000020).
func (*World) Range() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).RemoveChunk recovered at 0x0000000001b714c0 (size 0x00000120).
func (*World) RemoveChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).RespawnAnchorExplodes recovered at 0x0000000001b73f40 (size 0x000001e0).
func (*World) RespawnAnchorExplodes() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).SetBlock recovered at 0x0000000001b72d40 (size 0x000001c0).
func (*World) SetBlock() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).SetBlockEntityData recovered at 0x0000000001b72860 (size 0x00000260).
func (*World) SetBlockEntityData() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).SetBlockPalette recovered at 0x0000000001b70e40 (size 0x000000e0).
func (*World) SetBlockPalette() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).SetBlockRegistry recovered at 0x0000000001b70d40 (size 0x000000c0).
func (*World) SetBlockRegistry() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).SetDimension recovered at 0x0000000001b738e0 (size 0x00000380).
func (*World) SetDimension() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).SetUseBlockHashes recovered at 0x0000000001b74160 (size 0x000000c0).
func (*World) SetUseBlockHashes() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).TryLock recovered at 0x0000000001b74600 (size 0x00000020).
func (*World) TryLock() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).TryRLock recovered at 0x0000000001b74620 (size 0x00000040).
func (*World) TryRLock() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).Unlock recovered at 0x0000000001b74660 (size 0x00000020).
func (*World) Unlock() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).UpdateDimensionData recovered at 0x0000000001b737a0 (size 0x00000100).
func (*World) UpdateDimensionData() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).UseBlockHashes recovered at 0x0000000001b74260 (size 0x00000020).
func (*World) UseBlockHashes() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).applyRuntimeIDBlockUpdateLocked recovered at 0x0000000001b6e400 (size 0x00000360).
func (*World) applyRuntimeIDBlockUpdateLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).blockEntityDataLocked recovered at 0x0000000001b6d180 (size 0x000002a0).
func (*World) blockEntityDataLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).blockFromSnapshot recovered at 0x0000000001b6cf40 (size 0x00000240).
func (*World) blockFromSnapshot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).blockRuntimeIDHasNBT recovered at 0x0000000001b6fa40 (size 0x00000080).
func (*World) blockRuntimeIDHasNBT() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).defaultBlockEntityData recovered at 0x0000000001b6d4a0 (size 0x000000e0).
func (*World) defaultBlockEntityData() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).foldBlockUpdatesIntoChunkLocked recovered at 0x0000000001b6f1a0 (size 0x000005a0).
func (*World) foldBlockUpdatesIntoChunkLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).forEachChunkBlockUpdateLocked recovered at 0x0000000001b6cce0 (size 0x00000260).
func (*World) forEachChunkBlockUpdateLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).runtimeUpdateBlockFromSnapshot recovered at 0x0000000001b6f8a0 (size 0x00000120).
func (*World) runtimeUpdateBlockFromSnapshot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).setBlockUpdateLocked recovered at 0x0000000001b6eae0 (size 0x00000360).
func (*World) setBlockUpdateLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).setChunkBlock recovered at 0x0000000001b6e860 (size 0x00000160).
func (*World) setChunkBlock() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).setPaletteLocked recovered at 0x0000000001b70f60 (size 0x00000220).
func (*World) setPaletteLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).setRuntimeBlockEntityDataLocked recovered at 0x0000000001b6f740 (size 0x00000160).
func (*World) setRuntimeBlockEntityDataLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).setRuntimeBlockUpdateLocked recovered at 0x0000000001b6ef40 (size 0x00000260).
func (*World) setRuntimeBlockUpdateLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/world.(*World).syncChunkBlockEntityDataBeforeBlockUpdateLocked recovered at 0x0000000001b6ee40 (size 0x00000100).
func (*World) syncChunkBlockEntityDataBeforeBlockUpdateLocked() {
	panic("stub")
}
