package settings

import (
	"encoding/json"
	"fmt"
	"reflect"
	"sort"
	"strings"
)

type AFKClicker struct {
	Enabled   bool
	CPS       int
	ClickType string
	Crouch    bool
}

type AimAssist struct {
	Enabled        bool
	Range          float64
	RequireClick   bool
	WeaponsOnly    bool
	PlayersOnly    bool
	IncludeFriends bool
}

type AnchorAura struct {
	Enabled         bool
	Range           float64
	AutoPlace       bool
	FaceAnchors     string
	CheckLineOfSight bool
	TakeFrom        string
	IncludeMobs     bool
	StopWhenEating  bool
}

type AntiCrystal struct {
	Enabled bool
	YLevel  float64
}

type AutoClicker struct {
	Enabled bool
	CPS     int
}

type AutoCrit struct {
	Enabled        bool
	ApplyToFriends bool
}

type AutoCrystal struct {
	Enabled          bool
	Range            float64
	AutoPlace        bool   `name:"Auto Place Crystals"`
	HeldCrystalOnly  bool
	AutoPlaceObsidian bool
	ESP              bool
	SafeMode         bool
	StopWhenEating   bool
	FaceCrystals     string
	CheckLineOfSight bool
	OnlyOwnPlaced    bool `name:"Only Own Placed"`
}

func (s *AutoCrystal) ESPActive() bool {
	return s.Enabled && s.ESP
}

type AutoEat struct {
	Enabled      bool
	Hunger       float64
	GappleHearts float64
}

type AutoElytra struct {
	Enabled   bool
	Threshold float64
}

type AutoLog struct {
	Enabled bool
	Hearts  float64
	Command string
}

type AutoMiner struct {
	Enabled         bool
	Radius          int
	Block           string
	AutoEat         bool    `name:"AutoEat"`
	MinHealthHearts float64 `name:"Min HP"`
	Count           int
}

type AutoPotion struct {
	Enabled bool
	Hearts  float64
}

type AutoRocket struct {
	Enabled  bool
	Interval float64
}

type AutoStealer struct {
	Enabled bool
	DelayMs int
}

type AutoSwitch struct {
	Enabled       bool
	Slot1         int32
	Slot2         int32
	HitsPerSwitch int32
}

type AutoTotem struct {
	Enabled      bool
	ShowCounter  bool
	Delay        int
	Hearts       float64
}

type AutoWeb struct {
	Enabled         bool
	HitsPerWeb      int
	Range           float64
	FaceTarget      string
	CheckLineOfSight bool
	TakeFrom        string
}

type Backtrack struct {
	Enabled       bool
	MinDelay      uint16
	MaxDelay      uint16
	ESP           bool
	TargetMode    string
	Range         float64
	TrackingBuffer int
}

type BunnyHop struct {
	Enabled        bool
	VerticalMul    float64
	HorizontalMul  float64
}

type ChunkBorders struct {
	Enabled bool
	Mode    string
}

type ChunkFinder struct {
	Enabled          bool
	Deepslate        bool
	CobbledDeepslate bool
	RotatedDeepslate bool
	EndStone         bool
	DoubleChest      bool
	AmethystCluster  bool `name:"Amethyst Cluster"`
	Kelp             bool
	Vines            bool
	CaveVines        bool
	BeeNests         bool
	NotificationMode string
	SoundAlerts      bool
}

type Disabler struct {
	Enabled bool
	Mode    string
}

type DoubleClick struct {
	Enabled bool
	Min     int
	Max     int
}

type FastInteract struct {
	Enabled bool
	Speed   int
}

type Ghost struct {
	Enabled      bool
	HideCommands bool
	HideChat     bool
}

type HitBox struct {
	Enabled              bool
	Mode                 string
	WeaponsOnly          bool
	ForwardReachEnabled  bool
	IgnoreFriends        bool
	Width                float64
	Height               float64
}

type HoleESP struct {
	Enabled bool
	Depth   int
	Radius  int
	Limit   int
}

type JavaMode struct {
	Enabled  bool
	DelayPct float64
}

type KillAura struct {
	Enabled         bool
	Distance        float64
	CPS             uint8
	Players         bool
	WeaponsOnly     bool
	FOV             bool
	FOVDegrees      float64
	Mode            string
	DamageIndicator bool
	StopWhenEating  bool
}

func (s *KillAura) DamageIndicatorActive() bool {
	return s.Enabled && s.DamageIndicator
}

type Knockback struct {
	Enabled    bool
	Vertical   float32
	Horizontal float32
}

type MaceSwap struct {
	Enabled bool
	Slot    int32
}

type MotionFly struct {
	Enabled        bool
	VerticalSpeed  float32
	HorizontalSpeed float32
	Bypass         bool
	GlideSpeed     float32
	DelayMs        float32
}

type NewChunks struct {
	Enabled          bool
	NotificationMode string
	SoundAlerts      bool
}

type Nickname struct {
	Enabled bool
	Value   string
}

type Nuke struct {
	Enabled bool
	Size    int32
}

type PlayerESP struct {
	ShowHighlights bool
	Mode           string
}

type Reach struct {
	Enabled  bool
	Distance float64
}

type Scaffold struct {
	Enabled   bool
	BlockOnly bool
}

type Spam struct {
	Message      string
	Rate         float64
	Enabled      bool
	BypassFilter bool
}

type SpawnerProtect struct {
	Enabled            bool
	Radius             float64
	IncludeFriends     bool
	DisconnectOnApproach bool
	Salvage            bool
	StoreInEnderChest  bool
	SneakWhileBreaking bool
	BreakRadius        float64
}

type Speed struct {
	Enabled bool
	Amount  float32
}

type Step struct {
	Enabled bool
	Height  float64
}

type TPAura struct {
	Enabled        bool
	Distance       float64
	CPS            uint8
	Height         bool
	StopWhenEating bool
}

type Timer struct {
	Enabled bool
	Amount  float32
}

type TriggerBot struct {
	Enabled      bool
	CPS          int
	WeaponsOnly  bool
	PlayersOnly  bool
}

type Velocity struct {
	Enabled    bool
	Horizontal float64
	Vertical   float64
}

type BlockTracers struct {
	Enabled  bool
	Targets  []string
	Entities bool
	Blocks   bool
	Animals  bool
}

func (s *BlockTracers) Active() bool {
	return s.Enabled && len(s.Targets) > 0
}

func (s *BlockTracers) VisualsEnabled() bool {
	return s.Enabled && (s.Entities || s.Blocks || s.Animals)
}

func (s *BlockTracers) TargetNames() []string {
	out := make([]string, 0, len(s.Targets))
	for _, t := range s.Targets {
		if t != "" && !contains(out, t) {
			out = append(out, t)
		}
	}
	sort.Strings(out)
	return out
}

type Settings struct {
	AFKClicker     AFKClicker
	AimAssist      AimAssist
	AnchorAura     AnchorAura
	AntiCrystal    AntiCrystal
	AutoClicker    AutoClicker
	AutoCrit       AutoCrit
	AutoCrystal    AutoCrystal
	AutoEat        AutoEat
	AutoElytra     AutoElytra
	AutoLog        AutoLog
	AutoMiner      AutoMiner
	AutoPotion     AutoPotion
	AutoRocket     AutoRocket
	AutoStealer    AutoStealer
	AutoSwitch     AutoSwitch
	AutoTotem      AutoTotem
	AutoWeb        AutoWeb
	Backtrack      Backtrack
	BlockTracers   BlockTracers
	BunnyHop       BunnyHop
	ChunkBorders   ChunkBorders
	ChunkFinder    ChunkFinder
	Disabler       Disabler
	DoubleClick    DoubleClick
	FastInteract   FastInteract
	Ghost          Ghost
	HitBox         HitBox
	HoleESP        HoleESP
	JavaMode       JavaMode
	KillAura       KillAura
	Knockback      Knockback
	MaceSwap       MaceSwap
	MotionFly      MotionFly
	NewChunks      NewChunks
	Nickname       Nickname
	Nuke           Nuke
	PlayerESP      PlayerESP
	Reach          Reach
	Scaffold       Scaffold
	Spam           Spam
	SpawnerProtect SpawnerProtect
	Speed          Speed
	Step           Step
	TPAura         TPAura
	Timer          Timer
	TriggerBot     TriggerBot
	Velocity       Velocity
}

func DefaultSettings() *Settings {
	return &Settings{
		AFKClicker: AFKClicker{
			CPS:       8,
			ClickType: "left",
		},
		AimAssist: AimAssist{
			Range:        4.0,
			WeaponsOnly:  true,
			PlayersOnly:  true,
			RequireClick: false,
		},
		AnchorAura: AnchorAura{
			Range:            6.0,
			AutoPlace:        true,
			FaceAnchors:      "server_side",
			CheckLineOfSight: true,
			TakeFrom:         "hotbar",
			IncludeMobs:      false,
		},
		AntiCrystal: AntiCrystal{
			YLevel: 2.0,
		},
		AutoClicker: AutoClicker{
			CPS: 8,
		},
		AutoCrystal: AutoCrystal{
			Range:            5.0,
			AutoPlace:        true,
			SafeMode:         true,
			CheckLineOfSight: true,
			FaceCrystals:     "server_side",
			OnlyOwnPlaced:    true,
		},
		AutoEat: AutoEat{
			Hunger:       6.0,
			GappleHearts: 4.0,
		},
		AutoElytra: AutoElytra{
			Threshold: 8.0,
		},
		AutoLog: AutoLog{
			Hearts: 3.0,
		},
		AutoMiner: AutoMiner{
			Radius:          5,
			Block:           "diamond_ore",
			AutoEat:         true,
			MinHealthHearts: 6.0,
			Count:           1,
		},
		AutoPotion: AutoPotion{
			Hearts: 4.0,
		},
		AutoRocket: AutoRocket{
			Interval: 1.0,
		},
		AutoStealer: AutoStealer{
			DelayMs: 500,
		},
		AutoSwitch: AutoSwitch{
			Slot1:         1,
			Slot2:         2,
			HitsPerSwitch: 2,
		},
		AutoTotem: AutoTotem{
			ShowCounter: true,
			Delay:       3,
			Hearts:      4.0,
		},
		AutoWeb: AutoWeb{
			HitsPerWeb:      3,
			Range:           4.0,
			FaceTarget:      "server_side",
			CheckLineOfSight: true,
			TakeFrom:        "hotbar",
		},
		Backtrack: Backtrack{
			MinDelay:       150,
			MaxDelay:       250,
			TargetMode:     "attack",
			Range:          4.0,
			TrackingBuffer: 1500,
		},
		BunnyHop: BunnyHop{
			VerticalMul:   0.9,
			HorizontalMul: 1.0,
		},
		ChunkBorders: ChunkBorders{
			Mode: "normal",
		},
		ChunkFinder: ChunkFinder{
			Deepslate:        true,
			DoubleChest:      true,
			AmethystCluster:  true,
			Kelp:             true,
			Vines:            true,
			CaveVines:        true,
			NotificationMode: "chat",
			SoundAlerts:      true,
		},
		Disabler: Disabler{
			Mode: "normal",
		},
		DoubleClick: DoubleClick{
			Min: 2,
			Max: 3,
		},
		FastInteract: FastInteract{
			Speed: 2,
		},
		HitBox: HitBox{
			Mode:          "closet",
			WeaponsOnly:   true,
			Width:         0.2,
			Height:        0.2,
			IgnoreFriends: false,
		},
		HoleESP: HoleESP{
			Depth:  4,
			Radius: 4,
			Limit:  4,
		},
		JavaMode: JavaMode{
			DelayPct: 100.0,
		},
		KillAura: KillAura{
			Distance: 4.0,
			CPS:      8,
			Players:  true,
			Mode:     "multi",
		},
		Knockback: Knockback{
			Vertical:   0.4,
			Horizontal: 0.4,
		},
		MaceSwap: MaceSwap{
			Slot: 1,
		},
		MotionFly: MotionFly{
			VerticalSpeed:   0.5,
			HorizontalSpeed: 1.2,
		},
		NewChunks: NewChunks{
			NotificationMode: "chat",
			SoundAlerts:      true,
		},
		Nuke: Nuke{
			Size: 5,
		},
		PlayerESP: PlayerESP{
			ShowHighlights: true,
			Mode:           "blatant",
		},
		Reach: Reach{
			Distance: 4.0,
		},
		Spam: Spam{
			Rate: 0.5,
		},
		SpawnerProtect: SpawnerProtect{
			Radius:             8.0,
			IncludeFriends:     true,
			SneakWhileBreaking: true,
			BreakRadius:        1.0,
		},
		Speed: Speed{
			Amount: 0.4,
		},
		Step: Step{
			Height: 1.0,
		},
		TPAura: TPAura{
			Distance: 4.0,
			CPS:      8,
		},
		Timer: Timer{
			Amount: 1.0,
		},
		TriggerBot: TriggerBot{
			CPS: 12,
		},
		Velocity: Velocity{
			Horizontal: 1.0,
			Vertical:   1.0,
		},
	}
}

func init() {
	_ = DefaultSettings()
}

func (s *Settings) String() string {
	data, err := json.Marshal(s)
	if err != nil {
		return "{}"
	}
	return string(data)
}

func (s *Settings) HasRenderLines() bool {
	return s.KillAura.DamageIndicatorActive() ||
		s.PlayerESP.ShowHighlights && s.PlayerESP.Mode == "blatant" ||
		s.Backtrack.Enabled && s.Backtrack.ESP ||
		s.HitBox.Enabled && s.HitBox.Mode == "blatant"
}

func formatStruct(v any) string {
	rv := reflect.ValueOf(v)
	if rv.Kind() == reflect.Ptr {
		rv = rv.Elem()
	}
	if rv.Kind() != reflect.Struct {
		return ""
	}
	t := rv.Type()
	var parts []string
	for i := 0; i < rv.NumField(); i++ {
		f := t.Field(i)
		name := f.Tag.Get("name")
		if name == "" {
			name = f.Name
		}
		val := rv.Field(i)
		parts = append(parts, fmt.Sprintf("%s: %v", name, formatValue(val)))
	}
	return strings.Join(parts, "\n")
}

func formatValue(v reflect.Value) string {
	switch v.Kind() {
	case reflect.Bool:
		if v.Bool() {
			return "true"
		}
		return "false"
	case reflect.Float32, reflect.Float64:
		return fmt.Sprintf("%g", v.Float())
	case reflect.Slice:
		if v.IsNil() {
			return "[]"
		}
		var items []string
		for i := 0; i < v.Len(); i++ {
			items = append(items, formatValue(v.Index(i)))
		}
		return "[" + strings.Join(items, ", ") + "]"
	default:
		return fmt.Sprintf("%v", v.Interface())
	}
}

func contains(list []string, s string) bool {
	for _, item := range list {
		if item == s {
			return true
		}
	}
	return false
}

var mobHeadNames = func() []string {
	return []string{
		"zombie_head", "skeleton_skull", "creeper_head", "player_head",
		"wither_skeleton_skull", "dragon_head", "piglin_head",
	}
}

var signNames = func() []string {
	return []string{
		"oak_sign", "spruce_sign", "birch_sign", "jungle_sign",
		"acacia_sign", "dark_oak_sign", "mangrove_sign", "crimson_sign",
		"warped_sign",
	}
}

func buildBlockTracerCategories() map[string][]string {
	return map[string][]string{
		"mob_heads": mobHeadNames(),
		"signs":     signNames(),
	}
}