package form

type Field interface {
	Type() Field
	Options() []Option
}

type Settings interface {
	Type() Settings
	Options() []Option
}

type Option struct {
	Label string
	Value string
}

func Bool(key, label string, value bool, set func(bool)) *BoolField {
	return &BoolField{baseField: baseField{key: key, label: label}, value: value, set: set}
}

func Int(key, label string, value int, set func(int)) *IntField {
	return &IntField{baseField: baseField{key: key, label: label}, value: value, set: set}
}

func Float(key, label string, value float64, set func(float64)) *FloatField {
	return &FloatField{baseField: baseField{key: key, label: label}, value: value, set: set}
}

func String(key, label string, value string, set func(string)) *StringField {
	return &StringField{baseField: baseField{key: key, label: label}, value: value, set: set}
}

func Dropdown(key, label string, value string, options []Option, set func(string)) *DropdownField {
	return &DropdownField{baseField: baseField{key: key, label: label}, value: value, options: options, set: set}
}

type baseField struct {
	key   string
	label string
}

func (f *baseField) Key() string   { return f.key }
func (f *baseField) Label() string { return f.label }

type BoolField struct {
	baseField
	value bool
	set   func(bool)
}

func (f *BoolField) Type() Field { return f }

func (f *BoolField) Options() []Option {
	return []Option{{Label: "false", Value: "false"}, {Label: "true", Value: "true"}}
}

func (f *BoolField) Value() bool       { return f.value }
func (f *BoolField) SetValue(v bool)   { f.value = v; f.set(v) }

type IntField struct {
	baseField
	value int
	set   func(int)
}

func (f *IntField) Type() Field { return f }

func (f *IntField) Options() []Option {
	return nil
}

func (f *IntField) Value() int     { return f.value }
func (f *IntField) SetValue(v int) { f.value = v; f.set(v) }

type FloatField struct {
	baseField
	value float64
	set   func(float64)
}

func (f *FloatField) Type() Field { return f }

func (f *FloatField) Options() []Option {
	return nil
}

func (f *FloatField) Value() float64     { return f.value }
func (f *FloatField) SetValue(v float64) { f.value = v; f.set(v) }

type StringField struct {
	baseField
	value string
	set   func(string)
}

func (f *StringField) Type() Field { return f }

func (f *StringField) Options() []Option {
	return nil
}

func (f *StringField) Value() string     { return f.value }
func (f *StringField) SetValue(v string) { f.value = v; f.set(v) }

type DropdownField struct {
	baseField
	value   string
	options []Option
	set     func(string)
}

func (f *DropdownField) Type() Field { return f }

func (f *DropdownField) Options() []Option {
	return f.options
}

func (f *DropdownField) Value() string { return f.value }
func (f *DropdownField) SetValue(v string) {
	f.value = v
	f.set(v)
}