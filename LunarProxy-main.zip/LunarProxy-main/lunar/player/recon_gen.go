// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package player

// Recovered types (from pclntab type descriptors).

// Actions is a recovered type.
type Actions struct{}

// BacktrackDeferContext is a recovered type.
type BacktrackDeferContext struct{}

// BadSection is a recovered type.
type BadSection struct{}

// BlockedModule is a recovered type.
type BlockedModule struct{}

// ClickUIOption is a recovered type.
type ClickUIOption struct{}

// ClickUIStyle is a recovered type.
type ClickUIStyle struct{}

// Data is a recovered type.
type Data struct{}

// DeathPositionEntry is a recovered type.
type DeathPositionEntry struct{}

// ModuleAvailability is a recovered type.
type ModuleAvailability struct{}

// ModuleCategoryMeta is a recovered type.
type ModuleCategoryMeta struct{}

// ModuleMeta is a recovered type.
type ModuleMeta struct{}

// ShulkerPreviewEntry is a recovered type.
type ShulkerPreviewEntry struct{}

// StatChangerLine is a recovered type.
type StatChangerLine struct{}

// XrayBlockUpdateGuard is a recovered type.
type XrayBlockUpdateGuard struct{}

// afkClicker is a recovered type.
type afkClicker struct{}

// aimAssistComponent is a recovered type.
type aimAssistComponent struct{}

// aimAssistTeleport is a recovered type.
type aimAssistTeleport struct{}

// atomicFloat32 is a recovered type.
type atomicFloat32 struct{}

// attackInfo is a recovered type.
type attackInfo struct{}

// attributeState is a recovered type.
type attributeState struct{}

// autoCrystalDamageScorer is a recovered type.
type autoCrystalDamageScorer struct{}

// autoCrystalPlacement is a recovered type.
type autoCrystalPlacement struct{}

// autoCrystalTarget is a recovered type.
type autoCrystalTarget struct{}

// autoMinerRuntimeBlockInfo is a recovered type.
type autoMinerRuntimeBlockInfo struct{}

// backtrackSnapshot is a recovered type.
type backtrackSnapshot struct{}

// blockHit is a recovered type.
type blockHit struct{}

// blockTracerCategoryMeta is a recovered type.
type blockTracerCategoryMeta struct{}

// blockTracerRenderEntry is a recovered type.
type blockTracerRenderEntry struct{}

// blockTracerRenderState is a recovered type.
type blockTracerRenderState struct{}

// blockTracerSelectedEntry is a recovered type.
type blockTracerSelectedEntry struct{}

// blockTracerTextShapeState is a recovered type.
type blockTracerTextShapeState struct{}

// blockTracerVisualMeta is a recovered type.
type blockTracerVisualMeta struct{}

// candidate·3 is a recovered type.
type candidate_3 struct{}

// chunkFinderBlockInfo is a recovered type.
type chunkFinderBlockInfo struct{}

// coalescingScan is a recovered type.
type coalescingScan struct{}

// containerWindowArbiter is a recovered type.
type containerWindowArbiter struct{}

// deathLightningComponent is a recovered type.
type deathLightningComponent struct{}

// debugDrawerState is a recovered type.
type debugDrawerState struct{}

// debugShapeKey is a recovered type.
type debugShapeKey struct{}

// deferredPacket is a recovered type.
type deferredPacket struct{}

// doubleClickBurst is a recovered type.
type doubleClickBurst struct{}

// eatingState is a recovered type.
type eatingState struct{}

// effectData is a recovered type.
type effectData struct{}

// emote is a recovered type.
type emote struct{}

// friendAlertRosterEntry is a recovered type.
type friendAlertRosterEntry struct{}

// gameModeState is a recovered type.
type gameModeState struct{}

// hole is a recovered type.
type hole struct{}

// holeESPCandidate is a recovered type.
type holeESPCandidate struct{}

// holeESPMarker is a recovered type.
type holeESPMarker struct{}

// lightningState is a recovered type.
type lightningState struct{}

// listedPlayer is a recovered type.
type listedPlayer struct{}

// motionFlyState is a recovered type.
type motionFlyState struct{}

// noFallComponent is a recovered type.
type noFallComponent struct{}

// spamComponent is a recovered type.
type spamComponent struct{}

// spamLoopState is a recovered type.
type spamLoopState struct{}

// spawnerProtectComponent is a recovered type.
type spawnerProtectComponent struct{}

// targetInfo is a recovered type.
type targetInfo struct{}

// targetSelectOptions is a recovered type.
type targetSelectOptions struct{}

// weatherState is a recovered type.
type weatherState struct{}

// xrayChunkOverlay is a recovered type.
type xrayChunkOverlay struct{}

// Placeholder receiver types (no equality descriptor in pclntab).

type BoundaryWriter struct{}

type ClickUIState struct{}

type FileConfigStore struct{}

type FriendList struct{}

type Player struct{}

type SavedConfig struct{}

type Scoreboard struct{}

type abilityState struct{}

type anchorAuraComponent struct{}

type autoClickerComponent struct{}

type autoCrystal struct{}

type autoEatComponent struct{}

type autoEquipComponent struct{}

type autoFishComponent struct{}

type autoMinerComponent struct{}

type autoRocketComponent struct{}

type autoSellComponent struct{}

type autoTotemComponent struct{}

type backtrackState struct{}

type blockHit_bool_ struct{}

type blockHit_github_com_lunar_bedrock_lunar_lunar_player_autoMinerRuntimeBlockInfo_ struct{}

type blockHit_github_com_lunar_bedrock_lunar_lunar_player_chunkFinderBlockInfo_ struct{}

type blockHit_string_ struct{}

type blockScanTargets struct{}

type blockTracerCandidateIndex struct{}

type blockTracers struct{}

type bunnyHopComponent struct{}

type chunkFinderState struct{}

type chunkScanSweep struct{}

type chunkScanner struct{}

type clicksState struct{}

type combatPacer struct{}

type deathComponent struct{}

type deathPositionState struct{}

type debugDrawerRuntime struct{}

type effectTracker struct{}

type entityTracker struct{}

type fastInteractComponent struct{}

type formsState struct{}

type friendAlertsComponent struct{}

type heldSlotArbiter struct{}

type holeESPScan struct{}

type holeESPState struct{}

type infiniteAuraComponent struct{}

type killAuraComponent struct{}

type killAuraLockState struct{}

type newChunksState struct{}

type placementUser struct{}

type pvpBotComponent struct{}

type scaffoldComponent struct{}

type shulkerTooltipComponent struct{}

type stepComponent struct{}

type tpAuraComponent struct{}

type triggerBotComponent struct{}

type xray struct{}

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// BeginXrayBlockUpdatePacket recovered at 0x0000000001c15240 (size 0x00000120).
func BeginXrayBlockUpdatePacket() {
	panic("stub")
}

// DeleteUserConfig recovered at 0x0000000001bbf580 (size 0x00000140).
func DeleteUserConfig() {
	panic("stub")
}

// ListUserConfigs recovered at 0x0000000001bbf6c0 (size 0x00000520).
func ListUserConfigs() {
	panic("stub")
}

// LoadConfig recovered at 0x0000000001bbfc80 (size 0x00000640).
func LoadConfig() {
	panic("stub")
}

// LoadSavedData recovered at 0x0000000001c57e40 (size 0x000000c0).
func LoadSavedData() {
	panic("stub")
}

// New recovered at 0x0000000001c2ad40 (size 0x000017a0).
func New() {
	panic("stub")
}

// NormalizeUserConfig recovered at 0x0000000001bbe360 (size 0x00000380).
func NormalizeUserConfig() {
	panic("stub")
}

// RegisterModuleFactoryWithAvailability recovered at 0x0000000001c27840 (size 0x000001a0).
func RegisterModuleFactoryWithAvailability() {
	panic("stub")
}

// RenameUserConfig recovered at 0x0000000001bbf240 (size 0x00000340).
func RenameUserConfig() {
	panic("stub")
}

// SanitizeConfigName recovered at 0x0000000001bbe140 (size 0x00000120).
func SanitizeConfigName() {
	panic("stub")
}

// SanitizeStatChangerText recovered at 0x0000000001c5a980 (size 0x00000140).
func SanitizeStatChangerText() {
	panic("stub")
}

// SaveUserConfig recovered at 0x0000000001bbe6e0 (size 0x000003c0).
func SaveUserConfig() {
	panic("stub")
}

// activeShulkerTooltipStackIDs recovered at 0x0000000001c0c660 (size 0x00000140).
func activeShulkerTooltipStackIDs() {
	panic("stub")
}

// activeShulkerTooltipStackIDs.activeShulkerTooltipStackIDs.func1.func2 recovered at 0x0000000001c0c920 (size 0x00000180).
func activeShulkerTooltipStackIDs_activeShulkerTooltipStackIDs_func1_func2() {
	panic("stub")
}

// activeShulkerTooltipStackIDs.activeShulkerTooltipStackIDs.func1.func3 recovered at 0x0000000001c0c7a0 (size 0x00000180).
func activeShulkerTooltipStackIDs_activeShulkerTooltipStackIDs_func1_func3() {
	panic("stub")
}

// addFriendName recovered at 0x0000000001c20960 (size 0x000001a0).
func addFriendName() {
	panic("stub")
}

// airJump.apply recovered at 0x0000000001bc5e00 (size 0x000000e0).
func airJump_apply() {
	panic("stub")
}

// analyzeChunkForFinder recovered at 0x0000000001bf79a0 (size 0x00000520).
func analyzeChunkForFinder() {
	panic("stub")
}

// anchorAuraPlacementHitVec recovered at 0x0000000001bca740 (size 0x000001c0).
func anchorAuraPlacementHitVec() {
	panic("stub")
}

// autoCrystalBlockBox recovered at 0x0000000001bcdf40 (size 0x00000100).
func autoCrystalBlockBox() {
	panic("stub")
}

// autoCrystalBoxAboveBase recovered at 0x0000000001bcdc40 (size 0x000001c0).
func autoCrystalBoxAboveBase() {
	panic("stub")
}

// autoCrystalDamageScorer.estimateDamage recovered at 0x0000000001bce640 (size 0x00000220).
func autoCrystalDamageScorer_estimateDamage() {
	panic("stub")
}

// autoCrystalDamageScorer.scoreExplosion recovered at 0x0000000001bce040 (size 0x000002c0).
func autoCrystalDamageScorer_scoreExplosion() {
	panic("stub")
}

// autoCrystalHasPlacementAir recovered at 0x0000000001bcde00 (size 0x00000140).
func autoCrystalHasPlacementAir() {
	panic("stub")
}

// autoCrystalSearchBox recovered at 0x0000000001bcd560 (size 0x00000120).
func autoCrystalSearchBox() {
	panic("stub")
}

// autoCrystalTargetsByDistance recovered at 0x0000000001bce300 (size 0x00000160).
func autoCrystalTargetsByDistance() {
	panic("stub")
}

// autoFishHoldingRod recovered at 0x0000000001bd8a80 (size 0x00000180).
func autoFishHoldingRod() {
	panic("stub")
}

// autoFishScanHooks recovered at 0x0000000001bd8680 (size 0x00000400).
func autoFishScanHooks() {
	panic("stub")
}

// autoMinerBlockInfo recovered at 0x0000000001bdda20 (size 0x000000c0).
func autoMinerBlockInfo() {
	panic("stub")
}

// autoSellIsConfirmPane recovered at 0x0000000001be7ec0 (size 0x000001c0).
func autoSellIsConfirmPane() {
	panic("stub")
}

// autoSellIsStorage recovered at 0x0000000001be6aa0 (size 0x00000060).
func autoSellIsStorage() {
	panic("stub")
}

// autoSellOpenStorage recovered at 0x0000000001be6940 (size 0x00000160).
func autoSellOpenStorage() {
	panic("stub")
}

// autoSellStorageWindow recovered at 0x0000000001be6780 (size 0x000001c0).
func autoSellStorageWindow() {
	panic("stub")
}

// autoSellWindowOpen recovered at 0x0000000001be7e60 (size 0x00000060).
func autoSellWindowOpen() {
	panic("stub")
}

// autoSprint.apply recovered at 0x0000000001be8080 (size 0x00000480).
func autoSprint_apply() {
	panic("stub")
}

// bfsOrderBlockPosComponent recovered at 0x0000000001be3580 (size 0x00000640).
func bfsOrderBlockPosComponent() {
	panic("stub")
}

// blockNameFromRuntimeID recovered at 0x0000000001bb9e20 (size 0x000000e0).
func blockNameFromRuntimeID() {
	panic("stub")
}

// blockScanValueAt recovered at 0x0000000001c68ba0 (size 0x000002e0).
func blockScanValueAt() {
	panic("stub")
}

// blockTracerCanSkipSubChunk recovered at 0x0000000001beefe0 (size 0x00000180).
func blockTracerCanSkipSubChunk() {
	panic("stub")
}

// blockTracerCategoryForName recovered at 0x0000000001bea0a0 (size 0x000003a0).
func blockTracerCategoryForName() {
	panic("stub")
}

// blockTracerColorForCategory recovered at 0x0000000001bea5e0 (size 0x000001c0).
func blockTracerColorForCategory() {
	panic("stub")
}

// blockTracerDoubleChestTextLocation recovered at 0x0000000001bf23a0 (size 0x000002e0).
func blockTracerDoubleChestTextLocation() {
	panic("stub")
}

// blockTracerKeepClosestEntries recovered at 0x0000000001beb740 (size 0x000000e0).
func blockTracerKeepClosestEntries() {
	panic("stub")
}

// blockTracerLoadedChunkSnapshot recovered at 0x0000000001bf3880 (size 0x000000c0).
func blockTracerLoadedChunkSnapshot() {
	panic("stub")
}

// blockTracerNameForCategory recovered at 0x0000000001bea480 (size 0x00000120).
func blockTracerNameForCategory() {
	panic("stub")
}

// blockTracerPushClosestEntry recovered at 0x0000000001bef160 (size 0x000002a0).
func blockTracerPushClosestEntry() {
	panic("stub")
}

// blockTracerSubChunkMinDistSq recovered at 0x0000000001beb880 (size 0x00000120).
func blockTracerSubChunkMinDistSq() {
	panic("stub")
}

// blockTracerTargetNames recovered at 0x0000000001bbb7a0 (size 0x000001a0).
func blockTracerTargetNames() {
	panic("stub")
}

// borrowBlockScanOverlay recovered at 0x0000000001bb9f00 (size 0x00000100).
func borrowBlockScanOverlay() {
	panic("stub")
}

// borrowChunkHighlightSnapshot recovered at 0x0000000001c54aa0 (size 0x000000e0).
func borrowChunkHighlightSnapshot() {
	panic("stub")
}

// breakDurationTicks recovered at 0x0000000001c49000 (size 0x00000280).
func breakDurationTicks() {
	panic("stub")
}

// buildBlockTracerVisualCategories recovered at 0x0000000001bba4c0 (size 0x000012e0).
func buildBlockTracerVisualCategories() {
	panic("stub")
}

// buildBreakSteps recovered at 0x0000000001c44a40 (size 0x00000560).
func buildBreakSteps() {
	panic("stub")
}

// buildXrayNameColors recovered at 0x0000000001bbbb60 (size 0x000002e0).
func buildXrayNameColors() {
	panic("stub")
}

// chunkFinderBlockInfoFromBlock recovered at 0x0000000001bf9940 (size 0x00000140).
func chunkFinderBlockInfoFromBlock() {
	panic("stub")
}

// chunkFinderCommit recovered at 0x0000000001bf53c0 (size 0x00000620).
func chunkFinderCommit() {
	panic("stub")
}

// chunkFinderCountDirection recovered at 0x0000000001bf96e0 (size 0x00000160).
func chunkFinderCountDirection() {
	panic("stub")
}

// chunkFinderIsInLargeDeepslateLine recovered at 0x0000000001bf93c0 (size 0x00000200).
func chunkFinderIsInLargeDeepslateLine() {
	panic("stub")
}

// chunkFinderIsNormalDeepslateCached recovered at 0x0000000001bf9840 (size 0x00000100).
func chunkFinderIsNormalDeepslateCached() {
	panic("stub")
}

// chunkFinderLineMeetsThreshold recovered at 0x0000000001bf95c0 (size 0x00000120).
func chunkFinderLineMeetsThreshold() {
	panic("stub")
}

// chunkFinderScannerAnalyse recovered at 0x0000000001bf50c0 (size 0x000001a0).
func chunkFinderScannerAnalyse() {
	panic("stub")
}

// chunkFinderScannerRelevant recovered at 0x0000000001bf5260 (size 0x00000160).
func chunkFinderScannerRelevant() {
	panic("stub")
}

// chunkFinderShouldTrackInfo recovered at 0x0000000001bf9080 (size 0x00000340).
func chunkFinderShouldTrackInfo() {
	panic("stub")
}

// chunkFinderSuspiciousReasons recovered at 0x0000000001bf6da0 (size 0x00000c00).
func chunkFinderSuspiciousReasons() {
	panic("stub")
}

// chunkXZMinDistSq recovered at 0x0000000001bc1ae0 (size 0x000000a0).
func chunkXZMinDistSq() {
	panic("stub")
}

// cloneAvailableCommands recovered at 0x0000000001bb52e0 (size 0x000001c0).
func cloneAvailableCommands() {
	panic("stub")
}

// cloneNBTMap recovered at 0x0000000001c5d840 (size 0x00000080).
func cloneNBTMap() {
	panic("stub")
}

// cloneShulkerItemsPath recovered at 0x0000000001c5d980 (size 0x00000160).
func cloneShulkerItemsPath() {
	panic("stub")
}

// collectConnectedBlockPosComponentAndClosest recovered at 0x0000000001be2f20 (size 0x00000660).
func collectConnectedBlockPosComponentAndClosest() {
	panic("stub")
}

// colorFromID recovered at 0x0000000001c52800 (size 0x000000a0).
func colorFromID() {
	panic("stub")
}

// combatRayBox.intercept recovered at 0x0000000001c3b560 (size 0x000007c0).
func combatRayBox_intercept() {
	panic("stub")
}

// combatRayBox.intersects recovered at 0x0000000001c3b400 (size 0x00000160).
func combatRayBox_intersects() {
	panic("stub")
}

// combatView.EyePosition32 recovered at 0x0000000001bbc700 (size 0x00000120).
func combatView_EyePosition32() {
	panic("stub")
}

// combatView.Geometry recovered at 0x0000000001bbc5c0 (size 0x00000140).
func combatView_Geometry() {
	panic("stub")
}

// combatView.HasUnobstructedPath recovered at 0x0000000001bbca40 (size 0x00000520).
func combatView_HasUnobstructedPath() {
	panic("stub")
}

// combatView.HasUnobstructedPathToEye recovered at 0x0000000001bbcf60 (size 0x00000100).
func combatView_HasUnobstructedPathToEye() {
	panic("stub")
}

// combatView.NearbyEntities recovered at 0x0000000001bbd680 (size 0x00000120).
func combatView_NearbyEntities() {
	panic("stub")
}

// combatView.NearbyEntities.func1 recovered at 0x0000000001bbd7a0 (size 0x00000200).
func combatView_NearbyEntities_func1() {
	panic("stub")
}

// combatView.WithinDistance recovered at 0x0000000001bbc820 (size 0x00000180).
func combatView_WithinDistance() {
	panic("stub")
}

// combatView.WithinView recovered at 0x0000000001bbc9a0 (size 0x000000a0).
func combatView_WithinView() {
	panic("stub")
}

// combatView.aimBoxIntercept recovered at 0x0000000001bbd060 (size 0x000003e0).
func combatView_aimBoxIntercept() {
	panic("stub")
}

// combatView.eyePath recovered at 0x0000000001bbd440 (size 0x00000240).
func combatView_eyePath() {
	panic("stub")
}

// cpsWithFluctuation recovered at 0x0000000001c606c0 (size 0x000000c0).
func cpsWithFluctuation() {
	panic("stub")
}

// debugDrawerBoxLocation recovered at 0x0000000001c54340 (size 0x00000240).
func debugDrawerBoxLocation() {
	panic("stub")
}

// decodeSectionData recovered at 0x0000000001c5b4e0 (size 0x00000300).
func decodeSectionData() {
	panic("stub")
}

// decodeSettingsSection recovered at 0x0000000001c5ba80 (size 0x000000c0).
func decodeSettingsSection() {
	panic("stub")
}

// deferredServerPacketTargetRuntimeID recovered at 0x0000000001bb63c0 (size 0x000001a0).
func deferredServerPacketTargetRuntimeID() {
	panic("stub")
}

// disablerComponent.apply recovered at 0x0000000001bfc220 (size 0x000004a0).
func disablerComponent_apply() {
	panic("stub")
}

// discoverWoodTrapdoorNames recovered at 0x0000000001bbb940 (size 0x00000220).
func discoverWoodTrapdoorNames() {
	panic("stub")
}

// effectiveLanguage recovered at 0x0000000001c2c4e0 (size 0x000000e0).
func effectiveLanguage() {
	panic("stub")
}

// emptyHotbarSlot recovered at 0x0000000001c252e0 (size 0x00000080).
func emptyHotbarSlot() {
	panic("stub")
}

// faceClickOffset recovered at 0x0000000001c32d00 (size 0x00000180).
func faceClickOffset() {
	panic("stub")
}

// findHotbarBlock recovered at 0x0000000001c32340 (size 0x000002c0).
func findHotbarBlock() {
	panic("stub")
}

// forEachXrayBreakRadius recovered at 0x0000000001c16720 (size 0x000001e0).
func forEachXrayBreakRadius() {
	panic("stub")
}

// forEachXrayFallingBlock recovered at 0x0000000001c158a0 (size 0x000002e0).
func forEachXrayFallingBlock() {
	panic("stub")
}

// formatArrayListText recovered at 0x0000000001bcc300 (size 0x00000300).
func formatArrayListText() {
	panic("stub")
}

// generateRandomSuffix recovered at 0x0000000001c0e2c0 (size 0x000000a0).
func generateRandomSuffix() {
	panic("stub")
}

// hasAquaAffinity recovered at 0x0000000001c48e80 (size 0x00000180).
func hasAquaAffinity() {
	panic("stub")
}

// heldItemStack recovered at 0x0000000001c262e0 (size 0x00000280).
func heldItemStack() {
	panic("stub")
}

// heldSlotItemSnapshot recovered at 0x0000000001c23ce0 (size 0x000002a0).
func heldSlotItemSnapshot() {
	panic("stub")
}

// hideShulkerItems recovered at 0x0000000001c5d8c0 (size 0x000000c0).
func hideShulkerItems() {
	panic("stub")
}

// hitBoxComponent.refreshOnVisibleWeaponChange recovered at 0x0000000001bfef00 (size 0x000000c0).
func hitBoxComponent_refreshOnVisibleWeaponChange() {
	panic("stub")
}

// hitBoxComponent.refreshOnVisibleWeaponChange.func1 recovered at 0x0000000001c64100 (size 0x00000020).
func hitBoxComponent_refreshOnVisibleWeaponChange_func1() {
	panic("stub")
}

// hitBoxComponent.refreshOnVisibleWeaponChange.func2 recovered at 0x0000000001bfefc0 (size 0x00000060).
func hitBoxComponent_refreshOnVisibleWeaponChange_func2() {
	panic("stub")
}

// hitBoxComponent.updateBoundingBoxes recovered at 0x0000000001bff020 (size 0x00000540).
func hitBoxComponent_updateBoundingBoxes() {
	panic("stub")
}

// holeESPBlockUpdateNeighbours recovered at 0x0000000001c015e0 (size 0x000004e0).
func holeESPBlockUpdateNeighbours() {
	panic("stub")
}

// holeESPCappedShaft recovered at 0x0000000001c010a0 (size 0x000002e0).
func holeESPCappedShaft() {
	panic("stub")
}

// holeESPEnclosedAt recovered at 0x0000000001c014c0 (size 0x00000120).
func holeESPEnclosedAt() {
	panic("stub")
}

// holeESPScannerAnalyse recovered at 0x0000000001c01ac0 (size 0x000000a0).
func holeESPScannerAnalyse() {
	panic("stub")
}

// holeESPScannerCommit recovered at 0x0000000001c01b60 (size 0x000004a0).
func holeESPScannerCommit() {
	panic("stub")
}

// holeESPShaftAt recovered at 0x0000000001c00f80 (size 0x00000120).
func holeESPShaftAt() {
	panic("stub")
}

// holeESPShaftTop recovered at 0x0000000001c01380 (size 0x00000140).
func holeESPShaftTop() {
	panic("stub")
}

// hotbarSlotMatching recovered at 0x0000000001c25260 (size 0x00000080).
func hotbarSlotMatching() {
	panic("stub")
}

// humanizeMinecraftName recovered at 0x0000000001c5e220 (size 0x000001e0).
func humanizeMinecraftName() {
	panic("stub")
}

// init recovered at 0x0000000001bb0680 (size 0x00000b00).
func init() {
	panic("stub")
}

// init.0 recovered at 0x0000000001c2ab60 (size 0x000000c0).
func init_0() {
	panic("stub")
}

// init.1 recovered at 0x0000000001c2ace0 (size 0x00000060).
func init_1() {
	panic("stub")
}

// init.toolStackMatching.func11 recovered at 0x0000000001bb1180 (size 0x00000200).
func init_toolStackMatching_func11() {
	panic("stub")
}

// inputBusy recovered at 0x0000000001c407c0 (size 0x000003c0).
func inputBusy() {
	panic("stub")
}

// inputState.applyEatingTransitions recovered at 0x0000000001c3fb80 (size 0x000005a0).
func inputState_applyEatingTransitions() {
	panic("stub")
}

// inputState.applyLocomotion recovered at 0x0000000001c41000 (size 0x00000de0).
func inputState_applyLocomotion() {
	panic("stub")
}

// inputState.applySneak recovered at 0x0000000001c40120 (size 0x000002c0).
func inputState_applySneak() {
	panic("stub")
}

// isAutoEatFood recovered at 0x0000000001bd5e40 (size 0x00000240).
func isAutoEatFood() {
	panic("stub")
}

// isAutoEatGapple recovered at 0x0000000001bd6080 (size 0x000001a0).
func isAutoEatGapple() {
	panic("stub")
}

// isBlockExposed recovered at 0x0000000001bf9d20 (size 0x00000360).
func isBlockExposed() {
	panic("stub")
}

// isEndCrystal recovered at 0x0000000001bd3740 (size 0x00000260).
func isEndCrystal() {
	panic("stub")
}

// isEndCrystalItemInstance recovered at 0x0000000001bd3fe0 (size 0x00000120).
func isEndCrystalItemInstance() {
	panic("stub")
}

// isGlowstone recovered at 0x0000000001bcb040 (size 0x00000180).
func isGlowstone() {
	panic("stub")
}

// isMaceStack recovered at 0x0000000001c03760 (size 0x00000280).
func isMaceStack() {
	panic("stub")
}

// isNearLiquid recovered at 0x0000000001bde0c0 (size 0x000001c0).
func isNearLiquid() {
	panic("stub")
}

// isObsidian recovered at 0x0000000001bd3d80 (size 0x00000260).
func isObsidian() {
	panic("stub")
}

// isRespawnAnchor recovered at 0x0000000001bcaec0 (size 0x00000180).
func isRespawnAnchor() {
	panic("stub")
}

// isWeb recovered at 0x0000000001be9f00 (size 0x000001a0).
func isWeb() {
	panic("stub")
}

// jetpack.apply recovered at 0x0000000001c02680 (size 0x00000260).
func jetpack_apply() {
	panic("stub")
}

// joinReasonedIDs recovered at 0x0000000001c67d80 (size 0x00000220).
func joinReasonedIDs() {
	panic("stub")
}

// killAuraIndicatorAppearance recovered at 0x0000000001c4d800 (size 0x000000a0).
func killAuraIndicatorAppearance() {
	panic("stub")
}

// killAuraIndicatorShape recovered at 0x0000000001c4d8a0 (size 0x00000440).
func killAuraIndicatorShape() {
	panic("stub")
}

// maceDamageComponent.tryAttack recovered at 0x0000000001c028e0 (size 0x00000460).
func maceDamageComponent_tryAttack() {
	panic("stub")
}

// mainInventoryStack recovered at 0x0000000001c25360 (size 0x00000200).
func mainInventoryStack() {
	panic("stub")
}

// map.init.0 recovered at 0x0000000001bb1580 (size 0x000000c0).
func map_init_0() {
	panic("stub")
}

// marshalSectionData recovered at 0x0000000001c5b340 (size 0x00000060).
func marshalSectionData() {
	panic("stub")
}

// mergeAvailableCommands recovered at 0x0000000001bb54a0 (size 0x00000f00).
func mergeAvailableCommands() {
	panic("stub")
}

// newChunksRuntimeIDIsFlowingLiquid recovered at 0x0000000001c06060 (size 0x00000100).
func newChunksRuntimeIDIsFlowingLiquid() {
	panic("stub")
}

// newClientCloneEntityID recovered at 0x0000000001c381c0 (size 0x00000060).
func newClientCloneEntityID() {
	panic("stub")
}

// newDebugTracerAnchor recovered at 0x0000000001bc1900 (size 0x000001e0).
func newDebugTracerAnchor() {
	panic("stub")
}

// newHoleESPScan recovered at 0x0000000001bffda0 (size 0x000002e0).
func newHoleESPScan() {
	panic("stub")
}

// newPlayerModules recovered at 0x0000000001c27c00 (size 0x00000400).
func newPlayerModules() {
	panic("stub")
}

// normalizeFriendName recovered at 0x0000000001c20920 (size 0x00000040).
func normalizeFriendName() {
	panic("stub")
}

// orderAutoMinerTargetsAcrossVeins recovered at 0x0000000001be29c0 (size 0x00000560).
func orderAutoMinerTargetsAcrossVeins() {
	panic("stub")
}

// protocolInstanceFromStackWrapper recovered at 0x0000000001be0300 (size 0x00000320).
func protocolInstanceFromStackWrapper() {
	panic("stub")
}

// radiusUpdatePacket recovered at 0x0000000001c17920 (size 0x000003a0).
func radiusUpdatePacket() {
	panic("stub")
}

// rayIntersectsBBoxSidewaysOnly recovered at 0x0000000001c3c620 (size 0x00000560).
func rayIntersectsBBoxSidewaysOnly() {
	panic("stub")
}

// reconcileBlockScanOverlay recovered at 0x0000000001c68580 (size 0x000002e0).
func reconcileBlockScanOverlay() {
	panic("stub")
}

// reconcileHoleESPOverlays recovered at 0x0000000001c003a0 (size 0x00000560).
func reconcileHoleESPOverlays() {
	panic("stub")
}

// relativeClickPosition recovered at 0x0000000001c32a20 (size 0x000002e0).
func relativeClickPosition() {
	panic("stub")
}

// releaseBlockRuntimeNameCache recovered at 0x0000000001bb9d80 (size 0x000000a0).
func releaseBlockRuntimeNameCache() {
	panic("stub")
}

// releaseBlockScanOverlay recovered at 0x0000000001bba000 (size 0x000000a0).
func releaseBlockScanOverlay() {
	panic("stub")
}

// releaseBlockScanOverlaySeen recovered at 0x0000000001bba140 (size 0x000000a0).
func releaseBlockScanOverlaySeen() {
	panic("stub")
}

// releaseBlockScanOverlayUpdates recovered at 0x0000000001bba0a0 (size 0x000000a0).
func releaseBlockScanOverlayUpdates() {
	panic("stub")
}

// releaseBlockTracerLoadedChunks recovered at 0x0000000001bf3760 (size 0x000000a0).
func releaseBlockTracerLoadedChunks() {
	panic("stub")
}

// releaseBlockTracerPosNameMap recovered at 0x0000000001bf36c0 (size 0x000000a0).
func releaseBlockTracerPosNameMap() {
	panic("stub")
}

// releaseChunkFinderSnapshot recovered at 0x0000000001c54b80 (size 0x000000a0).
func releaseChunkFinderSnapshot() {
	panic("stub")
}

// removeFriendName recovered at 0x0000000001c20b00 (size 0x00000260).
func removeFriendName() {
	panic("stub")
}

// removeInactiveShapes recovered at 0x0000000001c54580 (size 0x00000400).
func removeInactiveShapes() {
	panic("stub")
}

// resolveClientUUID recovered at 0x0000000001c2c5c0 (size 0x000000c0).
func resolveClientUUID() {
	panic("stub")
}

// scanChunkForBlocksInto recovered at 0x0000000001bf3e20 (size 0x00000220).
func scanChunkForBlocksInto() {
	panic("stub")
}

// scanChunkForBlocksInto.blockTracerScanTargets.func3 recovered at 0x0000000001bf41a0 (size 0x00000060).
func scanChunkForBlocksInto_blockTracerScanTargets_func3() {
	panic("stub")
}

// scanChunkForHoles recovered at 0x0000000001c00b60 (size 0x00000420).
func scanChunkForHoles() {
	panic("stub")
}

// scanChunkTargets recovered at 0x0000000001c681a0 (size 0x00000380).
func scanChunkTargets() {
	panic("stub")
}

// scanRadiusTargets recovered at 0x0000000001c6fd60 (size 0x00000840).
func scanRadiusTargets() {
	panic("stub")
}

// scanSubChunkForBlocks recovered at 0x0000000001bf3940 (size 0x00000200).
func scanSubChunkForBlocks() {
	panic("stub")
}

// scanSubChunkForBlocks.blockTracerScanTargets.func3 recovered at 0x0000000001bf3ca0 (size 0x00000060).
func scanSubChunkForBlocks_blockTracerScanTargets_func3() {
	panic("stub")
}

// scanSubChunkTargets recovered at 0x0000000001c69fa0 (size 0x000002c0).
func scanSubChunkTargets() {
	panic("stub")
}

// scanSubChunkYRangeTargets recovered at 0x0000000001c68860 (size 0x00000340).
func scanSubChunkYRangeTargets() {
	panic("stub")
}

// setInputSneaking recovered at 0x0000000001c40b80 (size 0x00000480).
func setInputSneaking() {
	panic("stub")
}

// shouldBreakSpawner recovered at 0x0000000001c0fe00 (size 0x000001e0).
func shouldBreakSpawner() {
	panic("stub")
}

// shulkerCustomName recovered at 0x0000000001c5df60 (size 0x000002c0).
func shulkerCustomName() {
	panic("stub")
}

// shulkerItemGlyph recovered at 0x0000000001c5c880 (size 0x00000100).
func shulkerItemGlyph() {
	panic("stub")
}

// shulkerNBTTag recovered at 0x0000000001c5dae0 (size 0x00000480).
func shulkerNBTTag() {
	panic("stub")
}

// shulkerPreviewEntryFromNBT recovered at 0x0000000001c5d460 (size 0x000003e0).
func shulkerPreviewEntryFromNBT() {
	panic("stub")
}

// shulkerPreviewFromNBT recovered at 0x0000000001c5cd60 (size 0x000006c0).
func shulkerPreviewFromNBT() {
	panic("stub")
}

// shulkerTooltipHeaderMatches recovered at 0x0000000001c0b360 (size 0x000001a0).
func shulkerTooltipHeaderMatches() {
	panic("stub")
}

// shulkerTooltipStackIdentityMatches recovered at 0x0000000001c0b500 (size 0x000000e0).
func shulkerTooltipStackIdentityMatches() {
	panic("stub")
}

// sidewaysRayOffset recovered at 0x0000000001c3bd20 (size 0x00000240).
func sidewaysRayOffset() {
	panic("stub")
}

// snapshotBlockScanOverlay recovered at 0x0000000001bba1e0 (size 0x000000a0).
func snapshotBlockScanOverlay() {
	panic("stub")
}

// snapshotModuleFactories recovered at 0x0000000001c27a20 (size 0x000001a0).
func snapshotModuleFactories() {
	panic("stub")
}

// spawnerProtectCanInteractEnderChest recovered at 0x0000000001c11080 (size 0x00000120).
func spawnerProtectCanInteractEnderChest() {
	panic("stub")
}

// spawnerProtectItem recovered at 0x0000000001c0f6e0 (size 0x00000160).
func spawnerProtectItem() {
	panic("stub")
}

// stackIsWeapon recovered at 0x0000000001c39f60 (size 0x00000160).
func stackIsWeapon() {
	panic("stub")
}

// stepComponent.requiredHeight recovered at 0x0000000001c116e0 (size 0x00000dc0).
func stepComponent_requiredHeight() {
	panic("stub")
}

// stripEnabledKey recovered at 0x0000000001c5b3a0 (size 0x00000140).
func stripEnabledKey() {
	panic("stub")
}

// subChunkPaletteValues recovered at 0x0000000001bba320 (size 0x000001a0).
func subChunkPaletteValues() {
	panic("stub")
}

// updateKeyedShapes recovered at 0x0000000001c74a40 (size 0x00000680).
func updateKeyedShapes() {
	panic("stub")
}

// userConfigPath recovered at 0x0000000001bbe260 (size 0x00000100).
func userConfigPath() {
	panic("stub")
}

// validateConfigVersion recovered at 0x0000000001bbdda0 (size 0x000000c0).
func validateConfigVersion() {
	panic("stub")
}

// waterWalkComponent.apply recovered at 0x0000000001c124a0 (size 0x00000320).
func waterWalkComponent_apply() {
	panic("stub")
}

// waterWalkSurfaceY recovered at 0x0000000001c127c0 (size 0x00000360).
func waterWalkSurfaceY() {
	panic("stub")
}

// writeFallingBlockVariant recovered at 0x0000000001c15c00 (size 0x00000120).
func writeFallingBlockVariant() {
	panic("stub")
}

// writeFileAtomic recovered at 0x0000000001bbeaa0 (size 0x00000760).
func writeFileAtomic() {
	panic("stub")
}

// xrayBlockRepresentation recovered at 0x0000000001c17f00 (size 0x000005c0).
func xrayBlockRepresentation() {
	panic("stub")
}

// xrayBreakRadiusIntersectsChunk recovered at 0x0000000001c16660 (size 0x000000c0).
func xrayBreakRadiusIntersectsChunk() {
	panic("stub")
}

// xrayChunkPos recovered at 0x0000000001c13100 (size 0x00000040).
func xrayChunkPos() {
	panic("stub")
}

// xrayOreColorForName recovered at 0x0000000001bbbe40 (size 0x000002a0).
func xrayOreColorForName() {
	panic("stub")
}

// xrayRequestModeLevelChunk recovered at 0x0000000001c20380 (size 0x00000120).
func xrayRequestModeLevelChunk() {
	panic("stub")
}

// xrayShouldShowBlock recovered at 0x0000000001c12b20 (size 0x000003e0).
func xrayShouldShowBlock() {
	panic("stub")
}

// xrayTargetNames recovered at 0x0000000001c1e380 (size 0x000004e0).
func xrayTargetNames() {
	panic("stub")
}

// xrayWithinBreakRadius recovered at 0x0000000001c16620 (size 0x00000040).
func xrayWithinBreakRadius() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Actions).CloseForm recovered at 0x0000000001bb2660 (size 0x00000040).
func (*Actions) CloseForm() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Actions).SendActionBarMessage recovered at 0x0000000001bb23e0 (size 0x000000a0).
func (*Actions) SendActionBarMessage() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Actions).SendEffect recovered at 0x0000000001bb2520 (size 0x000000c0).
func (*Actions) SendEffect() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Actions).SendFreeCameraPresets recovered at 0x0000000001bb26a0 (size 0x00000100).
func (*Actions) SendFreeCameraPresets() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Actions).SendJukeboxPopup recovered at 0x0000000001bb2480 (size 0x000000a0).
func (*Actions) SendJukeboxPopup() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Actions).SendRemoveEffect recovered at 0x0000000001bb25e0 (size 0x00000080).
func (*Actions) SendRemoveEffect() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Actions).SendTip recovered at 0x0000000001bb2340 (size 0x000000a0).
func (*Actions) SendTip() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Actions).SendToast recovered at 0x0000000001bb2260 (size 0x000000e0).
func (*Actions) SendToast() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Actions).SyncGameMode recovered at 0x0000000001bb27a0 (size 0x00000060).
func (*Actions) SyncGameMode() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Actions).SyncGameSpeed recovered at 0x0000000001bb2900 (size 0x000000a0).
func (*Actions) SyncGameSpeed() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Actions).SyncMovementSpeed recovered at 0x0000000001bb2800 (size 0x00000100).
func (*Actions) SyncMovementSpeed() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Actions).SyncWeatherHidden recovered at 0x0000000001bb29a0 (size 0x000000e0).
func (*Actions) SyncWeatherHidden() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Actions).SyncWeatherRestored recovered at 0x0000000001bb2a80 (size 0x00000100).
func (*Actions) SyncWeatherRestored() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Actions).Title recovered at 0x0000000001bb2b80 (size 0x00000180).
func (*Actions) Title() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Actions).WritePacket recovered at 0x0000000001bb1960 (size 0x000000a0).
func (*Actions) WritePacket() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Actions).WritePacketDirect recovered at 0x0000000001bb1ba0 (size 0x00000200).
func (*Actions) WritePacketDirect() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Actions).WriteServerPacket recovered at 0x0000000001bb2100 (size 0x000000a0).
func (*Actions) WriteServerPacket() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Actions).clientWriter recovered at 0x0000000001bb1640 (size 0x000000e0).
func (*Actions) clientWriter() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Actions).disconnect recovered at 0x0000000001bb1a00 (size 0x000001a0).
func (*Actions) disconnect() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Actions).flushServerPackets recovered at 0x0000000001bb21a0 (size 0x000000c0).
func (*Actions) flushServerPackets() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Actions).reset recovered at 0x0000000001bb1880 (size 0x000000e0).
func (*Actions) reset() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Actions).serverWriter recovered at 0x0000000001bb1760 (size 0x000000e0).
func (*Actions) serverWriter() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Actions).writePacketImmediate recovered at 0x0000000001bb1da0 (size 0x00000160).
func (*Actions) writePacketImmediate() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*BacktrackDeferContext).Active recovered at 0x0000000001bb63a0 (size 0x00000020).
func (*BacktrackDeferContext) Active() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*BoundaryWriter).DisconnectPacket recovered at 0x0000000001bbc140 (size 0x00000160).
func (*BoundaryWriter) DisconnectPacket() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*BoundaryWriter).Flush recovered at 0x0000000001bbc0e0 (size 0x00000060).
func (*BoundaryWriter) Flush() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*BoundaryWriter).WritePacket recovered at 0x0000000001c7fea0 (size 0x00000080).
func (*BoundaryWriter) WritePacket() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*ClickUIState).Expanded recovered at 0x0000000001c2a8c0 (size 0x00000100).
func (*ClickUIState) Expanded() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*ClickUIState).IsCategoryOpen recovered at 0x0000000001c29f60 (size 0x00000160).
func (*ClickUIState) IsCategoryOpen() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*ClickUIState).OpenCategories recovered at 0x0000000001c29d80 (size 0x000001a0).
func (*ClickUIState) OpenCategories() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*ClickUIState).PanelCategory recovered at 0x0000000001c29a60 (size 0x000000e0).
func (*ClickUIState) PanelCategory() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*ClickUIState).SetExpanded recovered at 0x0000000001c2aa00 (size 0x00000120).
func (*ClickUIState) SetExpanded() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*ClickUIState).SetPanelCategory recovered at 0x0000000001c29b80 (size 0x00000100).
func (*ClickUIState) SetPanelCategory() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*ClickUIState).ToggleCategoryOpen recovered at 0x0000000001c2a100 (size 0x00000580).
func (*ClickUIState) ToggleCategoryOpen() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*ClickUIState).TouchCategory recovered at 0x0000000001c2a6c0 (size 0x000001c0).
func (*ClickUIState) TouchCategory() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*FileConfigStore).Delete recovered at 0x0000000001bbdd00 (size 0x00000060).
func (*FileConfigStore) Delete() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*FileConfigStore).List recovered at 0x0000000001bbd9a0 (size 0x00000020).
func (*FileConfigStore) List() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*FileConfigStore).Load recovered at 0x0000000001bbd9c0 (size 0x00000200).
func (*FileConfigStore) Load() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*FileConfigStore).Rename recovered at 0x0000000001bbdc80 (size 0x00000080).
func (*FileConfigStore) Rename() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*FileConfigStore).Save recovered at 0x0000000001bbdbc0 (size 0x000000c0).
func (*FileConfigStore) Save() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*FriendList).Add recovered at 0x0000000001c212a0 (size 0x00000260).
func (*FriendList) Add() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*FriendList).ByServer recovered at 0x0000000001c21b40 (size 0x00000280).
func (*FriendList) ByServer() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*FriendList).Contains recovered at 0x0000000001c21020 (size 0x00000240).
func (*FriendList) Contains() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*FriendList).ContainsIn recovered at 0x0000000001c20d60 (size 0x00000280).
func (*FriendList) ContainsIn() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*FriendList).Names recovered at 0x0000000001c217e0 (size 0x00000320).
func (*FriendList) Names() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*FriendList).Remove recovered at 0x0000000001c21540 (size 0x00000260).
func (*FriendList) Remove() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*FriendList).load recovered at 0x0000000001c204a0 (size 0x000003a0).
func (*FriendList) load() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*FriendList).reset recovered at 0x0000000001c21e00 (size 0x00000060).
func (*FriendList) reset() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*FriendList).setServer recovered at 0x0000000001c20880 (size 0x000000a0).
func (*FriendList) setServer() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*ModuleMeta).DescriptionMessageKey recovered at 0x0000000001c27600 (size 0x00000180).
func (*ModuleMeta) DescriptionMessageKey() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).AbilityData recovered at 0x0000000001c57500 (size 0x000000c0).
func (*Player) AbilityData() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Absorption recovered at 0x0000000001c3f6c0 (size 0x00000020).
func (*Player) Absorption() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).AcquireHeldSlot recovered at 0x0000000001c21f20 (size 0x000005e0).
func (*Player) AcquireHeldSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).AcquireHeldSlotFullLeaseForTest recovered at 0x0000000001c5f260 (size 0x00000040).
func (*Player) AcquireHeldSlotFullLeaseForTest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).AcquireHeldSlotGuard recovered at 0x0000000001c22900 (size 0x00000340).
func (*Player) AcquireHeldSlotGuard() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).AcquireHeldSlotGuardForTest recovered at 0x0000000001c5f2a0 (size 0x00000040).
func (*Player) AcquireHeldSlotGuardForTest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).AddEffect recovered at 0x0000000001c36e60 (size 0x000000e0).
func (*Player) AddEffect() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).AddEntity recovered at 0x0000000001c38c20 (size 0x00000060).
func (*Player) AddEntity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).AddNukeBlocks recovered at 0x0000000001c37000 (size 0x000004c0).
func (*Player) AddNukeBlocks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).AddToPlayerList recovered at 0x0000000001c2d140 (size 0x000000c0).
func (*Player) AddToPlayerList() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).AimAssistActive recovered at 0x0000000001c39720 (size 0x00000020).
func (*Player) AimAssistActive() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).AlignClientActionHeldSlot recovered at 0x0000000001c256a0 (size 0x000002c0).
func (*Player) AlignClientActionHeldSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).AllModules recovered at 0x0000000001c29720 (size 0x00000060).
func (*Player) AllModules() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).AnimateUseItem recovered at 0x0000000001c2ec20 (size 0x00000080).
func (*Player) AnimateUseItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ApplyAndReport recovered at 0x0000000001c4a5e0 (size 0x000009a0).
func (*Player) ApplyAndReport() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ApplyAntiCrystalInventoryTransaction recovered at 0x0000000001bcb800 (size 0x00000240).
func (*Player) ApplyAntiCrystalInventoryTransaction() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ApplyAntiCrystalMovePlayer recovered at 0x0000000001bcba40 (size 0x00000100).
func (*Player) ApplyAntiCrystalMovePlayer() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ApplyAttributesPacket recovered at 0x0000000001c3ee60 (size 0x00000700).
func (*Player) ApplyAttributesPacket() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ApplyAutoMiner recovered at 0x0000000001bd8e00 (size 0x00000060).
func (*Player) ApplyAutoMiner() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ApplyBacktrackDelay recovered at 0x0000000001bb90c0 (size 0x00000060).
func (*Player) ApplyBacktrackDelay() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ApplyClearWeatherToggle recovered at 0x0000000001c389a0 (size 0x000000e0).
func (*Player) ApplyClearWeatherToggle() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ApplyConfig recovered at 0x0000000001c4b820 (size 0x00001120).
func (*Player) ApplyConfig() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ApplyEffects recovered at 0x0000000001c38a80 (size 0x00000160).
func (*Player) ApplyEffects() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ApplyEntityAttributes recovered at 0x0000000001c4d520 (size 0x000000c0).
func (*Player) ApplyEntityAttributes() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ApplyGhostSettings recovered at 0x0000000001bb5120 (size 0x00000140).
func (*Player) ApplyGhostSettings() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ApplyNoInvisibleEntities recovered at 0x0000000001c35d60 (size 0x00000220).
func (*Player) ApplyNoInvisibleEntities() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ApplyStatChangerRemoveObjective recovered at 0x0000000001c5ad60 (size 0x000000c0).
func (*Player) ApplyStatChangerRemoveObjective() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ApplyStatChangerSetDisplayObjective recovered at 0x0000000001c5ac20 (size 0x00000140).
func (*Player) ApplyStatChangerSetDisplayObjective() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ApplyStatChangerSetScore recovered at 0x0000000001c5b060 (size 0x000002e0).
func (*Player) ApplyStatChangerSetScore() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ApplyToggles recovered at 0x0000000001c38940 (size 0x00000060).
func (*Player) ApplyToggles() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ArmBacktrackTarget recovered at 0x0000000001bb8ec0 (size 0x00000200).
func (*Player) ArmBacktrackTarget() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).AttachLeash recovered at 0x0000000001c38420 (size 0x00000460).
func (*Player) AttachLeash() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).AttackEntity recovered at 0x0000000001c39c80 (size 0x000002e0).
func (*Player) AttackEntity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).AttackedEntityTick recovered at 0x0000000001c3d440 (size 0x00000020).
func (*Player) AttackedEntityTick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).AutoSellOwnsContainer recovered at 0x0000000001c44300 (size 0x00000040).
func (*Player) AutoSellOwnsContainer() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).AutoSwitchAfterAttack recovered at 0x0000000001c3a440 (size 0x00000120).
func (*Player) AutoSwitchAfterAttack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).AutoToolSwapForBlock recovered at 0x0000000001c47740 (size 0x00000520).
func (*Player) AutoToolSwapForBlock() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).AutomationPaused recovered at 0x0000000001c2e520 (size 0x00000020).
func (*Player) AutomationPaused() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).BBox recovered at 0x0000000001c7d940 (size 0x00000080).
func (*Player) BBox() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).BacktrackBufferedServerLen recovered at 0x0000000001bb9280 (size 0x00000040).
func (*Player) BacktrackBufferedServerLen() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).BacktrackRemainingDelay recovered at 0x0000000001bb9200 (size 0x00000040).
func (*Player) BacktrackRemainingDelay() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).BacktrackTargetRuntimeID recovered at 0x0000000001bb9240 (size 0x00000040).
func (*Player) BacktrackTargetRuntimeID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).BlockTracerHandleLevelChunk recovered at 0x0000000001befee0 (size 0x00000060).
func (*Player) BlockTracerHandleLevelChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).BlockTracerHandleSubChunk recovered at 0x0000000001bf09e0 (size 0x00000060).
func (*Player) BlockTracerHandleSubChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).BlockTracerRescan recovered at 0x0000000001bef400 (size 0x000000a0).
func (*Player) BlockTracerRescan() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Blocking recovered at 0x0000000001c7da40 (size 0x00000020).
func (*Player) Blocking() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).BufferedAttackPacketCount recovered at 0x0000000001bb3080 (size 0x000000e0).
func (*Player) BufferedAttackPacketCount() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).BuildClientAbilityData recovered at 0x0000000001c575c0 (size 0x000002a0).
func (*Player) BuildClientAbilityData() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).CPS recovered at 0x0000000001c3d100 (size 0x00000040).
func (*Player) CPS() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).CacheResolvedShulkerTooltipStack recovered at 0x0000000001c5ede0 (size 0x000000c0).
func (*Player) CacheResolvedShulkerTooltipStack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).CacheShulkerTooltipStack recovered at 0x0000000001c5ed60 (size 0x00000080).
func (*Player) CacheShulkerTooltipStack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).CanUseModule recovered at 0x0000000001c28380 (size 0x00000060).
func (*Player) CanUseModule() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ChatSilenced recovered at 0x0000000001bb5100 (size 0x00000020).
func (*Player) ChatSilenced() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ChunkFinderClear recovered at 0x0000000001bf6020 (size 0x000001a0).
func (*Player) ChunkFinderClear() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ChunkFinderCompletedScans recovered at 0x0000000001c5f1c0 (size 0x00000020).
func (*Player) ChunkFinderCompletedScans() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ChunkFinderFlaggedCount recovered at 0x0000000001c5f1e0 (size 0x00000040).
func (*Player) ChunkFinderFlaggedCount() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ChunkFinderHandleLevelChunk recovered at 0x0000000001bf5a20 (size 0x00000120).
func (*Player) ChunkFinderHandleLevelChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ChunkFinderHandleSubChunk recovered at 0x0000000001bf5b40 (size 0x00000100).
func (*Player) ChunkFinderHandleSubChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ChunkFinderRescan recovered at 0x0000000001bf5f20 (size 0x00000100).
func (*Player) ChunkFinderRescan() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ChunksByRing recovered at 0x0000000001c622e0 (size 0x00000080).
func (*Player) ChunksByRing() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ChunksClosest recovered at 0x0000000001c61e80 (size 0x00000220).
func (*Player) ChunksClosest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ClearAFKClickerSwing recovered at 0x0000000001bc3ae0 (size 0x00000020).
func (*Player) ClearAFKClickerSwing() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ClearBlockBreakQueueOwnedBy recovered at 0x0000000001c44480 (size 0x000004c0).
func (*Player) ClearBlockBreakQueueOwnedBy() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ClearClientEatingState recovered at 0x0000000001bc1ee0 (size 0x00000040).
func (*Player) ClearClientEatingState() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ClearCombatTargetIfRuntimeID recovered at 0x0000000001bbc500 (size 0x000000c0).
func (*Player) ClearCombatTargetIfRuntimeID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ClearDeathPositions recovered at 0x0000000001bfc1e0 (size 0x00000040).
func (*Player) ClearDeathPositions() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ClearPlayerGameMode recovered at 0x0000000001c39c00 (size 0x00000080).
func (*Player) ClearPlayerGameMode() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ClearStatChangerOverrides recovered at 0x0000000001c3df20 (size 0x00000180).
func (*Player) ClearStatChangerOverrides() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ClickBlock recovered at 0x0000000001c32600 (size 0x00000080).
func (*Player) ClickBlock() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ClickTickerRunning recovered at 0x0000000001c5f1a0 (size 0x00000020).
func (*Player) ClickTickerRunning() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ClickUI recovered at 0x0000000001c29cc0 (size 0x000000c0).
func (*Player) ClickUI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ClickUIStyle recovered at 0x0000000001c29780 (size 0x00000100).
func (*Player) ClickUIStyle() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ClientMoving recovered at 0x0000000001c33f00 (size 0x00000020).
func (*Player) ClientMoving() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ClientTick recovered at 0x0000000001c3d420 (size 0x00000020).
func (*Player) ClientTick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ClientUUID recovered at 0x0000000001c2c680 (size 0x00000040).
func (*Player) ClientUUID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Close recovered at 0x0000000001c3d360 (size 0x00000060).
func (*Player) Close() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).CloseForm recovered at 0x0000000001c3d260 (size 0x00000060).
func (*Player) CloseForm() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).CombatTarget recovered at 0x0000000001bbc380 (size 0x00000180).
func (*Player) CombatTarget() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).CommandsHidden recovered at 0x0000000001bb50c0 (size 0x00000040).
func (*Player) CommandsHidden() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ConfigSaveAllowed recovered at 0x0000000001c4b260 (size 0x00000280).
func (*Player) ConfigSaveAllowed() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Configs recovered at 0x0000000001c34ca0 (size 0x00000040).
func (*Player) Configs() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Conn recovered at 0x0000000001c35080 (size 0x00000020).
func (*Player) Conn() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Context recovered at 0x0000000001c34c60 (size 0x00000040).
func (*Player) Context() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).CopyShulkerTooltipStack recovered at 0x0000000001c5f020 (size 0x000000a0).
func (*Player) CopyShulkerTooltipStack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Crawling recovered at 0x0000000001c7da80 (size 0x00000020).
func (*Player) Crawling() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).CustomBlockDefinitions recovered at 0x0000000001c2cfa0 (size 0x00000100).
func (*Player) CustomBlockDefinitions() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).CustomBlockRuntimeID recovered at 0x0000000001c2d0a0 (size 0x000000a0).
func (*Player) CustomBlockRuntimeID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).DeactivateAimAssist recovered at 0x0000000001c39740 (size 0x00000040).
func (*Player) DeactivateAimAssist() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Dead recovered at 0x0000000001c7dac0 (size 0x00000020).
func (*Player) Dead() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).DeathPositions recovered at 0x0000000001bfc1a0 (size 0x00000040).
func (*Player) DeathPositions() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).DebugShapesTickerRunning recovered at 0x0000000001c5f180 (size 0x00000020).
func (*Player) DebugShapesTickerRunning() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).DecorateShulkerTooltip recovered at 0x0000000001c5e5c0 (size 0x00000140).
func (*Player) DecorateShulkerTooltip() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).DeferServerBacktrackPacket recovered at 0x0000000001bb99e0 (size 0x000000c0).
func (*Player) DeferServerBacktrackPacket() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).DirectionVector recovered at 0x0000000001c7db00 (size 0x00000060).
func (*Player) DirectionVector() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).DisableModule recovered at 0x0000000001c290c0 (size 0x00000120).
func (*Player) DisableModule() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).DisableSpeed recovered at 0x0000000001c360e0 (size 0x00000040).
func (*Player) DisableSpeed() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).DisableTimer recovered at 0x0000000001c37520 (size 0x00000040).
func (*Player) DisableTimer() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).DisableUnavailableModules recovered at 0x0000000001c28ec0 (size 0x00000200).
func (*Player) DisableUnavailableModules() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).DisableXray recovered at 0x0000000001c1aae0 (size 0x00000040).
func (*Player) DisableXray() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Disconnect recovered at 0x0000000001c3d2c0 (size 0x000000a0).
func (*Player) Disconnect() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).DistanceFrom recovered at 0x0000000001c7dbc0 (size 0x00000040).
func (*Player) DistanceFrom() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).DoEmote recovered at 0x0000000001c36660 (size 0x00000460).
func (*Player) DoEmote() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).DoubleClickExtraCount recovered at 0x0000000001c3cea0 (size 0x000000c0).
func (*Player) DoubleClickExtraCount() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).EffectiveClientActionHeldSlot recovered at 0x0000000001c25ee0 (size 0x00000060).
func (*Player) EffectiveClientActionHeldSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Eject recovered at 0x0000000001c2f6c0 (size 0x000001c0).
func (*Player) Eject() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Emotes recovered at 0x0000000001bc2060 (size 0x00000020).
func (*Player) Emotes() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).EnableFreeCam recovered at 0x0000000001c377c0 (size 0x00000a00).
func (*Player) EnableFreeCam() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).EnableModule recovered at 0x0000000001c286a0 (size 0x000001e0).
func (*Player) EnableModule() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).EnableXray recovered at 0x0000000001c194e0 (size 0x00000040).
func (*Player) EnableXray() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).EnableXrayForChunks recovered at 0x0000000001c184c0 (size 0x00000080).
func (*Player) EnableXrayForChunks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).EnsureCameraPresetsSent recovered at 0x0000000001c39aa0 (size 0x00000060).
func (*Player) EnsureCameraPresetsSent() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).EnsureModuleRuntimeDeps recovered at 0x0000000001c27780 (size 0x00000060).
func (*Player) EnsureModuleRuntimeDeps() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Entities recovered at 0x0000000001c38be0 (size 0x00000040).
func (*Player) Entities() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).EquipTotem recovered at 0x0000000001c2d9e0 (size 0x00000960).
func (*Player) EquipTotem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ExecuteCommand recovered at 0x0000000001c350c0 (size 0x00000120).
func (*Player) ExecuteCommand() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Exhaustion recovered at 0x0000000001c3f780 (size 0x00000020).
func (*Player) Exhaustion() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ExperienceLevel recovered at 0x0000000001c3f800 (size 0x00000020).
func (*Player) ExperienceLevel() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ExperienceProgress recovered at 0x0000000001c3f7c0 (size 0x00000020).
func (*Player) ExperienceProgress() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).EyeHeight recovered at 0x0000000001c7dc20 (size 0x00000040).
func (*Player) EyeHeight() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).EyePosition recovered at 0x0000000001c7dc80 (size 0x00000080).
func (*Player) EyePosition() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).EyePosition32 recovered at 0x0000000001c7dd20 (size 0x00000080).
func (*Player) EyePosition32() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).FallDistance recovered at 0x0000000001c3f5e0 (size 0x00000020).
func (*Player) FallDistance() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Falling recovered at 0x0000000001c7ddc0 (size 0x00000020).
func (*Player) Falling() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).FlushBufferedAttackPackets recovered at 0x0000000001bb2da0 (size 0x000001c0).
func (*Player) FlushBufferedAttackPackets() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Flying recovered at 0x0000000001c7de00 (size 0x00000020).
func (*Player) Flying() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ForEachBlockByNameSetFrom recovered at 0x0000000001c62b80 (size 0x000000c0).
func (*Player) ForEachBlockByNameSetFrom() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Form recovered at 0x0000000001c363a0 (size 0x00000040).
func (*Player) Form() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).FormatBool recovered at 0x0000000001c35880 (size 0x000000a0).
func (*Player) FormatBool() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).FormatDeleteResult recovered at 0x0000000001bbde60 (size 0x000002e0).
func (*Player) FormatDeleteResult() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).FreeCamPresetID recovered at 0x0000000001c39a80 (size 0x00000020).
func (*Player) FreeCamPresetID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).FriendWorld recovered at 0x0000000001c34be0 (size 0x00000020).
func (*Player) FriendWorld() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Friends recovered at 0x0000000001c21e60 (size 0x00000020).
func (*Player) Friends() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).GameType recovered at 0x0000000001c7de40 (size 0x00000020).
func (*Player) GameType() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).GenerateEmotes recovered at 0x0000000001bc2040 (size 0x00000020).
func (*Player) GenerateEmotes() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).GetEntity recovered at 0x0000000001c38c80 (size 0x00000040).
func (*Player) GetEntity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).GetEntityByUniqueID recovered at 0x0000000001c38cc0 (size 0x00000040).
func (*Player) GetEntityByUniqueID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).GetServerEffect recovered at 0x0000000001c36d80 (size 0x000000e0).
func (*Player) GetServerEffect() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Gliding recovered at 0x0000000001c7de80 (size 0x00000020).
func (*Player) Gliding() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HandleAimAssist recovered at 0x0000000001c397c0 (size 0x00000060).
func (*Player) HandleAimAssist() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HandleAimAssistServerPacket recovered at 0x0000000001c39820 (size 0x000001e0).
func (*Player) HandleAimAssistServerPacket() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HandleAutoFish recovered at 0x0000000001c43c60 (size 0x00000280).
func (*Player) HandleAutoFish() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HandleAutoFishTransaction recovered at 0x0000000001c43ee0 (size 0x00000060).
func (*Player) HandleAutoFishTransaction() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HandleAutoLog recovered at 0x0000000001c3f820 (size 0x00000360).
func (*Player) HandleAutoLog() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HandleAvailableCommands recovered at 0x0000000001bb4cc0 (size 0x000000e0).
func (*Player) HandleAvailableCommands() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HandleChestPairBlockEntity recovered at 0x0000000001c4a320 (size 0x000002c0).
func (*Player) HandleChestPairBlockEntity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HandleClientAttack recovered at 0x0000000001bb3ce0 (size 0x000001e0).
func (*Player) HandleClientAttack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HandleContainerClose recovered at 0x0000000001bc1180 (size 0x00000080).
func (*Player) HandleContainerClose() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HandleDeathActorEvent recovered at 0x0000000001c4d460 (size 0x000000c0).
func (*Player) HandleDeathActorEvent() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HandleFishingActorEvent recovered at 0x0000000001c43fa0 (size 0x00000060).
func (*Player) HandleFishingActorEvent() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HandleFriendAlertsPlayerList recovered at 0x0000000001c21e80 (size 0x00000060).
func (*Player) HandleFriendAlertsPlayerList() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HandleModAlertsAddPlayer recovered at 0x0000000001c03ba0 (size 0x00000100).
func (*Player) HandleModAlertsAddPlayer() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HandleModAlertsPlayerList recovered at 0x0000000001c039e0 (size 0x000001c0).
func (*Player) HandleModAlertsPlayerList() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HandlePlayerAuthInput recovered at 0x0000000001c42940 (size 0x00001320).
func (*Player) HandlePlayerAuthInput() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HandlePlayerList recovered at 0x0000000001c54c20 (size 0x00000300).
func (*Player) HandlePlayerList() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HandleRespawn recovered at 0x0000000001c4d5e0 (size 0x00000080).
func (*Player) HandleRespawn() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HandleWorldBlockUpdates recovered at 0x0000000001c49e00 (size 0x00000100).
func (*Player) HandleWorldBlockUpdates() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HandleXraySubChunkRequest recovered at 0x0000000001c1ec00 (size 0x00000060).
func (*Player) HandleXraySubChunkRequest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HasBufferedAttackPackets recovered at 0x0000000001bb2f60 (size 0x000000e0).
func (*Player) HasBufferedAttackPackets() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HasEntityFriend recovered at 0x0000000001c34e80 (size 0x00000060).
func (*Player) HasEntityFriend() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HasTrustedShulkerTooltipStack recovered at 0x0000000001c5efa0 (size 0x00000040).
func (*Player) HasTrustedShulkerTooltipStack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HasUnobstructedPath recovered at 0x0000000001c2f9c0 (size 0x00000620).
func (*Player) HasUnobstructedPath() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Health recovered at 0x0000000001c3f640 (size 0x00000020).
func (*Player) Health() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HealthInfo recovered at 0x0000000001c7dec0 (size 0x00000040).
func (*Player) HealthInfo() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HeldItem recovered at 0x0000000001c7df20 (size 0x000000c0).
func (*Player) HeldItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HeldItemName recovered at 0x0000000001c260c0 (size 0x00000220).
func (*Player) HeldItemName() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HeldShulkerPreview recovered at 0x0000000001c5c980 (size 0x000003e0).
func (*Player) HeldShulkerPreview() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HeldSlotOwner recovered at 0x0000000001c22ee0 (size 0x000000e0).
func (*Player) HeldSlotOwner() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HitBoxActive recovered at 0x0000000001c3a360 (size 0x00000060).
func (*Player) HitBoxActive() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HoldItemUse recovered at 0x0000000001c2e620 (size 0x000000e0).
func (*Player) HoldItemUse() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HoldingWeapon recovered at 0x0000000001c3a0c0 (size 0x00000140).
func (*Player) HoldingWeapon() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HoleESPClear recovered at 0x0000000001c02620 (size 0x00000040).
func (*Player) HoleESPClear() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HoleESPHandleLevelChunk recovered at 0x0000000001c02040 (size 0x00000120).
func (*Player) HoleESPHandleLevelChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HoleESPHandleSubChunk recovered at 0x0000000001c02160 (size 0x00000120).
func (*Player) HoleESPHandleSubChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HoleESPRescan recovered at 0x0000000001c023c0 (size 0x000001c0).
func (*Player) HoleESPRescan() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).HoleESPSetEnabled recovered at 0x0000000001c02660 (size 0x00000020).
func (*Player) HoleESPSetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Hosted recovered at 0x0000000001c34d60 (size 0x00000020).
func (*Player) Hosted() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Hunger recovered at 0x0000000001c3f700 (size 0x00000020).
func (*Player) Hunger() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).IdentityUniqueID recovered at 0x0000000001c34ee0 (size 0x00000080).
func (*Player) IdentityUniqueID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).InPlayerList recovered at 0x0000000001c2d2c0 (size 0x00000100).
func (*Player) InPlayerList() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Initialize recovered at 0x0000000001c7e0a0 (size 0x00000020).
func (*Player) Initialize() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Inject recovered at 0x0000000001c2f880 (size 0x00000140).
func (*Player) Inject() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).InteractBlockOnce recovered at 0x0000000001c32680 (size 0x000001c0).
func (*Player) InteractBlockOnce() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).InteractOpenInventory recovered at 0x0000000001c2ee60 (size 0x00000080).
func (*Player) InteractOpenInventory() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Inventory recovered at 0x0000000001c255e0 (size 0x00000020).
func (*Player) Inventory() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Item recovered at 0x0000000001c25fe0 (size 0x000000e0).
func (*Player) Item() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ItemNetworkID recovered at 0x0000000001c27040 (size 0x00000120).
func (*Player) ItemNetworkID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).JavaAttackCooldown recovered at 0x0000000001c2f440 (size 0x000001c0).
func (*Player) JavaAttackCooldown() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Jump recovered at 0x0000000001c30e00 (size 0x00000080).
func (*Player) Jump() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Jumping recovered at 0x0000000001c7e0e0 (size 0x00000020).
func (*Player) Jumping() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).LanguageOverride recovered at 0x0000000001c35980 (size 0x00000020).
func (*Player) LanguageOverride() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).LastAttackedEntity recovered at 0x0000000001c2f2e0 (size 0x00000060).
func (*Player) LastAttackedEntity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).LastClickTime recovered at 0x0000000001c2f600 (size 0x00000020).
func (*Player) LastClickTime() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).LastDamageTime recovered at 0x0000000001c2eee0 (size 0x00000020).
func (*Player) LastDamageTime() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).LastItemUseTime recovered at 0x0000000001c2efe0 (size 0x00000020).
func (*Player) LastItemUseTime() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).LastManualAttackTime recovered at 0x0000000001c2f340 (size 0x00000020).
func (*Player) LastManualAttackTime() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).LoadAndApplyConfig recovered at 0x0000000001c4af80 (size 0x000002e0).
func (*Player) LoadAndApplyConfig() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).LoadBlocks recovered at 0x0000000001c2cc20 (size 0x00000380).
func (*Player) LoadBlocks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).LoadItems recovered at 0x0000000001c2c6c0 (size 0x000000c0).
func (*Player) LoadItems() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Log recovered at 0x0000000001c3ede0 (size 0x00000020).
func (*Player) Log() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).LookAt recovered at 0x0000000001c3cd80 (size 0x00000120).
func (*Player) LookAt() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).LookingAt recovered at 0x0000000001c3a9c0 (size 0x00000400).
func (*Player) LookingAt() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ManualAttackCPS recovered at 0x0000000001c3d140 (size 0x00000040).
func (*Player) ManualAttackCPS() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).MaxHealth recovered at 0x0000000001c3f680 (size 0x00000020).
func (*Player) MaxHealth() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).MergeAttributes recovered at 0x0000000001c7e120 (size 0x00000080).
func (*Player) MergeAttributes() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Message recovered at 0x0000000001c35560 (size 0x00000120).
func (*Player) Message() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).MessageAlreadyToggled recovered at 0x0000000001c28ba0 (size 0x00000320).
func (*Player) MessageAlreadyToggled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).MessageServer recovered at 0x0000000001c351e0 (size 0x000001e0).
func (*Player) MessageServer() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Messagef recovered at 0x0000000001c35680 (size 0x000000a0).
func (*Player) Messagef() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Messaget recovered at 0x0000000001c357c0 (size 0x000000c0).
func (*Player) Messaget() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Metadata recovered at 0x0000000001c7e1c0 (size 0x00000040).
func (*Player) Metadata() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Module recovered at 0x0000000001c280e0 (size 0x000000a0).
func (*Player) Module() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ModuleAccess recovered at 0x0000000001c283e0 (size 0x000002c0).
func (*Player) ModuleAccess() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ModuleAvailability recovered at 0x0000000001c282e0 (size 0x000000a0).
func (*Player) ModuleAvailability() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ModulePremiumOnly recovered at 0x0000000001c28260 (size 0x00000080).
func (*Player) ModulePremiumOnly() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).MovementSpeed recovered at 0x0000000001c3f580 (size 0x00000020).
func (*Player) MovementSpeed() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).MustModule recovered at 0x0000000001c28180 (size 0x000000e0).
func (*Player) MustModule() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).MutateAutoCrit recovered at 0x0000000001bb4780 (size 0x00000540).
func (*Player) MutateAutoCrit() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).NearbyLiveEntities recovered at 0x0000000001c38e60 (size 0x000000e0).
func (*Player) NearbyLiveEntities() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).NearestEntity recovered at 0x0000000001c38da0 (size 0x000000c0).
func (*Player) NearestEntity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).NewChunksClear recovered at 0x0000000001c05840 (size 0x00000280).
func (*Player) NewChunksClear() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).NewChunksFlaggedCount recovered at 0x0000000001c5f220 (size 0x00000040).
func (*Player) NewChunksFlaggedCount() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).NewChunksHandleLevelChunk recovered at 0x0000000001c04ce0 (size 0x00000460).
func (*Player) NewChunksHandleLevelChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).NewChunksHandleSubChunk recovered at 0x0000000001c05180 (size 0x00000540).
func (*Player) NewChunksHandleSubChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).NewChunksHandleUpdateBlock recovered at 0x0000000001c05700 (size 0x00000080).
func (*Player) NewChunksHandleUpdateBlock() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).NewChunksHandleUpdateSubChunkBlocks recovered at 0x0000000001c05780 (size 0x000000c0).
func (*Player) NewChunksHandleUpdateSubChunkBlocks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ObserveAutoSellInventoryEdit recovered at 0x0000000001c442a0 (size 0x00000060).
func (*Player) ObserveAutoSellInventoryEdit() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ObserveClientSelectedHotBarSlot recovered at 0x0000000001c25620 (size 0x00000080).
func (*Player) ObserveClientSelectedHotBarSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).OnGround recovered at 0x0000000001c3e7c0 (size 0x00000020).
func (*Player) OnGround() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).OtherPlayerListNames recovered at 0x0000000001c54f60 (size 0x000002a0).
func (*Player) OtherPlayerListNames() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Owner recovered at 0x0000000001c7e220 (size 0x00000040).
func (*Player) Owner() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).PauseAutomation recovered at 0x0000000001c2e540 (size 0x00000020).
func (*Player) PauseAutomation() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Player recovered at 0x0000000001c7e280 (size 0x00000020).
func (*Player) Player() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).PlayerGameMode recovered at 0x0000000001c39640 (size 0x00000020).
func (*Player) PlayerGameMode() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Position recovered at 0x0000000001c7e2c0 (size 0x000000c0).
func (*Player) Position() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Position32 recovered at 0x0000000001c7e420 (size 0x00000060).
func (*Player) Position32() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Premium recovered at 0x0000000001c34c00 (size 0x00000040).
func (*Player) Premium() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Properties recovered at 0x0000000001c7e4e0 (size 0x000000a0).
func (*Player) Properties() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).PublishAvailableCommandsIfServerSentNone recovered at 0x0000000001bb4fc0 (size 0x00000040).
func (*Player) PublishAvailableCommandsIfServerSentNone() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).QueueBlockBreak recovered at 0x0000000001c44fa0 (size 0x00000080).
func (*Player) QueueBlockBreak() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).QueueBlockBreakWithOptions recovered at 0x0000000001c45020 (size 0x000008c0).
func (*Player) QueueBlockBreakWithOptions() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).RainIntensity recovered at 0x0000000001c36c40 (size 0x00000020).
func (*Player) RainIntensity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).RayTraceDistance recovered at 0x0000000001c3b0a0 (size 0x00000360).
func (*Player) RayTraceDistance() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ReachDistance recovered at 0x0000000001c2f360 (size 0x000000e0).
func (*Player) ReachDistance() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Realm recovered at 0x0000000001c34bc0 (size 0x00000020).
func (*Player) Realm() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).RefreshAFKClickerSettings recovered at 0x0000000001bc2ee0 (size 0x00000040).
func (*Player) RefreshAFKClickerSettings() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).RefreshActorData recovered at 0x0000000001c382e0 (size 0x00000140).
func (*Player) RefreshActorData() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).RefreshAvailableCommands recovered at 0x0000000001bb4e20 (size 0x00000160).
func (*Player) RefreshAvailableCommands() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).RefreshAvailableCommandsIfHiddenChanged recovered at 0x0000000001bb5260 (size 0x00000080).
func (*Player) RefreshAvailableCommandsIfHiddenChanged() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).RefreshHitBoxOnVisibleWeaponChange recovered at 0x0000000001c3a3c0 (size 0x00000040).
func (*Player) RefreshHitBoxOnVisibleWeaponChange() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).RefreshStatChangerScoreboard recovered at 0x0000000001c5a8e0 (size 0x000000a0).
func (*Player) RefreshStatChangerScoreboard() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).RefreshXrayFallingBlockAfterMove recovered at 0x0000000001c3d5e0 (size 0x00000080).
func (*Player) RefreshXrayFallingBlockAfterMove() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).RegisterClick recovered at 0x0000000001c3cf60 (size 0x000001a0).
func (*Player) RegisterClick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ReleaseHeldSlot recovered at 0x0000000001c22540 (size 0x00000380).
func (*Player) ReleaseHeldSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ReleaseHeldSlotGuard recovered at 0x0000000001c22c80 (size 0x00000220).
func (*Player) ReleaseHeldSlotGuard() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ReleaseItemUse recovered at 0x0000000001c2e700 (size 0x00000080).
func (*Player) ReleaseItemUse() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).RemoveBacktrackDelay recovered at 0x0000000001bb9120 (size 0x000000e0).
func (*Player) RemoveBacktrackDelay() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).RemoveEffect recovered at 0x0000000001c36f40 (size 0x00000080).
func (*Player) RemoveEffect() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).RemoveEntity recovered at 0x0000000001c38d00 (size 0x000000a0).
func (*Player) RemoveEntity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).RemoveFromPlayerList recovered at 0x0000000001c2d200 (size 0x000000c0).
func (*Player) RemoveFromPlayerList() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).RemoveStatChangerOverride recovered at 0x0000000001c3dcc0 (size 0x00000220).
func (*Player) RemoveStatChangerOverride() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ResetAimAssist recovered at 0x0000000001c39780 (size 0x00000040).
func (*Player) ResetAimAssist() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ResetAutoEatState recovered at 0x0000000001bd43c0 (size 0x000000c0).
func (*Player) ResetAutoEatState() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ResetAutoFishState recovered at 0x0000000001c44000 (size 0x00000040).
func (*Player) ResetAutoFishState() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ResetAutoRocketDelay recovered at 0x0000000001be44c0 (size 0x00000020).
func (*Player) ResetAutoRocketDelay() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ResetAutoSwitchHits recovered at 0x0000000001c3a560 (size 0x00000020).
func (*Player) ResetAutoSwitchHits() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ResetAutoWebHits recovered at 0x0000000001be85a0 (size 0x00000020).
func (*Player) ResetAutoWebHits() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ResetEatingState recovered at 0x0000000001bc1f20 (size 0x000000e0).
func (*Player) ResetEatingState() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ResetFallDistance recovered at 0x0000000001c3f600 (size 0x00000020).
func (*Player) ResetFallDistance() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ResetNukeBlocks recovered at 0x0000000001c36fc0 (size 0x00000040).
func (*Player) ResetNukeBlocks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ResetShulkerTooltipStacks recovered at 0x0000000001c5efe0 (size 0x00000040).
func (*Player) ResetShulkerTooltipStacks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ResetSpawnerProtect recovered at 0x0000000001c10080 (size 0x000000c0).
func (*Player) ResetSpawnerProtect() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ResumeAutomation recovered at 0x0000000001c2e560 (size 0x00000020).
func (*Player) ResumeAutomation() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Rotate recovered at 0x0000000001c3e9c0 (size 0x00000080).
func (*Player) Rotate() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).RotateServerSide recovered at 0x0000000001c303c0 (size 0x00000260).
func (*Player) RotateServerSide() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Rotation recovered at 0x0000000001c7e620 (size 0x00000060).
func (*Player) Rotation() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).RunPostAttackHooks recovered at 0x0000000001bb2d60 (size 0x00000040).
func (*Player) RunPostAttackHooks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).RunPreAttackHooks recovered at 0x0000000001bb2d00 (size 0x00000060).
func (*Player) RunPreAttackHooks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SanitizeStatChangerOverrides recovered at 0x0000000001c3e0e0 (size 0x000000a0).
func (*Player) SanitizeStatChangerOverrides() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Saturation recovered at 0x0000000001c3f740 (size 0x00000020).
func (*Player) Saturation() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ScanBlocks recovered at 0x0000000001c62800 (size 0x00000080).
func (*Player) ScanBlocks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ScanBlocksByName recovered at 0x0000000001c62fa0 (size 0x00000220).
func (*Player) ScanBlocksByName() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ScanBlocksByNameFrom recovered at 0x0000000001c631c0 (size 0x00000140).
func (*Player) ScanBlocksByNameFrom() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ScanBlocksByNameSet recovered at 0x0000000001c62ca0 (size 0x00000280).
func (*Player) ScanBlocksByNameSet() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Scoreboard recovered at 0x0000000001c58120 (size 0x00000020).
func (*Player) Scoreboard() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SendActionBarMessage recovered at 0x0000000001c359a0 (size 0x000000c0).
func (*Player) SendActionBarMessage() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SendForm recovered at 0x0000000001c36260 (size 0x00000140).
func (*Player) SendForm() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SendJukeboxPopup recovered at 0x0000000001c35a60 (size 0x000000c0).
func (*Player) SendJukeboxPopup() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SendTip recovered at 0x0000000001c354a0 (size 0x000000c0).
func (*Player) SendTip() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SendToast recovered at 0x0000000001c353c0 (size 0x000000e0).
func (*Player) SendToast() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ServerAbilityData recovered at 0x0000000001c573a0 (size 0x000000c0).
func (*Player) ServerAbilityData() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ServerAddress recovered at 0x0000000001c34f60 (size 0x00000020).
func (*Player) ServerAddress() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ServerBBox recovered at 0x0000000001c7e6e0 (size 0x00000080).
func (*Player) ServerBBox() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ServerBacktrackDeferContext recovered at 0x0000000001bb9960 (size 0x00000080).
func (*Player) ServerBacktrackDeferContext() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ServerCameraInstruction recovered at 0x0000000001c396c0 (size 0x00000020).
func (*Player) ServerCameraInstruction() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ServerConn recovered at 0x0000000001c350a0 (size 0x00000020).
func (*Player) ServerConn() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ServerControlSchemeSet recovered at 0x0000000001c39700 (size 0x00000020).
func (*Player) ServerControlSchemeSet() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ServerGameMode recovered at 0x0000000001c39660 (size 0x00000020).
func (*Player) ServerGameMode() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ServerMovementSpeed recovered at 0x0000000001c3f5a0 (size 0x00000020).
func (*Player) ServerMovementSpeed() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ServerSideTeleport recovered at 0x0000000001c30620 (size 0x000001e0).
func (*Player) ServerSideTeleport() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ServerSideWalkTo recovered at 0x0000000001c30bc0 (size 0x00000080).
func (*Player) ServerSideWalkTo() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ServerType recovered at 0x0000000001c34d80 (size 0x00000020).
func (*Player) ServerType() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetAFKClickerClickType recovered at 0x0000000001bc2de0 (size 0x00000100).
func (*Player) SetAFKClickerClickType() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetAbsorption recovered at 0x0000000001c3f6a0 (size 0x00000020).
func (*Player) SetAbsorption() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetAttributeValues recovered at 0x0000000001c7e7e0 (size 0x00000080).
func (*Player) SetAttributeValues() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetAvailableCommandsHooks recovered at 0x0000000001bb4da0 (size 0x00000080).
func (*Player) SetAvailableCommandsHooks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetBBox recovered at 0x0000000001c7e880 (size 0x00000080).
func (*Player) SetBBox() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetBlocking recovered at 0x0000000001c7e980 (size 0x00000040).
func (*Player) SetBlocking() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetClickUIStyle recovered at 0x0000000001c298c0 (size 0x00000160).
func (*Player) SetClickUIStyle() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetClientMoving recovered at 0x0000000001c33f20 (size 0x00000020).
func (*Player) SetClientMoving() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetClientTick recovered at 0x0000000001c5f2e0 (size 0x00000020).
func (*Player) SetClientTick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetCombatTarget recovered at 0x0000000001bbc2a0 (size 0x000000e0).
func (*Player) SetCombatTarget() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetConfigStore recovered at 0x0000000001c34ce0 (size 0x00000080).
func (*Player) SetConfigStore() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetConnections recovered at 0x0000000001c5f100 (size 0x00000080).
func (*Player) SetConnections() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetCrawling recovered at 0x0000000001c7ea00 (size 0x00000040).
func (*Player) SetCrawling() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetDead recovered at 0x0000000001c7ea80 (size 0x00000020).
func (*Player) SetDead() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetExhaustion recovered at 0x0000000001c3f760 (size 0x00000020).
func (*Player) SetExhaustion() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetExperienceLevel recovered at 0x0000000001c3f7e0 (size 0x00000020).
func (*Player) SetExperienceLevel() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetExperienceProgress recovered at 0x0000000001c3f7a0 (size 0x00000020).
func (*Player) SetExperienceProgress() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetFalling recovered at 0x0000000001c7eac0 (size 0x00000040).
func (*Player) SetFalling() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetFlying recovered at 0x0000000001c7eb40 (size 0x00000040).
func (*Player) SetFlying() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetFreeCamPresetID recovered at 0x0000000001c39a00 (size 0x00000060).
func (*Player) SetFreeCamPresetID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetGameSpeed recovered at 0x0000000001c374c0 (size 0x00000060).
func (*Player) SetGameSpeed() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetGameType recovered at 0x0000000001c7ebc0 (size 0x00000020).
func (*Player) SetGameType() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetGliding recovered at 0x0000000001c7ec00 (size 0x00000040).
func (*Player) SetGliding() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetHealth recovered at 0x0000000001c3f620 (size 0x00000020).
func (*Player) SetHealth() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetHeldItem recovered at 0x0000000001c7ec80 (size 0x000000c0).
func (*Player) SetHeldItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetHunger recovered at 0x0000000001c3f6e0 (size 0x00000020).
func (*Player) SetHunger() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetInPlayerList recovered at 0x0000000001c7ee20 (size 0x00000020).
func (*Player) SetInPlayerList() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetInventory recovered at 0x0000000001c25560 (size 0x00000080).
func (*Player) SetInventory() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetJumping recovered at 0x0000000001c7ee60 (size 0x00000040).
func (*Player) SetJumping() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetLanguage recovered at 0x0000000001c35920 (size 0x00000060).
func (*Player) SetLanguage() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetLastAttackedEntity recovered at 0x0000000001c2f0e0 (size 0x00000200).
func (*Player) SetLastAttackedEntity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetLastDamageTime recovered at 0x0000000001c2ef00 (size 0x000000e0).
func (*Player) SetLastDamageTime() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetLastItemUseTime recovered at 0x0000000001c2f000 (size 0x000000e0).
func (*Player) SetLastItemUseTime() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetMaxHealth recovered at 0x0000000001c3f660 (size 0x00000020).
func (*Player) SetMaxHealth() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetMetadata recovered at 0x0000000001c7eee0 (size 0x00000040).
func (*Player) SetMetadata() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetMovementSpeed recovered at 0x0000000001c3f560 (size 0x00000020).
func (*Player) SetMovementSpeed() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetPacketWriter recovered at 0x0000000001bb1f00 (size 0x00000100).
func (*Player) SetPacketWriter() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetPlayerGameMode recovered at 0x0000000001c39b80 (size 0x00000080).
func (*Player) SetPlayerGameMode() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetPosition recovered at 0x0000000001c36480 (size 0x000001e0).
func (*Player) SetPosition() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetPremium recovered at 0x0000000001c34c40 (size 0x00000020).
func (*Player) SetPremium() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetProperties recovered at 0x0000000001c7ef40 (size 0x00000140).
func (*Player) SetProperties() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetRainIntensity recovered at 0x0000000001c36c60 (size 0x00000020).
func (*Player) SetRainIntensity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetRotation recovered at 0x0000000001c7f1a0 (size 0x00000040).
func (*Player) SetRotation() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetSaturation recovered at 0x0000000001c3f720 (size 0x00000020).
func (*Player) SetSaturation() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetServerAbilityData recovered at 0x0000000001c57460 (size 0x000000a0).
func (*Player) SetServerAbilityData() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetServerBBox recovered at 0x0000000001c7f200 (size 0x00000080).
func (*Player) SetServerBBox() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetServerCameraInstruction recovered at 0x0000000001c39680 (size 0x00000040).
func (*Player) SetServerCameraInstruction() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetServerConfigKey recovered at 0x0000000001c34f80 (size 0x00000100).
func (*Player) SetServerConfigKey() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetServerControlSchemeSet recovered at 0x0000000001c396e0 (size 0x00000020).
func (*Player) SetServerControlSchemeSet() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetServerEffect recovered at 0x0000000001c36cc0 (size 0x000000c0).
func (*Player) SetServerEffect() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetServerMovementSpeed recovered at 0x0000000001c3f5c0 (size 0x00000020).
func (*Player) SetServerMovementSpeed() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetServerPacketWriter recovered at 0x0000000001bb2000 (size 0x00000100).
func (*Player) SetServerPacketWriter() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetServerType recovered at 0x0000000001c34da0 (size 0x000000a0).
func (*Player) SetServerType() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetSneaking recovered at 0x0000000001c7f300 (size 0x00000040).
func (*Player) SetSneaking() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetSpeed recovered at 0x0000000001c36080 (size 0x00000060).
func (*Player) SetSpeed() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetSpinAttack recovered at 0x0000000001c7f380 (size 0x00000040).
func (*Player) SetSpinAttack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetSprinting recovered at 0x0000000001c7f400 (size 0x00000040).
func (*Player) SetSprinting() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetStatChangerOverride recovered at 0x0000000001c3da20 (size 0x00000260).
func (*Player) SetStatChangerOverride() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetSwimming recovered at 0x0000000001c7f480 (size 0x00000040).
func (*Player) SetSwimming() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetThunderstormIntensity recovered at 0x0000000001c36ca0 (size 0x00000020).
func (*Player) SetThunderstormIntensity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetUsingSocks5Proxy recovered at 0x0000000001c34e60 (size 0x00000020).
func (*Player) SetUsingSocks5Proxy() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetVisibleHeldSlot recovered at 0x0000000001c25f40 (size 0x000000a0).
func (*Player) SetVisibleHeldSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SetWorldUpdater recovered at 0x0000000001c61d60 (size 0x00000080).
func (*Player) SetWorldUpdater() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ShouldRenderDebugShapes recovered at 0x0000000001c61ae0 (size 0x000001c0).
func (*Player) ShouldRenderDebugShapes() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ShouldSuppressContainerOpen recovered at 0x0000000001bc1120 (size 0x00000060).
func (*Player) ShouldSuppressContainerOpen() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ShouldSuppressHeldSlotEcho recovered at 0x0000000001c23000 (size 0x00000480).
func (*Player) ShouldSuppressHeldSlotEcho() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ShowCoordinates recovered at 0x0000000001c36b60 (size 0x000000e0).
func (*Player) ShowCoordinates() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ShowLightning recovered at 0x0000000001c271a0 (size 0x00000360).
func (*Player) ShowLightning() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ShulkerTooltipDecorated recovered at 0x0000000001c5e540 (size 0x00000080).
func (*Player) ShulkerTooltipDecorated() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ShulkerTooltipRequestDecorated recovered at 0x0000000001c5eb40 (size 0x000000a0).
func (*Player) ShulkerTooltipRequestDecorated() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Skin recovered at 0x0000000001c38880 (size 0x00000020).
func (*Player) Skin() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SnapshotConfig recovered at 0x0000000001c4b4e0 (size 0x00000340).
func (*Player) SnapshotConfig() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SnapshotSections recovered at 0x0000000001c5c3a0 (size 0x000001c0).
func (*Player) SnapshotSections() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SnapshotStatChangerSettings recovered at 0x0000000001c3d7c0 (size 0x00000220).
func (*Player) SnapshotStatChangerSettings() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Sneaking recovered at 0x0000000001c7f500 (size 0x00000020).
func (*Player) Sneaking() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SpeedValue recovered at 0x0000000001c36120 (size 0x00000040).
func (*Player) SpeedValue() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SpinAttack recovered at 0x0000000001c7f540 (size 0x00000020).
func (*Player) SpinAttack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Sprinting recovered at 0x0000000001c7f580 (size 0x00000020).
func (*Player) Sprinting() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).StackFromItem recovered at 0x0000000001c26d80 (size 0x000002c0).
func (*Player) StackFromItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).StackToItem recovered at 0x0000000001c26640 (size 0x00000420).
func (*Player) StackToItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).StartArrayList recovered at 0x0000000001bcbb40 (size 0x00000100).
func (*Player) StartArrayList() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).StartBacktrackTicking recovered at 0x0000000001c60780 (size 0x00000100).
func (*Player) StartBacktrackTicking() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).StartClickTicker recovered at 0x0000000001c5fca0 (size 0x00000200).
func (*Player) StartClickTicker() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).StartPlayerTicker recovered at 0x0000000001c2d400 (size 0x00000140).
func (*Player) StartPlayerTicker() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).StartShapesTicker recovered at 0x0000000001c613c0 (size 0x00000220).
func (*Player) StartShapesTicker() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).StartSpam recovered at 0x0000000001c0d6c0 (size 0x00000280).
func (*Player) StartSpam() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).StartStealContainerTicker recovered at 0x0000000001c335e0 (size 0x00000180).
func (*Player) StartStealContainerTicker() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).StatChangerCurrentLines recovered at 0x0000000001c5ae20 (size 0x00000240).
func (*Player) StatChangerCurrentLines() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).StatChangerOverrides recovered at 0x0000000001c3d660 (size 0x00000120).
func (*Player) StatChangerOverrides() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).StopClickTicker recovered at 0x0000000001c60540 (size 0x00000180).
func (*Player) StopClickTicker() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).StopEmote recovered at 0x0000000001c36ac0 (size 0x000000a0).
func (*Player) StopEmote() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).StopFastThrow recovered at 0x0000000001bfdf80 (size 0x000000c0).
func (*Player) StopFastThrow() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).StopModuleRuntimeDeps recovered at 0x0000000001c277e0 (size 0x00000060).
func (*Player) StopModuleRuntimeDeps() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).StopPlayerTicker recovered at 0x0000000001c2f620 (size 0x000000a0).
func (*Player) StopPlayerTicker() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).StopShapesTicker recovered at 0x0000000001c61960 (size 0x00000180).
func (*Player) StopShapesTicker() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).StoreServerGameMode recovered at 0x0000000001c39b60 (size 0x00000020).
func (*Player) StoreServerGameMode() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).StoreSkin recovered at 0x0000000001c388a0 (size 0x00000040).
func (*Player) StoreSkin() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).StoreSkinIfEmpty recovered at 0x0000000001c388e0 (size 0x00000060).
func (*Player) StoreSkinIfEmpty() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).StripShulkerTooltip recovered at 0x0000000001c5e700 (size 0x00000140).
func (*Player) StripShulkerTooltip() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).StripShulkerTooltipRequestResult recovered at 0x0000000001c5ebe0 (size 0x00000180).
func (*Player) StripShulkerTooltipRequestResult() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).StripShulkerTooltipResult recovered at 0x0000000001c5e9c0 (size 0x00000180).
func (*Player) StripShulkerTooltipResult() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).StripShulkerTooltipWithTrustedStack recovered at 0x0000000001c5e840 (size 0x00000180).
func (*Player) StripShulkerTooltipWithTrustedStack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Swimming recovered at 0x0000000001c7f5c0 (size 0x00000020).
func (*Player) Swimming() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SyncAutoSell recovered at 0x0000000001c44040 (size 0x00000260).
func (*Player) SyncAutoSell() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SyncFriendAlerts recovered at 0x0000000001c21ee0 (size 0x00000040).
func (*Player) SyncFriendAlerts() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SyncModules recovered at 0x0000000001c291e0 (size 0x00000300).
func (*Player) SyncModules() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SyncShulkerTooltips recovered at 0x0000000001c5f0c0 (size 0x00000040).
func (*Player) SyncShulkerTooltips() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).SyncSpam recovered at 0x0000000001c0d940 (size 0x00000040).
func (*Player) SyncSpam() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Teleport recovered at 0x0000000001c3e7e0 (size 0x00000080).
func (*Player) Teleport() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).TeleportAndRotate recovered at 0x0000000001c3ea40 (size 0x00000060).
func (*Player) TeleportAndRotate() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).TeleportMove recovered at 0x0000000001c3e940 (size 0x00000080).
func (*Player) TeleportMove() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).TeleportSelf recovered at 0x0000000001c3e860 (size 0x000000e0).
func (*Player) TeleportSelf() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ThunderstormIntensity recovered at 0x0000000001c36c80 (size 0x00000020).
func (*Player) ThunderstormIntensity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Tick recovered at 0x0000000001c2d800 (size 0x000001e0).
func (*Player) Tick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).TickAutoFish recovered at 0x0000000001c43f40 (size 0x00000060).
func (*Player) TickAutoFish() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).TimerValue recovered at 0x0000000001c37560 (size 0x00000020).
func (*Player) TimerValue() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Title recovered at 0x0000000001c363e0 (size 0x000000a0).
func (*Player) Title() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Toggle recovered at 0x0000000001c35b20 (size 0x00000240).
func (*Player) Toggle() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Tr recovered at 0x0000000001c35720 (size 0x000000a0).
func (*Player) Tr() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).TrackLocalBlockPlacement recovered at 0x0000000001c497e0 (size 0x00000520).
func (*Player) TrackLocalBlockPlacement() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).TrackUseItemTransaction recovered at 0x0000000001c49740 (size 0x000000a0).
func (*Player) TrackUseItemTransaction() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).TrustedShulkerTooltipHotBarItem recovered at 0x0000000001c25960 (size 0x00000140).
func (*Player) TrustedShulkerTooltipHotBarItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).TrustedShulkerTooltipSlotItem recovered at 0x0000000001c25aa0 (size 0x00000440).
func (*Player) TrustedShulkerTooltipSlotItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).TrustedShulkerTooltipStack recovered at 0x0000000001c5eea0 (size 0x00000100).
func (*Player) TrustedShulkerTooltipStack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).TryFlushBlockBreakQueue recovered at 0x0000000001c45920 (size 0x000011c0).
func (*Player) TryFlushBlockBreakQueue() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).TryStartFastThrow recovered at 0x0000000001bfdda0 (size 0x000001e0).
func (*Player) TryStartFastThrow() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).TryStartStashFinderScan recovered at 0x0000000001c2ac20 (size 0x000000a0).
func (*Player) TryStartStashFinderScan() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).UnknownItem recovered at 0x0000000001c26560 (size 0x000000e0).
func (*Player) UnknownItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).UpdateAbilities recovered at 0x0000000001c57a40 (size 0x00000400).
func (*Player) UpdateAbilities() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).UpdateBoundingBoxes recovered at 0x0000000001c3a400 (size 0x00000040).
func (*Player) UpdateBoundingBoxes() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).UpdateClientSkin recovered at 0x0000000001c37580 (size 0x00000080).
func (*Player) UpdateClientSkin() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).UpdateMetadata recovered at 0x0000000001c38220 (size 0x000000c0).
func (*Player) UpdateMetadata() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).UpdateServerSkin recovered at 0x0000000001c35f80 (size 0x00000100).
func (*Player) UpdateServerSkin() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).UpdateSkin recovered at 0x0000000001c37600 (size 0x000001c0).
func (*Player) UpdateSkin() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).UseItemClickAir recovered at 0x0000000001c2eca0 (size 0x000001c0).
func (*Player) UseItemClickAir() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).UseItemRightClickAir recovered at 0x0000000001c2e920 (size 0x00000300).
func (*Player) UseItemRightClickAir() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).UsingSocks5Proxy recovered at 0x0000000001c34e40 (size 0x00000020).
func (*Player) UsingSocks5Proxy() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Variant recovered at 0x0000000001c7f600 (size 0x00000040).
func (*Player) Variant() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Velocity recovered at 0x0000000001c7f660 (size 0x000000c0).
func (*Player) Velocity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).Velocity32 recovered at 0x0000000001c7f7e0 (size 0x00000060).
func (*Player) Velocity32() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).VisibleHeldSlot recovered at 0x0000000001c25600 (size 0x00000020).
func (*Player) VisibleHeldSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).VisibleHoldingWeapon recovered at 0x0000000001c3a200 (size 0x00000160).
func (*Player) VisibleHoldingWeapon() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).WalkTeleportSelf recovered at 0x0000000001c30c40 (size 0x00000100).
func (*Player) WalkTeleportSelf() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).WithinDistance recovered at 0x0000000001c7f8a0 (size 0x000000e0).
func (*Player) WithinDistance() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).WithinView recovered at 0x0000000001c3cb80 (size 0x000000e0).
func (*Player) WithinView() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).WithinView32 recovered at 0x0000000001c3cc60 (size 0x00000120).
func (*Player) WithinView32() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).World recovered at 0x0000000001c61e00 (size 0x00000020).
func (*Player) World() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).WorldUpdater recovered at 0x0000000001c61de0 (size 0x00000020).
func (*Player) WorldUpdater() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).WritePacket recovered at 0x0000000001c3d580 (size 0x00000060).
func (*Player) WritePacket() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).WritePacketDirect recovered at 0x0000000001c3e560 (size 0x00000080).
func (*Player) WritePacketDirect() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).WriteServerPacket recovered at 0x0000000001c3e5e0 (size 0x00000060).
func (*Player) WriteServerPacket() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).XrayFallingBlockClientVariant recovered at 0x0000000001c15d20 (size 0x00000060).
func (*Player) XrayFallingBlockClientVariant() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).XraySent recovered at 0x0000000001c14b60 (size 0x00000020).
func (*Player) XraySent() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).XraySettingsApplied recovered at 0x0000000001c14b80 (size 0x00000040).
func (*Player) XraySettingsApplied() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).XraySettingsPending recovered at 0x0000000001c14c20 (size 0x00000040).
func (*Player) XraySettingsPending() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).XrayShouldSuppressContainerOpen recovered at 0x0000000001c14fa0 (size 0x00000080).
func (*Player) XrayShouldSuppressContainerOpen() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).activeFeatures recovered at 0x0000000001bcc600 (size 0x00000f60).
func (*Player) activeFeatures() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).activeModuleRuntimeDeps recovered at 0x0000000001c294e0 (size 0x000001a0).
func (*Player) activeModuleRuntimeDeps() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).alertKnownStaff recovered at 0x0000000001c03ca0 (size 0x00000180).
func (*Player) alertKnownStaff() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).anchorAuraAnchorHit recovered at 0x0000000001bc9e60 (size 0x00000560).
func (*Player) anchorAuraAnchorHit() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).anchorAuraFeetRayBlocked recovered at 0x0000000001bc9a60 (size 0x000002c0).
func (*Player) anchorAuraFeetRayBlocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).anchorAuraHasFootCover recovered at 0x0000000001bc94c0 (size 0x000005a0).
func (*Player) anchorAuraHasFootCover() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).anchorAuraHasUnobstructedAnchorPath recovered at 0x0000000001bca3c0 (size 0x00000240).
func (*Player) anchorAuraHasUnobstructedAnchorPath() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).anchorAuraNearbyAnchors recovered at 0x0000000001bc8ee0 (size 0x00000400).
func (*Player) anchorAuraNearbyAnchors() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).anchorAuraSafeDetonationDistance recovered at 0x0000000001bc92e0 (size 0x000001e0).
func (*Player) anchorAuraSafeDetonationDistance() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).antiCrystalAdjustedPosition recovered at 0x0000000001bcb1c0 (size 0x00000120).
func (*Player) antiCrystalAdjustedPosition() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).applyAbilityOverrides recovered at 0x0000000001c57860 (size 0x000001e0).
func (*Player) applyAbilityOverrides() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).applyAntiCrystalPlayerAuthInput recovered at 0x0000000001bcb2e0 (size 0x00000520).
func (*Player) applyAntiCrystalPlayerAuthInput() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).applyAvailableCommandsLunar recovered at 0x0000000001bb5000 (size 0x000000c0).
func (*Player) applyAvailableCommandsLunar() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).applyFreeCamPose recovered at 0x0000000001c424e0 (size 0x00000120).
func (*Player) applyFreeCamPose() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).applyOwnedSneak recovered at 0x0000000001c403e0 (size 0x000003e0).
func (*Player) applyOwnedSneak() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).applySpeed recovered at 0x0000000001c36160 (size 0x00000100).
func (*Player) applySpeed() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).autoClickerDeficitCPS recovered at 0x0000000001c3d180 (size 0x000000e0).
func (*Player) autoClickerDeficitCPS() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).autoEatActive recovered at 0x0000000001bd44c0 (size 0x000000e0).
func (*Player) autoEatActive() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).autoEatBusy recovered at 0x0000000001bd45e0 (size 0x00000100).
func (*Player) autoEatBusy() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).autoEatModes recovered at 0x0000000001bd4b00 (size 0x00000100).
func (*Player) autoEatModes() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).autoEatRecentAction recovered at 0x0000000001bd4c00 (size 0x00000120).
func (*Player) autoEatRecentAction() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).autoElytraFallDistanceAfter recovered at 0x0000000001bd6540 (size 0x000001a0).
func (*Player) autoElytraFallDistanceAfter() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).autoElytraOwnsChestSlot recovered at 0x0000000001bd66e0 (size 0x000001e0).
func (*Player) autoElytraOwnsChestSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).autoRocketCanUse recovered at 0x0000000001be44e0 (size 0x000001a0).
func (*Player) autoRocketCanUse() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).autoWebCandidates recovered at 0x0000000001be89c0 (size 0x000008a0).
func (*Player) autoWebCandidates() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).autoWebClickTarget recovered at 0x0000000001be95a0 (size 0x00000960).
func (*Player) autoWebClickTarget() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).autoWebSwapAndClick recovered at 0x0000000001be88c0 (size 0x00000100).
func (*Player) autoWebSwapAndClick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).blockBreakContext recovered at 0x0000000001c48a60 (size 0x00000240).
func (*Player) blockBreakContext() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).blocksByNameWithinReach recovered at 0x0000000001c635c0 (size 0x00000380).
func (*Player) blocksByNameWithinReach() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).breakActionFace recovered at 0x0000000001c49280 (size 0x00000300).
func (*Player) breakActionFace() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).canMeleeTarget recovered at 0x0000000001c3af80 (size 0x00000120).
func (*Player) canMeleeTarget() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).checkOnGround recovered at 0x0000000001c3e640 (size 0x00000180).
func (*Player) checkOnGround() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).chunkFinderApplyAnalysisLocked recovered at 0x0000000001bf6200 (size 0x00000420).
func (*Player) chunkFinderApplyAnalysisLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).chunkFinderHandleBlockEntity recovered at 0x0000000001bf5c40 (size 0x000001a0).
func (*Player) chunkFinderHandleBlockEntity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).chunkFinderHandleBlockUpdates recovered at 0x0000000001bf5de0 (size 0x00000140).
func (*Player) chunkFinderHandleBlockUpdates() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).chunkFinderNotifyLocked recovered at 0x0000000001bf6620 (size 0x00000780).
func (*Player) chunkFinderNotifyLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).chunkFinderUpdateTipLocked recovered at 0x0000000001bf9a80 (size 0x000002a0).
func (*Player) chunkFinderUpdateTipLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).claimItemUseForEmit recovered at 0x0000000001c2e780 (size 0x00000100).
func (*Player) claimItemUseForEmit() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).clearDebugTracers recovered at 0x0000000001c51a60 (size 0x00000da0).
func (*Player) clearDebugTracers() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).clickActivatesBlock recovered at 0x0000000001c32960 (size 0x000000c0).
func (*Player) clickActivatesBlock() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).clickBlock recovered at 0x0000000001c32e80 (size 0x00000360).
func (*Player) clickBlock() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).clickBlockTracked recovered at 0x0000000001c32840 (size 0x00000120).
func (*Player) clickBlockTracked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).close recovered at 0x0000000001c3d460 (size 0x00000120).
func (*Player) close() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).collectDebugTracerShapes recovered at 0x0000000001c4dd40 (size 0x00003900).
func (*Player) collectDebugTracerShapes() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).combatRayBox recovered at 0x0000000001c3bf60 (size 0x000005c0).
func (*Player) combatRayBox() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).createChunkBorderShapes recovered at 0x0000000001c53500 (size 0x000008e0).
func (*Player) createChunkBorderShapes() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).currentKillAuraIndicatorTarget recovered at 0x0000000001c4d6e0 (size 0x00000120).
func (*Player) currentKillAuraIndicatorTarget() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).dispatchDeathEvent recovered at 0x0000000001c4d660 (size 0x00000080).
func (*Player) dispatchDeathEvent() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).doubleClickDelay recovered at 0x0000000001bfcd20 (size 0x00000080).
func (*Player) doubleClickDelay() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).doubleClickHeldItem recovered at 0x0000000001bfcda0 (size 0x00000340).
func (*Player) doubleClickHeldItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).dropAutoEatState recovered at 0x0000000001bd5600 (size 0x00000120).
func (*Player) dropAutoEatState() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).ensureModules recovered at 0x0000000001c28000 (size 0x00000080).
func (*Player) ensureModules() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).equipElytra recovered at 0x0000000001bd68c0 (size 0x00000540).
func (*Player) equipElytra() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).executePendingPotionThrow recovered at 0x0000000001be4040 (size 0x000000a0).
func (*Player) executePendingPotionThrow() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).expectedBreakTicksWithStack recovered at 0x0000000001c49580 (size 0x000001c0).
func (*Player) expectedBreakTicksWithStack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).eyeInWater recovered at 0x0000000001c48d40 (size 0x00000140).
func (*Player) eyeInWater() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).facePosition recovered at 0x0000000001c30100 (size 0x000002c0).
func (*Player) facePosition() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).fasterBreakDuration recovered at 0x0000000001c47c60 (size 0x00000200).
func (*Player) fasterBreakDuration() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).findAnchorDetonateSlot recovered at 0x0000000001bca900 (size 0x000003a0).
func (*Player) findAnchorDetonateSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).findAutoEatItemInRange recovered at 0x0000000001bd5c20 (size 0x00000220).
func (*Player) findAutoEatItemInRange() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).findBacktrackRangeTarget recovered at 0x0000000001bb92c0 (size 0x000001c0).
func (*Player) findBacktrackRangeTarget() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).findBestToolInHotbarForBlock recovered at 0x0000000001c48300 (size 0x00000760).
func (*Player) findBestToolInHotbarForBlock() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).findItem recovered at 0x0000000001bcaca0 (size 0x00000220).
func (*Player) findItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).findOrMoveAutoEatItemToHotbar recovered at 0x0000000001bd5720 (size 0x00000500).
func (*Player) findOrMoveAutoEatItemToHotbar() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).finishBlockBreakTool recovered at 0x0000000001c476c0 (size 0x00000080).
func (*Player) finishBlockBreakTool() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).finishClickTicker recovered at 0x0000000001c60440 (size 0x00000100).
func (*Player) finishClickTicker() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).finishItemUseEmit recovered at 0x0000000001c2e8c0 (size 0x00000060).
func (*Player) finishItemUseEmit() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).finishShapesTicker recovered at 0x0000000001c61860 (size 0x00000100).
func (*Player) finishShapesTicker() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).flushDoubleClickAfterAutoCrit recovered at 0x0000000001bfc9e0 (size 0x00000220).
func (*Player) flushDoubleClickAfterAutoCrit() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).formatArrayList recovered at 0x0000000001bcbf20 (size 0x00000260).
func (*Player) formatArrayList() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).guaranteeInventoryOpen recovered at 0x0000000001c2e580 (size 0x000000a0).
func (*Player) guaranteeInventoryOpen() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).handleAutoElytra recovered at 0x0000000001bd6220 (size 0x00000320).
func (*Player) handleAutoElytra() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).handleAutoPot recovered at 0x0000000001be3bc0 (size 0x00000360).
func (*Player) handleAutoPot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).handleBlockActions recovered at 0x0000000001c41de0 (size 0x00000500).
func (*Player) handleBlockActions() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).handleMissedSwing recovered at 0x0000000001c422e0 (size 0x00000200).
func (*Player) handleMissedSwing() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).hasPendingDoubleClick recovered at 0x0000000001bfcc00 (size 0x000000e0).
func (*Player) hasPendingDoubleClick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).heldItemForHotbarSlot recovered at 0x0000000001c331e0 (size 0x00000400).
func (*Player) heldItemForHotbarSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).holeESPHandleBlockUpdates recovered at 0x0000000001c02280 (size 0x00000140).
func (*Player) holeESPHandleBlockUpdates() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).isFastThrowableProtocol recovered at 0x0000000001bfe1c0 (size 0x00000180).
func (*Player) isFastThrowableProtocol() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).isHealingSplashPotion recovered at 0x0000000001be40e0 (size 0x00000260).
func (*Player) isHealingSplashPotion() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).isMaceSwapSlotUsable recovered at 0x0000000001c03600 (size 0x00000160).
func (*Player) isMaceSwapSlotUsable() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).isValidKillAuraTarget recovered at 0x0000000001c5f420 (size 0x000001e0).
func (*Player) isValidKillAuraTarget() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).loadItems recovered at 0x0000000001c2c780 (size 0x00000460).
func (*Player) loadItems() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).maceSwapAttack recovered at 0x0000000001c02d40 (size 0x000003e0).
func (*Player) maceSwapAttack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).maceSwapSlot recovered at 0x0000000001c03460 (size 0x00000120).
func (*Player) maceSwapSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).messageModuleToggle recovered at 0x0000000001c28880 (size 0x00000320).
func (*Player) messageModuleToggle() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).moveSelf recovered at 0x0000000001c3ec20 (size 0x000001c0).
func (*Player) moveSelf() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).nearbyUnfriendlyPlayer recovered at 0x0000000001c39100 (size 0x000002a0).
func (*Player) nearbyUnfriendlyPlayer() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).newChunksApplySignalLocked recovered at 0x0000000001c06160 (size 0x00000100).
func (*Player) newChunksApplySignalLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).newChunksHandleRuntimeIDUpdate recovered at 0x0000000001c05b00 (size 0x00000520).
func (*Player) newChunksHandleRuntimeIDUpdate() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).newChunksNotifyLocked recovered at 0x0000000001c06260 (size 0x00000740).
func (*Player) newChunksNotifyLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).placedBlockFromUseItem recovered at 0x0000000001c49f00 (size 0x00000420).
func (*Player) placedBlockFromUseItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).prepareBlockBreakTool recovered at 0x0000000001c46ae0 (size 0x00000be0).
func (*Player) prepareBlockBreakTool() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).preparePotionThrow recovered at 0x0000000001be3f20 (size 0x00000120).
func (*Player) preparePotionThrow() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).processDoubleClick recovered at 0x0000000001bfd0e0 (size 0x00000a60).
func (*Player) processDoubleClick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).proxySwapFallbackAttack recovered at 0x0000000001bb35c0 (size 0x000001a0).
func (*Player) proxySwapFallbackAttack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).queueDoubleClickAttack recovered at 0x0000000001bfc740 (size 0x000002a0).
func (*Player) queueDoubleClickAttack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).queueDoubleClickDefaults recovered at 0x0000000001bfc6c0 (size 0x00000080).
func (*Player) queueDoubleClickDefaults() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).rayIntersectsEntity recovered at 0x0000000001c3c520 (size 0x00000100).
func (*Player) rayIntersectsEntity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).reconcileModuleRuntimeDeps recovered at 0x0000000001c29680 (size 0x000000a0).
func (*Player) reconcileModuleRuntimeDeps() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).refreshSettings recovered at 0x0000000001c34aa0 (size 0x00000120).
func (*Player) refreshSettings() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).releaseAutoEatItem recovered at 0x0000000001bd5360 (size 0x00000180).
func (*Player) releaseAutoEatItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).removeAllChunkBorders recovered at 0x0000000001c53de0 (size 0x00000300).
func (*Player) removeAllChunkBorders() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).resetAutoEatState recovered at 0x0000000001bd54e0 (size 0x00000120).
func (*Player) resetAutoEatState() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).restartBacktrackTickerIfNeeded recovered at 0x0000000001c61300 (size 0x000000c0).
func (*Player) restartBacktrackTickerIfNeeded() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).restoreSavedCheats recovered at 0x0000000001c5c560 (size 0x00000320).
func (*Player) restoreSavedCheats() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).restoreServerSideHotBarSlot recovered at 0x0000000001c03580 (size 0x00000080).
func (*Player) restoreServerSideHotBarSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).restoreSettingsSection recovered at 0x0000000001c5bfc0 (size 0x00000280).
func (*Player) restoreSettingsSection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).restoreSettingsSections recovered at 0x0000000001c5bb40 (size 0x00000480).
func (*Player) restoreSettingsSections() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).retainedChunkRadius recovered at 0x0000000001c61e20 (size 0x00000060).
func (*Player) retainedChunkRadius() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).retireQueuedBreak recovered at 0x0000000001c44980 (size 0x000000c0).
func (*Player) retireQueuedBreak() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).sanitizeStatChangerOverridesLocked recovered at 0x0000000001c3e1c0 (size 0x00000300).
func (*Player) sanitizeStatChangerOverridesLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).scaffoldTo recovered at 0x0000000001c314e0 (size 0x00000500).
func (*Player) scaffoldTo() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).scanBlocksInRadiusFrom recovered at 0x0000000001c62880 (size 0x000001c0).
func (*Player) scanBlocksInRadiusFrom() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).sectionResetsPerConnection recovered at 0x0000000001c5c2a0 (size 0x00000100).
func (*Player) sectionResetsPerConnection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).selectServerSideHotBarSlot recovered at 0x0000000001c31320 (size 0x000001c0).
func (*Player) selectServerSideHotBarSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).selectSingleKillAuraTarget recovered at 0x0000000001c5f600 (size 0x000002c0).
func (*Player) selectSingleKillAuraTarget() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).selectTarget recovered at 0x0000000001c33f40 (size 0x00000240).
func (*Player) selectTarget() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).sendAttackPacket recovered at 0x0000000001bb40c0 (size 0x000004e0).
func (*Player) sendAttackPacket() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).sendAttackTx recovered at 0x0000000001bb3ec0 (size 0x00000200).
func (*Player) sendAttackTx() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).sendDebugTracers recovered at 0x0000000001c4dce0 (size 0x00000060).
func (*Player) sendDebugTracers() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).sendEquipmentForSlot recovered at 0x0000000001c30e80 (size 0x000004a0).
func (*Player) sendEquipmentForSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).sendVisibleEquipmentSpoof recovered at 0x0000000001c07f80 (size 0x00000200).
func (*Player) sendVisibleEquipmentSpoof() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).serverEffectLevel recovered at 0x0000000001c48ca0 (size 0x000000a0).
func (*Player) serverEffectLevel() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).setAndRenderLocalBlock recovered at 0x0000000001c321e0 (size 0x00000160).
func (*Player) setAndRenderLocalBlock() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).setClientEatingFromInteraction recovered at 0x0000000001bc1c60 (size 0x00000280).
func (*Player) setClientEatingFromInteraction() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).shieldDisablerAttack recovered at 0x0000000001c072c0 (size 0x000003e0).
func (*Player) shieldDisablerAttack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).shieldDisablerSendHooks recovered at 0x0000000001c07b80 (size 0x00000220).
func (*Player) shieldDisablerSendHooks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).shieldDisablerSlot recovered at 0x0000000001c08180 (size 0x000003c0).
func (*Player) shieldDisablerSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).shouldEmitFastThrow recovered at 0x0000000001bfe040 (size 0x00000180).
func (*Player) shouldEmitFastThrow() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).shouldKeepBacktrackRangeTarget recovered at 0x0000000001bb9780 (size 0x000001e0).
func (*Player) shouldKeepBacktrackRangeTarget() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).shouldRunClickTicker recovered at 0x0000000001c61ca0 (size 0x000000c0).
func (*Player) shouldRunClickTicker() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).showBlockCracking recovered at 0x0000000001c44340 (size 0x00000140).
func (*Player) showBlockCracking() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).snapshotSettingsSections recovered at 0x0000000001c5b7e0 (size 0x000002a0).
func (*Player) snapshotSettingsSections() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).stackItemType recovered at 0x0000000001c26a60 (size 0x00000320).
func (*Player) stackItemType() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).startAutoEatAttempt recovered at 0x0000000001bd4d20 (size 0x00000640).
func (*Player) startAutoEatAttempt() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).swapAndClick recovered at 0x0000000001c24060 (size 0x00000560).
func (*Player) swapAndClick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).swapAttackHooks recovered at 0x0000000001bb31a0 (size 0x00000260).
func (*Player) swapAttackHooks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).swapFallbackAttack recovered at 0x0000000001c07980 (size 0x00000200).
func (*Player) swapFallbackAttack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).switchHeldSlotFor recovered at 0x0000000001c23f80 (size 0x000000e0).
func (*Player) switchHeldSlotFor() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).syncAutomaticEating recovered at 0x0000000001bc1b80 (size 0x000000e0).
func (*Player) syncAutomaticEating() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).teleportAndRotate recovered at 0x0000000001c3eaa0 (size 0x00000180).
func (*Player) teleportAndRotate() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).tickAutoEat recovered at 0x0000000001bd42c0 (size 0x000000c0).
func (*Player) tickAutoEat() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).tryArmBacktrackRangeTarget recovered at 0x0000000001bb9680 (size 0x00000100).
func (*Player) tryArmBacktrackRangeTarget() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).tryAutoWeb recovered at 0x0000000001be85c0 (size 0x00000300).
func (*Player) tryAutoWeb() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).tryBufferAutoCritAttack recovered at 0x0000000001c3a580 (size 0x000003a0).
func (*Player) tryBufferAutoCritAttack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).tryMaceSwapAttack recovered at 0x0000000001c03200 (size 0x00000180).
func (*Player) tryMaceSwapAttack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).tryPlaceBlockAt recovered at 0x0000000001c319e0 (size 0x00000800).
func (*Player) tryPlaceBlockAt() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).tryShieldDisablerAttack recovered at 0x0000000001c07780 (size 0x00000160).
func (*Player) tryShieldDisablerAttack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).trySwapClientAttack recovered at 0x0000000001bb3760 (size 0x00000420).
func (*Player) trySwapClientAttack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).updateBlockBreakCompletionDelayForQueue recovered at 0x0000000001c47e60 (size 0x000004a0).
func (*Player) updateBlockBreakCompletionDelayForQueue() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).updateChunkBorders recovered at 0x0000000001c528a0 (size 0x00000c60).
func (*Player) updateChunkBorders() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).walkTo recovered at 0x0000000001c30800 (size 0x00000120).
func (*Player) walkTo() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).withinEyeReach recovered at 0x0000000001c63400 (size 0x000001c0).
func (*Player) withinEyeReach() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).writeDeferredServerPacket recovered at 0x0000000001bb9c20 (size 0x00000160).
func (*Player) writeDeferredServerPacket() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).writePlayerAuthInput recovered at 0x0000000001c42600 (size 0x00000340).
func (*Player) writePlayerAuthInput() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).writePrimitiveShapes recovered at 0x0000000001c54980 (size 0x00000120).
func (*Player) writePrimitiveShapes() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Player).writeWalkAuthInput recovered at 0x0000000001c309c0 (size 0x00000200).
func (*Player) writeWalkAuthInput() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*SavedConfig).EnabledModules recovered at 0x0000000001bbdd60 (size 0x00000040).
func (*SavedConfig) EnabledModules() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Scoreboard).ClearObjective recovered at 0x0000000001c58da0 (size 0x00000160).
func (*Scoreboard) ClearObjective() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Scoreboard).Lines recovered at 0x0000000001c58140 (size 0x000001a0).
func (*Scoreboard) Lines() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Scoreboard).RememberDisplayObjective recovered at 0x0000000001c58800 (size 0x00000240).
func (*Scoreboard) RememberDisplayObjective() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Scoreboard).RememberScore recovered at 0x0000000001c58a80 (size 0x000002e0).
func (*Scoreboard) RememberScore() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Scoreboard).buildStatChangerReplay recovered at 0x0000000001c590e0 (size 0x000017c0).
func (*Scoreboard) buildStatChangerReplay() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Scoreboard).clientObjectiveRewrite recovered at 0x0000000001c58f40 (size 0x00000160).
func (*Scoreboard) clientObjectiveRewrite() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Scoreboard).displayEntries recovered at 0x0000000001c58320 (size 0x000002a0).
func (*Scoreboard) displayEntries() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Scoreboard).displayIndexes recovered at 0x0000000001c58640 (size 0x00000180).
func (*Scoreboard) displayIndexes() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*Scoreboard).title recovered at 0x0000000001c5aac0 (size 0x00000120).
func (*Scoreboard) title() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*ShulkerPreviewEntry).Description recovered at 0x0000000001c5e400 (size 0x00000140).
func (*ShulkerPreviewEntry) Description() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*XrayBlockUpdateGuard).Complete recovered at 0x0000000001c15360 (size 0x00000080).
func (*XrayBlockUpdateGuard) Complete() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*abilityState).Client recovered at 0x0000000001c56dc0 (size 0x000002a0).
func (*abilityState) Client() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*abilityState).Server recovered at 0x0000000001c568c0 (size 0x000002a0).
func (*abilityState) Server() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*abilityState).SetClient recovered at 0x0000000001c570a0 (size 0x00000220).
func (*abilityState) SetClient() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*abilityState).SetServer recovered at 0x0000000001c56ba0 (size 0x00000220).
func (*abilityState) SetServer() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*abilityState).reset recovered at 0x0000000001c572c0 (size 0x000000e0).
func (*abilityState) reset() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*afkClicker).applyCrouch recovered at 0x0000000001bc3d00 (size 0x000000c0).
func (*afkClicker) applyCrouch() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*afkClicker).applySwing recovered at 0x0000000001bc3b00 (size 0x00000200).
func (*afkClicker) applySwing() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*afkClicker).clickDue recovered at 0x0000000001bc2ca0 (size 0x000000e0).
func (*afkClicker) clickDue() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*afkClicker).combatTick recovered at 0x0000000001bc2b80 (size 0x00000120).
func (*afkClicker) combatTick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*afkClicker).leftClick recovered at 0x0000000001bc3400 (size 0x000000e0).
func (*afkClicker) leftClick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*afkClicker).lookingAtBlock recovered at 0x0000000001bc34e0 (size 0x000003e0).
func (*afkClicker) lookingAtBlock() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*afkClicker).refreshSettings recovered at 0x0000000001bc2f20 (size 0x000000e0).
func (*afkClicker) refreshSettings() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*afkClicker).rightClick recovered at 0x0000000001bc3000 (size 0x000003c0).
func (*afkClicker) rightClick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*afkClicker).tick recovered at 0x0000000001bc2d80 (size 0x00000060).
func (*afkClicker) tick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*aimAssistComponent).acknowledgeTeleport recovered at 0x0000000001bc4b20 (size 0x00000120).
func (*aimAssistComponent) acknowledgeTeleport() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*aimAssistComponent).applyInput recovered at 0x0000000001bc4c80 (size 0x00000260).
func (*aimAssistComponent) applyInput() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*aimAssistComponent).applyLocked recovered at 0x0000000001bc4f20 (size 0x00000380).
func (*aimAssistComponent) applyLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*aimAssistComponent).deactivate recovered at 0x0000000001bc3dc0 (size 0x00000100).
func (*aimAssistComponent) deactivate() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*aimAssistComponent).forwardServerCamera recovered at 0x0000000001bc5600 (size 0x00000300).
func (*aimAssistComponent) forwardServerCamera() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*aimAssistComponent).forwardServerControlScheme recovered at 0x0000000001bc5940 (size 0x00000120).
func (*aimAssistComponent) forwardServerControlScheme() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*aimAssistComponent).forwardTeleport recovered at 0x0000000001bc5aa0 (size 0x00000320).
func (*aimAssistComponent) forwardTeleport() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*aimAssistComponent).handle recovered at 0x0000000001bc41a0 (size 0x00000980).
func (*aimAssistComponent) handle() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*aimAssistComponent).reset recovered at 0x0000000001bc3f00 (size 0x000000e0).
func (*aimAssistComponent) reset() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*aimAssistComponent).resetInstructionLocked recovered at 0x0000000001bc5400 (size 0x00000200).
func (*aimAssistComponent) resetInstructionLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*aimAssistComponent).resetLocked recovered at 0x0000000001bc52a0 (size 0x00000160).
func (*aimAssistComponent) resetLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*aimAssistComponent).terminate recovered at 0x0000000001bc4020 (size 0x00000140).
func (*aimAssistComponent) terminate() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*anchorAuraComponent).tick recovered at 0x0000000001bc5ee0 (size 0x00002da0).
func (*anchorAuraComponent) tick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*atomicFloat32).Add recovered at 0x0000000001c3ee40 (size 0x00000020).
func (*atomicFloat32) Add() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*atomicFloat32).Load recovered at 0x0000000001c3ee00 (size 0x00000020).
func (*atomicFloat32) Load() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*atomicFloat32).Store recovered at 0x0000000001c3ee20 (size 0x00000020).
func (*atomicFloat32) Store() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoClickerComponent).combatTick recovered at 0x0000000001bfa3e0 (size 0x000003a0).
func (*autoClickerComponent) combatTick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoCrystal).bestAttack recovered at 0x0000000001bcf2a0 (size 0x00001000).
func (*autoCrystal) bestAttack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoCrystal).bestPlacementBlock recovered at 0x0000000001bd02a0 (size 0x00000b20).
func (*autoCrystal) bestPlacementBlock() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoCrystal).clearOwnershipState recovered at 0x0000000001bd2b60 (size 0x00000100).
func (*autoCrystal) clearOwnershipState() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoCrystal).collectTargets recovered at 0x0000000001bcece0 (size 0x000005c0).
func (*autoCrystal) collectTargets() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoCrystal).forgetOwnedCrystal recovered at 0x0000000001bd2c60 (size 0x000000e0).
func (*autoCrystal) forgetOwnedCrystal() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoCrystal).hasBlockLineOfSight recovered at 0x0000000001bd39a0 (size 0x00000240).
func (*autoCrystal) hasBlockLineOfSight() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoCrystal).isOwnedCrystal recovered at 0x0000000001bd3000 (size 0x000004e0).
func (*autoCrystal) isOwnedCrystal() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoCrystal).newTickContext recovered at 0x0000000001bce860 (size 0x00000480).
func (*autoCrystal) newTickContext() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoCrystal).prunePlacementsLocked recovered at 0x0000000001bd34e0 (size 0x00000260).
func (*autoCrystal) prunePlacementsLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoCrystal).prunedEntityBBoxes recovered at 0x0000000001bcd680 (size 0x000005c0).
func (*autoCrystal) prunedEntityBBoxes() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoCrystal).recordPlacement recovered at 0x0000000001bd2d40 (size 0x000002c0).
func (*autoCrystal) recordPlacement() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoCrystal).tick recovered at 0x0000000001bd0dc0 (size 0x000006e0).
func (*autoCrystal) tick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoCrystal).trackManualCrystalPlacement recovered at 0x0000000001bd2840 (size 0x00000320).
func (*autoCrystal) trackManualCrystalPlacement() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoCrystal).tryPlaceObsidian recovered at 0x0000000001bd14a0 (size 0x000013a0).
func (*autoCrystal) tryPlaceObsidian() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoCrystalDamageScorer).Block recovered at 0x0000000001bce5a0 (size 0x000000a0).
func (*autoCrystalDamageScorer) Block() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoEatComponent).armRelease recovered at 0x0000000001bd4100 (size 0x000001c0).
func (*autoEatComponent) armRelease() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoEatComponent).tick recovered at 0x0000000001bd4720 (size 0x000003e0).
func (*autoEatComponent) tick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoEquipComponent).tick recovered at 0x0000000001bd6f40 (size 0x000006a0).
func (*autoEquipComponent) tick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoFishComponent).forgetHook recovered at 0x0000000001bd8180 (size 0x00000160).
func (*autoFishComponent) forgetHook() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoFishComponent).handleActorEvent recovered at 0x0000000001bd7de0 (size 0x00000140).
func (*autoFishComponent) handleActorEvent() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoFishComponent).handleManualUse recovered at 0x0000000001bd7f60 (size 0x000001e0).
func (*autoFishComponent) handleManualUse() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoFishComponent).reel recovered at 0x0000000001bd8420 (size 0x00000060).
func (*autoFishComponent) reel() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoFishComponent).rescheduleCast recovered at 0x0000000001bd8480 (size 0x000000c0).
func (*autoFishComponent) rescheduleCast() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoFishComponent).resetState recovered at 0x0000000001bd8540 (size 0x00000100).
func (*autoFishComponent) resetState() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoFishComponent).tick recovered at 0x0000000001bd7980 (size 0x00000420).
func (*autoFishComponent) tick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoFishComponent).trackHook recovered at 0x0000000001bd8320 (size 0x00000100).
func (*autoFishComponent) trackHook() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).autoEatActiveForPlayer recovered at 0x0000000001be0fe0 (size 0x00000100).
func (*autoMinerComponent) autoEatActiveForPlayer() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).autoEatBusy recovered at 0x0000000001be1120 (size 0x00000140).
func (*autoMinerComponent) autoEatBusy() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).autoMinerBestStandEye recovered at 0x0000000001bdcac0 (size 0x00000460).
func (*autoMinerComponent) autoMinerBestStandEye() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).autoMinerCanQueueTarget recovered at 0x0000000001bde280 (size 0x00000160).
func (*autoMinerComponent) autoMinerCanQueueTarget() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).autoMinerHasNearbyItemEntities recovered at 0x0000000001bdfa40 (size 0x000001a0).
func (*autoMinerComponent) autoMinerHasNearbyItemEntities() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).autoMinerHasUnobstructedTargetPath recovered at 0x0000000001bdc720 (size 0x00000240).
func (*autoMinerComponent) autoMinerHasUnobstructedTargetPath() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).autoMinerHealUntilHealthOK recovered at 0x0000000001be0620 (size 0x000000a0).
func (*autoMinerComponent) autoMinerHealUntilHealthOK() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).autoMinerMaybeMessageProgress recovered at 0x0000000001bdfbe0 (size 0x00000200).
func (*autoMinerComponent) autoMinerMaybeMessageProgress() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).autoMinerRegisterInFlight recovered at 0x0000000001bde9c0 (size 0x00000180).
func (*autoMinerComponent) autoMinerRegisterInFlight() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).autoMinerReleaseEatItem recovered at 0x0000000001be1ba0 (size 0x000001a0).
func (*autoMinerComponent) autoMinerReleaseEatItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).autoMinerShouldBreakLocalTargetInPlace recovered at 0x0000000001bdc300 (size 0x00000420).
func (*autoMinerComponent) autoMinerShouldBreakLocalTargetInPlace() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).autoMinerStartEatAttempt recovered at 0x0000000001be13a0 (size 0x00000800).
func (*autoMinerComponent) autoMinerStartEatAttempt() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).autoMinerStatus recovered at 0x0000000001bd8ce0 (size 0x00000120).
func (*autoMinerComponent) autoMinerStatus() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).autoMinerStepPathHasHazard recovered at 0x0000000001bde420 (size 0x000005a0).
func (*autoMinerComponent) autoMinerStepPathHasHazard() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).breakBlocksInsidePlayerWithOptions recovered at 0x0000000001bdb3e0 (size 0x00000440).
func (*autoMinerComponent) breakBlocksInsidePlayerWithOptions() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).clearAutoEatState recovered at 0x0000000001be1260 (size 0x00000140).
func (*autoMinerComponent) clearAutoEatState() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).computeLocalAndClosestTargetFromTargets recovered at 0x0000000001bdbda0 (size 0x00000280).
func (*autoMinerComponent) computeLocalAndClosestTargetFromTargets() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).findBestConsumableInRange recovered at 0x0000000001be2260 (size 0x00000520).
func (*autoMinerComponent) findBestConsumableInRange() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).findOrMoveConsumableToHotbar recovered at 0x0000000001be1d40 (size 0x00000520).
func (*autoMinerComponent) findOrMoveConsumableToHotbar() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).findTargetIndicesForPositions recovered at 0x0000000001bdfde0 (size 0x000004e0).
func (*autoMinerComponent) findTargetIndicesForPositions() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).hasRegenerationEffect recovered at 0x0000000001be0f80 (size 0x00000060).
func (*autoMinerComponent) hasRegenerationEffect() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).limitStepTowards recovered at 0x0000000001bddf80 (size 0x00000140).
func (*autoMinerComponent) limitStepTowards() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).popTargetsByIndices recovered at 0x0000000001bddae0 (size 0x00000460).
func (*autoMinerComponent) popTargetsByIndices() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).queueNearbyTargets recovered at 0x0000000001bdb820 (size 0x00000580).
func (*autoMinerComponent) queueNearbyTargets() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).refreshTargetsIfNeeded recovered at 0x0000000001bdcf20 (size 0x00000760).
func (*autoMinerComponent) refreshTargetsIfNeeded() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).resetAutoMinerState recovered at 0x0000000001be2780 (size 0x00000240).
func (*autoMinerComponent) resetAutoMinerState() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).resetMining recovered at 0x0000000001bd8c00 (size 0x000000e0).
func (*autoMinerComponent) resetMining() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).scanAutoMinerTargetsFrom recovered at 0x0000000001bdd680 (size 0x000001c0).
func (*autoMinerComponent) scanAutoMinerTargetsFrom() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).stepIsObstructed recovered at 0x0000000001bdc020 (size 0x000002e0).
func (*autoMinerComponent) stepIsObstructed() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).tick recovered at 0x0000000001bd8e60 (size 0x00002580).
func (*autoMinerComponent) tick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).tickAutoEat recovered at 0x0000000001be06c0 (size 0x00000880).
func (*autoMinerComponent) tickAutoEat() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoMinerComponent).tickAutoMinerVerifyAndRetry recovered at 0x0000000001bdeb80 (size 0x00000ec0).
func (*autoMinerComponent) tickAutoMinerVerifyAndRetry() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoRocketComponent).tick recovered at 0x0000000001be4340 (size 0x00000180).
func (*autoRocketComponent) tick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoSellComponent).adoptMenu recovered at 0x0000000001be6b00 (size 0x00000300).
func (*autoSellComponent) adoptMenu() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoSellComponent).advance recovered at 0x0000000001be6e00 (size 0x000005a0).
func (*autoSellComponent) advance() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoSellComponent).arm recovered at 0x0000000001be4680 (size 0x000002a0).
func (*autoSellComponent) arm() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoSellComponent).collect recovered at 0x0000000001be5da0 (size 0x000005e0).
func (*autoSellComponent) collect() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoSellComponent).finishGather recovered at 0x0000000001be64e0 (size 0x000002a0).
func (*autoSellComponent) finishGather() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoSellComponent).handleContainerClose recovered at 0x0000000001be7aa0 (size 0x000001a0).
func (*autoSellComponent) handleContainerClose() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoSellComponent).handleManualEdit recovered at 0x0000000001be7c40 (size 0x00000120).
func (*autoSellComponent) handleManualEdit() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoSellComponent).nextStorage recovered at 0x0000000001be5800 (size 0x000003a0).
func (*autoSellComponent) nextStorage() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoSellComponent).ownsContainer recovered at 0x0000000001be7d60 (size 0x000000c0).
func (*autoSellComponent) ownsContainer() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoSellComponent).release recovered at 0x0000000001be7980 (size 0x00000120).
func (*autoSellComponent) release() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoSellComponent).request recovered at 0x0000000001be4c20 (size 0x00000a80).
func (*autoSellComponent) request() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoSellComponent).retire recovered at 0x0000000001be77a0 (size 0x000001e0).
func (*autoSellComponent) retire() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoSellComponent).submit recovered at 0x0000000001be7500 (size 0x000002a0).
func (*autoSellComponent) submit() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoSellComponent).tick recovered at 0x0000000001be4920 (size 0x00000300).
func (*autoSellComponent) tick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*autoTotemComponent).tick recovered at 0x0000000001be8500 (size 0x000000a0).
func (*autoTotemComponent) tick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*backtrackState).activeDeferContext recovered at 0x0000000001bb7080 (size 0x00000120).
func (*backtrackState) activeDeferContext() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*backtrackState).advanceWindow recovered at 0x0000000001bb6f40 (size 0x00000100).
func (*backtrackState) advanceWindow() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*backtrackState).applyDelay recovered at 0x0000000001bb6ac0 (size 0x00000140).
func (*backtrackState) applyDelay() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*backtrackState).applySnapshot recovered at 0x0000000001bb7a40 (size 0x000000c0).
func (*backtrackState) applySnapshot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*backtrackState).arm recovered at 0x0000000001bb6880 (size 0x00000200).
func (*backtrackState) arm() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*backtrackState).bufferedServerLen recovered at 0x0000000001bb6760 (size 0x000000e0).
func (*backtrackState) bufferedServerLen() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*backtrackState).canTryRangeAcquire recovered at 0x0000000001bb8480 (size 0x000000e0).
func (*backtrackState) canTryRangeAcquire() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*backtrackState).captureDeferredSnapshot recovered at 0x0000000001bb7660 (size 0x000003e0).
func (*backtrackState) captureDeferredSnapshot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*backtrackState).currentSnapshot recovered at 0x0000000001bb7320 (size 0x000001c0).
func (*backtrackState) currentSnapshot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*backtrackState).deferServerPacket recovered at 0x0000000001bb8560 (size 0x000004a0).
func (*backtrackState) deferServerPacket() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*backtrackState).delayNextRangeAcquire recovered at 0x0000000001bb83a0 (size 0x000000e0).
func (*backtrackState) delayNextRangeAcquire() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*backtrackState).expireWindowAndTakeBuffered recovered at 0x0000000001bb8ce0 (size 0x000001a0).
func (*backtrackState) expireWindowAndTakeBuffered() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*backtrackState).geometry recovered at 0x0000000001bb7b00 (size 0x000002a0).
func (*backtrackState) geometry() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*backtrackState).releaseReady recovered at 0x0000000001bb8a00 (size 0x000002a0).
func (*backtrackState) releaseReady() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*backtrackState).remaining recovered at 0x0000000001bb6660 (size 0x000000c0).
func (*backtrackState) remaining() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*backtrackState).removeDelayAndTakeBuffered recovered at 0x0000000001bb6dc0 (size 0x00000140).
func (*backtrackState) removeDelayAndTakeBuffered() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*backtrackState).serverDeferContext recovered at 0x0000000001bb71e0 (size 0x00000140).
func (*backtrackState) serverDeferContext() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*backtrackState).shouldKeepTrackingBuffered recovered at 0x0000000001bb8160 (size 0x00000200).
func (*backtrackState) shouldKeepTrackingBuffered() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*backtrackState).snapshotForWindow recovered at 0x0000000001bb74e0 (size 0x00000180).
func (*backtrackState) snapshotForWindow() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*backtrackState).takeBufferedLocked recovered at 0x0000000001bb6c40 (size 0x00000140).
func (*backtrackState) takeBufferedLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*backtrackState).targetRuntimeID recovered at 0x0000000001bb6560 (size 0x000000c0).
func (*backtrackState) targetRuntimeID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*backtrackState).tickTarget recovered at 0x0000000001bb7fe0 (size 0x000000e0).
func (*backtrackState) tickTarget() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*backtrackState).tickTargetLivePosition recovered at 0x0000000001bb80c0 (size 0x000000a0).
func (*backtrackState) tickTargetLivePosition() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*backtrackState).visibleSnapshot recovered at 0x0000000001bb7da0 (size 0x00000200).
func (*backtrackState) visibleSnapshot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*blockHit[bool]).BlockPos recovered at 0x0000000001c80480 (size 0x00000120).
func (*blockHit_bool_) BlockPos() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*blockHit[github.com/lunar-bedrock/lunar/lunar/player.autoMinerRuntimeBlockInfo]).BlockPos recovered at 0x0000000001c80340 (size 0x00000140).
func (*blockHit_github_com_lunar_bedrock_lunar_lunar_player_autoMinerRuntimeBlockInfo_) BlockPos() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*blockHit[github.com/lunar-bedrock/lunar/lunar/player.chunkFinderBlockInfo]).BlockPos recovered at 0x0000000001c800c0 (size 0x00000140).
func (*blockHit_github_com_lunar_bedrock_lunar_lunar_player_chunkFinderBlockInfo_) BlockPos() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*blockHit[string]).BlockPos recovered at 0x0000000001c80200 (size 0x00000140).
func (*blockHit_string_) BlockPos() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*blockTracerCandidateIndex).appendCandidate recovered at 0x0000000001bea8e0 (size 0x000002a0).
func (*blockTracerCandidateIndex) appendCandidate() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*blockTracerCandidateIndex).candidateAt recovered at 0x0000000001bea7e0 (size 0x00000100).
func (*blockTracerCandidateIndex) candidateAt() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*blockTracerCandidateIndex).remove recovered at 0x0000000001beaf40 (size 0x00000240).
func (*blockTracerCandidateIndex) remove() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*blockTracerCandidateIndex).set recovered at 0x0000000001beab80 (size 0x000003c0).
func (*blockTracerCandidateIndex) set() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*blockTracers).applyDoubleChestPostProcess recovered at 0x0000000001bf2680 (size 0x00000200).
func (*blockTracers) applyDoubleChestPostProcess() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*blockTracers).blockTracerCheckDimension recovered at 0x0000000001bf2ae0 (size 0x00000180).
func (*blockTracers) blockTracerCheckDimension() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*blockTracers).blockTracerScanTargets recovered at 0x0000000001bebce0 (size 0x000000a0).
func (*blockTracers) blockTracerScanTargets() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*blockTracers).blockTracerTargetNames recovered at 0x0000000001bebaa0 (size 0x00000240).
func (*blockTracers) blockTracerTargetNames() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*blockTracers).blockTracerTargetSets recovered at 0x0000000001beb9a0 (size 0x00000100).
func (*blockTracers) blockTracerTargetSets() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*blockTracers).blockTracerVersionSnapshot recovered at 0x0000000001bf3800 (size 0x00000080).
func (*blockTracers) blockTracerVersionSnapshot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*blockTracers).classifyBlockTracerChestAt recovered at 0x0000000001bf2880 (size 0x00000260).
func (*blockTracers) classifyBlockTracerChestAt() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*blockTracers).clearBlockTracerChunk recovered at 0x0000000001bf2c60 (size 0x000001e0).
func (*blockTracers) clearBlockTracerChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*blockTracers).drainBlockTracerRemovalsLocked recovered at 0x0000000001bf3340 (size 0x00000380).
func (*blockTracers) drainBlockTracerRemovalsLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*blockTracers).handleBlockUpdate recovered at 0x0000000001bf1bc0 (size 0x000007e0).
func (*blockTracers) handleBlockUpdate() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*blockTracers).handleLevelChunk recovered at 0x0000000001beff40 (size 0x00000aa0).
func (*blockTracers) handleLevelChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*blockTracers).handleSubChunk recovered at 0x0000000001bf0a40 (size 0x00001180).
func (*blockTracers) handleSubChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*blockTracers).removeAllBlockTracers recovered at 0x0000000001bf2e40 (size 0x00000500).
func (*blockTracers) removeAllBlockTracers() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*blockTracers).scanAllChunks recovered at 0x0000000001bef4e0 (size 0x00000a00).
func (*blockTracers) scanAllChunks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*blockTracers).updateBlockTracers recovered at 0x0000000001bebd80 (size 0x00003140).
func (*blockTracers) updateBlockTracers() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*bunnyHopComponent).apply recovered at 0x0000000001bf4320 (size 0x000002c0).
func (*bunnyHopComponent) apply() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*chunkFinderState).cleanupDue recovered at 0x0000000001bf4fc0 (size 0x00000100).
func (*chunkFinderState) cleanupDue() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*chunkFinderState).cleanupLoadedLocked recovered at 0x0000000001bf4c00 (size 0x000003c0).
func (*chunkFinderState) cleanupLoadedLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*chunkFinderState).flaggedCount recovered at 0x0000000001bf4720 (size 0x000000e0).
func (*chunkFinderState) flaggedCount() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*chunkFinderState).flaggedSnapshot recovered at 0x0000000001bf4840 (size 0x000000a0).
func (*chunkFinderState) flaggedSnapshot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*chunkFinderState).isFlagged recovered at 0x0000000001bf4600 (size 0x000000e0).
func (*chunkFinderState) isFlagged() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*chunkFinderState).pruneRecentAlertsLocked recovered at 0x0000000001bf49c0 (size 0x00000240).
func (*chunkFinderState) pruneRecentAlertsLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*chunkFinderState).recordScanComplete recovered at 0x0000000001bf45e0 (size 0x00000020).
func (*chunkFinderState) recordScanComplete() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*chunkFinderState).shouldNotifyLocked recovered at 0x0000000001bf48e0 (size 0x000000e0).
func (*chunkFinderState) shouldNotifyLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*chunkScanSweep).has recovered at 0x0000000001c805e0 (size 0x000000e0).
func (*chunkScanSweep) has() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*clicksState).cps recovered at 0x0000000001c55d40 (size 0x000000e0).
func (*clicksState) cps() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*clicksState).cpsLocked recovered at 0x0000000001c55e60 (size 0x000000a0).
func (*clicksState) cpsLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*clicksState).manualAttackCPS recovered at 0x0000000001c56260 (size 0x00000120).
func (*clicksState) manualAttackCPS() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*clicksState).record recovered at 0x0000000001c55a20 (size 0x00000320).
func (*clicksState) record() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*clicksState).registerManualAttack recovered at 0x0000000001c55f00 (size 0x00000320).
func (*clicksState) registerManualAttack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*clicksState).reset recovered at 0x0000000001c563c0 (size 0x000000c0).
func (*clicksState) reset() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*coalescingScan).request recovered at 0x0000000001c57f00 (size 0x00000140).
func (*coalescingScan) request() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*combatPacer).cpsDue recovered at 0x0000000001bfa160 (size 0x000000c0).
func (*combatPacer) cpsDue() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*combatPacer).due recovered at 0x0000000001bfa080 (size 0x000000e0).
func (*combatPacer) due() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*containerWindowArbiter).acceptedBy recovered at 0x0000000001bc0c80 (size 0x000000e0).
func (*containerWindowArbiter) acceptedBy() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*containerWindowArbiter).acquire recovered at 0x0000000001bc02c0 (size 0x00000320).
func (*containerWindowArbiter) acquire() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*containerWindowArbiter).busy recovered at 0x0000000001bc1020 (size 0x000000c0).
func (*containerWindowArbiter) busy() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*containerWindowArbiter).close recovered at 0x0000000001bc0b40 (size 0x00000100).
func (*containerWindowArbiter) close() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*containerWindowArbiter).handleOpen recovered at 0x0000000001bc08a0 (size 0x00000260).
func (*containerWindowArbiter) handleOpen() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*containerWindowArbiter).markOpenRequested recovered at 0x0000000001bc0620 (size 0x000000e0).
func (*containerWindowArbiter) markOpenRequested() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*containerWindowArbiter).preempt recovered at 0x0000000001bc0f00 (size 0x000000e0).
func (*containerWindowArbiter) preempt() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*containerWindowArbiter).release recovered at 0x0000000001bc0740 (size 0x00000120).
func (*containerWindowArbiter) release() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*containerWindowArbiter).withAccepted recovered at 0x0000000001bc0da0 (size 0x00000120).
func (*containerWindowArbiter) withAccepted() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*deathComponent).applyEntityAttributes recovered at 0x0000000001c4d040 (size 0x00000180).
func (*deathComponent) applyEntityAttributes() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*deathComponent).beginDeath recovered at 0x0000000001c4d1c0 (size 0x000000c0).
func (*deathComponent) beginDeath() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*deathComponent).handleActorEvent recovered at 0x0000000001c4ce60 (size 0x000001e0).
func (*deathComponent) handleActorEvent() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*deathComponent).handleHealthChange recovered at 0x0000000001c4d280 (size 0x000000c0).
func (*deathComponent) handleHealthChange() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*deathComponent).handleTrackedEntityDeath recovered at 0x0000000001c4d340 (size 0x00000120).
func (*deathComponent) handleTrackedEntityDeath() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*deathLightningComponent).handle recovered at 0x0000000001bfbba0 (size 0x000000a0).
func (*deathLightningComponent) handle() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*deathLightningComponent).play recovered at 0x0000000001bfb9c0 (size 0x000000a0).
func (*deathLightningComponent) play() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*deathLightningComponent).playSelfActorDeath recovered at 0x0000000001bfba60 (size 0x000000c0).
func (*deathLightningComponent) playSelfActorDeath() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*deathLightningComponent).playSelfHealthDeath recovered at 0x0000000001bfbb20 (size 0x00000080).
func (*deathLightningComponent) playSelfHealthDeath() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*deathPositionState).All recovered at 0x0000000001bfbf60 (size 0x000001a0).
func (*deathPositionState) All() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*deathPositionState).BeginCycle recovered at 0x0000000001bfbc40 (size 0x00000020).
func (*deathPositionState) BeginCycle() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*deathPositionState).EndCycle recovered at 0x0000000001bfbc60 (size 0x00000020).
func (*deathPositionState) EndCycle() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*deathPositionState).Record recovered at 0x0000000001bfbc80 (size 0x000002a0).
func (*deathPositionState) Record() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*deathPositionState).clear recovered at 0x0000000001bfc140 (size 0x00000060).
func (*deathPositionState) clear() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*debugDrawerRuntime).appendHoleESPShapes recovered at 0x0000000001c24ce0 (size 0x000003e0).
func (*debugDrawerRuntime) appendHoleESPShapes() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*debugDrawerRuntime).clearBlockTracerState recovered at 0x0000000001beb180 (size 0x00000220).
func (*debugDrawerRuntime) clearBlockTracerState() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*debugDrawerRuntime).queueRenderedBlockTracerRemovalsInChunkLocked recovered at 0x0000000001beb580 (size 0x000001c0).
func (*debugDrawerRuntime) queueRenderedBlockTracerRemovalsInChunkLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*debugDrawerRuntime).queueRenderedBlockTracerRemovalsInSubChunkLocked recovered at 0x0000000001beb3a0 (size 0x000001e0).
func (*debugDrawerRuntime) queueRenderedBlockTracerRemovalsInSubChunkLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*debugDrawerRuntime).updateChunkHighlights recovered at 0x0000000001c540e0 (size 0x000000e0).
func (*debugDrawerRuntime) updateChunkHighlights() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*debugDrawerState).ensureInitialized recovered at 0x0000000001bc1200 (size 0x00000060).
func (*debugDrawerState) ensureInitialized() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*debugDrawerState).ensureShapeIDLocked recovered at 0x0000000001bc16c0 (size 0x000000c0).
func (*debugDrawerState) ensureShapeIDLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*debugDrawerState).lockRuntime recovered at 0x0000000001bc1660 (size 0x00000060).
func (*debugDrawerState) lockRuntime() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*debugDrawerState).queueBlockTracerRenderRemovalLocked recovered at 0x0000000001bc1780 (size 0x00000180).
func (*debugDrawerState) queueBlockTracerRenderRemovalLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*debugDrawerState).runtimeLocked recovered at 0x0000000001bc1260 (size 0x00000400).
func (*debugDrawerState) runtimeLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*effectData).ID recovered at 0x0000000001c7fd60 (size 0x00000020).
func (*effectData) ID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*effectData).Marshal recovered at 0x0000000001c7fd80 (size 0x00000020).
func (*effectData) Marshal() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*effectTracker).Get recovered at 0x0000000001c555c0 (size 0x00000380).
func (*effectTracker) Get() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*effectTracker).Set recovered at 0x0000000001c55320 (size 0x00000260).
func (*effectTracker) Set() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*effectTracker).reset recovered at 0x0000000001c55980 (size 0x000000a0).
func (*effectTracker) reset() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*entityTracker).add recovered at 0x0000000001bc22a0 (size 0x000000a0).
func (*entityTracker) add() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*entityTracker).all recovered at 0x0000000001bc2080 (size 0x000001e0).
func (*entityTracker) all() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*entityTracker).get recovered at 0x0000000001bc2340 (size 0x000000c0).
func (*entityTracker) get() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*entityTracker).getByUniqueID recovered at 0x0000000001bc2400 (size 0x000001a0).
func (*entityTracker) getByUniqueID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*entityTracker).nearest recovered at 0x0000000001bc26e0 (size 0x000003e0).
func (*entityTracker) nearest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*entityTracker).remove recovered at 0x0000000001bc25e0 (size 0x00000100).
func (*entityTracker) remove() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*entityTracker).reset recovered at 0x0000000001bc2b00 (size 0x00000080).
func (*entityTracker) reset() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*fastInteractComponent).tick recovered at 0x0000000001bfdc40 (size 0x00000160).
func (*fastInteractComponent) tick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*formsState).register recovered at 0x0000000001c56480 (size 0x000001e0).
func (*formsState) register() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*formsState).reset recovered at 0x0000000001c56820 (size 0x000000a0).
func (*formsState) reset() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*formsState).take recovered at 0x0000000001c566a0 (size 0x00000140).
func (*formsState) take() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*friendAlertsComponent).handlePlayerList recovered at 0x0000000001bfe340 (size 0x000004a0).
func (*friendAlertsComponent) handlePlayerList() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*friendAlertsComponent).reset recovered at 0x0000000001bfee60 (size 0x000000a0).
func (*friendAlertsComponent) reset() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*friendAlertsComponent).tick recovered at 0x0000000001bfe820 (size 0x00000640).
func (*friendAlertsComponent) tick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*gameModeState).Override recovered at 0x0000000001c55200 (size 0x00000020).
func (*gameModeState) Override() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*gameModeState).Server recovered at 0x0000000001c55240 (size 0x00000020).
func (*gameModeState) Server() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*gameModeState).SetOverride recovered at 0x0000000001c55220 (size 0x00000020).
func (*gameModeState) SetOverride() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*gameModeState).StoreServer recovered at 0x0000000001c55260 (size 0x00000020).
func (*gameModeState) StoreServer() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*heldSlotArbiter).canTrackSelections recovered at 0x0000000001c23720 (size 0x000000a0).
func (*heldSlotArbiter) canTrackSelections() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*heldSlotArbiter).consumeSelection recovered at 0x0000000001c237c0 (size 0x00000220).
func (*heldSlotArbiter) consumeSelection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*heldSlotArbiter).expireSelections recovered at 0x0000000001c239e0 (size 0x00000300).
func (*heldSlotArbiter) expireSelections() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*heldSlotArbiter).rememberSelection recovered at 0x0000000001c234c0 (size 0x00000260).
func (*heldSlotArbiter) rememberSelection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*holeESPScan).blockAt recovered at 0x0000000001c00900 (size 0x00000260).
func (*holeESPScan) blockAt() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*holeESPScan).buildHeightGrid recovered at 0x0000000001c001a0 (size 0x00000200).
func (*holeESPScan) buildHeightGrid() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*holeESPState).applyScanBatchLocked recovered at 0x0000000001bff560 (size 0x00000540).
func (*holeESPState) applyScanBatchLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*holeESPState).beginSweep recovered at 0x0000000001bffce0 (size 0x000000c0).
func (*holeESPState) beginSweep() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*holeESPState).cleanupDue recovered at 0x0000000001bffbe0 (size 0x00000100).
func (*holeESPState) cleanupDue() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*holeESPState).markers recovered at 0x0000000001c24640 (size 0x000006a0).
func (*holeESPState) markers() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*holeESPState).reset recovered at 0x0000000001bffaa0 (size 0x00000100).
func (*holeESPState) reset() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*infiniteAuraComponent).combatTick recovered at 0x0000000001bface0 (size 0x00000460).
func (*infiniteAuraComponent) combatTick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*killAuraComponent).combatTick recovered at 0x0000000001bfb140 (size 0x00000280).
func (*killAuraComponent) combatTick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*killAuraComponent).serviceSingleTargetLock recovered at 0x0000000001bfb460 (size 0x000001e0).
func (*killAuraComponent) serviceSingleTargetLock() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*killAuraLockState).keep recovered at 0x0000000001c5f300 (size 0x00000120).
func (*killAuraLockState) keep() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*motionFlyState).apply recovered at 0x0000000001c03e20 (size 0x000005c0).
func (*motionFlyState) apply() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*newChunksState).cleanupLoadedLocked recovered at 0x0000000001c04900 (size 0x000003e0).
func (*newChunksState) cleanupLoadedLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*newChunksState).flaggedCount recovered at 0x0000000001c04420 (size 0x000000e0).
func (*newChunksState) flaggedCount() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*newChunksState).flaggedSnapshot recovered at 0x0000000001c04540 (size 0x000000a0).
func (*newChunksState) flaggedSnapshot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*newChunksState).pruneRecentAlertsLocked recovered at 0x0000000001c046c0 (size 0x00000240).
func (*newChunksState) pruneRecentAlertsLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*newChunksState).shouldNotifyLocked recovered at 0x0000000001c045e0 (size 0x000000e0).
func (*newChunksState) shouldNotifyLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*noFallComponent).apply recovered at 0x0000000001c069a0 (size 0x000002c0).
func (*noFallComponent) apply() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*placementUser).Position recovered at 0x0000000001c49d00 (size 0x000000a0).
func (*placementUser) Position() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*placementUser).Rotation recovered at 0x0000000001c49da0 (size 0x00000060).
func (*placementUser) Rotation() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*pvpBotComponent).combatTick recovered at 0x0000000001bfb640 (size 0x00000380).
func (*pvpBotComponent) combatTick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*scaffoldComponent).tick recovered at 0x0000000001c06c60 (size 0x00000600).
func (*scaffoldComponent) tick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*shulkerTooltipComponent).cache recovered at 0x0000000001c0b5e0 (size 0x00000100).
func (*shulkerTooltipComponent) cache() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*shulkerTooltipComponent).cacheResolved recovered at 0x0000000001c0b6e0 (size 0x00000280).
func (*shulkerTooltipComponent) cacheResolved() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*shulkerTooltipComponent).copy recovered at 0x0000000001c0ccc0 (size 0x00000440).
func (*shulkerTooltipComponent) copy() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*shulkerTooltipComponent).decorate recovered at 0x0000000001c085c0 (size 0x00000b00).
func (*shulkerTooltipComponent) decorate() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*shulkerTooltipComponent).decorated recovered at 0x0000000001c08540 (size 0x00000080).
func (*shulkerTooltipComponent) decorated() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*shulkerTooltipComponent).forget recovered at 0x0000000001c0caa0 (size 0x000001e0).
func (*shulkerTooltipComponent) forget() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*shulkerTooltipComponent).has recovered at 0x0000000001c0bac0 (size 0x000000c0).
func (*shulkerTooltipComponent) has() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*shulkerTooltipComponent).lines recovered at 0x0000000001c090c0 (size 0x00000840).
func (*shulkerTooltipComponent) lines() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*shulkerTooltipComponent).markerIDFromNBT recovered at 0x0000000001c0d420 (size 0x00000160).
func (*shulkerTooltipComponent) markerIDFromNBT() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*shulkerTooltipComponent).remember recovered at 0x0000000001c0bf40 (size 0x000002c0).
func (*shulkerTooltipComponent) remember() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*shulkerTooltipComponent).rememberLocked recovered at 0x0000000001c0c200 (size 0x00000460).
func (*shulkerTooltipComponent) rememberLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*shulkerTooltipComponent).reset recovered at 0x0000000001c0bea0 (size 0x000000a0).
func (*shulkerTooltipComponent) reset() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*shulkerTooltipComponent).signID recovered at 0x0000000001c0d580 (size 0x000000e0).
func (*shulkerTooltipComponent) signID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*shulkerTooltipComponent).stackIdentifier recovered at 0x0000000001c0b960 (size 0x00000160).
func (*shulkerTooltipComponent) stackIdentifier() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*shulkerTooltipComponent).strip recovered at 0x0000000001c09900 (size 0x00000380).
func (*shulkerTooltipComponent) strip() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*shulkerTooltipComponent).stripResult recovered at 0x0000000001c0a3a0 (size 0x000007a0).
func (*shulkerTooltipComponent) stripResult() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*shulkerTooltipComponent).stripResultRequestItem recovered at 0x0000000001c0ab40 (size 0x00000820).
func (*shulkerTooltipComponent) stripResultRequestItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*shulkerTooltipComponent).stripWithTrusted recovered at 0x0000000001c09c80 (size 0x00000720).
func (*shulkerTooltipComponent) stripWithTrusted() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*shulkerTooltipComponent).sync recovered at 0x0000000001c0d100 (size 0x000000c0).
func (*shulkerTooltipComponent) sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*shulkerTooltipComponent).syncWindow recovered at 0x0000000001c0d1c0 (size 0x00000260).
func (*shulkerTooltipComponent) syncWindow() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*shulkerTooltipComponent).trusted recovered at 0x0000000001c0bb80 (size 0x00000320).
func (*shulkerTooltipComponent) trusted() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*spamComponent).ensure recovered at 0x0000000001c0da80 (size 0x00000360).
func (*spamComponent) ensure() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*spamComponent).finish recovered at 0x0000000001c0e1e0 (size 0x000000e0).
func (*spamComponent) finish() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*spamComponent).stop recovered at 0x0000000001c0e100 (size 0x000000e0).
func (*spamComponent) stop() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*spamComponent).sync recovered at 0x0000000001c0d980 (size 0x00000100).
func (*spamComponent) sync() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*spawnerProtectComponent).advanceSalvage recovered at 0x0000000001c0f840 (size 0x00000180).
func (*spawnerProtectComponent) advanceSalvage() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*spawnerProtectComponent).applyBreakSneak recovered at 0x0000000001c0e360 (size 0x00000180).
func (*spawnerProtectComponent) applyBreakSneak() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*spawnerProtectComponent).armStorage recovered at 0x0000000001c0f9c0 (size 0x00000160).
func (*spawnerProtectComponent) armStorage() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*spawnerProtectComponent).cancelBreak recovered at 0x0000000001c0fb20 (size 0x00000060).
func (*spawnerProtectComponent) cancelBreak() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*spawnerProtectComponent).clickStorageTarget recovered at 0x0000000001c10c00 (size 0x000001c0).
func (*spawnerProtectComponent) clickStorageTarget() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*spawnerProtectComponent).giveUpStorage recovered at 0x0000000001c10f40 (size 0x00000060).
func (*spawnerProtectComponent) giveUpStorage() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*spawnerProtectComponent).openStorage recovered at 0x0000000001c10180 (size 0x00000200).
func (*spawnerProtectComponent) openStorage() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*spawnerProtectComponent).pollStorageResult recovered at 0x0000000001c10a60 (size 0x000001a0).
func (*spawnerProtectComponent) pollStorageResult() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*spawnerProtectComponent).prepareEnderChestOpen recovered at 0x0000000001c0f140 (size 0x00000220).
func (*spawnerProtectComponent) prepareEnderChestOpen() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*spawnerProtectComponent).releaseStorageWindow recovered at 0x0000000001c10fa0 (size 0x000000e0).
func (*spawnerProtectComponent) releaseStorageWindow() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*spawnerProtectComponent).reset recovered at 0x0000000001c0ffe0 (size 0x000000a0).
func (*spawnerProtectComponent) reset() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*spawnerProtectComponent).restoreEnderChestSneak recovered at 0x0000000001c0f560 (size 0x00000140).
func (*spawnerProtectComponent) restoreEnderChestSneak() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*spawnerProtectComponent).sendPreparedEnderChestOpen recovered at 0x0000000001c0f3a0 (size 0x00000180).
func (*spawnerProtectComponent) sendPreparedEnderChestOpen() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*spawnerProtectComponent).sendStorageClick recovered at 0x0000000001c10dc0 (size 0x00000140).
func (*spawnerProtectComponent) sendStorageClick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*spawnerProtectComponent).startNearbySpawnerBreak recovered at 0x0000000001c0fb80 (size 0x00000260).
func (*spawnerProtectComponent) startNearbySpawnerBreak() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*spawnerProtectComponent).storeInventorySpawners recovered at 0x0000000001c0ece0 (size 0x00000460).
func (*spawnerProtectComponent) storeInventorySpawners() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*spawnerProtectComponent).storeSpawner recovered at 0x0000000001c10380 (size 0x000004e0).
func (*spawnerProtectComponent) storeSpawner() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*spawnerProtectComponent).tick recovered at 0x0000000001c0e4e0 (size 0x000007c0).
func (*spawnerProtectComponent) tick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*stepComponent).apply recovered at 0x0000000001c111a0 (size 0x00000540).
func (*stepComponent) apply() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*tpAuraComponent).combatTick recovered at 0x0000000001bfa780 (size 0x000001c0).
func (*tpAuraComponent) combatTick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*triggerBotComponent).combatTick recovered at 0x0000000001bfa220 (size 0x000001c0).
func (*triggerBotComponent) combatTick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*weatherState).RainIntensity recovered at 0x0000000001c55280 (size 0x00000020).
func (*weatherState) RainIntensity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*weatherState).SetRainIntensity recovered at 0x0000000001c552a0 (size 0x00000020).
func (*weatherState) SetRainIntensity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*weatherState).SetThunderstormIntensity recovered at 0x0000000001c552e0 (size 0x00000020).
func (*weatherState) SetThunderstormIntensity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*weatherState).SwapCleared recovered at 0x0000000001c55300 (size 0x00000020).
func (*weatherState) SwapCleared() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*weatherState).ThunderstormIntensity recovered at 0x0000000001c552c0 (size 0x00000020).
func (*weatherState) ThunderstormIntensity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).abandonApply recovered at 0x0000000001c14280 (size 0x000000e0).
func (*xray) abandonApply() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).beginDrivenBreak recovered at 0x0000000001c1e8e0 (size 0x00000320).
func (*xray) beginDrivenBreak() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).blockRepresentation recovered at 0x0000000001c17cc0 (size 0x00000240).
func (*xray) blockRepresentation() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).breakCenterFor recovered at 0x0000000001c1b8a0 (size 0x00000260).
func (*xray) breakCenterFor() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).chunkTransformed recovered at 0x0000000001c13700 (size 0x000000e0).
func (*xray) chunkTransformed() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).chunkViewState recovered at 0x0000000001c13d80 (size 0x000001e0).
func (*xray) chunkViewState() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).clearTransformedChunks recovered at 0x0000000001c13820 (size 0x000000a0).
func (*xray) clearTransformedChunks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).disable recovered at 0x0000000001c1ab20 (size 0x000001c0).
func (*xray) disable() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).enable recovered at 0x0000000001c19520 (size 0x00000700).
func (*xray) enable() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).encodeXrayChunk recovered at 0x0000000001c1b5c0 (size 0x000002e0).
func (*xray) encodeXrayChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).enqueueReapply recovered at 0x0000000001c18540 (size 0x00000340).
func (*xray) enqueueReapply() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).fallingBlockClientRuntimeID recovered at 0x0000000001c1c3c0 (size 0x000002a0).
func (*xray) fallingBlockClientRuntimeID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).fallingBlockClientVariant recovered at 0x0000000001c15d80 (size 0x00000120).
func (*xray) fallingBlockClientVariant() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).filtersForTransformedChunk recovered at 0x0000000001c13c80 (size 0x00000100).
func (*xray) filtersForTransformedChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).finishApplyScan recovered at 0x0000000001c14760 (size 0x000001e0).
func (*xray) finishApplyScan() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).forgetAuthenticUpdate recovered at 0x0000000001c140c0 (size 0x00000100).
func (*xray) forgetAuthenticUpdate() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).forgetTransformedChunk recovered at 0x0000000001c13be0 (size 0x000000a0).
func (*xray) forgetTransformedChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).handleBlockAction recovered at 0x0000000001c1e860 (size 0x00000080).
func (*xray) handleBlockAction() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).handleSubChunkRequest recovered at 0x0000000001c1ec60 (size 0x00000f80).
func (*xray) handleSubChunkRequest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).handleWorldBlockUpdate recovered at 0x0000000001c153e0 (size 0x000004c0).
func (*xray) handleWorldBlockUpdate() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).markChunkRestored recovered at 0x0000000001c134a0 (size 0x00000220).
func (*xray) markChunkRestored() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).markChunkTransformed recovered at 0x0000000001c13220 (size 0x00000240).
func (*xray) markChunkTransformed() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).noteAuthenticUpdate recovered at 0x0000000001c13fa0 (size 0x00000120).
func (*xray) noteAuthenticUpdate() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).noteChunkApplied recovered at 0x0000000001c14980 (size 0x000001a0).
func (*xray) noteChunkApplied() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).processChunkAt recovered at 0x0000000001c1d8c0 (size 0x00000900).
func (*xray) processChunkAt() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).reapplyChunk recovered at 0x0000000001c190a0 (size 0x00000400).
func (*xray) reapplyChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).reapplySnapshot recovered at 0x0000000001c18ee0 (size 0x00000180).
func (*xray) reapplySnapshot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).refreshFallingBlockAfterMove recovered at 0x0000000001c16340 (size 0x000001c0).
func (*xray) refreshFallingBlockAfterMove() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).refreshFallingBlocksInChunk recovered at 0x0000000001c1c120 (size 0x00000100).
func (*xray) refreshFallingBlocksInChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).remainingRequiredChunks recovered at 0x0000000001c14500 (size 0x00000220).
func (*xray) remainingRequiredChunks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).requiredChunk recovered at 0x0000000001c143a0 (size 0x00000120).
func (*xray) requiredChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).restoreRemainingXrayChunks recovered at 0x0000000001c1b4a0 (size 0x00000120).
func (*xray) restoreRemainingXrayChunks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).runReapplyWorker recovered at 0x0000000001c18900 (size 0x000003a0).
func (*xray) runReapplyWorker() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).sendChunkPublisherUpdate recovered at 0x0000000001c12f00 (size 0x00000200).
func (*xray) sendChunkPublisherUpdate() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).sendFallingBlockVariant recovered at 0x0000000001c15b80 (size 0x00000080).
func (*xray) sendFallingBlockVariant() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).sendRestoredChunk recovered at 0x0000000001c1bea0 (size 0x00000240).
func (*xray) sendRestoredChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).sendXrayBlockUpdateOverlays recovered at 0x0000000001c1c940 (size 0x000005c0).
func (*xray) sendXrayBlockUpdateOverlays() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).sendXrayChunk recovered at 0x0000000001c1bb40 (size 0x00000320).
func (*xray) sendXrayChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).settingsApplied recovered at 0x0000000001c14bc0 (size 0x00000060).
func (*xray) settingsApplied() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).settingsMatch recovered at 0x0000000001c14cc0 (size 0x000002e0).
func (*xray) settingsMatch() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).settingsPending recovered at 0x0000000001c14c60 (size 0x00000060).
func (*xray) settingsPending() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).shouldMaskFallingBlock recovered at 0x0000000001c16540 (size 0x000000e0).
func (*xray) shouldMaskFallingBlock() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).shouldMaskFallingBlockAt recovered at 0x0000000001c15ee0 (size 0x00000460).
func (*xray) shouldMaskFallingBlockAt() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).shouldSuppressContainerOpen recovered at 0x0000000001c15020 (size 0x00000220).
func (*xray) shouldSuppressContainerOpen() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).subChunkBlockEntities recovered at 0x0000000001c1fea0 (size 0x000004e0).
func (*xray) subChunkBlockEntities() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).tick recovered at 0x0000000001c16900 (size 0x00000980).
func (*xray) tick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).transformChunkForRequest recovered at 0x0000000001c1fc20 (size 0x00000280).
func (*xray) transformChunkForRequest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).unrestoredTransformedChunks recovered at 0x0000000001c138c0 (size 0x000002e0).
func (*xray) unrestoredTransformedChunks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).viewLocked recovered at 0x0000000001c13140 (size 0x000000e0).
func (*xray) viewLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).xrayChunkBlockEntityStubs recovered at 0x0000000001c1cf00 (size 0x00000980).
func (*xray) xrayChunkBlockEntityStubs() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).xrayChunkBlockUpdateOverlays recovered at 0x0000000001c1c660 (size 0x000000e0).
func (*xray) xrayChunkBlockUpdateOverlays() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(*xray).xrayOperationActive recovered at 0x0000000001c141c0 (size 0x000000c0).
func (*xray) xrayOperationActive() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(blockHit).BlockPos recovered at 0x0000000001c69120 (size 0x00000100).
func (blockHit) BlockPos() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(blockScanTargets).paletteMatches recovered at 0x0000000001c645a0 (size 0x00000140).
func (blockScanTargets) paletteMatches() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(blockScanTargets).value recovered at 0x0000000001c646e0 (size 0x00000120).
func (blockScanTargets) value() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(chunkScanner).handleBlockUpdates recovered at 0x0000000001c655a0 (size 0x00000340).
func (chunkScanner) handleBlockUpdates() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(chunkScanner).handleLevelChunk recovered at 0x0000000001c65c60 (size 0x000001a0).
func (chunkScanner) handleLevelChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(chunkScanner).handleSubChunk recovered at 0x0000000001c658e0 (size 0x00000380).
func (chunkScanner) handleSubChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(chunkScanner).markArrival recovered at 0x0000000001c66120 (size 0x00000380).
func (chunkScanner) markArrival() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(chunkScanner).markBlockUpdate recovered at 0x0000000001c65e00 (size 0x00000320).
func (chunkScanner) markBlockUpdate() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(chunkScanner).rescan recovered at 0x0000000001c653e0 (size 0x00000140).
func (chunkScanner) rescan() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(chunkScanner).runDirty recovered at 0x0000000001c64800 (size 0x00000400).
func (chunkScanner) runDirty() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player.(chunkScanner).scanAllChunks recovered at 0x0000000001c64c00 (size 0x000007a0).
func (chunkScanner) scanAllChunks() {
	panic("stub")
}
