// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package component

// Placeholder receiver types (no equality descriptor in pclntab).

type WorldUpdaterComponent struct{}

type inventoryPlayerHost struct{}

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// Register recovered at 0x0000000001d0d880 (size 0x00000100).
func Register() {
	panic("stub")
}

// clearSubChunkBlockEntityData recovered at 0x0000000001d10080 (size 0x00000180).
func clearSubChunkBlockEntityData() {
	panic("stub")
}

// init recovered at 0x0000000001d0d520 (size 0x00000040).
func init() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*WorldUpdaterComponent).AddPendingUpdate recovered at 0x0000000001d0ff40 (size 0x00000040).
func (*WorldUpdaterComponent) AddPendingUpdate() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*WorldUpdaterComponent).AttemptItemInteractionWithBlock recovered at 0x0000000001d0fd00 (size 0x00000040).
func (*WorldUpdaterComponent) AttemptItemInteractionWithBlock() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*WorldUpdaterComponent).BlockBreakPos recovered at 0x0000000001d0fec0 (size 0x00000040).
func (*WorldUpdaterComponent) BlockBreakPos() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*WorldUpdaterComponent).ChunkRadius recovered at 0x0000000001d0fda0 (size 0x000000c0).
func (*WorldUpdaterComponent) ChunkRadius() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*WorldUpdaterComponent).Flush recovered at 0x0000000001d10040 (size 0x00000040).
func (*WorldUpdaterComponent) Flush() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*WorldUpdaterComponent).HandleLevelChunk recovered at 0x0000000001d0f5e0 (size 0x00000460).
func (*WorldUpdaterComponent) HandleLevelChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*WorldUpdaterComponent).HandleSubChunk recovered at 0x0000000001d0dc20 (size 0x00001740).
func (*WorldUpdaterComponent) HandleSubChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*WorldUpdaterComponent).HandleUpdateBlock recovered at 0x0000000001d0d980 (size 0x000000e0).
func (*WorldUpdaterComponent) HandleUpdateBlock() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*WorldUpdaterComponent).HandleUpdateSubChunkBlocks recovered at 0x0000000001d0fa40 (size 0x000002c0).
func (*WorldUpdaterComponent) HandleUpdateSubChunkBlocks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*WorldUpdaterComponent).HasPendingUpdate recovered at 0x0000000001d0ff80 (size 0x00000040).
func (*WorldUpdaterComponent) HasPendingUpdate() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*WorldUpdaterComponent).QueueBlockPlacement recovered at 0x0000000001d0ff00 (size 0x00000040).
func (*WorldUpdaterComponent) QueueBlockPlacement() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*WorldUpdaterComponent).RemovePendingUpdate recovered at 0x0000000001d0ffc0 (size 0x00000040).
func (*WorldUpdaterComponent) RemovePendingUpdate() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*WorldUpdaterComponent).SetBlockBreakPos recovered at 0x0000000001d0fe80 (size 0x00000040).
func (*WorldUpdaterComponent) SetBlockBreakPos() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*WorldUpdaterComponent).SetServerChunkRadius recovered at 0x0000000001d0fd80 (size 0x00000020).
func (*WorldUpdaterComponent) SetServerChunkRadius() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*WorldUpdaterComponent).Tick recovered at 0x0000000001d10000 (size 0x00000040).
func (*WorldUpdaterComponent) Tick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*WorldUpdaterComponent).UsesSubChunkRequests recovered at 0x0000000001d0fe60 (size 0x00000020).
func (*WorldUpdaterComponent) UsesSubChunkRequests() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*WorldUpdaterComponent).ValidateInteraction recovered at 0x0000000001d0fd40 (size 0x00000040).
func (*WorldUpdaterComponent) ValidateInteraction() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*WorldUpdaterComponent).applyChunkMutation recovered at 0x0000000001d0da60 (size 0x00000080).
func (*WorldUpdaterComponent) applyChunkMutation() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*WorldUpdaterComponent).debugAppliedLevelChunk recovered at 0x0000000001d10c80 (size 0x00000340).
func (*WorldUpdaterComponent) debugAppliedLevelChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*WorldUpdaterComponent).debugAppliedSubChunk recovered at 0x0000000001d106a0 (size 0x000003e0).
func (*WorldUpdaterComponent) debugAppliedSubChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*WorldUpdaterComponent).debugAppliedUpdateBlock recovered at 0x0000000001d103a0 (size 0x00000300).
func (*WorldUpdaterComponent) debugAppliedUpdateBlock() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*WorldUpdaterComponent).debugAppliedUpdateSubChunkBlocks recovered at 0x0000000001d10fc0 (size 0x00000420).
func (*WorldUpdaterComponent) debugAppliedUpdateSubChunkBlocks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*WorldUpdaterComponent).debugIgnoredLevelChunkRequestMode recovered at 0x0000000001d10a80 (size 0x00000200).
func (*WorldUpdaterComponent) debugIgnoredLevelChunkRequestMode() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*WorldUpdaterComponent).debugIgnoredUpdateBlockLayer recovered at 0x0000000001d10200 (size 0x000001a0).
func (*WorldUpdaterComponent) debugIgnoredUpdateBlockLayer() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*WorldUpdaterComponent).trackDimension recovered at 0x0000000001d0dae0 (size 0x00000140).
func (*WorldUpdaterComponent) trackDimension() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).AbilityData recovered at 0x0000000001d113e0 (size 0x000000c0).
func (*inventoryPlayerHost) AbilityData() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Absorption recovered at 0x0000000001d11560 (size 0x00000020).
func (*inventoryPlayerHost) Absorption() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).AcquireHeldSlot recovered at 0x0000000001d115a0 (size 0x00000060).
func (*inventoryPlayerHost) AcquireHeldSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).AcquireHeldSlotFullLeaseForTest recovered at 0x0000000001d11620 (size 0x00000040).
func (*inventoryPlayerHost) AcquireHeldSlotFullLeaseForTest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).AcquireHeldSlotGuard recovered at 0x0000000001d116a0 (size 0x00000040).
func (*inventoryPlayerHost) AcquireHeldSlotGuard() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).AcquireHeldSlotGuardForTest recovered at 0x0000000001d11700 (size 0x00000040).
func (*inventoryPlayerHost) AcquireHeldSlotGuardForTest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).AddEffect recovered at 0x0000000001d11780 (size 0x00000060).
func (*inventoryPlayerHost) AddEffect() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).AddEntity recovered at 0x0000000001d11800 (size 0x00000060).
func (*inventoryPlayerHost) AddEntity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).AddNukeBlocks recovered at 0x0000000001d118c0 (size 0x00000060).
func (*inventoryPlayerHost) AddNukeBlocks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).AddToPlayerList recovered at 0x0000000001d11940 (size 0x00000060).
func (*inventoryPlayerHost) AddToPlayerList() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).AimAssistActive recovered at 0x0000000001d119c0 (size 0x00000020).
func (*inventoryPlayerHost) AimAssistActive() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).AlignClientActionHeldSlot recovered at 0x0000000001d11a00 (size 0x00000040).
func (*inventoryPlayerHost) AlignClientActionHeldSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).AllModules recovered at 0x0000000001d11a60 (size 0x00000060).
func (*inventoryPlayerHost) AllModules() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).AnimateUseItem recovered at 0x0000000001d11b20 (size 0x00000080).
func (*inventoryPlayerHost) AnimateUseItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ApplyAndReport recovered at 0x0000000001d11c20 (size 0x000000c0).
func (*inventoryPlayerHost) ApplyAndReport() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ApplyAntiCrystalInventoryTransaction recovered at 0x0000000001d11d80 (size 0x00000040).
func (*inventoryPlayerHost) ApplyAntiCrystalInventoryTransaction() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ApplyAntiCrystalMovePlayer recovered at 0x0000000001d11de0 (size 0x00000040).
func (*inventoryPlayerHost) ApplyAntiCrystalMovePlayer() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ApplyAttributesPacket recovered at 0x0000000001d11e40 (size 0x00000060).
func (*inventoryPlayerHost) ApplyAttributesPacket() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ApplyAutoMiner recovered at 0x0000000001d11ec0 (size 0x00000060).
func (*inventoryPlayerHost) ApplyAutoMiner() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ApplyBacktrackDelay recovered at 0x0000000001d11f80 (size 0x00000040).
func (*inventoryPlayerHost) ApplyBacktrackDelay() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ApplyClearWeatherToggle recovered at 0x0000000001d11fe0 (size 0x00000040).
func (*inventoryPlayerHost) ApplyClearWeatherToggle() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ApplyConfig recovered at 0x0000000001d12040 (size 0x000001a0).
func (*inventoryPlayerHost) ApplyConfig() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ApplyEffects recovered at 0x0000000001d122a0 (size 0x00000040).
func (*inventoryPlayerHost) ApplyEffects() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ApplyEntityAttributes recovered at 0x0000000001d12300 (size 0x00000060).
func (*inventoryPlayerHost) ApplyEntityAttributes() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ApplyGhostSettings recovered at 0x0000000001d12380 (size 0x00000060).
func (*inventoryPlayerHost) ApplyGhostSettings() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ApplyNoInvisibleEntities recovered at 0x0000000001d12400 (size 0x00000040).
func (*inventoryPlayerHost) ApplyNoInvisibleEntities() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ApplyStatChangerRemoveObjective recovered at 0x0000000001d12460 (size 0x00000040).
func (*inventoryPlayerHost) ApplyStatChangerRemoveObjective() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ApplyStatChangerSetDisplayObjective recovered at 0x0000000001d124c0 (size 0x00000040).
func (*inventoryPlayerHost) ApplyStatChangerSetDisplayObjective() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ApplyStatChangerSetScore recovered at 0x0000000001d12520 (size 0x00000040).
func (*inventoryPlayerHost) ApplyStatChangerSetScore() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ApplyToggles recovered at 0x0000000001d12580 (size 0x00000040).
func (*inventoryPlayerHost) ApplyToggles() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ArmBacktrackTarget recovered at 0x0000000001d125e0 (size 0x00000040).
func (*inventoryPlayerHost) ArmBacktrackTarget() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).AttachLeash recovered at 0x0000000001d12640 (size 0x00000040).
func (*inventoryPlayerHost) AttachLeash() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).AttackEntity recovered at 0x0000000001d126a0 (size 0x00000060).
func (*inventoryPlayerHost) AttackEntity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).AttackedEntityTick recovered at 0x0000000001d12720 (size 0x00000020).
func (*inventoryPlayerHost) AttackedEntityTick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).AutoSellOwnsContainer recovered at 0x0000000001d12760 (size 0x00000040).
func (*inventoryPlayerHost) AutoSellOwnsContainer() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).AutoSwitchAfterAttack recovered at 0x0000000001d12800 (size 0x00000040).
func (*inventoryPlayerHost) AutoSwitchAfterAttack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).AutoToolSwapForBlock recovered at 0x0000000001d12860 (size 0x00000040).
func (*inventoryPlayerHost) AutoToolSwapForBlock() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).AutomationPaused recovered at 0x0000000001d128c0 (size 0x00000020).
func (*inventoryPlayerHost) AutomationPaused() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).BBox recovered at 0x0000000001d12900 (size 0x00000080).
func (*inventoryPlayerHost) BBox() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).BacktrackBufferedServerLen recovered at 0x0000000001d12a00 (size 0x00000040).
func (*inventoryPlayerHost) BacktrackBufferedServerLen() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).BacktrackRemainingDelay recovered at 0x0000000001d12a80 (size 0x00000040).
func (*inventoryPlayerHost) BacktrackRemainingDelay() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).BacktrackTargetRuntimeID recovered at 0x0000000001d12b00 (size 0x00000040).
func (*inventoryPlayerHost) BacktrackTargetRuntimeID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).BlockAt recovered at 0x0000000001d0d7c0 (size 0x000000a0).
func (*inventoryPlayerHost) BlockAt() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).BlockTracerHandleLevelChunk recovered at 0x0000000001d12be0 (size 0x00000060).
func (*inventoryPlayerHost) BlockTracerHandleLevelChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).BlockTracerHandleSubChunk recovered at 0x0000000001d12ca0 (size 0x00000060).
func (*inventoryPlayerHost) BlockTracerHandleSubChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).BlockTracerRescan recovered at 0x0000000001d12d60 (size 0x00000040).
func (*inventoryPlayerHost) BlockTracerRescan() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Blocking recovered at 0x0000000001d12dc0 (size 0x00000020).
func (*inventoryPlayerHost) Blocking() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).BufferedAttackPacketCount recovered at 0x0000000001d12e00 (size 0x00000040).
func (*inventoryPlayerHost) BufferedAttackPacketCount() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).BuildClientAbilityData recovered at 0x0000000001d12e60 (size 0x00000160).
func (*inventoryPlayerHost) BuildClientAbilityData() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).CPS recovered at 0x0000000001d13040 (size 0x00000040).
func (*inventoryPlayerHost) CPS() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).CacheResolvedShulkerTooltipStack recovered at 0x0000000001d130c0 (size 0x000000c0).
func (*inventoryPlayerHost) CacheResolvedShulkerTooltipStack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).CacheShulkerTooltipStack recovered at 0x0000000001d13240 (size 0x00000080).
func (*inventoryPlayerHost) CacheShulkerTooltipStack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).CanUseModule recovered at 0x0000000001d13340 (size 0x00000060).
func (*inventoryPlayerHost) CanUseModule() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ChatSilenced recovered at 0x0000000001d13400 (size 0x00000020).
func (*inventoryPlayerHost) ChatSilenced() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ChunkFinderClear recovered at 0x0000000001d13440 (size 0x00000040).
func (*inventoryPlayerHost) ChunkFinderClear() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ChunkFinderCompletedScans recovered at 0x0000000001d134a0 (size 0x00000020).
func (*inventoryPlayerHost) ChunkFinderCompletedScans() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ChunkFinderFlaggedCount recovered at 0x0000000001d134e0 (size 0x00000040).
func (*inventoryPlayerHost) ChunkFinderFlaggedCount() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ChunkFinderHandleLevelChunk recovered at 0x0000000001d13560 (size 0x00000040).
func (*inventoryPlayerHost) ChunkFinderHandleLevelChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ChunkFinderHandleSubChunk recovered at 0x0000000001d135c0 (size 0x00000040).
func (*inventoryPlayerHost) ChunkFinderHandleSubChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ChunkFinderRescan recovered at 0x0000000001d13620 (size 0x00000040).
func (*inventoryPlayerHost) ChunkFinderRescan() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ChunksByRing recovered at 0x0000000001d13680 (size 0x00000080).
func (*inventoryPlayerHost) ChunksByRing() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ChunksClosest recovered at 0x0000000001d13e40 (size 0x00000040).
func (*inventoryPlayerHost) ChunksClosest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ClearAFKClickerSwing recovered at 0x0000000001d13ea0 (size 0x00000020).
func (*inventoryPlayerHost) ClearAFKClickerSwing() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ClearBlockBreakQueueOwnedBy recovered at 0x0000000001d13ee0 (size 0x00000040).
func (*inventoryPlayerHost) ClearBlockBreakQueueOwnedBy() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ClearClientEatingState recovered at 0x0000000001d13f40 (size 0x00000040).
func (*inventoryPlayerHost) ClearClientEatingState() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ClearCombatTargetIfRuntimeID recovered at 0x0000000001d13fc0 (size 0x00000040).
func (*inventoryPlayerHost) ClearCombatTargetIfRuntimeID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ClearDeathPositions recovered at 0x0000000001d14020 (size 0x00000040).
func (*inventoryPlayerHost) ClearDeathPositions() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ClearPlayerGameMode recovered at 0x0000000001d140a0 (size 0x00000040).
func (*inventoryPlayerHost) ClearPlayerGameMode() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ClearStatChangerOverrides recovered at 0x0000000001d14100 (size 0x00000040).
func (*inventoryPlayerHost) ClearStatChangerOverrides() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ClickBlock recovered at 0x0000000001d14160 (size 0x00000080).
func (*inventoryPlayerHost) ClickBlock() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ClickTickerRunning recovered at 0x0000000001d14260 (size 0x00000020).
func (*inventoryPlayerHost) ClickTickerRunning() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ClickUI recovered at 0x0000000001d142a0 (size 0x000000c0).
func (*inventoryPlayerHost) ClickUI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ClickUIStyle recovered at 0x0000000001d14420 (size 0x00000040).
func (*inventoryPlayerHost) ClickUIStyle() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ClientMoving recovered at 0x0000000001d14480 (size 0x00000020).
func (*inventoryPlayerHost) ClientMoving() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ClientTick recovered at 0x0000000001d144c0 (size 0x00000020).
func (*inventoryPlayerHost) ClientTick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ClientUUID recovered at 0x0000000001d14500 (size 0x00000060).
func (*inventoryPlayerHost) ClientUUID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Close recovered at 0x0000000001d145c0 (size 0x00000040).
func (*inventoryPlayerHost) Close() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).CloseForm recovered at 0x0000000001d14620 (size 0x00000060).
func (*inventoryPlayerHost) CloseForm() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).CombatTarget recovered at 0x0000000001d146e0 (size 0x00000040).
func (*inventoryPlayerHost) CombatTarget() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).CommandsHidden recovered at 0x0000000001d14740 (size 0x00000040).
func (*inventoryPlayerHost) CommandsHidden() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ConfigSaveAllowed recovered at 0x0000000001d147c0 (size 0x00000060).
func (*inventoryPlayerHost) ConfigSaveAllowed() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Configs recovered at 0x0000000001d14840 (size 0x00000040).
func (*inventoryPlayerHost) Configs() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Conn recovered at 0x0000000001d148c0 (size 0x00000020).
func (*inventoryPlayerHost) Conn() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Context recovered at 0x0000000001d14900 (size 0x00000040).
func (*inventoryPlayerHost) Context() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).CopyShulkerTooltipStack recovered at 0x0000000001d14980 (size 0x000000a0).
func (*inventoryPlayerHost) CopyShulkerTooltipStack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Crawling recovered at 0x0000000001d14ac0 (size 0x00000020).
func (*inventoryPlayerHost) Crawling() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).CreativeItem recovered at 0x0000000001d0d640 (size 0x00000120).
func (*inventoryPlayerHost) CreativeItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).CustomBlockDefinitions recovered at 0x0000000001d14c40 (size 0x00000100).
func (*inventoryPlayerHost) CustomBlockDefinitions() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).CustomBlockRuntimeID recovered at 0x0000000001d14e40 (size 0x00000060).
func (*inventoryPlayerHost) CustomBlockRuntimeID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).DeactivateAimAssist recovered at 0x0000000001d14ec0 (size 0x00000040).
func (*inventoryPlayerHost) DeactivateAimAssist() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Dead recovered at 0x0000000001d14f40 (size 0x00000020).
func (*inventoryPlayerHost) Dead() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).DeathPositions recovered at 0x0000000001d14f80 (size 0x00000040).
func (*inventoryPlayerHost) DeathPositions() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).DebugShapesTickerRunning recovered at 0x0000000001d15000 (size 0x00000020).
func (*inventoryPlayerHost) DebugShapesTickerRunning() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).DecorateShulkerTooltip recovered at 0x0000000001d15040 (size 0x00000140).
func (*inventoryPlayerHost) DecorateShulkerTooltip() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).DeferServerBacktrackPacket recovered at 0x0000000001d152c0 (size 0x00000080).
func (*inventoryPlayerHost) DeferServerBacktrackPacket() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).DirectionVector recovered at 0x0000000001d15360 (size 0x00000060).
func (*inventoryPlayerHost) DirectionVector() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).DisableModule recovered at 0x0000000001d15420 (size 0x00000060).
func (*inventoryPlayerHost) DisableModule() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).DisableSpeed recovered at 0x0000000001d154a0 (size 0x00000040).
func (*inventoryPlayerHost) DisableSpeed() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).DisableTimer recovered at 0x0000000001d15500 (size 0x00000040).
func (*inventoryPlayerHost) DisableTimer() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).DisableUnavailableModules recovered at 0x0000000001d15560 (size 0x00000040).
func (*inventoryPlayerHost) DisableUnavailableModules() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).DisableXray recovered at 0x0000000001d155c0 (size 0x00000040).
func (*inventoryPlayerHost) DisableXray() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Disconnect recovered at 0x0000000001d15640 (size 0x000000a0).
func (*inventoryPlayerHost) Disconnect() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).DistanceFrom recovered at 0x0000000001d15780 (size 0x00000040).
func (*inventoryPlayerHost) DistanceFrom() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).DoEmote recovered at 0x0000000001d157e0 (size 0x00000060).
func (*inventoryPlayerHost) DoEmote() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).DoubleClickExtraCount recovered at 0x0000000001d15860 (size 0x00000040).
func (*inventoryPlayerHost) DoubleClickExtraCount() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).EffectiveClientActionHeldSlot recovered at 0x0000000001d158c0 (size 0x00000040).
func (*inventoryPlayerHost) EffectiveClientActionHeldSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Eject recovered at 0x0000000001d15920 (size 0x00000040).
func (*inventoryPlayerHost) Eject() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Emotes recovered at 0x0000000001d15980 (size 0x00000020).
func (*inventoryPlayerHost) Emotes() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).EnableFreeCam recovered at 0x0000000001d159c0 (size 0x00000040).
func (*inventoryPlayerHost) EnableFreeCam() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).EnableModule recovered at 0x0000000001d15a20 (size 0x00000060).
func (*inventoryPlayerHost) EnableModule() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).EnableXray recovered at 0x0000000001d15aa0 (size 0x00000040).
func (*inventoryPlayerHost) EnableXray() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).EnableXrayForChunks recovered at 0x0000000001d15b20 (size 0x00000060).
func (*inventoryPlayerHost) EnableXrayForChunks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).EnsureCameraPresetsSent recovered at 0x0000000001d15ba0 (size 0x00000040).
func (*inventoryPlayerHost) EnsureCameraPresetsSent() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).EnsureModuleRuntimeDeps recovered at 0x0000000001d15c00 (size 0x00000040).
func (*inventoryPlayerHost) EnsureModuleRuntimeDeps() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Entities recovered at 0x0000000001d15c60 (size 0x00000040).
func (*inventoryPlayerHost) Entities() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).EquipTotem recovered at 0x0000000001d15ce0 (size 0x00000040).
func (*inventoryPlayerHost) EquipTotem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ExecuteCommand recovered at 0x0000000001d15d40 (size 0x00000060).
func (*inventoryPlayerHost) ExecuteCommand() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Exhaustion recovered at 0x0000000001d15dc0 (size 0x00000020).
func (*inventoryPlayerHost) Exhaustion() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ExperienceLevel recovered at 0x0000000001d15e00 (size 0x00000020).
func (*inventoryPlayerHost) ExperienceLevel() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ExperienceProgress recovered at 0x0000000001d15e40 (size 0x00000020).
func (*inventoryPlayerHost) ExperienceProgress() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).EyeHeight recovered at 0x0000000001d15e80 (size 0x00000040).
func (*inventoryPlayerHost) EyeHeight() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).EyePosition recovered at 0x0000000001d15ee0 (size 0x00000080).
func (*inventoryPlayerHost) EyePosition() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).EyePosition32 recovered at 0x0000000001d15f80 (size 0x00000060).
func (*inventoryPlayerHost) EyePosition32() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).FallDistance recovered at 0x0000000001d16000 (size 0x00000020).
func (*inventoryPlayerHost) FallDistance() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Falling recovered at 0x0000000001d16040 (size 0x00000020).
func (*inventoryPlayerHost) Falling() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).FlushBufferedAttackPackets recovered at 0x0000000001d16080 (size 0x00000040).
func (*inventoryPlayerHost) FlushBufferedAttackPackets() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Flying recovered at 0x0000000001d160e0 (size 0x00000020).
func (*inventoryPlayerHost) Flying() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ForEachBlockByNameSetFrom recovered at 0x0000000001d16120 (size 0x00000080).
func (*inventoryPlayerHost) ForEachBlockByNameSetFrom() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Form recovered at 0x0000000001d161e0 (size 0x00000040).
func (*inventoryPlayerHost) Form() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).FormatBool recovered at 0x0000000001d16260 (size 0x00000040).
func (*inventoryPlayerHost) FormatBool() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).FormatDeleteResult recovered at 0x0000000001d162c0 (size 0x00000080).
func (*inventoryPlayerHost) FormatDeleteResult() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).FreeCamPresetID recovered at 0x0000000001d16360 (size 0x00000020).
func (*inventoryPlayerHost) FreeCamPresetID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).FriendWorld recovered at 0x0000000001d163a0 (size 0x00000020).
func (*inventoryPlayerHost) FriendWorld() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Friends recovered at 0x0000000001d163e0 (size 0x00000020).
func (*inventoryPlayerHost) Friends() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).GameType recovered at 0x0000000001d16420 (size 0x00000020).
func (*inventoryPlayerHost) GameType() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).GenerateEmotes recovered at 0x0000000001d16460 (size 0x00000020).
func (*inventoryPlayerHost) GenerateEmotes() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).GetEntity recovered at 0x0000000001d164a0 (size 0x00000040).
func (*inventoryPlayerHost) GetEntity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).GetEntityByUniqueID recovered at 0x0000000001d16520 (size 0x00000040).
func (*inventoryPlayerHost) GetEntityByUniqueID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).GetServerEffect recovered at 0x0000000001d165a0 (size 0x000000e0).
func (*inventoryPlayerHost) GetServerEffect() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Gliding recovered at 0x0000000001d16760 (size 0x00000020).
func (*inventoryPlayerHost) Gliding() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HandleAimAssist recovered at 0x0000000001d167a0 (size 0x00000060).
func (*inventoryPlayerHost) HandleAimAssist() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HandleAimAssistServerPacket recovered at 0x0000000001d16860 (size 0x00000060).
func (*inventoryPlayerHost) HandleAimAssistServerPacket() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HandleAutoFish recovered at 0x0000000001d168e0 (size 0x00000040).
func (*inventoryPlayerHost) HandleAutoFish() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HandleAutoFishTransaction recovered at 0x0000000001d16940 (size 0x00000060).
func (*inventoryPlayerHost) HandleAutoFishTransaction() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HandleAutoLog recovered at 0x0000000001d16a00 (size 0x00000060).
func (*inventoryPlayerHost) HandleAutoLog() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HandleAvailableCommands recovered at 0x0000000001d16a80 (size 0x00000040).
func (*inventoryPlayerHost) HandleAvailableCommands() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HandleChestPairBlockEntity recovered at 0x0000000001d16ae0 (size 0x00000060).
func (*inventoryPlayerHost) HandleChestPairBlockEntity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HandleClientAttack recovered at 0x0000000001d16b60 (size 0x00000040).
func (*inventoryPlayerHost) HandleClientAttack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HandleContainerClose recovered at 0x0000000001d16bc0 (size 0x00000040).
func (*inventoryPlayerHost) HandleContainerClose() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HandleDeathActorEvent recovered at 0x0000000001d16c20 (size 0x00000040).
func (*inventoryPlayerHost) HandleDeathActorEvent() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HandleFishingActorEvent recovered at 0x0000000001d16c80 (size 0x00000060).
func (*inventoryPlayerHost) HandleFishingActorEvent() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HandleFriendAlertsPlayerList recovered at 0x0000000001d16d40 (size 0x00000060).
func (*inventoryPlayerHost) HandleFriendAlertsPlayerList() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HandleModAlertsAddPlayer recovered at 0x0000000001d16e00 (size 0x00000040).
func (*inventoryPlayerHost) HandleModAlertsAddPlayer() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HandleModAlertsPlayerList recovered at 0x0000000001d16e60 (size 0x00000040).
func (*inventoryPlayerHost) HandleModAlertsPlayerList() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HandlePlayerAuthInput recovered at 0x0000000001d16ec0 (size 0x00000040).
func (*inventoryPlayerHost) HandlePlayerAuthInput() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HandlePlayerList recovered at 0x0000000001d16f20 (size 0x00000040).
func (*inventoryPlayerHost) HandlePlayerList() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HandleRespawn recovered at 0x0000000001d16f80 (size 0x00000040).
func (*inventoryPlayerHost) HandleRespawn() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HandleWorldBlockUpdates recovered at 0x0000000001d16fe0 (size 0x00000060).
func (*inventoryPlayerHost) HandleWorldBlockUpdates() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HandleXraySubChunkRequest recovered at 0x0000000001d17060 (size 0x00000060).
func (*inventoryPlayerHost) HandleXraySubChunkRequest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HasBufferedAttackPackets recovered at 0x0000000001d17120 (size 0x00000040).
func (*inventoryPlayerHost) HasBufferedAttackPackets() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HasEntityFriend recovered at 0x0000000001d17180 (size 0x00000060).
func (*inventoryPlayerHost) HasEntityFriend() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HasTrustedShulkerTooltipStack recovered at 0x0000000001d17240 (size 0x00000040).
func (*inventoryPlayerHost) HasTrustedShulkerTooltipStack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HasUnobstructedPath recovered at 0x0000000001d172c0 (size 0x00000080).
func (*inventoryPlayerHost) HasUnobstructedPath() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Health recovered at 0x0000000001d17380 (size 0x00000020).
func (*inventoryPlayerHost) Health() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HealthInfo recovered at 0x0000000001d173c0 (size 0x00000040).
func (*inventoryPlayerHost) HealthInfo() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HeldItem recovered at 0x0000000001d17420 (size 0x000000c0).
func (*inventoryPlayerHost) HeldItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HeldItemName recovered at 0x0000000001d175a0 (size 0x00000040).
func (*inventoryPlayerHost) HeldItemName() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HeldShulkerPreview recovered at 0x0000000001d17600 (size 0x00000100).
func (*inventoryPlayerHost) HeldShulkerPreview() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HeldSlotOwner recovered at 0x0000000001d17740 (size 0x00000040).
func (*inventoryPlayerHost) HeldSlotOwner() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HitBoxActive recovered at 0x0000000001d177a0 (size 0x00000060).
func (*inventoryPlayerHost) HitBoxActive() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HoldItemUse recovered at 0x0000000001d17860 (size 0x00000040).
func (*inventoryPlayerHost) HoldItemUse() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HoldingWeapon recovered at 0x0000000001d178c0 (size 0x00000040).
func (*inventoryPlayerHost) HoldingWeapon() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HoleESPClear recovered at 0x0000000001d17920 (size 0x00000040).
func (*inventoryPlayerHost) HoleESPClear() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HoleESPHandleLevelChunk recovered at 0x0000000001d179a0 (size 0x00000040).
func (*inventoryPlayerHost) HoleESPHandleLevelChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HoleESPHandleSubChunk recovered at 0x0000000001d17a00 (size 0x00000040).
func (*inventoryPlayerHost) HoleESPHandleSubChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HoleESPRescan recovered at 0x0000000001d17a60 (size 0x00000040).
func (*inventoryPlayerHost) HoleESPRescan() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).HoleESPSetEnabled recovered at 0x0000000001d17ac0 (size 0x00000020).
func (*inventoryPlayerHost) HoleESPSetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Hosted recovered at 0x0000000001d17b00 (size 0x00000020).
func (*inventoryPlayerHost) Hosted() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Hunger recovered at 0x0000000001d17b40 (size 0x00000020).
func (*inventoryPlayerHost) Hunger() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).IdentityUniqueID recovered at 0x0000000001d17b80 (size 0x00000080).
func (*inventoryPlayerHost) IdentityUniqueID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).InPlayerList recovered at 0x0000000001d17c80 (size 0x00000040).
func (*inventoryPlayerHost) InPlayerList() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Initialize recovered at 0x0000000001d17ce0 (size 0x00000020).
func (*inventoryPlayerHost) Initialize() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Inject recovered at 0x0000000001d17d20 (size 0x00000040).
func (*inventoryPlayerHost) Inject() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).InteractBlockOnce recovered at 0x0000000001d17d80 (size 0x00000040).
func (*inventoryPlayerHost) InteractBlockOnce() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).InteractOpenInventory recovered at 0x0000000001d17de0 (size 0x00000080).
func (*inventoryPlayerHost) InteractOpenInventory() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Inventory recovered at 0x0000000001d17ee0 (size 0x00000020).
func (*inventoryPlayerHost) Inventory() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Item recovered at 0x0000000001d17f20 (size 0x00000040).
func (*inventoryPlayerHost) Item() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ItemNetworkID recovered at 0x0000000001d17f80 (size 0x00000060).
func (*inventoryPlayerHost) ItemNetworkID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).JavaAttackCooldown recovered at 0x0000000001d18000 (size 0x00000040).
func (*inventoryPlayerHost) JavaAttackCooldown() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Jump recovered at 0x0000000001d18060 (size 0x00000040).
func (*inventoryPlayerHost) Jump() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Jumping recovered at 0x0000000001d180c0 (size 0x00000020).
func (*inventoryPlayerHost) Jumping() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).LanguageOverride recovered at 0x0000000001d18100 (size 0x00000040).
func (*inventoryPlayerHost) LanguageOverride() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).LastAttackedEntity recovered at 0x0000000001d18180 (size 0x00000040).
func (*inventoryPlayerHost) LastAttackedEntity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).LastClickTime recovered at 0x0000000001d181e0 (size 0x00000020).
func (*inventoryPlayerHost) LastClickTime() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).LastDamageTime recovered at 0x0000000001d18220 (size 0x00000020).
func (*inventoryPlayerHost) LastDamageTime() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).LastItemUseTime recovered at 0x0000000001d18260 (size 0x00000020).
func (*inventoryPlayerHost) LastItemUseTime() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).LastManualAttackTime recovered at 0x0000000001d182a0 (size 0x00000020).
func (*inventoryPlayerHost) LastManualAttackTime() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).LoadAndApplyConfig recovered at 0x0000000001d182e0 (size 0x00000060).
func (*inventoryPlayerHost) LoadAndApplyConfig() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).LoadBlocks recovered at 0x0000000001d18360 (size 0x00000060).
func (*inventoryPlayerHost) LoadBlocks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).LoadItems recovered at 0x0000000001d183e0 (size 0x000000c0).
func (*inventoryPlayerHost) LoadItems() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Log recovered at 0x0000000001d18560 (size 0x00000020).
func (*inventoryPlayerHost) Log() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).LookAt recovered at 0x0000000001d185a0 (size 0x00000040).
func (*inventoryPlayerHost) LookAt() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).LookingAt recovered at 0x0000000001d18600 (size 0x00000040).
func (*inventoryPlayerHost) LookingAt() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ManualAttackCPS recovered at 0x0000000001d18660 (size 0x00000040).
func (*inventoryPlayerHost) ManualAttackCPS() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).MaxHealth recovered at 0x0000000001d186e0 (size 0x00000020).
func (*inventoryPlayerHost) MaxHealth() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).MergeAttributes recovered at 0x0000000001d18720 (size 0x00000060).
func (*inventoryPlayerHost) MergeAttributes() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Message recovered at 0x0000000001d187a0 (size 0x00000080).
func (*inventoryPlayerHost) Message() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).MessageAlreadyToggled recovered at 0x0000000001d18840 (size 0x00000080).
func (*inventoryPlayerHost) MessageAlreadyToggled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).MessageServer recovered at 0x0000000001d188e0 (size 0x00000060).
func (*inventoryPlayerHost) MessageServer() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Messagef recovered at 0x0000000001d18960 (size 0x00000080).
func (*inventoryPlayerHost) Messagef() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Messaget recovered at 0x0000000001d18a00 (size 0x00000080).
func (*inventoryPlayerHost) Messaget() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Metadata recovered at 0x0000000001d18aa0 (size 0x00000040).
func (*inventoryPlayerHost) Metadata() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Module recovered at 0x0000000001d18b00 (size 0x000000a0).
func (*inventoryPlayerHost) Module() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ModuleAccess recovered at 0x0000000001d18c40 (size 0x00000060).
func (*inventoryPlayerHost) ModuleAccess() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ModuleAvailability recovered at 0x0000000001d18cc0 (size 0x000000a0).
func (*inventoryPlayerHost) ModuleAvailability() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ModulePremiumOnly recovered at 0x0000000001d18e00 (size 0x00000080).
func (*inventoryPlayerHost) ModulePremiumOnly() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).MovementSpeed recovered at 0x0000000001d18f00 (size 0x00000020).
func (*inventoryPlayerHost) MovementSpeed() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).MustModule recovered at 0x0000000001d18f40 (size 0x00000060).
func (*inventoryPlayerHost) MustModule() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).MutateAutoCrit recovered at 0x0000000001d18fc0 (size 0x00000040).
func (*inventoryPlayerHost) MutateAutoCrit() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).NearbyLiveEntities recovered at 0x0000000001d19020 (size 0x00000040).
func (*inventoryPlayerHost) NearbyLiveEntities() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).NearestEntity recovered at 0x0000000001d19080 (size 0x00000040).
func (*inventoryPlayerHost) NearestEntity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).NewChunksClear recovered at 0x0000000001d190e0 (size 0x00000040).
func (*inventoryPlayerHost) NewChunksClear() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).NewChunksFlaggedCount recovered at 0x0000000001d19140 (size 0x00000040).
func (*inventoryPlayerHost) NewChunksFlaggedCount() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).NewChunksHandleLevelChunk recovered at 0x0000000001d191c0 (size 0x00000060).
func (*inventoryPlayerHost) NewChunksHandleLevelChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).NewChunksHandleSubChunk recovered at 0x0000000001d19240 (size 0x00000060).
func (*inventoryPlayerHost) NewChunksHandleSubChunk() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).NewChunksHandleUpdateBlock recovered at 0x0000000001d192c0 (size 0x00000060).
func (*inventoryPlayerHost) NewChunksHandleUpdateBlock() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).NewChunksHandleUpdateSubChunkBlocks recovered at 0x0000000001d193a0 (size 0x00000040).
func (*inventoryPlayerHost) NewChunksHandleUpdateSubChunkBlocks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ObserveAutoSellInventoryEdit recovered at 0x0000000001d19400 (size 0x00000060).
func (*inventoryPlayerHost) ObserveAutoSellInventoryEdit() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ObserveClientSelectedHotBarSlot recovered at 0x0000000001d194c0 (size 0x00000040).
func (*inventoryPlayerHost) ObserveClientSelectedHotBarSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).OnGround recovered at 0x0000000001d19520 (size 0x00000020).
func (*inventoryPlayerHost) OnGround() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).OtherPlayerListNames recovered at 0x0000000001d19560 (size 0x00000040).
func (*inventoryPlayerHost) OtherPlayerListNames() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Owner recovered at 0x0000000001d195c0 (size 0x00000040).
func (*inventoryPlayerHost) Owner() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).PauseAutomation recovered at 0x0000000001d19620 (size 0x00000020).
func (*inventoryPlayerHost) PauseAutomation() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).PlayerGameMode recovered at 0x0000000001d19660 (size 0x00000020).
func (*inventoryPlayerHost) PlayerGameMode() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Position recovered at 0x0000000001d196a0 (size 0x000000a0).
func (*inventoryPlayerHost) Position() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Position32 recovered at 0x0000000001d197e0 (size 0x00000060).
func (*inventoryPlayerHost) Position32() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Premium recovered at 0x0000000001d198a0 (size 0x00000040).
func (*inventoryPlayerHost) Premium() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Properties recovered at 0x0000000001d19920 (size 0x000000a0).
func (*inventoryPlayerHost) Properties() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).PublishAvailableCommandsIfServerSentNone recovered at 0x0000000001d19a60 (size 0x00000040).
func (*inventoryPlayerHost) PublishAvailableCommandsIfServerSentNone() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).QueueBlockBreak recovered at 0x0000000001d19ae0 (size 0x000000a0).
func (*inventoryPlayerHost) QueueBlockBreak() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).QueueBlockBreakWithOptions recovered at 0x0000000001d19c40 (size 0x000000e0).
func (*inventoryPlayerHost) QueueBlockBreakWithOptions() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).RainIntensity recovered at 0x0000000001d19d80 (size 0x00000020).
func (*inventoryPlayerHost) RainIntensity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).RayTraceDistance recovered at 0x0000000001d19dc0 (size 0x00000060).
func (*inventoryPlayerHost) RayTraceDistance() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ReachDistance recovered at 0x0000000001d19e40 (size 0x00000040).
func (*inventoryPlayerHost) ReachDistance() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Realm recovered at 0x0000000001d19ea0 (size 0x00000020).
func (*inventoryPlayerHost) Realm() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Recipe recovered at 0x0000000001d0d760 (size 0x00000060).
func (*inventoryPlayerHost) Recipe() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).RefreshAFKClickerSettings recovered at 0x0000000001d19f60 (size 0x00000040).
func (*inventoryPlayerHost) RefreshAFKClickerSettings() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).RefreshActorData recovered at 0x0000000001d19fe0 (size 0x00000040).
func (*inventoryPlayerHost) RefreshActorData() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).RefreshAvailableCommands recovered at 0x0000000001d1a040 (size 0x00000040).
func (*inventoryPlayerHost) RefreshAvailableCommands() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).RefreshAvailableCommandsIfHiddenChanged recovered at 0x0000000001d1a0a0 (size 0x00000040).
func (*inventoryPlayerHost) RefreshAvailableCommandsIfHiddenChanged() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).RefreshHitBoxOnVisibleWeaponChange recovered at 0x0000000001d1a100 (size 0x00000040).
func (*inventoryPlayerHost) RefreshHitBoxOnVisibleWeaponChange() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).RefreshStatChangerScoreboard recovered at 0x0000000001d1a180 (size 0x00000040).
func (*inventoryPlayerHost) RefreshStatChangerScoreboard() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).RefreshXrayFallingBlockAfterMove recovered at 0x0000000001d1a1e0 (size 0x000000a0).
func (*inventoryPlayerHost) RefreshXrayFallingBlockAfterMove() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).RegisterClick recovered at 0x0000000001d1a340 (size 0x00000040).
func (*inventoryPlayerHost) RegisterClick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ReleaseHeldSlot recovered at 0x0000000001d1a3a0 (size 0x00000040).
func (*inventoryPlayerHost) ReleaseHeldSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ReleaseHeldSlotGuard recovered at 0x0000000001d1a400 (size 0x00000040).
func (*inventoryPlayerHost) ReleaseHeldSlotGuard() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ReleaseItemUse recovered at 0x0000000001d1a460 (size 0x00000040).
func (*inventoryPlayerHost) ReleaseItemUse() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).RemoveBacktrackDelay recovered at 0x0000000001d1a4c0 (size 0x00000040).
func (*inventoryPlayerHost) RemoveBacktrackDelay() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).RemoveEffect recovered at 0x0000000001d1a520 (size 0x00000080).
func (*inventoryPlayerHost) RemoveEffect() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).RemoveEntity recovered at 0x0000000001d1a640 (size 0x00000040).
func (*inventoryPlayerHost) RemoveEntity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).RemoveFromPlayerList recovered at 0x0000000001d1a6a0 (size 0x00000060).
func (*inventoryPlayerHost) RemoveFromPlayerList() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).RemoveStatChangerOverride recovered at 0x0000000001d1a720 (size 0x00000040).
func (*inventoryPlayerHost) RemoveStatChangerOverride() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ResetAimAssist recovered at 0x0000000001d1a780 (size 0x00000040).
func (*inventoryPlayerHost) ResetAimAssist() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ResetAutoEatState recovered at 0x0000000001d1a800 (size 0x00000040).
func (*inventoryPlayerHost) ResetAutoEatState() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ResetAutoFishState recovered at 0x0000000001d1a860 (size 0x00000040).
func (*inventoryPlayerHost) ResetAutoFishState() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ResetAutoRocketDelay recovered at 0x0000000001d1a8e0 (size 0x00000020).
func (*inventoryPlayerHost) ResetAutoRocketDelay() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ResetAutoSwitchHits recovered at 0x0000000001d1a920 (size 0x00000020).
func (*inventoryPlayerHost) ResetAutoSwitchHits() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ResetAutoWebHits recovered at 0x0000000001d1a960 (size 0x00000020).
func (*inventoryPlayerHost) ResetAutoWebHits() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ResetEatingState recovered at 0x0000000001d1a9a0 (size 0x00000040).
func (*inventoryPlayerHost) ResetEatingState() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ResetFallDistance recovered at 0x0000000001d1aa00 (size 0x00000020).
func (*inventoryPlayerHost) ResetFallDistance() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ResetNukeBlocks recovered at 0x0000000001d1aa40 (size 0x00000040).
func (*inventoryPlayerHost) ResetNukeBlocks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ResetShulkerTooltipStacks recovered at 0x0000000001d1aac0 (size 0x00000040).
func (*inventoryPlayerHost) ResetShulkerTooltipStacks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ResetSpawnerProtect recovered at 0x0000000001d1ab40 (size 0x00000040).
func (*inventoryPlayerHost) ResetSpawnerProtect() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ResumeAutomation recovered at 0x0000000001d1aba0 (size 0x00000020).
func (*inventoryPlayerHost) ResumeAutomation() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Rotate recovered at 0x0000000001d1abe0 (size 0x00000040).
func (*inventoryPlayerHost) Rotate() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).RotateServerSide recovered at 0x0000000001d1ac40 (size 0x00000060).
func (*inventoryPlayerHost) RotateServerSide() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Rotation recovered at 0x0000000001d1ace0 (size 0x00000060).
func (*inventoryPlayerHost) Rotation() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).RunPostAttackHooks recovered at 0x0000000001d1ada0 (size 0x00000040).
func (*inventoryPlayerHost) RunPostAttackHooks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).RunPreAttackHooks recovered at 0x0000000001d1ae20 (size 0x00000060).
func (*inventoryPlayerHost) RunPreAttackHooks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SanitizeStatChangerOverrides recovered at 0x0000000001d1aee0 (size 0x00000040).
func (*inventoryPlayerHost) SanitizeStatChangerOverrides() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Saturation recovered at 0x0000000001d1af40 (size 0x00000020).
func (*inventoryPlayerHost) Saturation() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ScanBlocks recovered at 0x0000000001d1af80 (size 0x00000060).
func (*inventoryPlayerHost) ScanBlocks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ScanBlocksByName recovered at 0x0000000001d1b000 (size 0x00000060).
func (*inventoryPlayerHost) ScanBlocksByName() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ScanBlocksByNameFrom recovered at 0x0000000001d1b080 (size 0x00000080).
func (*inventoryPlayerHost) ScanBlocksByNameFrom() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ScanBlocksByNameSet recovered at 0x0000000001d1b140 (size 0x00000040).
func (*inventoryPlayerHost) ScanBlocksByNameSet() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Scoreboard recovered at 0x0000000001d1b1a0 (size 0x00000020).
func (*inventoryPlayerHost) Scoreboard() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SendActionBarMessage recovered at 0x0000000001d1b1e0 (size 0x000000c0).
func (*inventoryPlayerHost) SendActionBarMessage() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SendForm recovered at 0x0000000001d1b360 (size 0x00000060).
func (*inventoryPlayerHost) SendForm() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SendJukeboxPopup recovered at 0x0000000001d1b3e0 (size 0x000000c0).
func (*inventoryPlayerHost) SendJukeboxPopup() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SendTip recovered at 0x0000000001d1b560 (size 0x000000c0).
func (*inventoryPlayerHost) SendTip() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SendToast recovered at 0x0000000001d1b6e0 (size 0x000000e0).
func (*inventoryPlayerHost) SendToast() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ServerAbilityData recovered at 0x0000000001d1b8c0 (size 0x000000c0).
func (*inventoryPlayerHost) ServerAbilityData() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ServerAddress recovered at 0x0000000001d0d600 (size 0x00000040).
func (*inventoryPlayerHost) ServerAddress() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ServerAuthoritativeInventory recovered at 0x0000000001d0d560 (size 0x000000a0).
func (*inventoryPlayerHost) ServerAuthoritativeInventory() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ServerBBox recovered at 0x0000000001d1bb20 (size 0x00000080).
func (*inventoryPlayerHost) ServerBBox() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ServerBacktrackDeferContext recovered at 0x0000000001d1bc20 (size 0x00000080).
func (*inventoryPlayerHost) ServerBacktrackDeferContext() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ServerCameraInstruction recovered at 0x0000000001d1bd20 (size 0x00000020).
func (*inventoryPlayerHost) ServerCameraInstruction() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ServerConn recovered at 0x0000000001d1bd60 (size 0x00000020).
func (*inventoryPlayerHost) ServerConn() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ServerControlSchemeSet recovered at 0x0000000001d1bda0 (size 0x00000020).
func (*inventoryPlayerHost) ServerControlSchemeSet() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ServerGameMode recovered at 0x0000000001d1bde0 (size 0x00000020).
func (*inventoryPlayerHost) ServerGameMode() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ServerMovementSpeed recovered at 0x0000000001d1be20 (size 0x00000020).
func (*inventoryPlayerHost) ServerMovementSpeed() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ServerSideTeleport recovered at 0x0000000001d1be60 (size 0x00000040).
func (*inventoryPlayerHost) ServerSideTeleport() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ServerSideWalkTo recovered at 0x0000000001d1bec0 (size 0x00000080).
func (*inventoryPlayerHost) ServerSideWalkTo() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ServerType recovered at 0x0000000001d1bfc0 (size 0x00000020).
func (*inventoryPlayerHost) ServerType() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetAFKClickerClickType recovered at 0x0000000001d1c000 (size 0x00000100).
func (*inventoryPlayerHost) SetAFKClickerClickType() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetAbsorption recovered at 0x0000000001d1c200 (size 0x00000020).
func (*inventoryPlayerHost) SetAbsorption() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetAttributeValues recovered at 0x0000000001d1c240 (size 0x00000060).
func (*inventoryPlayerHost) SetAttributeValues() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetAvailableCommandsHooks recovered at 0x0000000001d1c2c0 (size 0x00000080).
func (*inventoryPlayerHost) SetAvailableCommandsHooks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetBBox recovered at 0x0000000001d1c3c0 (size 0x00000080).
func (*inventoryPlayerHost) SetBBox() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetBlocking recovered at 0x0000000001d1c4c0 (size 0x00000040).
func (*inventoryPlayerHost) SetBlocking() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetClickUIStyle recovered at 0x0000000001d1c540 (size 0x00000060).
func (*inventoryPlayerHost) SetClickUIStyle() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetClientMoving recovered at 0x0000000001d1c5c0 (size 0x00000020).
func (*inventoryPlayerHost) SetClientMoving() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetClientTick recovered at 0x0000000001d1c600 (size 0x00000020).
func (*inventoryPlayerHost) SetClientTick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetCombatTarget recovered at 0x0000000001d1c640 (size 0x00000040).
func (*inventoryPlayerHost) SetCombatTarget() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetConfigStore recovered at 0x0000000001d1c6a0 (size 0x00000080).
func (*inventoryPlayerHost) SetConfigStore() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetConnections recovered at 0x0000000001d1c7a0 (size 0x00000080).
func (*inventoryPlayerHost) SetConnections() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetCrawling recovered at 0x0000000001d1c8a0 (size 0x00000040).
func (*inventoryPlayerHost) SetCrawling() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetDead recovered at 0x0000000001d1c920 (size 0x00000020).
func (*inventoryPlayerHost) SetDead() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetExhaustion recovered at 0x0000000001d1c960 (size 0x00000020).
func (*inventoryPlayerHost) SetExhaustion() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetExperienceLevel recovered at 0x0000000001d1c9a0 (size 0x00000020).
func (*inventoryPlayerHost) SetExperienceLevel() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetExperienceProgress recovered at 0x0000000001d1c9e0 (size 0x00000020).
func (*inventoryPlayerHost) SetExperienceProgress() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetFalling recovered at 0x0000000001d1ca20 (size 0x00000040).
func (*inventoryPlayerHost) SetFalling() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetFlying recovered at 0x0000000001d1caa0 (size 0x00000040).
func (*inventoryPlayerHost) SetFlying() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetFreeCamPresetID recovered at 0x0000000001d1cb20 (size 0x00000040).
func (*inventoryPlayerHost) SetFreeCamPresetID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetGameSpeed recovered at 0x0000000001d1cb80 (size 0x00000060).
func (*inventoryPlayerHost) SetGameSpeed() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetGameType recovered at 0x0000000001d1cc40 (size 0x00000020).
func (*inventoryPlayerHost) SetGameType() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetGliding recovered at 0x0000000001d1cc80 (size 0x00000040).
func (*inventoryPlayerHost) SetGliding() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetHealth recovered at 0x0000000001d1cd00 (size 0x00000020).
func (*inventoryPlayerHost) SetHealth() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetHeldItem recovered at 0x0000000001d1cd40 (size 0x000000e0).
func (*inventoryPlayerHost) SetHeldItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetHunger recovered at 0x0000000001d1cf00 (size 0x00000020).
func (*inventoryPlayerHost) SetHunger() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetInPlayerList recovered at 0x0000000001d1cf40 (size 0x00000020).
func (*inventoryPlayerHost) SetInPlayerList() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetInventory recovered at 0x0000000001d1cf80 (size 0x00000080).
func (*inventoryPlayerHost) SetInventory() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetJumping recovered at 0x0000000001d1d080 (size 0x00000040).
func (*inventoryPlayerHost) SetJumping() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetLanguage recovered at 0x0000000001d1d100 (size 0x00000060).
func (*inventoryPlayerHost) SetLanguage() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetLastAttackedEntity recovered at 0x0000000001d1d1e0 (size 0x00000040).
func (*inventoryPlayerHost) SetLastAttackedEntity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetLastDamageTime recovered at 0x0000000001d1d240 (size 0x000000c0).
func (*inventoryPlayerHost) SetLastDamageTime() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetLastItemUseTime recovered at 0x0000000001d1d3c0 (size 0x000000c0).
func (*inventoryPlayerHost) SetLastItemUseTime() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetMaxHealth recovered at 0x0000000001d1d540 (size 0x00000020).
func (*inventoryPlayerHost) SetMaxHealth() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetMetadata recovered at 0x0000000001d1d580 (size 0x00000040).
func (*inventoryPlayerHost) SetMetadata() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetMovementSpeed recovered at 0x0000000001d1d5e0 (size 0x00000020).
func (*inventoryPlayerHost) SetMovementSpeed() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetPacketWriter recovered at 0x0000000001d1d620 (size 0x00000060).
func (*inventoryPlayerHost) SetPacketWriter() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetPlayerGameMode recovered at 0x0000000001d1d6a0 (size 0x00000040).
func (*inventoryPlayerHost) SetPlayerGameMode() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetPosition recovered at 0x0000000001d1d700 (size 0x00000040).
func (*inventoryPlayerHost) SetPosition() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetPremium recovered at 0x0000000001d1d760 (size 0x00000020).
func (*inventoryPlayerHost) SetPremium() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetProperties recovered at 0x0000000001d1d7a0 (size 0x00000120).
func (*inventoryPlayerHost) SetProperties() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetRainIntensity recovered at 0x0000000001d1d9e0 (size 0x00000020).
func (*inventoryPlayerHost) SetRainIntensity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetRotation recovered at 0x0000000001d1da20 (size 0x00000040).
func (*inventoryPlayerHost) SetRotation() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetSaturation recovered at 0x0000000001d1da80 (size 0x00000020).
func (*inventoryPlayerHost) SetSaturation() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetServerAbilityData recovered at 0x0000000001d1dac0 (size 0x000000e0).
func (*inventoryPlayerHost) SetServerAbilityData() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetServerBBox recovered at 0x0000000001d1dca0 (size 0x00000080).
func (*inventoryPlayerHost) SetServerBBox() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetServerCameraInstruction recovered at 0x0000000001d1dda0 (size 0x00000040).
func (*inventoryPlayerHost) SetServerCameraInstruction() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetServerConfigKey recovered at 0x0000000001d1de20 (size 0x00000060).
func (*inventoryPlayerHost) SetServerConfigKey() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetServerControlSchemeSet recovered at 0x0000000001d1dea0 (size 0x00000020).
func (*inventoryPlayerHost) SetServerControlSchemeSet() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetServerEffect recovered at 0x0000000001d1dee0 (size 0x00000120).
func (*inventoryPlayerHost) SetServerEffect() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetServerMovementSpeed recovered at 0x0000000001d1e120 (size 0x00000020).
func (*inventoryPlayerHost) SetServerMovementSpeed() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetServerPacketWriter recovered at 0x0000000001d1e160 (size 0x00000060).
func (*inventoryPlayerHost) SetServerPacketWriter() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetServerType recovered at 0x0000000001d1e1e0 (size 0x00000040).
func (*inventoryPlayerHost) SetServerType() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetSneaking recovered at 0x0000000001d1e240 (size 0x00000040).
func (*inventoryPlayerHost) SetSneaking() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetSpeed recovered at 0x0000000001d1e2c0 (size 0x00000060).
func (*inventoryPlayerHost) SetSpeed() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetSpinAttack recovered at 0x0000000001d1e380 (size 0x00000040).
func (*inventoryPlayerHost) SetSpinAttack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetSprinting recovered at 0x0000000001d1e400 (size 0x00000040).
func (*inventoryPlayerHost) SetSprinting() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetStatChangerOverride recovered at 0x0000000001d1e480 (size 0x00000060).
func (*inventoryPlayerHost) SetStatChangerOverride() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetSwimming recovered at 0x0000000001d1e500 (size 0x00000040).
func (*inventoryPlayerHost) SetSwimming() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetThunderstormIntensity recovered at 0x0000000001d1e580 (size 0x00000020).
func (*inventoryPlayerHost) SetThunderstormIntensity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetUsingSocks5Proxy recovered at 0x0000000001d1e5c0 (size 0x00000020).
func (*inventoryPlayerHost) SetUsingSocks5Proxy() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetVisibleHeldSlot recovered at 0x0000000001d1e600 (size 0x00000040).
func (*inventoryPlayerHost) SetVisibleHeldSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SetWorldUpdater recovered at 0x0000000001d1e660 (size 0x00000080).
func (*inventoryPlayerHost) SetWorldUpdater() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ShouldRenderDebugShapes recovered at 0x0000000001d1e760 (size 0x00000040).
func (*inventoryPlayerHost) ShouldRenderDebugShapes() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ShouldSuppressContainerOpen recovered at 0x0000000001d1e7c0 (size 0x00000080).
func (*inventoryPlayerHost) ShouldSuppressContainerOpen() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ShouldSuppressHeldSlotEcho recovered at 0x0000000001d1e8c0 (size 0x00000040).
func (*inventoryPlayerHost) ShouldSuppressHeldSlotEcho() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ShowCoordinates recovered at 0x0000000001d1e920 (size 0x00000040).
func (*inventoryPlayerHost) ShowCoordinates() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ShowLightning recovered at 0x0000000001d1e980 (size 0x00000040).
func (*inventoryPlayerHost) ShowLightning() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ShulkerTooltipDecorated recovered at 0x0000000001d1e9e0 (size 0x00000080).
func (*inventoryPlayerHost) ShulkerTooltipDecorated() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ShulkerTooltipEnabled recovered at 0x0000000001d0d860 (size 0x00000020).
func (*inventoryPlayerHost) ShulkerTooltipEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ShulkerTooltipRequestDecorated recovered at 0x0000000001d1eb00 (size 0x000000a0).
func (*inventoryPlayerHost) ShulkerTooltipRequestDecorated() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Skin recovered at 0x0000000001d1ec40 (size 0x00000020).
func (*inventoryPlayerHost) Skin() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SnapshotConfig recovered at 0x0000000001d1ec80 (size 0x000001a0).
func (*inventoryPlayerHost) SnapshotConfig() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SnapshotSections recovered at 0x0000000001d1ee80 (size 0x00000040).
func (*inventoryPlayerHost) SnapshotSections() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SnapshotStatChangerSettings recovered at 0x0000000001d1eee0 (size 0x00000040).
func (*inventoryPlayerHost) SnapshotStatChangerSettings() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Sneaking recovered at 0x0000000001d1ef40 (size 0x00000020).
func (*inventoryPlayerHost) Sneaking() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SpeedValue recovered at 0x0000000001d1ef80 (size 0x00000040).
func (*inventoryPlayerHost) SpeedValue() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SpinAttack recovered at 0x0000000001d1f000 (size 0x00000020).
func (*inventoryPlayerHost) SpinAttack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Sprinting recovered at 0x0000000001d1f040 (size 0x00000020).
func (*inventoryPlayerHost) Sprinting() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).StackFromItem recovered at 0x0000000001d1f080 (size 0x00000140).
func (*inventoryPlayerHost) StackFromItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).StackToItem recovered at 0x0000000001d1f240 (size 0x00000160).
func (*inventoryPlayerHost) StackToItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).StartArrayList recovered at 0x0000000001d1f420 (size 0x00000040).
func (*inventoryPlayerHost) StartArrayList() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).StartBacktrackTicking recovered at 0x0000000001d1f480 (size 0x00000040).
func (*inventoryPlayerHost) StartBacktrackTicking() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).StartClickTicker recovered at 0x0000000001d1f4e0 (size 0x00000040).
func (*inventoryPlayerHost) StartClickTicker() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).StartPlayerTicker recovered at 0x0000000001d1f540 (size 0x00000040).
func (*inventoryPlayerHost) StartPlayerTicker() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).StartShapesTicker recovered at 0x0000000001d1f5a0 (size 0x00000040).
func (*inventoryPlayerHost) StartShapesTicker() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).StartSpam recovered at 0x0000000001d1f600 (size 0x00000060).
func (*inventoryPlayerHost) StartSpam() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).StartStealContainerTicker recovered at 0x0000000001d1f680 (size 0x00000040).
func (*inventoryPlayerHost) StartStealContainerTicker() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).StatChangerCurrentLines recovered at 0x0000000001d1f6e0 (size 0x00000040).
func (*inventoryPlayerHost) StatChangerCurrentLines() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).StatChangerOverrides recovered at 0x0000000001d1f740 (size 0x00000040).
func (*inventoryPlayerHost) StatChangerOverrides() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).StopClickTicker recovered at 0x0000000001d1f7a0 (size 0x00000040).
func (*inventoryPlayerHost) StopClickTicker() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).StopEmote recovered at 0x0000000001d1f800 (size 0x00000040).
func (*inventoryPlayerHost) StopEmote() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).StopFastThrow recovered at 0x0000000001d1f860 (size 0x000000a0).
func (*inventoryPlayerHost) StopFastThrow() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).StopModuleRuntimeDeps recovered at 0x0000000001d1f9c0 (size 0x00000040).
func (*inventoryPlayerHost) StopModuleRuntimeDeps() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).StopPlayerTicker recovered at 0x0000000001d1fa20 (size 0x00000040).
func (*inventoryPlayerHost) StopPlayerTicker() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).StopShapesTicker recovered at 0x0000000001d1fa80 (size 0x00000040).
func (*inventoryPlayerHost) StopShapesTicker() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).StoreServerGameMode recovered at 0x0000000001d1fae0 (size 0x00000020).
func (*inventoryPlayerHost) StoreServerGameMode() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).StoreSkin recovered at 0x0000000001d1fb20 (size 0x00000040).
func (*inventoryPlayerHost) StoreSkin() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).StoreSkinIfEmpty recovered at 0x0000000001d1fba0 (size 0x00000040).
func (*inventoryPlayerHost) StoreSkinIfEmpty() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).StripShulkerTooltip recovered at 0x0000000001d1fc00 (size 0x00000140).
func (*inventoryPlayerHost) StripShulkerTooltip() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).StripShulkerTooltipRequestResult recovered at 0x0000000001d1fe80 (size 0x00000180).
func (*inventoryPlayerHost) StripShulkerTooltipRequestResult() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).StripShulkerTooltipResult recovered at 0x0000000001d20180 (size 0x00000180).
func (*inventoryPlayerHost) StripShulkerTooltipResult() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).StripShulkerTooltipWithTrustedStack recovered at 0x0000000001d20480 (size 0x00000200).
func (*inventoryPlayerHost) StripShulkerTooltipWithTrustedStack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Swimming recovered at 0x0000000001d20880 (size 0x00000020).
func (*inventoryPlayerHost) Swimming() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SyncAutoSell recovered at 0x0000000001d208c0 (size 0x00000040).
func (*inventoryPlayerHost) SyncAutoSell() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SyncFriendAlerts recovered at 0x0000000001d20920 (size 0x00000040).
func (*inventoryPlayerHost) SyncFriendAlerts() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SyncModules recovered at 0x0000000001d209a0 (size 0x00000040).
func (*inventoryPlayerHost) SyncModules() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SyncShulkerTooltips recovered at 0x0000000001d20a00 (size 0x00000040).
func (*inventoryPlayerHost) SyncShulkerTooltips() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).SyncSpam recovered at 0x0000000001d20a80 (size 0x00000040).
func (*inventoryPlayerHost) SyncSpam() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Teleport recovered at 0x0000000001d20b00 (size 0x00000080).
func (*inventoryPlayerHost) Teleport() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).TeleportAndRotate recovered at 0x0000000001d20c00 (size 0x00000080).
func (*inventoryPlayerHost) TeleportAndRotate() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).TeleportMove recovered at 0x0000000001d20d00 (size 0x00000080).
func (*inventoryPlayerHost) TeleportMove() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).TeleportSelf recovered at 0x0000000001d20e00 (size 0x00000040).
func (*inventoryPlayerHost) TeleportSelf() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).ThunderstormIntensity recovered at 0x0000000001d20e60 (size 0x00000020).
func (*inventoryPlayerHost) ThunderstormIntensity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Tick recovered at 0x0000000001d20ea0 (size 0x00000040).
func (*inventoryPlayerHost) Tick() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).TickAutoFish recovered at 0x0000000001d20f00 (size 0x00000060).
func (*inventoryPlayerHost) TickAutoFish() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).TimerValue recovered at 0x0000000001d20fc0 (size 0x00000040).
func (*inventoryPlayerHost) TimerValue() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Title recovered at 0x0000000001d21040 (size 0x000000a0).
func (*inventoryPlayerHost) Title() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Toggle recovered at 0x0000000001d21180 (size 0x00000060).
func (*inventoryPlayerHost) Toggle() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Tr recovered at 0x0000000001d21200 (size 0x000000a0).
func (*inventoryPlayerHost) Tr() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).TrackLocalBlockPlacement recovered at 0x0000000001d21340 (size 0x00000040).
func (*inventoryPlayerHost) TrackLocalBlockPlacement() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).TrackUseItemTransaction recovered at 0x0000000001d213a0 (size 0x00000040).
func (*inventoryPlayerHost) TrackUseItemTransaction() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).TrustedShulkerTooltipHotBarItem recovered at 0x0000000001d21400 (size 0x00000120).
func (*inventoryPlayerHost) TrustedShulkerTooltipHotBarItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).TrustedShulkerTooltipSlotItem recovered at 0x0000000001d21560 (size 0x00000120).
func (*inventoryPlayerHost) TrustedShulkerTooltipSlotItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).TrustedShulkerTooltipStack recovered at 0x0000000001d216c0 (size 0x00000100).
func (*inventoryPlayerHost) TrustedShulkerTooltipStack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).TryFlushBlockBreakQueue recovered at 0x0000000001d218c0 (size 0x00000040).
func (*inventoryPlayerHost) TryFlushBlockBreakQueue() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).TryStartFastThrow recovered at 0x0000000001d21920 (size 0x00000040).
func (*inventoryPlayerHost) TryStartFastThrow() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).TryStartStashFinderScan recovered at 0x0000000001d21980 (size 0x000000a0).
func (*inventoryPlayerHost) TryStartStashFinderScan() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).UnknownItem recovered at 0x0000000001d21b40 (size 0x00000040).
func (*inventoryPlayerHost) UnknownItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).UpdateAbilities recovered at 0x0000000001d21ba0 (size 0x00000040).
func (*inventoryPlayerHost) UpdateAbilities() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).UpdateBoundingBoxes recovered at 0x0000000001d21c00 (size 0x00000040).
func (*inventoryPlayerHost) UpdateBoundingBoxes() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).UpdateClientSkin recovered at 0x0000000001d21c80 (size 0x00000080).
func (*inventoryPlayerHost) UpdateClientSkin() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).UpdateMetadata recovered at 0x0000000001d21d80 (size 0x00000040).
func (*inventoryPlayerHost) UpdateMetadata() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).UpdateServerSkin recovered at 0x0000000001d21de0 (size 0x00000100).
func (*inventoryPlayerHost) UpdateServerSkin() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).UpdateSkin recovered at 0x0000000001d21fe0 (size 0x00000040).
func (*inventoryPlayerHost) UpdateSkin() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).UseItemClickAir recovered at 0x0000000001d22040 (size 0x000000a0).
func (*inventoryPlayerHost) UseItemClickAir() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).UseItemRightClickAir recovered at 0x0000000001d22140 (size 0x00000040).
func (*inventoryPlayerHost) UseItemRightClickAir() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).UsingSocks5Proxy recovered at 0x0000000001d221a0 (size 0x00000020).
func (*inventoryPlayerHost) UsingSocks5Proxy() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Variant recovered at 0x0000000001d221e0 (size 0x00000040).
func (*inventoryPlayerHost) Variant() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Velocity recovered at 0x0000000001d22240 (size 0x000000c0).
func (*inventoryPlayerHost) Velocity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).Velocity32 recovered at 0x0000000001d223c0 (size 0x00000060).
func (*inventoryPlayerHost) Velocity32() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).VisibleHeldSlot recovered at 0x0000000001d22480 (size 0x00000020).
func (*inventoryPlayerHost) VisibleHeldSlot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).VisibleHoldingWeapon recovered at 0x0000000001d224c0 (size 0x00000040).
func (*inventoryPlayerHost) VisibleHoldingWeapon() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).WalkTeleportSelf recovered at 0x0000000001d22520 (size 0x00000040).
func (*inventoryPlayerHost) WalkTeleportSelf() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).WithinDistance recovered at 0x0000000001d22580 (size 0x000000e0).
func (*inventoryPlayerHost) WithinDistance() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).WithinView recovered at 0x0000000001d22740 (size 0x00000060).
func (*inventoryPlayerHost) WithinView() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).WithinView32 recovered at 0x0000000001d227e0 (size 0x00000060).
func (*inventoryPlayerHost) WithinView32() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).World recovered at 0x0000000001d22860 (size 0x00000020).
func (*inventoryPlayerHost) World() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).WorldUpdater recovered at 0x0000000001d228a0 (size 0x00000020).
func (*inventoryPlayerHost) WorldUpdater() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).WritePacket recovered at 0x0000000001d228e0 (size 0x00000060).
func (*inventoryPlayerHost) WritePacket() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).WritePacketDirect recovered at 0x0000000001d229a0 (size 0x00000060).
func (*inventoryPlayerHost) WritePacketDirect() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).WriteServerPacket recovered at 0x0000000001d22a60 (size 0x00000060).
func (*inventoryPlayerHost) WriteServerPacket() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).XrayFallingBlockClientVariant recovered at 0x0000000001d22b20 (size 0x00000060).
func (*inventoryPlayerHost) XrayFallingBlockClientVariant() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).XraySent recovered at 0x0000000001d22be0 (size 0x00000020).
func (*inventoryPlayerHost) XraySent() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).XraySettingsApplied recovered at 0x0000000001d22c20 (size 0x00000040).
func (*inventoryPlayerHost) XraySettingsApplied() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).XraySettingsPending recovered at 0x0000000001d22ca0 (size 0x00000040).
func (*inventoryPlayerHost) XraySettingsPending() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/player/component.(*inventoryPlayerHost).XrayShouldSuppressContainerOpen recovered at 0x0000000001d22d20 (size 0x00000080).
func (*inventoryPlayerHost) XrayShouldSuppressContainerOpen() {
	panic("stub")
}
