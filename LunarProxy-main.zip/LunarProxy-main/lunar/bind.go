package lunar

// Bind layer recovered from the gomobile Java proxy classes shipped in the
// release APK (lunar.App, lunar.Logger, ... in classes4.dex). The original Go
// core was bound with `gomobile bind` from this package; the Java proxy
// classes mirror the API below exactly.
//
// Bodies return zero values pending instruction-level reconstruction of the
// Go core; signatures are faithful to the released binary.

const ApiURL = "https://api-eu.lunarbedrock.com"

var ErrAuthTimedOut error

// New constructs the application entrypoint. The boolean argument selects the
// experimental renderer path in the released app.
func New(str string, b bool) *App { return &App{} }

// CoreVersion reports the Go core version embedded at build time.
func CoreVersion() string { return "" }

// App is the root object exposed to the React Native host through the
// lunargo Expo module. Every method is callable from the JS bridge.
type App struct {
	AuthState *AuthState
}

func (a *App) AnalyticsEnabled() bool                  { return false }
func (a *App) Authenticate(b bool)                     {}
func (a *App) CancelAuthentication()                   {}
func (a *App) ClearSkin()                              {}
func (a *App) ClientDeviceOS() string                  { return "" }
func (a *App) ContextDeadline() int32                  { return 0 }
func (a *App) CustomServers() string                   { return "" }
func (a *App) DeleteAccountByID(id string)             {}
func (a *App) DeviceOS() string                        { return "" }
func (a *App) DispatchInput(s string)                  {}
func (a *App) Ejected() bool                           { return false }
func (a *App) FastFlush() bool                         { return false }
func (a *App) FriendsJSON() string                     { return "" }
func (a *App) CurrentAccountID() string                { return "" }
func (a *App) ListAccountsJSON() string                { return "" }
func (a *App) LoadCachedAuth()                         {}
func (a *App) LoadSkinFromLocalFiles(a1, a2, a3 string) {}
func (a *App) Logout()                                 {}
func (a *App) ModulesJSON() string                     { return "" }
func (a *App) PingServers(s string) string             { return "" }
func (a *App) Port() int64                             { return 0 }
func (a *App) Premium() bool                           { return false }
func (a *App) ProxyingInfo() *ProxyInfo                { return &ProxyInfo{} }
func (a *App) ReadLog() string                         { return "" }
func (a *App) ReadLogWait() string                     { return "" }
func (a *App) RealmsJSON() string                      { return "" }
func (a *App) RecentServers() string                   { return "" }
func (a *App) RequestFriendsJSON() string              { return "" }
func (a *App) RequestRealmsJSON() string               { return "" }
func (a *App) ResolveRealm(s string) string            { return "" }
func (a *App) ResourcePackPaths() string               { return "" }
func (a *App) SaveSettings()                           {}
func (a *App) SetAnalyticsClientInfo(a1, a2 string)    {}
func (a *App) SetAnalyticsEnabled(b bool)              {}
func (a *App) SetContextDeadline(i int32)              {}
func (a *App) SetCustomServers(s string)               {}
func (a *App) SetDeviceOS(s string)                    {}
func (a *App) SetEjected(b bool)                       {}
func (a *App) SetFastFlush(b bool)                     {}
func (a *App) SetModuleEnabled(name string, b bool)    {}
func (a *App) SetModuleOverlayActive(b bool)           {}
func (a *App) SetModuleSetting(module, key, value string) {}
func (a *App) SetNetherNetLAN(b bool)                  {}
func (a *App) SetPort(p int64)                         {}
func (a *App) SetProxyAddress(a1, a2 string)           {}
func (a *App) SetRecentServers(s string)               {}
func (a *App) SetRequestProxyAddress(s string)         {}
func (a *App) SetResourcePackPaths(s string)           {}
func (a *App) SetSkinArmSize(s string)                 {}
func (a *App) SetUseCachedPacks(b bool)                {}
func (a *App) SetUserID(s string)                      {}
func (a *App) SkinArmSize() string                     { return "" }
func (a *App) SkinData() string                        { return "" }
func (a *App) SpoofDevice()                            {}
func (a *App) Start(a1, a2 string)                     {}
func (a *App) StartRedirectProxy(s string)             {}
func (a *App) StopRedirectProxy()                      {}
func (a *App) SwitchAccount(id string)                 {}
func (a *App) Terminate()                              {}
func (a *App) Terminated() bool                        { return false }
func (a *App) Token() string                           { return "" }
func (a *App) UnblockReadLog()                         {}
func (a *App) UseCachedPacks() bool                    { return false }
func (a *App) VersionInfo() *VersionInfo               { return &VersionInfo{} }
func (a *App) WriteMetricProxyAttempt(b bool, s string) {}
func (a *App) WriteMetricProxyJoin(a1, a2 string)      {}
func (a *App) WriteMetricSessionDuration(s string, ms int64) {}

// AuthState tracks the multi-account Microsoft (SISU) login state.
type AuthState struct{}

func (a *AuthState) Clear()               {}
func (a *AuthState) ClearDerivedClients() {}

// ProxyInfo describes the local proxy endpoints of an active session.
type ProxyInfo struct {
	LocalAddress  string
	RemoteAddress string
}

// VersionInfo reports the Minecraft version/protocol the core targets.
type VersionInfo struct {
	CurrentVersion  string
	CurrentProtocol int64
}

// ServerStatus is the result of a server ping.
type ServerStatus struct {
	Address string
	Online  bool
	PingMs  int64
}

// FriendWorld is a friends-only world resolved through NetherNet/XBL.
type FriendWorld struct {
	Gamertag                string
	XUID                    string
	WorldName               string
	MemberCount             int64
	MaxMembers              int64
	NetherNetID             string
	HandleID                string
	NethernetConnectionType int64
}

// RegionInfo is a geolocation record (ip-api.com) used for server selection.
type RegionInfo struct {
	Status      string
	Message     string
	Country     string
	CountryCode string
	Region      string
	RegionName  string
	City        string
	Timezone    string
	Query       string
}

// ConnectTarget is a resolved join target: a real server address plus the
// stable address and friend handle used to reach it through NetherNet.
type ConnectTarget struct {
	DialAddress    string
	StableAddress  string
	FriendHandleID string
	StatusSubtitle string
}

// Socks5Proxy is a user-provided SOCKS5 relay for the upstream connection.
type Socks5Proxy struct {
	Server   string
	Username string
	Password string
}

func (s *Socks5Proxy) String() string { return s.Server }

// ResourcePackPathData maps a resource pack name to its on-disk path.
type ResourcePackPathData struct {
	Name string
	Path string
}

// LogData is a single log event.
type LogData struct {
	Event string
}

// LokiLog is a structured log record shipped to the Loki endpoint.
type LokiLog struct {
	Source        string
	Message       string
	Error         error
	IncludeMemory bool
}

// Logger exposes the core's log stream to the host app.
type Logger struct{}

func (l *Logger) Read() string             { return "" }
func (l *Logger) ReadWait() string         { return "" }
func (l *Logger) Unblock()                 {}
func (l *Logger) WriteConnect(s string)    {}
func (l *Logger) WriteDebug(s string)      {}
func (l *Logger) WriteError(s, err string) {}
func (l *Logger) WriteFatal(s, err string) {}
func (l *Logger) WriteNeutral(s string)    {}
func (l *Logger) WriteSuccess(s string)    {}