// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package session

// Recovered types (from pclntab type descriptors).

// UpstreamDialResultEvent is a recovered type.
type UpstreamDialResultEvent struct{}

// slotRefresh·1 is a recovered type.
type slotRefresh_1 struct{}

// Placeholder receiver types (no equality descriptor in pclntab).

type DefaultDataProvider struct{}

type NopHandler struct{}

type Session struct{}

type nopPacketWriter struct{}

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// New recovered at 0x0000000001d306a0 (size 0x000009e0).
func New() {
	panic("stub")
}

// New.(*Session).installAvailableCommandsHooks.func1 recovered at 0x0000000001d310e0 (size 0x00000060).
func New___Session__installAvailableCommandsHooks_func1() {
	panic("stub")
}

// New.(*Session).installAvailableCommandsHooks.func2 recovered at 0x0000000001d31080 (size 0x00000060).
func New___Session__installAvailableCommandsHooks_func2() {
	panic("stub")
}

// NewDefaultDataProvider recovered at 0x0000000001d23f00 (size 0x00000100).
func NewDefaultDataProvider() {
	panic("stub")
}

// classifyInput recovered at 0x0000000001d24260 (size 0x000001e0).
func classifyInput() {
	panic("stub")
}

// collectServerCommandNames recovered at 0x0000000001d22f40 (size 0x000002c0).
func collectServerCommandNames() {
	panic("stub")
}

// filterServerPrefixCollisions recovered at 0x0000000001d23200 (size 0x00000320).
func filterServerPrefixCollisions() {
	panic("stub")
}

// lunarCustomBlocks recovered at 0x0000000001d23520 (size 0x00000080).
func lunarCustomBlocks() {
	panic("stub")
}

// lunarCustomBlocks.upstreamBlockNames.func1 recovered at 0x0000000001d235a0 (size 0x000000e0).
func lunarCustomBlocks_upstreamBlockNames_func1() {
	panic("stub")
}

// matchName recovered at 0x0000000001d2f940 (size 0x000000c0).
func matchName() {
	panic("stub")
}

// parseSlashCommandName recovered at 0x0000000001d22e20 (size 0x00000120).
func parseSlashCommandName() {
	panic("stub")
}

// refreshFallingBlockMetadataAfterMove recovered at 0x0000000001d33a60 (size 0x000003e0).
func refreshFallingBlockMetadataAfterMove() {
	panic("stub")
}

// rewriteNick recovered at 0x0000000001d2f360 (size 0x000005e0).
func rewriteNick() {
	panic("stub")
}

// stackRequestSourceNetworkIDs recovered at 0x0000000001d32fe0 (size 0x00000320).
func stackRequestSourceNetworkIDs() {
	panic("stub")
}

// stripClientShulkerTooltips recovered at 0x0000000001d319a0 (size 0x000008e0).
func stripClientShulkerTooltips() {
	panic("stub")
}

// stripShulkerTooltipActions recovered at 0x0000000001d33300 (size 0x00000480).
func stripShulkerTooltipActions() {
	panic("stub")
}

// stripShulkerTooltipHeld recovered at 0x0000000001d323c0 (size 0x000001e0).
func stripShulkerTooltipHeld() {
	panic("stub")
}

// stripShulkerTooltipItem recovered at 0x0000000001d325a0 (size 0x000005c0).
func stripShulkerTooltipItem() {
	panic("stub")
}

// stripShulkerTooltipStackRequest recovered at 0x0000000001d32b60 (size 0x00000480).
func stripShulkerTooltipStackRequest() {
	panic("stub")
}

// stripShulkerTooltipTransaction recovered at 0x0000000001d32280 (size 0x00000140).
func stripShulkerTooltipTransaction() {
	panic("stub")
}

// submitFormResponse recovered at 0x0000000001d24e60 (size 0x00000180).
func submitFormResponse() {
	panic("stub")
}

// translateEntityMetadataToClient recovered at 0x0000000001d338e0 (size 0x00000180).
func translateEntityMetadataToClient() {
	panic("stub")
}

// trustedInventoryActionItem recovered at 0x0000000001d33780 (size 0x00000160).
func trustedInventoryActionItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*DefaultDataProvider).AuthRepository recovered at 0x0000000001d24220 (size 0x00000020).
func (*DefaultDataProvider) AuthRepository() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*DefaultDataProvider).ConfigStore recovered at 0x0000000001d24240 (size 0x00000020).
func (*DefaultDataProvider) ConfigStore() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*DefaultDataProvider).PlayerConfig recovered at 0x0000000001d24000 (size 0x00000120).
func (*DefaultDataProvider) PlayerConfig() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*DefaultDataProvider).SavePlayerConfig recovered at 0x0000000001d24120 (size 0x00000100).
func (*DefaultDataProvider) SavePlayerConfig() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*NopHandler).HandleListenerConnect recovered at 0x0000000001d24e20 (size 0x00000020).
func (*NopHandler) HandleListenerConnect() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*NopHandler).HandlePlayerJoin recovered at 0x0000000001d24dc0 (size 0x00000020).
func (*NopHandler) HandlePlayerJoin() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*NopHandler).HandlePlayerQuit recovered at 0x0000000001d24de0 (size 0x00000020).
func (*NopHandler) HandlePlayerQuit() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*NopHandler).HandleUpstreamDialResult recovered at 0x0000000001d24e00 (size 0x00000020).
func (*NopHandler) HandleUpstreamDialResult() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).ClientConn recovered at 0x0000000001d31960 (size 0x00000020).
func (*Session) ClientConn() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).ClientDeviceOS recovered at 0x0000000001d24c80 (size 0x00000140).
func (*Session) ClientDeviceOS() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).Close recovered at 0x0000000001d31300 (size 0x00000060).
func (*Session) Close() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).CreatedAt recovered at 0x0000000001d31180 (size 0x00000020).
func (*Session) CreatedAt() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).DispatchInput recovered at 0x0000000001d24440 (size 0x00000280).
func (*Session) DispatchInput() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).Ejected recovered at 0x0000000001d31160 (size 0x00000020).
func (*Session) Ejected() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).ForwardServerPacket recovered at 0x0000000001d27460 (size 0x00000260).
func (*Session) ForwardServerPacket() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).HandleClientPacket recovered at 0x0000000001d25660 (size 0x00001ce0).
func (*Session) HandleClientPacket() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).HandleServerPacket recovered at 0x0000000001d273e0 (size 0x00000060).
func (*Session) HandleServerPacket() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).ModuleOverlayActive recovered at 0x0000000001d2ede0 (size 0x00000020).
func (*Session) ModuleOverlayActive() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).ModuleOverlaySnapshot recovered at 0x0000000001d2ee00 (size 0x00000020).
func (*Session) ModuleOverlaySnapshot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).OnSpawn recovered at 0x0000000001d24fe0 (size 0x00000500).
func (*Session) OnSpawn() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).Player recovered at 0x0000000001d31140 (size 0x00000020).
func (*Session) Player() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).QueueModuleOverlayAction recovered at 0x0000000001d2ee20 (size 0x00000260).
func (*Session) QueueModuleOverlayAction() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).ServerConn recovered at 0x0000000001d31980 (size 0x00000020).
func (*Session) ServerConn() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).SetEjected recovered at 0x0000000001d31260 (size 0x000000a0).
func (*Session) SetEjected() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).SetModuleOverlayActive recovered at 0x0000000001d2edc0 (size 0x00000020).
func (*Session) SetModuleOverlayActive() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).appendCustomItems recovered at 0x0000000001d23ac0 (size 0x00000440).
func (*Session) appendCustomItems() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).applyNickAddPlayer recovered at 0x0000000001d2ff40 (size 0x000000c0).
func (*Session) applyNickAddPlayer() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).applyNickBossEvent recovered at 0x0000000001d30320 (size 0x00000120).
func (*Session) applyNickBossEvent() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).applyNickCommandOutput recovered at 0x0000000001d30440 (size 0x00000260).
func (*Session) applyNickCommandOutput() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).applyNickPlayerList recovered at 0x0000000001d2fdc0 (size 0x00000180).
func (*Session) applyNickPlayerList() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).applyNickSetDisplayObjective recovered at 0x0000000001d30160 (size 0x000000a0).
func (*Session) applyNickSetDisplayObjective() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).applyNickSetScore recovered at 0x0000000001d30000 (size 0x00000160).
func (*Session) applyNickSetScore() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).applyNickSetTitle recovered at 0x0000000001d30200 (size 0x00000120).
func (*Session) applyNickSetTitle() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).applyNickText recovered at 0x0000000001d2fb80 (size 0x00000240).
func (*Session) applyNickText() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).clientSafePlayerUUID recovered at 0x0000000001d2e340 (size 0x000002a0).
func (*Session) clientSafePlayerUUID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).cmdCtx recovered at 0x0000000001d24e40 (size 0x00000020).
func (*Session) cmdCtx() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).drainModuleOverlayActions recovered at 0x0000000001d2f100 (size 0x00000260).
func (*Session) drainModuleOverlayActions() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).drainPendingInputs recovered at 0x0000000001d24740 (size 0x00000140).
func (*Session) drainPendingInputs() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).handleCommandRequest recovered at 0x0000000001d249a0 (size 0x00000140).
func (*Session) handleCommandRequest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).handleEntityMDBBox recovered at 0x0000000001d2e5e0 (size 0x00000440).
func (*Session) handleEntityMDBBox() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).handleServerBlockUpdate recovered at 0x0000000001d2e160 (size 0x000001a0).
func (*Session) handleServerBlockUpdate() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).handleServerPacket recovered at 0x0000000001d27740 (size 0x00006940).
func (*Session) handleServerPacket() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).handleTextCommand recovered at 0x0000000001d24ae0 (size 0x00000100).
func (*Session) handleTextCommand() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).loadCustomBlocks recovered at 0x0000000001d23680 (size 0x00000440).
func (*Session) loadCustomBlocks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).nickReplacement recovered at 0x0000000001d2fa00 (size 0x00000180).
func (*Session) nickReplacement() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).routeQueuedInput recovered at 0x0000000001d24880 (size 0x00000120).
func (*Session) routeQueuedInput() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).safeOperation recovered at 0x0000000001d2ea20 (size 0x000000e0).
func (*Session) safeOperation() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).serverHasCommand recovered at 0x0000000001d311a0 (size 0x000000c0).
func (*Session) serverHasCommand() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*Session).tryExecuteProxyCommand recovered at 0x0000000001d24be0 (size 0x000000a0).
func (*Session) tryExecuteProxyCommand() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session.(*nopPacketWriter).WritePacket recovered at 0x0000000001d27440 (size 0x00000020).
func (*nopPacketWriter) WritePacket() {
	panic("stub")
}
