// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package authrepo

// Recovered types (from pclntab type descriptors).

// Account is a recovered type.
type Account struct{}

// FileAuthStore is a recovered type.
type FileAuthStore struct{}

// MinecraftXBLTokenCache is a recovered type.
type MinecraftXBLTokenCache struct{}

// XBLTokenCache is a recovered type.
type XBLTokenCache struct{}

// Placeholder receiver types (no equality descriptor in pclntab).

type AuthRepo struct{}

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// FirstAccountID recovered at 0x00000000016d56c0 (size 0x00000200).
func FirstAccountID() {
	panic("stub")
}

// atomicWriteFile recovered at 0x00000000016d2d60 (size 0x00000340).
func atomicWriteFile() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session/authrepo.(*Account).EffectiveTime recovered at 0x00000000016d5680 (size 0x00000040).
func (*Account) EffectiveTime() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session/authrepo.(*AuthRepo).AddAccount recovered at 0x00000000016d3d80 (size 0x00000180).
func (*AuthRepo) AddAccount() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session/authrepo.(*AuthRepo).DeleteByID recovered at 0x00000000016d4fe0 (size 0x000000e0).
func (*AuthRepo) DeleteByID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session/authrepo.(*AuthRepo).DeleteCurrent recovered at 0x00000000016d5340 (size 0x00000080).
func (*AuthRepo) DeleteCurrent() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session/authrepo.(*AuthRepo).FindByGamertag recovered at 0x00000000016d53c0 (size 0x000001e0).
func (*AuthRepo) FindByGamertag() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session/authrepo.(*AuthRepo).List recovered at 0x00000000016d40e0 (size 0x00000260).
func (*AuthRepo) List() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session/authrepo.(*AuthRepo).LoadCurrent recovered at 0x00000000016d35c0 (size 0x000001a0).
func (*AuthRepo) LoadCurrent() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session/authrepo.(*AuthRepo).PlayerToken recovered at 0x00000000016d55a0 (size 0x000000e0).
func (*AuthRepo) PlayerToken() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session/authrepo.(*AuthRepo).SaveCurrent recovered at 0x00000000016d3760 (size 0x000001e0).
func (*AuthRepo) SaveCurrent() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session/authrepo.(*AuthRepo).SetCurrentByID recovered at 0x00000000016d4340 (size 0x000000e0).
func (*AuthRepo) SetCurrentByID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session/authrepo.(*AuthRepo).SetXBLTokenWithDedup recovered at 0x00000000016d4980 (size 0x00000100).
func (*AuthRepo) SetXBLTokenWithDedup() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session/authrepo.(*AuthRepo).UpdateByID recovered at 0x00000000016d4680 (size 0x00000100).
func (*AuthRepo) UpdateByID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session/authrepo.(*AuthRepo).loadAccountStore recovered at 0x00000000016d3100 (size 0x00000120).
func (*AuthRepo) loadAccountStore() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session/authrepo.(*AuthRepo).migrateFromLegacy recovered at 0x00000000016d32e0 (size 0x000002e0).
func (*AuthRepo) migrateFromLegacy() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session/authrepo.(*AuthRepo).saveAccountStore recovered at 0x00000000016d3220 (size 0x000000c0).
func (*AuthRepo) saveAccountStore() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session/authrepo.(*FileAuthStore).DeleteAccountStore recovered at 0x00000000016d2380 (size 0x000001a0).
func (*FileAuthStore) DeleteAccountStore() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session/authrepo.(*FileAuthStore).DeleteLegacyToken recovered at 0x00000000016d2720 (size 0x000001a0).
func (*FileAuthStore) DeleteLegacyToken() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session/authrepo.(*FileAuthStore).LoadAccountStore recovered at 0x00000000016d1fe0 (size 0x00000180).
func (*FileAuthStore) LoadAccountStore() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session/authrepo.(*FileAuthStore).LoadLegacyToken recovered at 0x00000000016d2560 (size 0x00000180).
func (*FileAuthStore) LoadLegacyToken() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session/authrepo.(*FileAuthStore).SaveAccountStore recovered at 0x00000000016d21a0 (size 0x000001a0).
func (*FileAuthStore) SaveAccountStore() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/session/authrepo.(*FileAuthStore).UpdateAccountStore recovered at 0x00000000016d2900 (size 0x00000420).
func (*FileAuthStore) UpdateAccountStore() {
	panic("stub")
}
