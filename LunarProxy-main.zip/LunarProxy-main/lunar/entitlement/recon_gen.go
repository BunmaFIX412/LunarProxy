// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package entitlement

// Recovered types (from pclntab type descriptors).

// Claims is a recovered type.
type Claims struct{}

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// Verify recovered at 0x0000000001996900 (size 0x00000440).
func Verify() {
	panic("stub")
}

// init recovered at 0x00000000019968c0 (size 0x00000040).
func init() {
	panic("stub")
}
