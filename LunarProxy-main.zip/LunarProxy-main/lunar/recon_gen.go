// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package lunar

// Recovered types (from pclntab type descriptors).

// accountDTO·1 is a recovered type.
type accountDTO_1 struct{}

// analyticsDimensions is a recovered type.
type analyticsDimensions struct{}

// analyticsEvent is a recovered type.
type analyticsEvent struct{}

// analyticsSession is a recovered type.
type analyticsSession struct{}

// authSnapshot is a recovered type.
type authSnapshot struct{}

// builtServiceTokenSource·4 is a recovered type.
type builtServiceTokenSource_4 struct{}

// connectionLogMetadata is a recovered type.
type connectionLogMetadata struct{}

// contextCancelRoundTripper is a recovered type.
type contextCancelRoundTripper struct{}

// debugHTTPRoundTripper is a recovered type.
type debugHTTPRoundTripper struct{}

// fileAttempt·5 is a recovered type.
type fileAttempt_5 struct{}

// friendJoin is a recovered type.
type friendJoin struct{}

// minecraftDialTokenSource is a recovered type.
type minecraftDialTokenSource struct{}

// resolvedDialTarget is a recovered type.
type resolvedDialTarget struct{}

// settings is a recovered type.
type settings struct{}

// skinData is a recovered type.
type skinData struct{}

// upstreamConnectError is a recovered type.
type upstreamConnectError struct{}

// upstreamDialPhaseError is a recovered type.
type upstreamDialPhaseError struct{}

// Placeholder receiver types (no equality descriptor in pclntab).

type analyticsClient struct{}

type errorWriter struct{}

type httpAnalyticsTransport struct{}

type lunarStatusProvider struct{}

type nethernetTransport struct{}

type redirectProxy struct{}

type releaseOnCloseBody struct{}

type retryAuthHTTPRoundTripper struct{}

type socks5RakNetDialer struct{}

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// InferTargetKind recovered at 0x0000000001d796e0 (size 0x000000e0).
func InferTargetKind() {
	panic("stub")
}

// accountCreationRequiredAuthError recovered at 0x0000000001d527c0 (size 0x00000080).
func accountCreationRequiredAuthError() {
	panic("stub")
}

// analyticsServerID recovered at 0x0000000001d4e1c0 (size 0x000000a0).
func analyticsServerID() {
	panic("stub")
}

// authSnapshot.newSession recovered at 0x0000000001d555a0 (size 0x00000100).
func authSnapshot_newSession() {
	panic("stub")
}

// baseContext recovered at 0x0000000001d55300 (size 0x000000e0).
func baseContext() {
	panic("stub")
}

// buildCustomSkinFromData recovered at 0x0000000001d77f60 (size 0x000008a0).
func buildCustomSkinFromData() {
	panic("stub")
}

// canonicalTargetIdentityAddress recovered at 0x0000000001d798c0 (size 0x000001c0).
func canonicalTargetIdentityAddress() {
	panic("stub")
}

// closeWithTimeout recovered at 0x0000000001d67b00 (size 0x00000200).
func closeWithTimeout() {
	panic("stub")
}

// coarseAnalyticsRegion recovered at 0x0000000001d4e0e0 (size 0x000000e0).
func coarseAnalyticsRegion() {
	panic("stub")
}

// cutPrefixFold recovered at 0x0000000001d79c40 (size 0x000000c0).
func cutPrefixFold() {
	panic("stub")
}

// debugHTTPClient recovered at 0x0000000001d5f600 (size 0x00000180).
func debugHTTPClient() {
	panic("stub")
}

// debugHTTPEnabled recovered at 0x0000000001d5f580 (size 0x00000080).
func debugHTTPEnabled() {
	panic("stub")
}

// debugHTTPHeaders recovered at 0x0000000001d5ff80 (size 0x00000240).
func debugHTTPHeaders() {
	panic("stub")
}

// debugHTTPLogBody recovered at 0x0000000001d605e0 (size 0x000000c0).
func debugHTTPLogBody() {
	panic("stub")
}

// debugHTTPRedactHeader recovered at 0x0000000001d601c0 (size 0x00000140).
func debugHTTPRedactHeader() {
	panic("stub")
}

// debugHTTPRequestBody recovered at 0x0000000001d60300 (size 0x000002e0).
func debugHTTPRequestBody() {
	panic("stub")
}

// debugHTTPURL recovered at 0x0000000001d5fea0 (size 0x000000e0).
func debugHTTPURL() {
	panic("stub")
}

// derivedAuthClients.close recovered at 0x0000000001d553e0 (size 0x000000c0).
func derivedAuthClients_close() {
	panic("stub")
}

// dialErrorCause recovered at 0x0000000001d6eec0 (size 0x00000080).
func dialErrorCause() {
	panic("stub")
}

// disconnectReason recovered at 0x0000000001d598a0 (size 0x000002a0).
func disconnectReason() {
	panic("stub")
}

// fetchSentryDSN recovered at 0x0000000001d6fd00 (size 0x00000240).
func fetchSentryDSN() {
	panic("stub")
}

// friendDialTarget recovered at 0x0000000001d5a740 (size 0x00000300).
func friendDialTarget() {
	panic("stub")
}

// friendWorldFromP2PWorld recovered at 0x0000000001d5edc0 (size 0x00000660).
func friendWorldFromP2PWorld() {
	panic("stub")
}

// friendXUIDFromAddress recovered at 0x0000000001d5a280 (size 0x000000c0).
func friendXUIDFromAddress() {
	panic("stub")
}

// handleRedirectConn recovered at 0x0000000001d76320 (size 0x00000560).
func handleRedirectConn() {
	panic("stub")
}

// hashTargetIdentity recovered at 0x0000000001d79a80 (size 0x00000140).
func hashTargetIdentity() {
	panic("stub")
}

// init recovered at 0x0000000001d4ab80 (size 0x000000e0).
func init() {
	panic("stub")
}

// init.0 recovered at 0x0000000001d615e0 (size 0x00000020).
func init_0() {
	panic("stub")
}

// isRealmAddress recovered at 0x0000000001d79de0 (size 0x00000080).
func isRealmAddress() {
	panic("stub")
}

// joinedResolvedDialTargetFromFriendWorld recovered at 0x0000000001d5ae00 (size 0x00000660).
func joinedResolvedDialTargetFromFriendWorld() {
	panic("stub")
}

// lazyAuthInit recovered at 0x0000000001d7b180 (size 0x000005a0).
func lazyAuthInit() {
	panic("stub")
}

// missingFriendUpstream recovered at 0x0000000001d5d720 (size 0x00000100).
func missingFriendUpstream() {
	panic("stub")
}

// nethernetOfferSignalConnectionClosed recovered at 0x0000000001d6eb80 (size 0x00000100).
func nethernetOfferSignalConnectionClosed() {
	panic("stub")
}

// nethernetTargetStale recovered at 0x0000000001d6ee00 (size 0x000000c0).
func nethernetTargetStale() {
	panic("stub")
}

// nethernetTurnAuthConnectionClosed recovered at 0x0000000001d6eaa0 (size 0x000000e0).
func nethernetTurnAuthConnectionClosed() {
	panic("stub")
}

// nethernetWebRTCAPI recovered at 0x0000000001d6aae0 (size 0x00000060).
func nethernetWebRTCAPI() {
	panic("stub")
}

// newAnalyticsClient recovered at 0x0000000001d4b200 (size 0x00000220).
func newAnalyticsClient() {
	panic("stub")
}

// newDefaultAnalyticsClient recovered at 0x0000000001d4b420 (size 0x00000080).
func newDefaultAnalyticsClient() {
	panic("stub")
}

// normalizeSocks5Proxies recovered at 0x0000000001d71840 (size 0x00000220).
func normalizeSocks5Proxies() {
	panic("stub")
}

// normalizeSocks5Server recovered at 0x0000000001d71a60 (size 0x00000140).
func normalizeSocks5Server() {
	panic("stub")
}

// normalizedTargetIdentity recovered at 0x0000000001d797c0 (size 0x00000100).
func normalizedTargetIdentity() {
	panic("stub")
}

// pingServer recovered at 0x0000000001d76d80 (size 0x00000460).
func pingServer() {
	panic("stub")
}

// redirectAcceptLoop recovered at 0x0000000001d75f60 (size 0x000002c0).
func redirectAcceptLoop() {
	panic("stub")
}

// requestFriendsWithTimeout recovered at 0x0000000001d5a340 (size 0x00000140).
func requestFriendsWithTimeout() {
	panic("stub")
}

// resolvedDialTargetFromFriendSession recovered at 0x0000000001d5aa40 (size 0x000003c0).
func resolvedDialTargetFromFriendSession() {
	panic("stub")
}

// resolvedTargetFromRealmAddress recovered at 0x0000000001d72f80 (size 0x000003c0).
func resolvedTargetFromRealmAddress() {
	panic("stub")
}

// retryableDeviceAuthPollNetworkError recovered at 0x0000000001d52460 (size 0x00000240).
func retryableDeviceAuthPollNetworkError() {
	panic("stub")
}

// serviceDeviceID recovered at 0x0000000001d554a0 (size 0x00000100).
func serviceDeviceID() {
	panic("stub")
}

// shouldIgnoreCachedAuthRefreshError recovered at 0x0000000001d523e0 (size 0x00000080).
func shouldIgnoreCachedAuthRefreshError() {
	panic("stub")
}

// targetIdentityHash recovered at 0x0000000001d79bc0 (size 0x00000080).
func targetIdentityHash() {
	panic("stub")
}

// terminalXboxAuthError recovered at 0x0000000001d526a0 (size 0x00000120).
func terminalXboxAuthError() {
	panic("stub")
}

// trimRealmCodePrefix recovered at 0x0000000001d79d00 (size 0x000000e0).
func trimRealmCodePrefix() {
	panic("stub")
}

// upstreamDialEventFromError recovered at 0x0000000001d7a2e0 (size 0x000001e0).
func upstreamDialEventFromError() {
	panic("stub")
}

// upstreamDialFailureReason recovered at 0x0000000001d7a4c0 (size 0x00000200).
func upstreamDialFailureReason() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).AuthenticateContext recovered at 0x0000000001d508a0 (size 0x00000480).
func (*App) AuthenticateContext() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).Compression recovered at 0x0000000001d62c80 (size 0x00000020).
func (*App) Compression() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).CustomSkin recovered at 0x0000000001d78d60 (size 0x00000020).
func (*App) CustomSkin() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).GetAuthState recovered at 0x0000000001d54940 (size 0x00000020).
func (*App) GetAuthState() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).GetCurrentAccountID recovered at 0x0000000001d548c0 (size 0x00000080).
func (*App) GetCurrentAccountID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).Handler recovered at 0x0000000001d63060 (size 0x00000020).
func (*App) Handler() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).ReadLogBlocking recovered at 0x0000000001d60a20 (size 0x00000020).
func (*App) ReadLogBlocking() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).Realms recovered at 0x0000000001d71ba0 (size 0x00000020).
func (*App) Realms() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).RealmsClient recovered at 0x0000000001d746e0 (size 0x00000040).
func (*App) RealmsClient() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).RequestFriends recovered at 0x0000000001d5e560 (size 0x00000860).
func (*App) RequestFriends() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).RequestRealms recovered at 0x0000000001d71bc0 (size 0x00000260).
func (*App) RequestRealms() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).ResolveRealmByCode recovered at 0x0000000001d72dc0 (size 0x000001c0).
func (*App) ResolveRealmByCode() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).Session recovered at 0x0000000001d6aac0 (size 0x00000020).
func (*App) Session() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).SetAuthHTTPTransportHook recovered at 0x0000000001d62d60 (size 0x00000060).
func (*App) SetAuthHTTPTransportHook() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).SetCompression recovered at 0x0000000001d62c00 (size 0x00000080).
func (*App) SetCompression() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).SetCustomSkin recovered at 0x0000000001d78d80 (size 0x00000060).
func (*App) SetCustomSkin() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).SetDataProvider recovered at 0x0000000001d62a40 (size 0x00000060).
func (*App) SetDataProvider() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).SetHandler recovered at 0x0000000001d62b00 (size 0x00000060).
func (*App) SetHandler() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).SetHostedPacks recovered at 0x0000000001d630c0 (size 0x00000080).
func (*App) SetHostedPacks() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).SetNethernetWebRTCAPI recovered at 0x0000000001d6ab40 (size 0x00000060).
func (*App) SetNethernetWebRTCAPI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).SetPacketBatchFunc recovered at 0x0000000001d62d00 (size 0x00000060).
func (*App) SetPacketBatchFunc() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).SetPacketFunc recovered at 0x0000000001d62ca0 (size 0x00000060).
func (*App) SetPacketFunc() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).SetProtocolMismatchObserver recovered at 0x0000000001d71120 (size 0x00000060).
func (*App) SetProtocolMismatchObserver() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).SetSocks5Proxies recovered at 0x0000000001d62b60 (size 0x000000a0).
func (*App) SetSocks5Proxies() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).StartContext recovered at 0x0000000001d63400 (size 0x000000c0).
func (*App) StartContext() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).StartTargetContext recovered at 0x0000000001d634c0 (size 0x00001a60).
func (*App) StartTargetContext() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).WriteLoki recovered at 0x0000000001d4e260 (size 0x000000c0).
func (*App) WriteLoki() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).adoptFriendTarget recovered at 0x0000000001d5d820 (size 0x00000120).
func (*App) adoptFriendTarget() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).analyticsDimensions recovered at 0x0000000001d4dd40 (size 0x000003a0).
func (*App) analyticsDimensions() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).applyResolvedFriendTarget recovered at 0x0000000001d65260 (size 0x00000160).
func (*App) applyResolvedFriendTarget() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).applyResolvedUpstreamTarget recovered at 0x0000000001d657e0 (size 0x00000280).
func (*App) applyResolvedUpstreamTarget() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).authenticateWithRetries recovered at 0x0000000001d52840 (size 0x00000580).
func (*App) authenticateWithRetries() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).beginSession recovered at 0x0000000001d6ffa0 (size 0x00000080).
func (*App) beginSession() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).cancellableAuthContext recovered at 0x0000000001d51f20 (size 0x000001a0).
func (*App) cancellableAuthContext() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).clearAuth recovered at 0x0000000001d52dc0 (size 0x00000080).
func (*App) clearAuth() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).clearRelay recovered at 0x0000000001d6a9a0 (size 0x000000e0).
func (*App) clearRelay() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).closeStep recovered at 0x0000000001d680e0 (size 0x00000180).
func (*App) closeStep() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).dialAttemptContext recovered at 0x0000000001d6ec80 (size 0x00000180).
func (*App) dialAttemptContext() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).dialUpstream recovered at 0x0000000001d6a3c0 (size 0x000004c0).
func (*App) dialUpstream() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).dialWithRetries recovered at 0x0000000001d6afa0 (size 0x00003b00).
func (*App) dialWithRetries() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).endAnalyticsSession recovered at 0x0000000001d4da80 (size 0x00000100).
func (*App) endAnalyticsSession() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).fetchLocalAddress recovered at 0x0000000001d6fba0 (size 0x00000160).
func (*App) fetchLocalAddress() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).formatError recovered at 0x0000000001d6f880 (size 0x000001a0).
func (*App) formatError() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).handleConnection recovered at 0x0000000001d66120 (size 0x000007a0).
func (*App) handleConnection() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).handleDisconnect recovered at 0x0000000001d67180 (size 0x00000520).
func (*App) handleDisconnect() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).handleDownstreamPacket recovered at 0x0000000001d66c40 (size 0x000000a0).
func (*App) handleDownstreamPacket() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).handleSpawn recovered at 0x0000000001d65b20 (size 0x00000320).
func (*App) handleSpawn() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).handleTransfer recovered at 0x0000000001d66ce0 (size 0x00000460).
func (*App) handleTransfer() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).handleUpstreamPacket recovered at 0x0000000001d66ba0 (size 0x000000a0).
func (*App) handleUpstreamPacket() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).joinedResolvedDialTargetFromFriendHandle recovered at 0x0000000001d5b460 (size 0x00000640).
func (*App) joinedResolvedDialTargetFromFriendHandle() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).loadCachedAuth recovered at 0x0000000001d514e0 (size 0x00000a40).
func (*App) loadCachedAuth() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).loadSettings recovered at 0x0000000001d771e0 (size 0x000000c0).
func (*App) loadSettings() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).logDisconnectObservation recovered at 0x0000000001d59b40 (size 0x000006a0).
func (*App) logDisconnectObservation() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).lookupAndSaveGamertag recovered at 0x0000000001d54d00 (size 0x00000600).
func (*App) lookupAndSaveGamertag() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).lookupRealmAddressByID recovered at 0x0000000001d74220 (size 0x000004c0).
func (*App) lookupRealmAddressByID() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).lookupRealmByCode recovered at 0x0000000001d73340 (size 0x00000ee0).
func (*App) lookupRealmByCode() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).nethernetSignalingConfig recovered at 0x0000000001d6adc0 (size 0x000001e0).
func (*App) nethernetSignalingConfig() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).prepareUpstreamDialer recovered at 0x0000000001d65a60 (size 0x000000c0).
func (*App) prepareUpstreamDialer() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).protocolMismatchMessage recovered at 0x0000000001d71180 (size 0x00000240).
func (*App) protocolMismatchMessage() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).queueOverlayAction recovered at 0x0000000001d70540 (size 0x000000a0).
func (*App) queueOverlayAction() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).readPacksFromPaths recovered at 0x0000000001d77620 (size 0x00000220).
func (*App) readPacksFromPaths() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).rebuildCustomSkin recovered at 0x0000000001d78800 (size 0x000004c0).
func (*App) rebuildCustomSkin() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).refreshNethernetTarget recovered at 0x0000000001d5dd60 (size 0x000005e0).
func (*App) refreshNethernetTarget() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).relaySnapshot recovered at 0x0000000001d6a880 (size 0x000000e0).
func (*App) relaySnapshot() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).requestFriends recovered at 0x0000000001d5a480 (size 0x00000080).
func (*App) requestFriends() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).requestRegionInfo recovered at 0x0000000001d50280 (size 0x000005e0).
func (*App) requestRegionInfo() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).requestToken recovered at 0x0000000001d53ac0 (size 0x000008e0).
func (*App) requestToken() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).resetSessionLifecycle recovered at 0x0000000001d66a60 (size 0x00000100).
func (*App) resetSessionLifecycle() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).resolveFriendUpstream recovered at 0x0000000001d5baa0 (size 0x00001c80).
func (*App) resolveFriendUpstream() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).resolveInitialFriendUpstream recovered at 0x0000000001d5d940 (size 0x00000420).
func (*App) resolveInitialFriendUpstream() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).resolveRealm recovered at 0x0000000001d72080 (size 0x00000160).
func (*App) resolveRealm() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).resolveRealmAddressForTarget recovered at 0x0000000001d5a500 (size 0x00000240).
func (*App) resolveRealmAddressForTarget() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).resolveRealmAddressIdentity recovered at 0x0000000001d721e0 (size 0x00000be0).
func (*App) resolveRealmAddressIdentity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).retireSession recovered at 0x0000000001d676e0 (size 0x000001c0).
func (*App) retireSession() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).runBackgroundTask recovered at 0x0000000001d62860 (size 0x000000a0).
func (*App) runBackgroundTask() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).sendJsonRequest recovered at 0x0000000001d4f9c0 (size 0x00000180).
func (*App) sendJsonRequest() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).sessionLogFields recovered at 0x0000000001d79ee0 (size 0x00000340).
func (*App) sessionLogFields() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).setupNetwork recovered at 0x0000000001d6aba0 (size 0x000001a0).
func (*App) setupNetwork() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).spoofClientData recovered at 0x0000000001d6ef40 (size 0x00000820).
func (*App) spoofClientData() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).spoofIdentityData recovered at 0x0000000001d6f760 (size 0x00000120).
func (*App) spoofIdentityData() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).startAnalyticsSession recovered at 0x0000000001d4d960 (size 0x00000120).
func (*App) startAnalyticsSession() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).startRelay recovered at 0x0000000001d685a0 (size 0x00001780).
func (*App) startRelay() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).stopProxy recovered at 0x0000000001d68260 (size 0x000002e0).
func (*App) stopProxy() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).targetMetricsAddress recovered at 0x0000000001d651e0 (size 0x00000080).
func (*App) targetMetricsAddress() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).tokenSource recovered at 0x0000000001d52f20 (size 0x00000620).
func (*App) tokenSource() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).tryRefreshCachedAccount recovered at 0x0000000001d535c0 (size 0x00000480).
func (*App) tryRefreshCachedAccount() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).updateConnectionStatus recovered at 0x0000000001d6fa20 (size 0x00000180).
func (*App) updateConnectionStatus() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).updateResolvedFriendCache recovered at 0x0000000001d653c0 (size 0x00000420).
func (*App) updateResolvedFriendCache() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).verifyEntitlement recovered at 0x0000000001d63240 (size 0x000001c0).
func (*App) verifyEntitlement() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*App).writeLoki recovered at 0x0000000001d4e400 (size 0x00000ec0).
func (*App) writeLoki() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*AuthState).Account recovered at 0x0000000001d593a0 (size 0x000000c0).
func (*AuthState) Account() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*AuthState).AuthorizationEnvironment recovered at 0x0000000001d56140 (size 0x00000100).
func (*AuthState) AuthorizationEnvironment() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*AuthState).BaseContext recovered at 0x0000000001d580e0 (size 0x000001e0).
func (*AuthState) BaseContext() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*AuthState).EnsureXBLTokenCache recovered at 0x0000000001d59060 (size 0x00000340).
func (*AuthState) EnsureXBLTokenCache() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*AuthState).HTTPClient recovered at 0x0000000001d58be0 (size 0x00000200).
func (*AuthState) HTTPClient() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*AuthState).Load recovered at 0x0000000001d587e0 (size 0x000001c0).
func (*AuthState) Load() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*AuthState).P2PAuth recovered at 0x0000000001d57d40 (size 0x000000c0).
func (*AuthState) P2PAuth() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*AuthState).PlayFabClient recovered at 0x0000000001d56740 (size 0x00000120).
func (*AuthState) PlayFabClient() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*AuthState).PrepareDialer recovered at 0x0000000001d57e00 (size 0x000002e0).
func (*AuthState) PrepareDialer() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*AuthState).RealmsClient recovered at 0x0000000001d594a0 (size 0x000003c0).
func (*AuthState) RealmsClient() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*AuthState).ServicePlayFabClient recovered at 0x0000000001d56da0 (size 0x00000120).
func (*AuthState) ServicePlayFabClient() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*AuthState).ServiceTokenSource recovered at 0x0000000001d57760 (size 0x00000120).
func (*AuthState) ServiceTokenSource() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*AuthState).SetHTTPClient recovered at 0x0000000001d589a0 (size 0x00000240).
func (*AuthState) SetHTTPClient() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*AuthState).SetTokenSource recovered at 0x0000000001d58f40 (size 0x00000120).
func (*AuthState) SetTokenSource() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*AuthState).TokenSource recovered at 0x0000000001d58e20 (size 0x000000e0).
func (*AuthState) TokenSource() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*AuthState).XSAPIClient recovered at 0x0000000001d55bc0 (size 0x00000100).
func (*AuthState) XSAPIClient() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*AuthState).resetXBLTokenCacheLocked recovered at 0x0000000001d583e0 (size 0x00000200).
func (*AuthState) resetXBLTokenCacheLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*AuthState).serviceAuth recovered at 0x0000000001d57c80 (size 0x000000c0).
func (*AuthState) serviceAuth() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*AuthState).snapshotLocked recovered at 0x0000000001d55760 (size 0x00000460).
func (*AuthState) snapshotLocked() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*ConnectTarget).Normalize recovered at 0x0000000001d79100 (size 0x000005e0).
func (*ConnectTarget) Normalize() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*FriendWorld).Join recovered at 0x0000000001d5e340 (size 0x000001a0).
func (*FriendWorld) Join() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*Logger).WriteData recovered at 0x0000000001d60b60 (size 0x00000100).
func (*Logger) WriteData() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*Logger).write recovered at 0x0000000001d61420 (size 0x000001c0).
func (*Logger) write() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*analyticsClient).EndSession recovered at 0x0000000001d4c4e0 (size 0x00000080).
func (*analyticsClient) EndSession() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*analyticsClient).Flush recovered at 0x0000000001d4cc20 (size 0x000001a0).
func (*analyticsClient) Flush() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*analyticsClient).SetClientInfo recovered at 0x0000000001d4b660 (size 0x00000160).
func (*analyticsClient) SetClientInfo() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*analyticsClient).SetEnabled recovered at 0x0000000001d4b4a0 (size 0x00000140).
func (*analyticsClient) SetEnabled() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*analyticsClient).StartSession recovered at 0x0000000001d4b940 (size 0x00000ae0).
func (*analyticsClient) StartSession() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*analyticsClient).clientInfo recovered at 0x0000000001d4b800 (size 0x00000100).
func (*analyticsClient) clientInfo() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*analyticsClient).enqueueForSession recovered at 0x0000000001d4d320 (size 0x00000500).
func (*analyticsClient) enqueueForSession() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*analyticsClient).finishSession recovered at 0x0000000001d4c560 (size 0x00000640).
func (*analyticsClient) finishSession() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*analyticsClient).runSession recovered at 0x0000000001d4d020 (size 0x00000280).
func (*analyticsClient) runSession() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*analyticsClient).send recovered at 0x0000000001d4cdc0 (size 0x00000260).
func (*analyticsClient) send() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*contextCancelRoundTripper).RoundTrip recovered at 0x0000000001d520c0 (size 0x00000260).
func (*contextCancelRoundTripper) RoundTrip() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*debugHTTPRoundTripper).RoundTrip recovered at 0x0000000001d5f780 (size 0x00000720).
func (*debugHTTPRoundTripper) RoundTrip() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*errorWriter).Write recovered at 0x0000000001d5a1e0 (size 0x000000a0).
func (*errorWriter) Write() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*httpAnalyticsTransport).SendAnalyticsEvents recovered at 0x0000000001d4ac60 (size 0x00000560).
func (*httpAnalyticsTransport) SendAnalyticsEvents() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*lunarStatusProvider).ServerStatus recovered at 0x0000000001d79e60 (size 0x00000080).
func (*lunarStatusProvider) ServerStatus() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*minecraftDialTokenSource).MultiplayerToken recovered at 0x0000000001d556a0 (size 0x000000c0).
func (*minecraftDialTokenSource) MultiplayerToken() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*minecraftDialTokenSource).Token recovered at 0x0000000001d7d040 (size 0x00000080).
func (*minecraftDialTokenSource) Token() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*nethernetTransport).SetWebRTCAPI recovered at 0x0000000001d705e0 (size 0x00000060).
func (*nethernetTransport) SetWebRTCAPI() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*nethernetTransport).network recovered at 0x0000000001d707c0 (size 0x000001a0).
func (*nethernetTransport) network() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*nethernetTransport).newLANSignaling recovered at 0x0000000001d70f60 (size 0x000001c0).
func (*nethernetTransport) newLANSignaling() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*nethernetTransport).register recovered at 0x0000000001d70640 (size 0x000000c0).
func (*nethernetTransport) register() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*redirectProxy).active recovered at 0x0000000001d74720 (size 0x000000c0).
func (*redirectProxy) active() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*redirectProxy).start recovered at 0x0000000001d74820 (size 0x00000c40).
func (*redirectProxy) start() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*redirectProxy).stop recovered at 0x0000000001d758e0 (size 0x000005e0).
func (*redirectProxy) stop() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*releaseOnCloseBody).Close recovered at 0x0000000001d52360 (size 0x00000080).
func (*releaseOnCloseBody) Close() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*releaseOnCloseBody).Read recovered at 0x0000000001d7cec0 (size 0x00000080).
func (*releaseOnCloseBody) Read() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*retryAuthHTTPRoundTripper).RoundTrip recovered at 0x0000000001d582c0 (size 0x00000120).
func (*retryAuthHTTPRoundTripper) RoundTrip() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*socks5RakNetDialer).DialContext recovered at 0x0000000001d713c0 (size 0x000002c0).
func (*socks5RakNetDialer) DialContext() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar.(*upstreamConnectError).Error recovered at 0x0000000001d7a2a0 (size 0x00000020).
func (*upstreamConnectError) Error() string {
	return ""
}

// github.com/lunar-bedrock/lunar/lunar.(*upstreamConnectError).Unwrap recovered at 0x0000000001d7a2c0 (size 0x00000020).
func (*upstreamConnectError) Unwrap() error {
	return nil
}

// github.com/lunar-bedrock/lunar/lunar.(*upstreamDialPhaseError).Error recovered at 0x0000000001d7a220 (size 0x00000060).
func (*upstreamDialPhaseError) Error() string {
	return ""
}

// github.com/lunar-bedrock/lunar/lunar.(*upstreamDialPhaseError).Unwrap recovered at 0x0000000001d7a280 (size 0x00000020).
func (*upstreamDialPhaseError) Unwrap() error {
	return nil
}
