// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package serverinfo

// Placeholder receiver types (no equality descriptor in pclntab).

type Type struct{}

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// DetectFromAddress recovered at 0x0000000001b9f4e0 (size 0x00000260).
func DetectFromAddress() {
	panic("stub")
}

// DetectFromWorldID recovered at 0x0000000001b9f460 (size 0x00000080).
func DetectFromWorldID() {
	panic("stub")
}

// init recovered at 0x0000000001b9edc0 (size 0x00000060).
func init() {
	panic("stub")
}

// splitAddress recovered at 0x0000000001b9f740 (size 0x00000180).
func splitAddress() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/serverinfo.(*Type).Contains recovered at 0x0000000001b9ee20 (size 0x00000020).
func (*Type) Contains() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/serverinfo.(*Type).DisplayName recovered at 0x0000000001b9f040 (size 0x000003c0).
func (*Type) DisplayName() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/serverinfo.(*Type).List recovered at 0x0000000001b9ee40 (size 0x00000100).
func (*Type) List() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/serverinfo.(*Type).MarshalText recovered at 0x0000000001b9f400 (size 0x00000060).
func (*Type) MarshalText() ([]byte, error) {
	return nil, nil
}

// github.com/lunar-bedrock/lunar/lunar/serverinfo.(*Type).String recovered at 0x0000000001b9ef40 (size 0x00000100).
func (*Type) String() string {
	return ""
}
