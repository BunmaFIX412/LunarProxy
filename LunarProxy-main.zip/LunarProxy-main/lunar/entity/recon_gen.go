// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package entity

// Recovered types (from pclntab type descriptors).

// Actions is a recovered type.
type Actions struct{}

// Placeholder receiver types (no equality descriptor in pclntab).

type Entity struct{}

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// New recovered at 0x00000000019a0600 (size 0x000003e0).
func New() {
	panic("stub")
}

// init recovered at 0x00000000019a0160 (size 0x00000080).
func init() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Actions).Blocking recovered at 0x00000000019a05e0 (size 0x00000020).
func (*Actions) Blocking() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Actions).ClientMoving recovered at 0x00000000019a02e0 (size 0x00000020).
func (*Actions) ClientMoving() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Actions).Crawling recovered at 0x00000000019a0520 (size 0x00000020).
func (*Actions) Crawling() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Actions).Falling recovered at 0x00000000019a0280 (size 0x00000020).
func (*Actions) Falling() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Actions).Flying recovered at 0x00000000019a04c0 (size 0x00000020).
func (*Actions) Flying() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Actions).Gliding recovered at 0x00000000019a0460 (size 0x00000020).
func (*Actions) Gliding() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Actions).Jumping recovered at 0x00000000019a0220 (size 0x00000020).
func (*Actions) Jumping() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Actions).SetBlocking recovered at 0x00000000019a05a0 (size 0x00000040).
func (*Actions) SetBlocking() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Actions).SetClientMoving recovered at 0x00000000019a02a0 (size 0x00000040).
func (*Actions) SetClientMoving() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Actions).SetCrawling recovered at 0x00000000019a04e0 (size 0x00000040).
func (*Actions) SetCrawling() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Actions).SetFalling recovered at 0x00000000019a0240 (size 0x00000040).
func (*Actions) SetFalling() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Actions).SetFlying recovered at 0x00000000019a0480 (size 0x00000040).
func (*Actions) SetFlying() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Actions).SetGliding recovered at 0x00000000019a0420 (size 0x00000040).
func (*Actions) SetGliding() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Actions).SetJumping recovered at 0x00000000019a01e0 (size 0x00000040).
func (*Actions) SetJumping() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Actions).SetSneaking recovered at 0x00000000019a0300 (size 0x00000040).
func (*Actions) SetSneaking() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Actions).SetSpinAttack recovered at 0x00000000019a0540 (size 0x00000040).
func (*Actions) SetSpinAttack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Actions).SetSprinting recovered at 0x00000000019a0360 (size 0x00000040).
func (*Actions) SetSprinting() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Actions).SetSwimming recovered at 0x00000000019a03c0 (size 0x00000040).
func (*Actions) SetSwimming() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Actions).Sneaking recovered at 0x00000000019a0340 (size 0x00000020).
func (*Actions) Sneaking() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Actions).SpinAttack recovered at 0x00000000019a0580 (size 0x00000020).
func (*Actions) SpinAttack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Actions).Sprinting recovered at 0x00000000019a03a0 (size 0x00000020).
func (*Actions) Sprinting() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Actions).Swimming recovered at 0x00000000019a0400 (size 0x00000020).
func (*Actions) Swimming() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).BBox recovered at 0x00000000019a0c00 (size 0x00000040).
func (*Entity) BBox() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).Blocking recovered at 0x00000000019a3420 (size 0x00000020).
func (*Entity) Blocking() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).ClientMoving recovered at 0x00000000019a3440 (size 0x00000020).
func (*Entity) ClientMoving() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).Crawling recovered at 0x00000000019a3460 (size 0x00000020).
func (*Entity) Crawling() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).Dead recovered at 0x00000000019a2f80 (size 0x00000020).
func (*Entity) Dead() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).DirectionVector recovered at 0x00000000019a1360 (size 0x00000040).
func (*Entity) DirectionVector() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).DistanceFrom recovered at 0x00000000019a13a0 (size 0x000000e0).
func (*Entity) DistanceFrom() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).EyeHeight recovered at 0x00000000019a1160 (size 0x00000080).
func (*Entity) EyeHeight() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).EyePosition recovered at 0x00000000019a0fe0 (size 0x000000c0).
func (*Entity) EyePosition() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).EyePosition32 recovered at 0x00000000019a10a0 (size 0x000000c0).
func (*Entity) EyePosition32() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).Falling recovered at 0x00000000019a3480 (size 0x00000020).
func (*Entity) Falling() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).Flying recovered at 0x00000000019a34a0 (size 0x00000020).
func (*Entity) Flying() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).GameType recovered at 0x00000000019a2580 (size 0x00000020).
func (*Entity) GameType() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).Gliding recovered at 0x00000000019a34c0 (size 0x00000020).
func (*Entity) Gliding() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).HealthInfo recovered at 0x00000000019a2d20 (size 0x00000220).
func (*Entity) HealthInfo() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).HeldItem recovered at 0x00000000019a0a00 (size 0x00000080).
func (*Entity) HeldItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).InPlayerList recovered at 0x00000000019a2fe0 (size 0x00000020).
func (*Entity) InPlayerList() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).Initialize recovered at 0x00000000019a09e0 (size 0x00000020).
func (*Entity) Initialize() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).Jumping recovered at 0x00000000019a34e0 (size 0x00000020).
func (*Entity) Jumping() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).MergeAttributes recovered at 0x00000000019a2980 (size 0x00000360).
func (*Entity) MergeAttributes() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).Metadata recovered at 0x00000000019a1540 (size 0x00000280).
func (*Entity) Metadata() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).Owner recovered at 0x00000000019a1980 (size 0x00000120).
func (*Entity) Owner() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).Player recovered at 0x00000000019a2fc0 (size 0x00000020).
func (*Entity) Player() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).Position recovered at 0x00000000019a0f40 (size 0x000000a0).
func (*Entity) Position() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).Position32 recovered at 0x00000000019a0f00 (size 0x00000040).
func (*Entity) Position32() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).Properties recovered at 0x00000000019a2400 (size 0x00000080).
func (*Entity) Properties() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).Rotation recovered at 0x00000000019a1320 (size 0x00000040).
func (*Entity) Rotation() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).ServerBBox recovered at 0x00000000019a0b40 (size 0x00000040).
func (*Entity) ServerBBox() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).SetAttributeValues recovered at 0x00000000019a25c0 (size 0x00000380).
func (*Entity) SetAttributeValues() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).SetBBox recovered at 0x00000000019a0c40 (size 0x00000080).
func (*Entity) SetBBox() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).SetBlocking recovered at 0x00000000019a3500 (size 0x00000040).
func (*Entity) SetBlocking() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).SetClientMoving recovered at 0x00000000019a3540 (size 0x00000040).
func (*Entity) SetClientMoving() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).SetCrawling recovered at 0x00000000019a3580 (size 0x00000040).
func (*Entity) SetCrawling() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).SetDead recovered at 0x00000000019a2fa0 (size 0x00000020).
func (*Entity) SetDead() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).SetFalling recovered at 0x00000000019a35c0 (size 0x00000040).
func (*Entity) SetFalling() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).SetFlying recovered at 0x00000000019a3600 (size 0x00000040).
func (*Entity) SetFlying() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).SetGameType recovered at 0x00000000019a25a0 (size 0x00000020).
func (*Entity) SetGameType() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).SetGliding recovered at 0x00000000019a3640 (size 0x00000040).
func (*Entity) SetGliding() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).SetHeldItem recovered at 0x00000000019a0a80 (size 0x000000c0).
func (*Entity) SetHeldItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).SetInPlayerList recovered at 0x00000000019a3000 (size 0x00000020).
func (*Entity) SetInPlayerList() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).SetJumping recovered at 0x00000000019a3680 (size 0x00000040).
func (*Entity) SetJumping() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).SetMetadata recovered at 0x00000000019a1e20 (size 0x00000260).
func (*Entity) SetMetadata() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).SetPosition recovered at 0x00000000019a0cc0 (size 0x00000160).
func (*Entity) SetPosition() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).SetProperties recovered at 0x00000000019a2480 (size 0x00000100).
func (*Entity) SetProperties() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).SetRotation recovered at 0x00000000019a11e0 (size 0x00000140).
func (*Entity) SetRotation() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).SetServerBBox recovered at 0x00000000019a0b80 (size 0x00000080).
func (*Entity) SetServerBBox() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).SetSneaking recovered at 0x00000000019a36c0 (size 0x00000040).
func (*Entity) SetSneaking() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).SetSpinAttack recovered at 0x00000000019a3700 (size 0x00000040).
func (*Entity) SetSpinAttack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).SetSprinting recovered at 0x00000000019a3740 (size 0x00000040).
func (*Entity) SetSprinting() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).SetSwimming recovered at 0x00000000019a3780 (size 0x00000040).
func (*Entity) SetSwimming() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).Sneaking recovered at 0x00000000019a37c0 (size 0x00000020).
func (*Entity) Sneaking() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).SpinAttack recovered at 0x00000000019a37e0 (size 0x00000020).
func (*Entity) SpinAttack() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).Sprinting recovered at 0x00000000019a3800 (size 0x00000020).
func (*Entity) Sprinting() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).Swimming recovered at 0x00000000019a3820 (size 0x00000020).
func (*Entity) Swimming() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).UpdateMetadata recovered at 0x00000000019a1ae0 (size 0x00000300).
func (*Entity) UpdateMetadata() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).Variant recovered at 0x00000000019a1800 (size 0x00000140).
func (*Entity) Variant() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).Velocity recovered at 0x00000000019a0e60 (size 0x000000a0).
func (*Entity) Velocity() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).Velocity32 recovered at 0x00000000019a0e20 (size 0x00000040).
func (*Entity) Velocity32() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).WithinDistance recovered at 0x00000000019a1480 (size 0x000000c0).
func (*Entity) WithinDistance() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/entity.(*Entity).syncActionFlagsFromMetadata recovered at 0x00000000019a2080 (size 0x00000380).
func (*Entity) syncActionFlagsFromMetadata() {
	panic("stub")
}
