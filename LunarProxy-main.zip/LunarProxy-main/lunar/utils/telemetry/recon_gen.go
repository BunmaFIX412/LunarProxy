// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package telemetry

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// CaptureError recovered at 0x0000000001d34200 (size 0x000000e0).
func CaptureError() {
	panic("stub")
}
