// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package utils

// Recovered types (from pclntab type descriptors).

// PanicInfo is a recovered type.
type PanicInfo struct{}

// Placeholder receiver types (no equality descriptor in pclntab).

type Changelog struct{}

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// CatchPanic recovered at 0x00000000016d0ec0 (size 0x00000120).
func CatchPanic() {
	panic("stub")
}

// CatchPanicFn recovered at 0x00000000016d0fe0 (size 0x000000c0).
func CatchPanicFn() {
	panic("stub")
}

// CatchPlayer recovered at 0x00000000016d10a0 (size 0x000000a0).
func CatchPlayer() {
	panic("stub")
}

// LogPanic recovered at 0x00000000016d0e60 (size 0x00000060).
func LogPanic() {
	panic("stub")
}

// LogPanicFn recovered at 0x00000000016d0e00 (size 0x00000060).
func LogPanicFn() {
	panic("stub")
}

// RandomDeviceModel recovered at 0x00000000016d0c80 (size 0x000000e0).
func RandomDeviceModel() {
	panic("stub")
}

// SetPanicReporter recovered at 0x00000000016d0d60 (size 0x000000a0).
func SetPanicReporter() {
	panic("stub")
}

// SleepContext recovered at 0x00000000016d1980 (size 0x00000100).
func SleepContext() {
	panic("stub")
}

// asError recovered at 0x00000000016d1860 (size 0x00000120).
func asError() {
	panic("stub")
}

// captureStack recovered at 0x00000000016d1740 (size 0x00000120).
func captureStack() {
	panic("stub")
}

// handlePanic recovered at 0x00000000016d1340 (size 0x00000280).
func handlePanic() {
	panic("stub")
}

// init recovered at 0x00000000016cf640 (size 0x00000100).
func init() {
	panic("stub")
}

// init.0 recovered at 0x00000000016d0320 (size 0x000000e0).
func init_0() {
	panic("stub")
}

// loadChangelog recovered at 0x00000000016d0400 (size 0x00000160).
func loadChangelog() {
	panic("stub")
}

// map.init.0 recovered at 0x00000000016cf740 (size 0x00000220).
func map_init_0() {
	panic("stub")
}

// map.init.1 recovered at 0x00000000016cf960 (size 0x000009c0).
func map_init_1() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/utils.(*Changelog).FormatLastEntry recovered at 0x00000000016d0680 (size 0x00000600).
func (*Changelog) FormatLastEntry() {
	panic("stub")
}
