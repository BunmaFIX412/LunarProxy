// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package data

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// GetFile recovered at 0x0000000001b784c0 (size 0x00000140).
func GetFile() {
	panic("stub")
}

// GetFileBytes recovered at 0x0000000001b78600 (size 0x00000140).
func GetFileBytes() {
	panic("stub")
}
