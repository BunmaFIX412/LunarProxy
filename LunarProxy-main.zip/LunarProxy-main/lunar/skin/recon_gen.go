// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package skin

// Recovered types (from pclntab type descriptors).

// geometryDescription is a recovered type.
type geometryDescription struct{}

// geometryEntry is a recovered type.
type geometryEntry struct{}

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// FromFiles recovered at 0x0000000001d47aa0 (size 0x00000920).
func FromFiles() {
	panic("stub")
}

// capeFromFile recovered at 0x0000000001d48de0 (size 0x00000240).
func capeFromFile() {
	panic("stub")
}

// defaultGeometryIdentifier recovered at 0x0000000001d49da0 (size 0x00000220).
func defaultGeometryIdentifier() {
	panic("stub")
}

// defaultModel recovered at 0x0000000001d495e0 (size 0x000001e0).
func defaultModel() {
	panic("stub")
}

// defaultModelJSONForSize recovered at 0x0000000001d497c0 (size 0x000005e0).
func defaultModelJSONForSize() {
	panic("stub")
}

// newSkin recovered at 0x0000000001d4a640 (size 0x00000440).
func newSkin() {
	panic("stub")
}

// parseTextureFile recovered at 0x0000000001d483c0 (size 0x00000660).
func parseTextureFile() {
	panic("stub")
}

// readCape recovered at 0x0000000001d49060 (size 0x00000380).
func readCape() {
	panic("stub")
}

// readModelWithDefault recovered at 0x0000000001d49fc0 (size 0x00000420).
func readModelWithDefault() {
	panic("stub")
}

// readTexture recovered at 0x0000000001d48a60 (size 0x00000380).
func readTexture() {
	panic("stub")
}

// rgbaPixels recovered at 0x0000000001d493e0 (size 0x00000200).
func rgbaPixels() {
	panic("stub")
}

// selectGeometry recovered at 0x0000000001d4a3e0 (size 0x00000260).
func selectGeometry() {
	panic("stub")
}
