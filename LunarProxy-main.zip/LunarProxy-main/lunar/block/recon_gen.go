// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package block

// Placeholder receiver types (no equality descriptor in pclntab).

type RespawnAnchor struct{}

type XrayMask struct{}

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// CopperChestNames recovered at 0x0000000001b64e80 (size 0x00000340).
func CopperChestNames() {
	panic("stub")
}

// ShulkerBoxNames recovered at 0x0000000001b64bc0 (size 0x000002c0).
func ShulkerBoxNames() {
	panic("stub")
}

// init recovered at 0x0000000001b64b80 (size 0x00000040).
func init() {
	panic("stub")
}

// init.0 recovered at 0x0000000001b651c0 (size 0x00000080).
func init_0() {
	panic("stub")
}

// init.1 recovered at 0x0000000001b65240 (size 0x000000a0).
func init_1() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/block.(*RespawnAnchor).Color recovered at 0x0000000001b65400 (size 0x00000020).
func (*RespawnAnchor) Color() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/block.(*RespawnAnchor).EncodeBlock recovered at 0x0000000001b652e0 (size 0x000000c0).
func (*RespawnAnchor) EncodeBlock() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/block.(*RespawnAnchor).EncodeItem recovered at 0x0000000001b653e0 (size 0x00000020).
func (*RespawnAnchor) EncodeItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/block.(*RespawnAnchor).Hash recovered at 0x0000000001b653a0 (size 0x00000020).
func (*RespawnAnchor) Hash() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/block.(*RespawnAnchor).Model recovered at 0x0000000001b653c0 (size 0x00000020).
func (*RespawnAnchor) Model() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/block.(*XrayMask).BreakInfo recovered at 0x0000000001b65a00 (size 0x00000060).
func (*XrayMask) BreakInfo() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/block.(*XrayMask).CanonicalIdentifier recovered at 0x0000000001b654a0 (size 0x00000080).
func (*XrayMask) CanonicalIdentifier() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/block.(*XrayMask).Category recovered at 0x0000000001b65720 (size 0x00000020).
func (*XrayMask) Category() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/block.(*XrayMask).EncodeBlock recovered at 0x0000000001b65420 (size 0x00000080).
func (*XrayMask) EncodeBlock() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/block.(*XrayMask).EncodeItem recovered at 0x0000000001b65520 (size 0x00000080).
func (*XrayMask) EncodeItem() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/block.(*XrayMask).Hash recovered at 0x0000000001b65740 (size 0x00000020).
func (*XrayMask) Hash() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/block.(*XrayMask).Model recovered at 0x0000000001b65760 (size 0x00000020).
func (*XrayMask) Model() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/block.(*XrayMask).Name recovered at 0x0000000001b655a0 (size 0x00000080).
func (*XrayMask) Name() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/block.(*XrayMask).Properties recovered at 0x0000000001b65780 (size 0x00000280).
func (*XrayMask) Properties() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/block.(*XrayMask).Sound recovered at 0x0000000001b65c00 (size 0x00000080).
func (*XrayMask) Sound() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/block.(*XrayMask).Tags recovered at 0x0000000001b65ae0 (size 0x00000120).
func (*XrayMask) Tags() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/block.(*XrayMask).Texture recovered at 0x0000000001b65620 (size 0x00000100).
func (*XrayMask) Texture() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/block.(*XrayMask).TextureName recovered at 0x0000000001b65a60 (size 0x00000080).
func (*XrayMask) TextureName() {
	panic("stub")
}
