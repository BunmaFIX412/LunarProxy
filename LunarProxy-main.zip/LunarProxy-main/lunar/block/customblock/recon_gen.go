// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.
// Recovered from reconstruction/go/go_funcs.txt: 3643 functions/methods and 264 types.


package customblock

// Placeholder receiver types (no equality descriptor in pclntab).

type Palette struct{}

// Recovered functions and methods (signature-level stubs; bodies require disassembly).

// All recovered at 0x0000000001b62e40 (size 0x000001a0).
func All() {
	panic("stub")
}

// AppendBlockEntries recovered at 0x0000000001b63660 (size 0x00000600).
func AppendBlockEntries() {
	panic("stub")
}

// AppendItemEntries recovered at 0x0000000001b644a0 (size 0x000006e0).
func AppendItemEntries() {
	panic("stub")
}

// NewPalette recovered at 0x0000000001b63220 (size 0x00000280).
func NewPalette() {
	panic("stub")
}

// Register recovered at 0x0000000001b62c80 (size 0x00000180).
func Register() {
	panic("stub")
}

// Registered recovered at 0x0000000001b63020 (size 0x000001c0).
func Registered() {
	panic("stub")
}

// ValidateTrailing recovered at 0x0000000001b63e00 (size 0x00000540).
func ValidateTrailing() {
	panic("stub")
}

// ValidateTrailing-range1 recovered at 0x0000000001b64340 (size 0x00000080).
func ValidateTrailing_range1() {
	panic("stub")
}

// blockEntry recovered at 0x0000000001b63c60 (size 0x000001a0).
func blockEntry() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/block/customblock.(*Palette).Definitions recovered at 0x0000000001b634c0 (size 0x00000100).
func (*Palette) Definitions() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/block/customblock.(*Palette).Registry recovered at 0x0000000001b634a0 (size 0x00000020).
func (*Palette) Registry() {
	panic("stub")
}

// github.com/lunar-bedrock/lunar/lunar/block/customblock.(*Palette).RuntimeID recovered at 0x0000000001b635c0 (size 0x000000a0).
func (*Palette) RuntimeID() {
	panic("stub")
}
