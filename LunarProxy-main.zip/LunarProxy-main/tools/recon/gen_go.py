import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.normpath(os.path.join(HERE, "..", "..", "..", "go", "go_funcs.txt"))
OUT = os.path.normpath(os.path.join(HERE, "..", ".."))
MODULE = "github.com/lunar-bedrock/lunar"

KEYWORDS = {"break","case","chan","const","continue","default","defer","else","fallthrough","for","func","go","goto","if","import","interface","map","package","range","return","select","struct","switch","type","var"}

def sanitize(name):
    n = re.sub(r"[^A-Za-z0-9_]", "_", name)
    if not n or n[0].isdigit():
        n = "_" + n
    if n in KEYWORDS:
        n = "_" + n
    return n

def split_generic_suffix(sym):
    i = sym.find("[")
    if i < 0:
        return sym, ""
    depth = 0
    for j in range(i, len(sym)):
        if sym[j] == "[":
            depth += 1
        elif sym[j] == "]":
            depth -= 1
            if depth == 0:
                return sym[:i], sym[j + 1:]
    return sym[:i], ""

def split_pkg(name):
    if name.startswith("type:.eq."):
        name = name[len("type:.eq."):]
    d = name.find(".", len(MODULE) + 1)
    if d > 0:
        return name[:d], name[d + 1:]
    return name, ""

def parse_bind(path):
    types = set()
    funcs = set()
    methods = set()
    text = open(path, encoding="utf-8").read()
    for m in re.finditer(r"^type\s+(\w+)", text, re.M):
        types.add(m.group(1))
    for m in re.finditer(r"^func\s+(\w+)", text, re.M):
        funcs.add(m.group(1))
    for m in re.finditer(r"^func\s+\(\s*(?:[A-Za-z0-9_]+\s+)?\*?\s*([A-Za-z0-9_]+)\s*\)\s+([A-Za-z0-9_]+)", text, re.M):
        methods.add((m.group(1), m.group(2)))
    return types, funcs, methods

ROOT_PKG = MODULE + "/lunar"
bind_types, bind_funcs, bind_methods = parse_bind(os.path.join(OUT, "lunar", "bind.go"))

raw = []
for line in open(SRC, encoding="utf-8"):
    m = re.match(r"^([0-9a-f]{16}) ([0-9a-f]{8}) (.*)$", line.strip())
    if m:
        raw.append((m.group(1), m.group(2), m.group(3)))

parens_methods = {}
for addr, size, name in raw:
    if not name.startswith(MODULE + "/") or name.startswith("type:.eq."):
        continue
    pkg, sym = split_pkg(name)
    rm = re.match(r"\((.*?)\)\.([A-Za-z0-9_]+)", sym)
    if rm:
        recv, method = rm.group(1), rm.group(2)
        parens_methods.setdefault((pkg, recv.lstrip("*"), method), recv)

types = {}
entries = []
seen = set()
for addr, size, name in raw:
    if name.startswith("type:.eq."):
        inner = name[len("type:.eq."):]
        if not inner.startswith(MODULE + "/"):
            continue
        pkg, sym = split_pkg(inner)
        t, _ = split_generic_suffix(sym)
        if not t:
            continue
        if pkg == ROOT_PKG and t in bind_types:
            continue
        types.setdefault(pkg, set()).add(t)
        continue
    if not name.startswith(MODULE + "/"):
        continue
    pkg, sym = split_pkg(name)
    if not sym:
        continue
    base, rest = split_generic_suffix(sym)
    if rest.startswith("."):
        mm = re.match(r"^\.([A-Za-z0-9_]+)", rest)
        if mm and not mm.group(1).startswith(("func", "gowrap", "deferwrap")):
            recv, method = base, mm.group(1)
            key = ("m", pkg, recv, method)
            if key in seen:
                continue
            seen.add(key)
            if pkg == ROOT_PKG and (recv, method) in bind_methods:
                continue
            entries.append((pkg, "method", recv, method, addr, size))
            continue
    rm = re.match(r"\((.*?)\)\.([A-Za-z0-9_]+)", sym)
    if rm:
        recv, method = rm.group(1), rm.group(2)
        key = ("m", pkg, recv, method)
        if key in seen:
            continue
        seen.add(key)
        if pkg == ROOT_PKG and (recv.lstrip("*"), method) in bind_methods:
            continue
        entries.append((pkg, "method", recv, method, addr, size))
        continue
    nm = re.match(r"^([A-Za-z0-9_]+)\.([A-Za-z0-9_]+)", sym)
    if nm:
        tname, mname = nm.group(1), nm.group(2)
        known = parens_methods.get((pkg, tname, mname))
        if known:
            key = ("m", pkg, known, mname)
            if key in seen:
                continue
            seen.add(key)
            if pkg == ROOT_PKG and (known.lstrip("*"), mname) in bind_methods:
                continue
            entries.append((pkg, "method", known, mname, addr, size))
            continue
        if mname.startswith(("func", "gowrap", "deferwrap")):
            key = ("f", pkg, tname)
            if key in seen:
                continue
            seen.add(key)
            if pkg == ROOT_PKG and tname in bind_funcs:
                continue
            entries.append((pkg, "func", None, tname, addr, size))
            continue
        key = ("f", pkg, sym)
        if key in seen:
            continue
        seen.add(key)
        if pkg == ROOT_PKG and sym in bind_funcs:
            continue
        entries.append((pkg, "func", None, sym, addr, size))
        continue
    key = ("f", pkg, base)
    if key in seen:
        continue
    seen.add(key)
    if pkg == ROOT_PKG and base in bind_funcs:
        continue
    entries.append((pkg, "func", None, base, addr, size))

pkgs = sorted(set(e[0] for e in entries) | set(types))
print("packages:", len(pkgs), "symbols:", len(entries), "types:", sum(len(v) for v in types.values()))

HEADER = ("// Code generated from libgojni.so pclntab reconstruction (Go 1.26.2 toolchain recovery). DO NOT EDIT.\n"
          "// Recovered from reconstruction/go/go_funcs.txt: %d functions/methods and %d types.\n")

for pkg in pkgs:
    d = os.path.join(OUT, pkg[len(MODULE):].lstrip("/"))
    os.makedirs(d, exist_ok=True)
    pkgname = sanitize(os.path.basename(pkg))
    pkg_entries = sorted((e for e in entries if e[0] == pkg), key=lambda e: (e[1], e[2], e[3]))
    func_names = {e[3] for e in pkg_entries if e[1] == "func"}
    pkg_types = sorted(t for t in types.get(pkg, set()) if t not in func_names)
    lines = [HEADER % (len(entries), sum(len(v) for v in types.values())), "", "package " + pkgname, ""]
    if pkg_types:
        lines.append("// Recovered types (from pclntab type descriptors).")
        for t in pkg_types:
            lines.append("")
            lines.append("// " + t + " is a recovered type.")
            lines.append("type " + sanitize(t) + " struct{}")
        lines.append("")
    recv_types = set()
    for p, kind, recv, sym, addr, size in pkg_entries:
        if kind == "method":
            recv_types.add(sanitize(recv.lstrip("*")))
    defined = {sanitize(t) for t in pkg_types}
    if pkg == ROOT_PKG:
        defined |= bind_types
    extra = sorted(recv_types - defined)
    if extra:
        lines.append("// Placeholder receiver types (no equality descriptor in pclntab).")
        for t in extra:
            lines.append("")
            lines.append("type " + t + " struct{}")
        lines.append("")
    if pkg_entries:
        lines.append("// Recovered functions and methods (signature-level stubs; bodies require disassembly).")
    SIGS = {
        "MarshalJSON": (["() ([]byte, error)"], "\treturn nil, nil"),
        "UnmarshalJSON": (["(b []byte) error"], "\treturn nil"),
        "MarshalText": (["() ([]byte, error)"], "\treturn nil, nil"),
        "UnmarshalText": (["(b []byte) error"], "\treturn nil"),
        "Unwrap": (["() error"], "\treturn nil"),
        "String": (["() string"], "\treturn \"\""),
        "Error": (["() string"], "\treturn \"\""),
        "GoString": (["() string"], "\treturn \"\""),
    }
    for p, kind, recv, sym, addr, size in pkg_entries:
        if kind == "method":
            t = sanitize(recv.lstrip("*"))
            recvdecl = "*" + t if recv.startswith("*") else t
            name = sanitize(sym)
            sig = SIGS.get(name)
            lines.append("")
            lines.append("// %s.(%s).%s recovered at 0x%s (size 0x%s)." % (p, recv, sym, addr, size))
            if sig:
                lines.append("func (%s) %s%s {" % (recvdecl, name, sig[0][0]))
                lines.append(sig[1])
                lines.append("}")
            else:
                lines.append("func (%s) %s() {" % (recvdecl, name))
                lines.append("\tpanic(\"stub\")")
                lines.append("}")
        else:
            name = sanitize(sym)
            if pkgname != "main" and name == "main":
                name = "main_"
            lines.append("")
            lines.append("// %s recovered at 0x%s (size 0x%s)." % (sym, addr, size))
            lines.append("func %s() {" % name)
            lines.append("\tpanic(\"stub\")")
            lines.append("}")
    with open(os.path.join(d, "recon_gen.go"), "w", encoding="utf-8", newline="\n") as w:
        w.write("\n".join(lines) + "\n")
print("done")